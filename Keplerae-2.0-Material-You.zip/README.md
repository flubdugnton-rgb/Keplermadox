# Kepleræ 2.0 — Material You / Material 3 Expressive

Projeto Android completo para revisar, enviar ao repositório Keplermadox e compilar.
**versionName 2.0.0 · versionCode 21 · pacote com.aistudio.keplerae.stdy**.
O catálogo de 1.022 materiais e o acesso nativo ao Drive da versão 1.2.2 foram
preservados. Não há navegação externa para reproduzir vídeos, áudios ou PDFs.

## O que foi integrado

| Requisito | Implementação |
| --- | --- |
| Tema e tipografia | MaterialExpressiveTheme, cores dinâmicas Android 12+, fallback, claro/escuro, Roboto via Google Fonts com fallback local |
| Login | Ícone definitivo, Kepleræ centralizado, único botão Entrar com Google, rodapé Madox Fênix, vidro com Haze, animação de entrada/toque |
| Início | Gradiente pastel, Kepleræ grande, foto Google com Coil, progresso real, retomada e grade de matérias |
| Perfil | Shared bounds a partir da foto, nome/e-mail da conta, sair, sol/lua sem texto visual, seleção destacada, DataStore |
| Pastas | Shared bounds do cartão/texto e shared element da ilustração, tanto em matérias quanto em subpastas |
| PDF | HorizontalPager, escala/opacidade pelo currentPageOffsetFraction, renderização nativa, pinch zoom e navegação por gesto/botões |
| Áudio | ExoPlayer, lista de faixas, play/pause, anterior/próxima, seek, tempo real, posição salva e velocidade |
| Vídeo | PlayerView/ExoPlayer interno, tela cheia, velocidade, controles existentes e progresso ondulado real |
| Listas | AnimatedVisibility + animateContentSize, drag handle com animação e rolagem nas bordas, ordem salva, ações de acessibilidade |
| Atualização | PullToRefreshBox e LoadingIndicator Expressive; pastas consultam novamente o Drive, catálogo relê o arquivo local |
| Indicadores | LoadingIndicator em loading; Linear/CircularWavyProgressIndicator em progresso, reprodução e buffering |
| Tooltips | RichTooltip manual via TooltipState.show(), ajuda contextual no progresso, organização, áudio e PDF |
| Diálogos | AlertDialog com icon nas configurações do Drive e na confirmação de saída |

O seletor no perfil contém **somente duas imagens nativas**, sol e lua, inspiradas
em Cycle of Vitality. Os nomes dos temas são descrições de acessibilidade, sem
texto visível. O modo automático anterior continua disponível em Aparência.
O DataStore migra somente tema e cores; favoritos, histórico, conclusões e posição
de reprodução anteriores continuam nos respectivos arquivos de preferências.

Os percentuais não são simulados: conclusões vêm do catálogo, download conta bytes
e áudio/vídeo consultam o player. Quando o tamanho/duração não está disponível,
o indicador de carregamento fica indeterminado e o seek fica desabilitado.

A lista de faixas utiliza os arquivos de áudio acessíveis da pasta atual ou os
links diretos de áudio do catálogo. Pastas fechadas não são abertas recursivamente
apenas para preencher uma playlist. Ao escolher outra faixa, ela começa a tocar;
a primeira abertura mantém o comportamento anterior de aguardar Play.

## Dependências e versões

Os arquivos Gradle completos estão no pacote. Não misture versões de Compose nem
adicione kotlinCompilerExtensionVersion: o projeto usa o plugin Kotlin Compose.

| Biblioteca / ferramenta | Versão |
| --- | --- |
| Kotlin + plugin Compose | 2.2.21 |
| Android Gradle Plugin | 8.11.1 |
| Gradle / Java | 8.13 / 17 |
| Compose UI, Animation, Foundation, Runtime e Google Fonts | 1.9.4 |
| Material 3 Expressive | **1.5.0-alpha07** |
| Haze | 1.7.0 |
| Coil Compose + Network OkHttp | 3.3.0 |
| DataStore Preferences | 1.1.7 |
| Reorderable | 2.5.1 |
| Credential Manager + Play Services | 1.6.0 |
| Google ID | 1.1.1 |
| Play Services Auth | 22.0.0 |
| Coroutines Android + Play Services | 1.10.2 |
| Media3 ExoPlayer + UI | 1.8.1 |

A alpha do Material 3 foi autorizada por você. Foi fixada em alpha07, em vez de
seguir automaticamente versões posteriores. LoadingIndicator, wavy indicators
e MaterialExpressiveTheme exigem ExperimentalMaterial3ExpressiveApi. A transição
compartilhada usa ExperimentalSharedTransitionApi. Os opt-ins estão nos arquivos.
**A resolução final de dependências e a compilação ainda precisam rodar no CI.**

minSdk 24, compileSdk/targetSdk 36. Android abaixo do 12 recebe a paleta do logo.
Haze aplica blur onde o aparelho suporta e preenchimento translúcido nos demais;
não forçamos blur em aparelhos que a biblioteca identifica como incompatíveis.
Não atualize Haze para 2.x isoladamente: a API e a base Compose são diferentes.

## Google: configuração antes de gerar o APK

O cliente Android da versão que funcionou continua necessário. O novo botão de
Credential Manager também precisa do **ID OAuth do tipo Aplicativo da Web**, no
mesmo projeto Google Cloud. A aplicação não usa Firebase Auth nem precisa de
google-services.json; a autenticação Google e a autorização do Drive são separadas.

1. No mesmo projeto em que ativou a Drive API, abra Google Auth Platform → Clients
   ou APIs e serviços → Credenciais.
2. Mantenha o cliente OAuth Android com pacote `com.aistudio.keplerae.stdy` e SHA-1
   `16:00:79:01:DB:BF:AB:9D:E7:B5:53:9F:FA:C6:04:FA:F1:9D:BC:8A`.
3. Crie/abra o cliente OAuth do tipo **Aplicativo da Web**. Para este fluxo nativo,
   não precisamos cadastrar origens JavaScript ou URIs de redirecionamento.
4. Copie somente o ID do cliente terminado em `.apps.googleusercontent.com`.
   Não copie client secret, JSON de credenciais ou chave de API.
5. Se o projeto estiver em teste, mantenha a conta como usuário de teste e o escopo
   `https://www.googleapis.com/auth/drive.readonly` na configuração de acesso a dados.
6. Preencha o ID público de uma das formas abaixo.

| Forma | Local |
| --- | --- |
| GitHub Actions | Settings → Secrets and variables → Actions → Variables → New repository variable; nome **GOOGLE_WEB_CLIENT_ID**, valor igual ao ID Web |
| Android Studio | `app/src/main/res/values/google_login.xml`, valor de `google_web_client_id` |

O XML está vazio porque o ID Web não foi fornecido. **Preencha antes de compilar
para distribuição.** O workflow aponta esse requisito e encerra se estiver vazio.
O formato de um cliente Android pode parecer igual: confirme o tipo Web no Google.
A configuração de chave API para materiais públicos continua em Google Drive.

Credential Manager fornece nome, e-mail e foto; AuthorizationClient pede leitura
do Drive na **mesma conta escolhida**. O ID token não é usado como access token.
Tokens não são gravados em perfil, logs ou repositório. O access token é mantido
em memória, como na versão que funcionou. Após encerrar o processo, é necessário
entrar novamente; permissões existentes podem ser reaproveitadas pelo Google.
A rotação mantém a sessão no ViewModel. Uma seleção de conta interrompida permite
uma nova tentativa pelo botão. Um token expirado exige renovar em Google Drive
ou desconectar e entrar novamente; não foi introduzido refresh token persistido.

Desconectar pelo perfil limpa DriveSession e chama clearCredentialState, depois
volta ao login. As concessões da conta no Google não são revogadas. Favoritos,
conclusões, ordem, tema e chave API local permanecem. Não há sessão Firebase para
limpar neste projeto. O acesso ao Drive pode ser reautorizado nas configurações.

## Arquivos: todos completos, prontos para substituir

`CODIGO_COMPLETO.md` reúne Gradle, fontes Kotlin, XMLs, scripts e workflow completos.
Os assets e PNGs ficam nas pastas correspondentes do projeto, dentro deste ZIP.

| Caminho relativo | Responsabilidade |
| --- | --- |
| `app/build.gradle.kts`, `build.gradle.kts`, `settings.gradle.kts` | Versões, dependências e build |
| `app/src/main/java/com/example/MainActivity.kt` | Sessão Google e aplicação global do tema |
| `.../data/auth/GoogleUser.kt`, `GoogleLoginConfiguration.kt`, `GoogleLoginViewModel.kt` | Identidade, autorização e saída |
| `.../data/repository/AppearancePreferences.kt` | DataStore e migração de aparência |
| `.../data/repository/ItemOrder.kt` | Ordenação por ID, mantendo itens ocultos |
| `.../data/repository/StudyViewModel.kt` | Catálogo, favoritos, progresso, tema e ordem |
| `.../ui/theme/Theme.kt`, `Color.kt`, `Type.kt`, `Shape.kt` | Material You, cores, Google Fonts e formas |
| `.../ui/login/LoginScreen.kt`, `LoginRoute.kt` | Tela de vidro e Credential Manager |
| `.../ui/home/HomeScreen.kt` | Início, grade, retomada e cartões compartilhados |
| `.../ui/profile/ProfileScreen.kt`, `ThemeSemantics.kt` | Perfil, foto, tema e saída |
| `.../ui/components/SharedMotion.kt` | Shared element/shared bounds |
| `.../ui/components/SubjectArtwork.kt` | Ilustrações locais das matérias |
| `.../ui/components/ExpressiveComponents.kt` | Refresh, loading e tooltips |
| `.../ui/KepleraeApp.kt` | Navegação, transições e aparência |
| `.../ui/CatalogScreen.kt` | Filtros, pastas, expansão e reordenação |
| `.../ui/NativePdf.kt` | PDF nativo com pager e zoom |
| `.../ui/NativeMedia.kt` | Áudio/vídeo nativos e controles reais |
| `.../ui/DriveViewer.kt`, `DriveConfigDialog.kt` | Visualização interna e consentimento do Drive |
| `app/src/main/res/values/google_login.xml` | ID Web |
| `app/src/main/res/values/font_certs.xml`, `AndroidManifest.xml` | Fontes e permissões existentes |
| `app/src/main/res/drawable-nodpi/keplerae_logo.png`, launcher `mipmap-*` | Ícone definitivo |
| `app/src/debug/java/com/example/ui/DesignPreview.kt` | Previews nativos de início/perfil, tablet e fonte ampliada |
| `app/src/debug/java/com/example/ui/login/LoginPreview.kt`, `ui/theme/ThemePreview.kt` | Previews anteriores de login e tema |
| `app/src/test/java/com/example/ItemOrderTest.kt` | Ordem com filtros, novos/removidos e cabeçalhos |
| `app/src/androidTest/java/com/example/ProfileTest.kt`, `NativePdfPagerTest.kt` | Perfil/tema/saída e gesto em PDF real |
| `app/src/androidTest/java/com/example/DevicePreview.kt` | Capturas reais do emulador no CI |
| `scripts/configure_google_login.py`, `validate_catalog.py`, `validate_network_permissions.py` | Configuração e verificações |
| `.github/workflows/compilar-apk.yml` | Build, assinatura, testes, relatórios e APK |

Nas linhas com `...`, o prefixo é `app/src/main/java/com/example`. O documento
`ARQUIVOS_ALTERADOS.md` contém a lista exata das alterações em relação ao projeto
1.2.2. DriveRepository, DriveRequests, DriveSettings, StudyItem e catálogo continuam
com o conteúdo original; as telas passaram a chamar o mesmo acesso nativo.

## Subir e compilar depois da revisão

1. Configure `GOOGLE_WEB_CLIENT_ID` como descrito acima.
2. Envie **Keplerae-2.0-Material-You.zip**, sem renomear e sem extrair, para a raiz de
   [Keplermadox](https://github.com/flubdugnton-rgb/Keplermadox).
3. Substitua `.github/workflows/compilar-apk.yml` pelo arquivo completo fornecido
   separadamente ou pelo equivalente dentro do ZIP. Não o envie como `.yml.txt`.
4. Abra Actions → **Compilar Keplerae 2.0 - Material You**. Push inicia build e testes;
   Run workflow permite escolher se executa também os testes no emulador.
5. Com sucesso, baixe **Keplerae-2.0-APK**. O arquivo é **Keplerae-2.0.0-debug.apk**.
   O artefato do GitHub é um ZIP: extraia antes de instalar o APK.
6. Consulte **Keplerae-2.0-verificacoes** e **Keplerae-2.0-testes-dispositivo** para
   relatórios e capturas reais do emulador, quando os testes de interface rodarem.

O workflow recupera o cache **keplerae-native-debug-signing-v1** e verifica o SHA-1
existente. Não muda silenciosamente a assinatura: isso preserva atualização e
OAuth do APK que já funcionou. Se o keystore antigo não estiver no cache, o build
pede sua recuperação; não está incluído neste pacote. Uma build local com outra
chave exige outro cliente Android/SHA-1 e não atualiza a instalação anterior.

Com Java 17, Gradle 8.13 e SDK 36 instalados, a mesma validação pode rodar localmente:

```bash
python3 scripts/configure_google_login.py
python3 scripts/validate_catalog.py
python3 scripts/validate_network_permissions.py
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest
gradle --no-daemon :app:connectedDebugAndroidTest
```

Abra o projeto pela pasta raiz no Android Studio. Não é necessário gradlew no CI:
o workflow instala a distribuição Gradle fixada. Há gradle-wrapper.properties
para quem configurar o wrapper pelo Android Studio/Gradle.

## Verificação e limites desta entrega

XMLs, PNGs, catálogo, permissões, scripts e YAML foram verificados localmente.
`VERIFICACAO.json` registra exatamente o que foi executado. **Este ambiente não
possui SDK Android/Gradle: compilação, lint, testes Kotlin e testes no aparelho
não foram executados aqui.** Foram incluídos no workflow. Login real e reprodução
com a conta Google precisam de verificação no dispositivo após a compilação.
O pacote é o código integrado para a revisão da versão 2.0; ainda não é um APK.

Previews no Android Studio e capturas do emulador usam os composables reais.
A imagem de apresentação externa é ilustrativa e não afirma que houve build.

Se a alpha exigir ajustes na compilação, a retirada dos efeitos envolve
`ExpressiveComponents.kt`, `NativeMedia.kt`, `HomeScreen.kt`, `LoginScreen.kt` e
`Theme.kt`: substituir MaterialExpressiveTheme por MaterialTheme, LoadingIndicator
por CircularProgressIndicator, os wavy por progress indicators comuns e usar o
indicator padrão do PullToRefreshBox. Só então trocar a dependência por Material 3
1.4.0 e retirar os opt-ins Expressive. PDF pager e transições pertencem ao Compose,
independentes desses componentes Expressive.

## Referências técnicas primárias

- [Releases Material 3](https://developer.android.com/jetpack/androidx/releases/compose-material3)
- [Transições compartilhadas Compose](https://developer.android.com/develop/ui/compose/animation/shared-elements)
- [Credential Manager Google](https://developer.android.com/identity/sign-in/credential-manager-siwg-implementation)
- [Autorização Google para Drive](https://developer.android.com/identity/authorization)
- [DataStore](https://developer.android.com/topic/libraries/architecture/datastore)
- [Coil Compose](https://coil-kt.github.io/coil/compose/)
- [Reorderable 2.5.1](https://github.com/Calvin-LL/Reorderable/tree/v2.5.1)
- [Haze 1.7.0](https://github.com/chrisbanes/haze/tree/1.7.0)
