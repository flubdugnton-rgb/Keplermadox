@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.auth.GoogleUser
import com.example.data.model.*
import com.example.data.repository.StudyState
import com.example.ui.Destination
import com.example.ui.components.*
import com.example.ui.profile.ProfileButton
import com.example.ui.theme.isDarkMode

@Composable fun HomeScreen(state: StudyState, user: GoogleUser?, motion: SharedMotion,
    onNavigate: (Destination) -> Unit, onSubject: (Subject) -> Unit,
    onOpen: (StudyItem) -> Unit, onProfile: () -> Unit, onRefresh: () -> Unit) {
    val dark = isDarkMode(state.theme)
    val recent = remember(state.items, state.accessed) {
        state.items.filter { it.id in state.accessed }.sortedByDescending { state.accessed[it.id] }.take(4)
    }
    val complete = state.items.count { it.id in state.completed }
    val progress = if (state.items.isEmpty()) 0f else complete.toFloat() / state.items.size
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val columns = if (maxWidth >= 800.dp) 3 else 2
        val wideHeader = maxWidth >= 650.dp
        ExpressiveRefreshBox(state.loading, onRefresh, Modifier.fillMaxSize()) {
            LazyVerticalGrid(columns = GridCells.Fixed(columns), modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Box(Modifier.fillMaxWidth().background(Brush.linearGradient(
                        if (dark) listOf(Color(0xFF36344F), Color(0xFF23483E))
                        else listOf(Color(0xFFFFD7E8), Color(0xFFFFECC0), Color(0xFFD4F1DB))),
                        MaterialTheme.shapes.extraLarge).padding(24.dp)) {
                        Column(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("SEU ESPAÇO DE ESTUDO", style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(user?.displayName?.substringBefore(' ')?.let { "Olá, $it" } ?: "Vamos explorar?",
                                        style = MaterialTheme.typography.titleMedium)
                                }
                                ProfileButton(user, motion, onProfile)
                            }
                            Spacer(Modifier.height(24.dp))
                            Text("Kepleræ", style = MaterialTheme.typography.displayLarge.copy(
                                fontSize = if (wideHeader) 96.sp else 62.sp,
                                lineHeight = if (wideHeader) 104.sp else 70.sp,
                                letterSpacing = (-2).sp, fontWeight = FontWeight.Bold))
                            Text("Aprender, no seu ritmo.", style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Card(shape = RoundedCornerShape(32.dp),
                        colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLowest)) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Text("Seu percurso", style = MaterialTheme.typography.headlineSmall,
                                    modifier = Modifier.weight(1f))
                                HelpTooltip("Seu percurso", "As conclusões e os favoritos ficam salvos neste aparelho. " +
                                    "Abra um material e toque em Concluir para atualizar seu progresso.")
                            }
                            Text("$complete de ${state.items.size} materiais concluídos",
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            LinearWavyProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = { if (recent.isEmpty()) onNavigate(Destination.SUBJECTS)
                                else onOpen(recent.first()) }, modifier = Modifier.heightIn(min = 52.dp)) {
                                Icon(if (recent.isEmpty()) Icons.Outlined.GridView else Icons.Filled.PlayArrow, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (recent.isEmpty()) "Escolher uma matéria" else "Retomar estudo")
                            }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf(Destination.VIDEOS, Destination.PDFS, Destination.AUDIO).forEach { dest ->
                            Card(onClick = { onNavigate(dest) }, modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerHigh)) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(dest.icon, null, tint = MaterialTheme.colorScheme.primary)
                                    Text(state.items.count { it.type == dest.type }.toString(),
                                        style = MaterialTheme.typography.headlineMedium)
                                    Text(dest.title, style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Suas matérias", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onNavigate(Destination.SUBJECTS) }) { Text("Ver todas") }
                    }
                }
                items(Subjects.all, key = { it.id }) { subject ->
                    SubjectTile(subject, state, motion, Modifier.fillMaxWidth()) { onSubject(subject) }
                }
                if (recent.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text("Continue de onde parou", style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier.padding(top = 8.dp))
                    }
                    items(recent, key = { "recent/${it.id}" }, span = { GridItemSpan(maxLineSpan) }) { item ->
                        Card(onClick = { onOpen(item) }, modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLow)) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Icon(if (item.type == ContentType.AUDIO) Icons.Outlined.Headphones
                                    else if (item.type == ContentType.PDF) Icons.Outlined.Description
                                    else Icons.Outlined.PlayCircleOutline, null, tint = MaterialTheme.colorScheme.primary)
                                Column(Modifier.weight(1f)) {
                                    Text(item.title, style = MaterialTheme.typography.titleMedium)
                                    Text(Subjects.get(item.subjectId).name, style = MaterialTheme.typography.bodySmall)
                                }
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, "Abrir material")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun SubjectTile(subject: Subject, state: StudyState, motion: SharedMotion,
    modifier: Modifier = Modifier, onClick: () -> Unit) {
    val palette = subjectPalette(subject.id, isDarkMode(state.theme))
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .96f else 1f, label = "subject_press")
    val rows = state.items.filter { it.subjectId == subject.id }
    val complete = rows.count { it.id in state.completed }
    Card(onClick = onClick, interactionSource = interaction,
        modifier = modifier.then(motion.bounds("subject/${subject.id}/container"))
            .graphicsLayer { scaleX = scale; scaleY = scale },
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 16.dp, bottomEnd = 28.dp, bottomStart = 28.dp),
        colors = CardDefaults.cardColors(palette.first, palette.second)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                SubjectArtwork(subject.id, palette.second,
                    motion.element("subject/${subject.id}/art").size(76.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(20.dp))
            }
            Text(subject.name, style = MaterialTheme.typography.titleMedium, minLines = 2,
                modifier = motion.bounds("subject/${subject.id}/name"))
            Text("${rows.size} materiais", style = MaterialTheme.typography.labelLarge)
            LinearProgressIndicator(progress = { if (rows.isEmpty()) 0f else complete.toFloat() / rows.size },
                modifier = Modifier.fillMaxWidth(), color = palette.second,
                trackColor = palette.second.copy(alpha = .15f))
        }
    }
}
