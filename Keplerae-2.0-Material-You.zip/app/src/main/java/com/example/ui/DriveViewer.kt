@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.drive.*
import com.example.data.model.*
import com.example.data.repository.StudyState
import com.example.data.repository.reconcileOrder
import com.example.ui.components.ExpressiveRefreshBox
import com.example.ui.components.LoadingPane
import kotlinx.coroutines.CancellationException
import java.io.File

private data class MaterialLoad(val loading: Boolean = true, val file: DriveFile? = null,
    val pdf: File? = null, val progress: Float? = null, val error: String? = null)
private data class FolderLoad(val loading: Boolean = true, val files: List<DriveFile> = emptyList(),
    val error: String? = null)

@Composable fun DriveViewer(item: StudyItem, state: StudyState, onDismiss: () -> Unit,
    onFavorite: (String) -> Unit, onCompleted: (String) -> Unit, onAccess: (String) -> Unit,
    accountEmail: String? = null) {
    val context = LocalContext.current
    val revision = DriveSession.revision
    val token = DriveSession.accessToken
    val credentials = remember(revision, token) { DriveSettings(context).credentials() }
    val repository = remember(credentials) { DriveRepository(context, credentials) }
    var configure by remember { mutableStateOf(false) }
    var fullscreen by remember(item.id) { mutableStateOf(false) }
    var selected by remember(item.id) { mutableStateOf(if (item.linkKind == LinkKind.FILE) item else null) }
    val initialFolder = remember(item.id) {
        DriveFile(DriveRequests.folderId(item.url), item.title, "application/vnd.google-apps.folder", DriveRequests.resourceKey(item.url))
    }
    var folders by remember(item.id) { mutableStateOf(listOf(initialFolder)) }
    var folderTracks by remember(item.id) { mutableStateOf<List<StudyItem>>(emptyList()) }
    var autoPlay by remember(item.id) { mutableStateOf(false) }
    val order = reconcileOrder(state.items.map { it.id }, state.itemOrder)
    val catalogAudio = remember(state.items, order) {
        val byId = state.items.associateBy { it.id }
        order.mapNotNull(byId::get).filter { it.type == ContentType.AUDIO && it.linkKind == LinkKind.FILE }
    }
    val active = selected ?: item
    fun back() {
        when {
            fullscreen -> fullscreen = false
            selected != null && item.linkKind == LinkKind.FOLDER -> selected = null
            selected == null && folders.size > 1 -> folders = folders.dropLast(1)
            else -> onDismiss()
        }
    }
    BackHandler { back() }
    key(item.id) {
        Surface(Modifier.fillMaxSize()) {
            Scaffold(
                topBar = {
                    if (!fullscreen) TopAppBar(
                        title = { Text(if (selected != null) active.title else folders.last().name,
                            maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        navigationIcon = { IconButton(onClick = ::back) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar")
                        } },
                        actions = {
                            IconButton(onClick = { configure = true }) { Icon(Icons.Outlined.Settings, "Configurar Drive") }
                            if (selected != null) {
                                IconButton(onClick = { onFavorite(active.id) }) {
                                    Icon(if (active.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favoritar")
                                }
                                IconButton(onClick = { fullscreen = true }) { Icon(Icons.Outlined.Fullscreen, "Tela cheia") }
                            }
                        })
                },
                bottomBar = {
                    if (!fullscreen && selected != null) Surface(color = MaterialTheme.colorScheme.surfaceContainer) {
                        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (active.note.isNotBlank()) Text(active.note, style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(active.type.label, style = MaterialTheme.typography.labelLarge)
                                    Text("Seu progresso fica salvo no Kepleræ.", style = MaterialTheme.typography.bodySmall)
                                }
                                Button(onClick = { onCompleted(active.id) }) {
                                    Text(if (active.id in state.completed) "Concluído ✓" else "Concluir")
                                }
                            }
                        }
                    }
                }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when {
                        !credentials.configured -> ViewerMessage("Conecte seu Google Drive",
                            "Adicione sua chave de API para materiais públicos ou autorize a conta Google para arquivos privados.",
                            onConfigure = { configure = true })
                        selected != null -> MaterialContent(active, repository, Modifier.fillMaxSize(),
                            onConfigure = { configure = true },
                            playlist = if (folderTracks.isNotEmpty()) folderTracks else catalogAudio, autoPlay = autoPlay,
                            onSelectTrack = { track -> selected = track; autoPlay = true; onAccess(track.id) })
                        else -> FolderContent(folders.last(), item, repository,
                            onFolder = { folders = folders + it },
                            onFile = { file, files ->
                                folderTracks = files.filter { it.contentType == ContentType.AUDIO && !it.folder }.map { it.studyItem(item) }
                                selected = file.studyItem(item); autoPlay = false; onAccess(selected!!.id)
                            },
                            onConfigure = { configure = true })
                    }
                    if (fullscreen) FilledIconButton(onClick = { fullscreen = false },
                        modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(12.dp)) {
                        Icon(Icons.Outlined.FullscreenExit, "Sair da tela cheia")
                    }
                }
            }
        }
    }
    if (configure) DriveConfigDialog(accountEmail = accountEmail, onDismiss = { configure = false })
}

@Composable private fun MaterialContent(item: StudyItem, repository: DriveRepository,
    modifier: Modifier, onConfigure: () -> Unit, playlist: List<StudyItem>, autoPlay: Boolean,
    onSelectTrack: (StudyItem) -> Unit) {
    val context = LocalContext.current
    var retry by remember(item.id) { mutableIntStateOf(0) }
    val loaded by produceState(MaterialLoad(), item.id, repository, retry) {
        value = MaterialLoad()
        var temporary: File? = null
        try {
            val file = repository.metadata(item.driveFileId, DriveRequests.resourceKey(item.url))
            require(file.canDownload) { "O proprietário bloqueou a leitura do conteúdo pela API. A chave não altera essa permissão." }
            require(file.contentType != null) { "Este formato não é suportado pelo visualizador interno." }
            if (file.contentType == ContentType.PDF) {
                temporary = File.createTempFile("drive-pdf-", ".pdf", context.cacheDir)
                val pdf = repository.pdf(file, temporary!!) { received, size ->
                    value = MaterialLoad(file = file, progress = if (size > 0) (received.toFloat() / size).coerceIn(0f, 1f) else null)
                }
                value = MaterialLoad(loading = false, file = file, pdf = pdf)
            } else value = MaterialLoad(loading = false, file = file)
        } catch (e: CancellationException) { temporary?.delete(); throw e }
        catch (e: Exception) {
            temporary?.delete()
            value = MaterialLoad(loading = false, error = e.message ?: "Não foi possível carregar o material.")
        }
        awaitDispose { temporary?.delete() }
    }
    when {
        loaded.loading -> LoadingPane(
            if (loaded.file?.contentType == ContentType.PDF) "Preparando PDF…" else "Carregando material…",
            modifier, loaded.progress)
        loaded.error != null -> ViewerMessage("Não foi possível carregar", loaded.error!!,
            onRetry = { retry++ }, onConfigure = onConfigure)
        loaded.pdf != null -> NativePdf(loaded.pdf!!, modifier)
        loaded.file != null -> NativeMedia(item.copy(type = loaded.file!!.contentType!!), loaded.file!!, repository, modifier, onConfigure,
            playlist = playlist, autoPlay = autoPlay, onSelectTrack = onSelectTrack)
    }
}

@Composable private fun FolderContent(folder: DriveFile, item: StudyItem, repository: DriveRepository,
    onFolder: (DriveFile) -> Unit, onFile: (DriveFile, List<DriveFile>) -> Unit, onConfigure: () -> Unit) {
    var query by remember(folder.id) { mutableStateOf("") }
    var retry by remember(folder.id) { mutableIntStateOf(0) }
    val loaded by produceState(FolderLoad(), folder.id, repository, retry) {
        value = FolderLoad(files = value.files)
        try { value = FolderLoad(false, repository.folder(folder.id, folder.resourceKey)) }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { value = FolderLoad(false, error = e.message ?: "Não foi possível ler a pasta.") }
    }
    if (loaded.loading && loaded.files.isEmpty()) LoadingPane("Carregando pasta…")
    else if (loaded.error != null) ViewerMessage("Não foi possível abrir a pasta", loaded.error!!,
        onRetry = { retry++ }, onConfigure = onConfigure)
    else ExpressiveRefreshBox(loaded.loading, { retry++ }, Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Localize: ${item.filename}", style = MaterialTheme.typography.bodyMedium)
        OutlinedTextField(query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, label = { Text("Buscar nesta pasta") })
        val files = loaded.files.filter { searchable(it.name).contains(searchable(query)) }
        if (files.isEmpty()) Text("Nenhum arquivo encontrado nesta pasta.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(files, key = { it.id }) { file ->
                val supported = file.folder || file.contentType != null
                Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.fillMaxWidth().clickable(enabled = supported) {
                        if (file.folder) onFolder(file) else onFile(file, loaded.files)
                    }) {
                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(when {
                            file.folder -> Icons.Outlined.Folder
                            file.contentType == ContentType.AUDIO -> Icons.Outlined.Headphones
                            file.contentType == ContentType.PDF -> Icons.Outlined.Description
                            else -> Icons.Outlined.PlayCircleOutline
                        }, null, tint = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f)) {
                            Text(file.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(if (file.folder) "Pasta" else file.contentType?.label ?: "Formato não suportado",
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
    }
}

@Composable private fun ViewerMessage(title: String, detail: String, onRetry: (() -> Unit)? = null,
    onConfigure: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Outlined.CloudOff, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp)); Text(detail)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (onRetry != null) Button(onClick = onRetry) { Text("Tentar novamente") }
            OutlinedButton(onClick = onConfigure) { Text("Configurar Drive") }
        }
    }
}
