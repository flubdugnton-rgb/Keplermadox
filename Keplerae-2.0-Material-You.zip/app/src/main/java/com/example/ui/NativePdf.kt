package com.example.ui

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.ZoomOutMap
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.example.ui.components.HelpTooltip
import com.example.ui.components.LoadingPane
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.absoluteValue

private data class PdfDocument(val count: Int = 0, val error: String? = null)
private data class PdfBitmap(val bitmap: Bitmap? = null, val error: String? = null)
// Limita renderizações simultâneas e o pico de memória durante o gesto de paginação.
private val pdfRenderGate = Semaphore(1)

@Composable fun NativePdf(file: File, modifier: Modifier = Modifier) {
    var savedPage by rememberSaveable(file.path) { mutableIntStateOf(0) }
    val document by produceState(PdfDocument(), file.path) {
        value = withContext(Dispatchers.IO) {
            try {
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                    PdfRenderer(descriptor).use { renderer ->
                        check(renderer.pageCount > 0)
                        PdfDocument(renderer.pageCount)
                    }
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { PdfDocument(error = "Não foi possível ler este PDF. Ele pode estar danificado ou protegido por senha.") }
        }
    }
    when {
        document.error != null -> Box(modifier, contentAlignment = Alignment.Center) {
            Text(document.error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(24.dp))
        }
        document.count == 0 -> LoadingPane("Preparando páginas…", modifier)
        else -> {
            val pager = rememberPagerState(initialPage = savedPage.coerceIn(0, document.count - 1),
                pageCount = { document.count })
            var zoomed by remember(file.path) { mutableStateOf(false) }
            var resetZoom by remember(file.path) { mutableIntStateOf(0) }
            val scope = rememberCoroutineScope()
            LaunchedEffect(pager) { snapshotFlow { pager.currentPage }.collect { savedPage = it; zoomed = false } }
            Column(modifier.fillMaxSize()) {
                HorizontalPager(state = pager, userScrollEnabled = !zoomed,
                    beyondViewportPageCount = 0, pageSpacing = 12.dp,
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    modifier = Modifier.fillMaxWidth().weight(1f).testTag("pdf_pager"), key = { it }) { index ->
                    // O offset varia continuamente enquanto o usuário arrasta.
                    val offset = ((pager.currentPage - index) + pager.currentPageOffsetFraction).absoluteValue
                    val fraction = offset.coerceIn(0f, 1f)
                    PdfPageContent(file, index, active = index == pager.currentPage, resetZoom = resetZoom,
                        modifier = Modifier.fillMaxSize().graphicsLayer {
                            scaleX = 1f - .12f * fraction
                            scaleY = 1f - .12f * fraction
                            alpha = 1f - .45f * fraction
                            clip = true
                        }, onZoomChanged = { if (index == pager.currentPage) zoomed = it })
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { resetZoom++; scope.launch { pager.animateScrollToPage((pager.currentPage - 1).coerceAtLeast(0)) } },
                        enabled = pager.currentPage > 0) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Página anterior") }
                    Text("${pager.currentPage + 1} / ${document.count}", style = MaterialTheme.typography.labelLarge)
                    IconButton(onClick = { resetZoom++; scope.launch { pager.animateScrollToPage((pager.currentPage + 1).coerceAtMost(document.count - 1)) } },
                        enabled = pager.currentPage < document.count - 1) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Próxima página") }
                    IconButton(onClick = { resetZoom++ }) { Icon(Icons.Outlined.ZoomOutMap, "Restaurar zoom") }
                    HelpTooltip("Ler PDF", "Deslize com um dedo para trocar de página. Use dois dedos para ampliar. " +
                        "Com zoom ativo, arraste para mover a página ou toque em Restaurar zoom para voltar à paginação.")
                }
            }
        }
    }
}

@Composable private fun PdfPageContent(file: File, index: Int, active: Boolean, resetZoom: Int,
    modifier: Modifier, onZoomChanged: (Boolean) -> Unit) {
    var zoom by remember(file.path, index) { mutableFloatStateOf(1f) }
    var pan by remember(file.path, index) { mutableStateOf(Offset.Zero) }
    val zoomCallback by rememberUpdatedState(onZoomChanged)
    LaunchedEffect(resetZoom, active) { zoom = 1f; pan = Offset.Zero; zoomCallback(false) }
    val page by produceState(PdfBitmap(), file.path, index) {
        value = pdfRenderGate.withPermit {
            withContext(Dispatchers.IO) {
                try {
                    ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                        PdfRenderer(descriptor).use { renderer ->
                            renderer.openPage(index).use { opened ->
                                val scale = minOf(1440f / opened.width, 2048f / opened.height)
                                val bitmap = Bitmap.createBitmap((opened.width * scale).toInt().coerceAtLeast(1),
                                    (opened.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                                bitmap.eraseColor(android.graphics.Color.WHITE)
                                opened.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                PdfBitmap(bitmap)
                            }
                        }
                    }
                } catch (e: CancellationException) { throw e }
                catch (e: Exception) { PdfBitmap(error = "Não foi possível renderizar esta página.") }
            }
        }
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        when {
            page.error != null -> Text(page.error!!, color = MaterialTheme.colorScheme.error)
            page.bitmap == null -> LoadingPane("Carregando página ${index + 1}…")
            else -> Image(bitmap = page.bitmap!!.asImageBitmap(), contentDescription = "Página ${index + 1}",
                contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()
                    .pointerInput(file.path, index) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            do {
                                val event = awaitPointerEvent()
                                val transform = event.changes.count { it.pressed } >= 2 || zoom > 1.01f
                                // Um dedo, sem zoom, permanece disponível para o HorizontalPager.
                                if (transform) {
                                    zoom = (zoom * event.calculateZoom()).coerceIn(1f, 4f)
                                    val delta = event.calculatePan()
                                    val limitX = size.width * (zoom - 1f) / 2f
                                    val limitY = size.height * (zoom - 1f) / 2f
                                    pan = Offset((pan.x + delta.x).coerceIn(-limitX, limitX),
                                        (pan.y + delta.y).coerceIn(-limitY, limitY))
                                    zoomCallback(zoom > 1.01f)
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    }.graphicsLayer { scaleX = zoom; scaleY = zoom; translationX = pan.x; translationY = pan.y })
        }
    }
}
