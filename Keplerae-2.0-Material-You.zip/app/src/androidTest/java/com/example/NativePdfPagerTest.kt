package com.example

import android.graphics.pdf.PdfDocument
import androidx.activity.ComponentActivity
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.ui.NativePdf
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class NativePdfPagerTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun oneFingerSwipeAdvancesRealRenderedPdfPages() {
        val file = File.createTempFile("pager-test", ".pdf", compose.activity.cacheDir)
        PdfDocument().use { document ->
            repeat(3) { index ->
                val page = document.startPage(PdfDocument.PageInfo.Builder(300, 450, index + 1).create())
                page.canvas.drawText("Página ${index + 1}", 40f, 60f, android.graphics.Paint().apply { textSize = 24f })
                document.finishPage(page)
            }
            file.outputStream().use(document::writeTo)
        }
        compose.setContent { KepleraeTheme { NativePdf(file, Modifier.fillMaxSize()) } }
        compose.waitUntil(20000) { compose.onAllNodesWithContentDescription("Página 1").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("pdf_pager").performTouchInput { swipeLeft() }
        compose.waitUntil(10000) { compose.onAllNodesWithText("2 / 3").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("2 / 3").assertIsDisplayed()
        saveDevicePreview("pdf-pagina-2")
        compose.onNodeWithContentDescription("Página anterior").performClick()
        compose.waitUntil(10000) { compose.onAllNodesWithText("1 / 3").fetchSemanticsNodes().isNotEmpty() }
        file.delete()
    }
}
