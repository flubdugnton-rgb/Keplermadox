#!/usr/bin/env python3
"""Reescala os originais definitivos, sem redesenhar o logo. Requer Pillow.

Não é uma etapa do build. Foreground adaptativo, monocromático e logo de login
já estão nos recursos Android; este utilitário regenera os PNGs legados e de design.
"""
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parents[1]
square = Image.open(root / "design/keplerae-original-square.png").convert("RGBA")
circle = Image.open(root / "design/keplerae-original-circle.png").convert("RGBA")
for density, size in [("mdpi", 48), ("hdpi", 72), ("xhdpi", 96), ("xxhdpi", 144), ("xxxhdpi", 192)]:
    dest = root / "app/src/main/res" / f"mipmap-{density}"
    dest.mkdir(exist_ok=True)
    square.resize((size, size), Image.Resampling.LANCZOS).save(dest / "ic_launcher.png")
    circle.resize((size, size), Image.Resampling.LANCZOS).save(dest / "ic_launcher_round.png")
circle.resize((512, 512), Image.Resampling.LANCZOS).save(root / "design/icon-512.png")
print("Ícone definitivo preservado: 10 PNGs de launcher e prévia 512 px.")
