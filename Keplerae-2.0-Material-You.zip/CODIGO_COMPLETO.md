# Código completo — Kepleræ 2.0

Arquivos completos. Copie cada bloco para o caminho indicado ou use o ZIP do projeto. O catálogo e os ícones binários estão no ZIP. Consulte README.md para OAuth Web e assinatura.

Compilação Android, lint e testes Kotlin aguardam o GitHub Actions; não foram executados neste ambiente.


## .github/workflows/android-apk.yml

```yaml
name: Compilar APK Keplerae
on:
  push:
    branches: [main, master, 'kepler/**']
  pull_request:
  workflow_dispatch:
    inputs:
      testar_interface:
        description: Executar teste de interface no emulador
        required: false
        type: boolean
        default: false
permissions:
  contents: read
concurrency:
  group: apk-${{ github.ref }}
  cancel-in-progress: true
jobs:
  apk:
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - name: Instalar SDK
        run: sdkmanager 'platforms;android-36' 'build-tools;36.0.0'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.13'
      - name: Preservar assinatura de teste entre builds
        uses: actions/cache@v4
        with:
          path: ~/.android/debug.keystore
          key: keplerae-debug-signing-v1
      - name: Validar catálogo
        run: python3 scripts/validate_catalog.py
      - name: Compilar, testar e verificar Android
        run: gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
      - name: Nomear o APK
        run: cp app/build/outputs/apk/debug/app-debug.apk Keplerae-1.1.0-debug.apk
      - uses: actions/upload-artifact@v4
        with:
          name: Keplerae-APK
          path: Keplerae-1.1.0-debug.apk
          if-no-files-found: error
          retention-days: 30
      - name: Resultados das verificações
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: Keplerae-verificacoes
          path: |
            app/build/reports/tests/
            app/build/reports/lint-results-debug.html
          if-no-files-found: ignore
  interface:
    if: github.event_name == 'workflow_dispatch' && inputs.testar_interface
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.13'
      - name: Ativar KVM
        run: |
          echo 'KERNEL=="kvm", GROUP="kvm", MODE="0666", OPTIONS+="static_node=kvm"' | sudo tee /etc/udev/rules.d/99-kvm4all.rules
          sudo udevadm control --reload-rules
          sudo udevadm trigger --name-match=kvm
      - uses: reactivecircus/android-emulator-runner@v2
        with:
          api-level: 35
          arch: x86_64
          script: gradle :app:connectedDebugAndroidTest
```


## .github/workflows/compilar-apk.yml

```yaml
name: Compilar Keplerae 2.0 - Material You

on:
  push:
    branches: [main, master]
  workflow_dispatch:
    inputs:
      testar_interface:
        description: Executar testes de login, perfil, catálogo e PDF no emulador
        type: boolean
        required: false
        default: true

permissions:
  contents: read

concurrency:
  group: apk-zip-${{ github.ref }}
  cancel-in-progress: true

jobs:
  apk:
    runs-on: ubuntu-latest
    timeout-minutes: 35
    defaults:
      run:
        working-directory: android-project
    steps:
      - uses: actions/checkout@v4
      - name: Extrair o projeto 2.0
        working-directory: .
        run: |
          test -f Keplerae-2.0-Material-You.zip
          unzip -q Keplerae-2.0-Material-You.zip -d android-project
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - name: Instalar SDK
        run: sdkmanager 'platforms;android-36' 'build-tools;36.0.0'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.13'
      - name: Recuperar assinatura que já funciona no Google
        uses: actions/cache@v4
        with:
          path: android-project/.signing/debug.keystore
          key: keplerae-native-debug-signing-v1
      - name: Conferir a assinatura existente
        run: |
          test -s .signing/debug.keystore || { echo 'A assinatura anterior não está no cache. Recupere a chave usada no APK 1.2.2 antes de compilar a atualização.'; exit 1; }
          keytool -exportcert -keystore .signing/debug.keystore -storepass android -alias androiddebugkey -file /tmp/keplerae-cert.der
          python3 - <<'PY'
          import hashlib
          from pathlib import Path
          expected = '16007901DBBFAB9DE7B5539FFAC604FAF19DBC8A'
          actual = hashlib.sha1(Path('/tmp/keplerae-cert.der').read_bytes()).hexdigest().upper()
          if actual != expected:
              raise SystemExit('A assinatura difere do APK que já funciona. Recupere a chave anterior para preservar atualização e OAuth.')
          print('Assinatura anterior preservada.')
          PY
      - name: Configurar entrada Google
        env:
          GOOGLE_WEB_CLIENT_ID: ${{ vars.GOOGLE_WEB_CLIENT_ID }}
        run: python3 scripts/configure_google_login.py
      - name: Validar catálogo e rede
        run: |
          python3 scripts/validate_catalog.py
          python3 scripts/validate_network_permissions.py
      - name: Compilar, testar e verificar
        run: gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleDebugAndroidTest
      - name: Validar APK e nomear
        run: |
          python3 scripts/validate_network_permissions.py app/build/outputs/apk/debug/app-debug.apk
          cp app/build/outputs/apk/debug/app-debug.apk Keplerae-2.0.0-debug.apk
      - uses: actions/upload-artifact@v4
        with:
          name: Keplerae-2.0-APK
          path: android-project/Keplerae-2.0.0-debug.apk
          if-no-files-found: error
          retention-days: 30
      - name: Resultados das verificações
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: Keplerae-2.0-verificacoes
          path: |
            android-project/app/build/reports/tests/
            android-project/app/build/reports/lint-results-debug.html
          if-no-files-found: ignore

  interface:
    if: ${{ github.event_name != 'workflow_dispatch' || inputs.testar_interface }}
    needs: apk
    runs-on: ubuntu-latest
    timeout-minutes: 35
    steps:
      - uses: actions/checkout@v4
      - name: Extrair projeto
        run: unzip -q Keplerae-2.0-Material-You.zip -d android-project
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.13'
      - uses: android-actions/setup-android@v3
      - name: Instalar SDK para compilar testes
        run: sdkmanager 'platforms;android-36' 'build-tools;36.0.0'
      - name: Ativar KVM
        run: |
          echo 'KERNEL=="kvm", GROUP="kvm", MODE="0666", OPTIONS+="static_node=kvm"' | sudo tee /etc/udev/rules.d/99-kvm4all.rules
          sudo udevadm control --reload-rules
          sudo udevadm trigger --name-match=kvm
      - uses: reactivecircus/android-emulator-runner@v2
        with:
          api-level: 35
          arch: x86_64
          script: |
            gradle --no-daemon -p android-project :app:connectedDebugAndroidTest
            mkdir -p android-project/app/build/design-preview
            adb pull /sdcard/Android/data/com.aistudio.keplerae.stdy/files/design-preview/. android-project/app/build/design-preview/ || true
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: Keplerae-2.0-testes-dispositivo
          path: |
            android-project/app/build/reports/androidTests/
            android-project/app/build/design-preview/
          if-no-files-found: ignore
```


## app/build.gradle.kts

```kotlin
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.example"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.aistudio.keplerae.stdy"
        minSdk = 24
        targetSdk = 36
        versionCode = 21
        versionName = "2.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    signingConfigs {
        getByName("debug") {
            val cachedKey = rootProject.file(".signing/debug.keystore")
            if (cachedKey.exists()) {
                storeFile = cachedKey
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures { compose = true }
}
kotlin { jvmToolchain(17) }
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.media3:media3-exoplayer:1.8.1")
    implementation("androidx.media3:media3-ui:1.8.1")
    implementation("com.google.android.gms:play-services-auth:22.0.0")
    // Haze 1.7.0 usa Compose 1.9.4. Mantenha todos os artefatos UI alinhados.
    val composeVersion = "1.9.4"
    implementation("androidx.credentials:credentials:1.6.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.6.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.10.2")
    implementation("dev.chrisbanes.haze:haze:1.7.0")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.compose.runtime:runtime:$composeVersion")
    implementation("androidx.compose.foundation:foundation:$composeVersion")
    implementation("androidx.compose.ui:ui:$composeVersion")
    implementation("androidx.compose.ui:ui-tooling-preview:$composeVersion")
    // Etapa 01 da versão 2.0: fontes Google, mesma versão do Compose UI.
    implementation("androidx.compose.ui:ui-text-google-fonts:$composeVersion")
    // Alpha autorizada: LoadingIndicator e indicadores ondulados Expressive.
    // Versão fixada para a base Compose 1.9 / SDK 36; não use '+' aqui.
    implementation("androidx.compose.material3:material3:1.5.0-alpha07")
    implementation("androidx.compose.animation:animation:$composeVersion")
    implementation("androidx.datastore:datastore-preferences:1.1.7")
    implementation("io.coil-kt.coil3:coil-compose:3.3.0")
    implementation("io.coil-kt.coil3:coil-network-okhttp:3.3.0")
    implementation("sh.calvin.reorderable:reorderable:2.5.1")
    implementation("androidx.compose.material:material-icons-extended:1.7.8")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4:$composeVersion")
    debugImplementation("androidx.compose.ui:ui-tooling:$composeVersion")
    debugImplementation("androidx.compose.ui:ui-test-manifest:$composeVersion")
}
```


## app/src/androidTest/java/com/example/DevicePreview.kt

```kotlin
package com.example

import android.graphics.Bitmap
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File

/** Capturas reais do emulador, publicadas pelo Actions junto dos relatórios de interface. */
internal fun saveDevicePreview(name: String) {
    val instrumentation = InstrumentationRegistry.getInstrumentation()
    val root = File(instrumentation.targetContext.getExternalFilesDir(null), "design-preview").apply { mkdirs() }
    val screenshot = instrumentation.uiAutomation.takeScreenshot() ?: return
    File(root, "$name.png").outputStream().use { screenshot.compress(Bitmap.CompressFormat.PNG, 100, it) }
    screenshot.recycle()
}
```


## app/src/androidTest/java/com/example/DriveNativeTest.kt

```kotlin
package com.example

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.example.data.drive.DriveSettings
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class DriveNativeTest {
    @Test fun installedAppHasNetworkPermissionAndCanCreateSocket() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals(android.content.pm.PackageManager.PERMISSION_GRANTED,
            context.checkPermission(android.Manifest.permission.INTERNET, android.os.Process.myPid(), android.os.Process.myUid()))
        java.net.ServerSocket(0, 1, java.net.InetAddress.getLoopbackAddress()).use { server ->
            java.net.Socket().use { client ->
                client.connect(java.net.InetSocketAddress(java.net.InetAddress.getLoopbackAddress(), server.localPort), 2000)
                server.accept().use { peer -> assertTrue(peer.isConnected) }
            }
        }
    }
    @Test fun pdfCanBeRenderedOnDeviceWithoutBrowser() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val file = File.createTempFile("native-pdf-test-", ".pdf", context.cacheDir)
        try {
            val document = PdfDocument()
            try {
                repeat(2) { index ->
                    val page = document.startPage(PdfDocument.PageInfo.Builder(300, 400, index + 1).create())
                    page.canvas.drawColor(if (index == 0) Color.RED else Color.BLUE)
                    document.finishPage(page)
                }
                file.outputStream().use(document::writeTo)
            } finally { document.close() }
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    assertEquals(2, renderer.pageCount)
                    renderer.openPage(1).use { page ->
                        val bitmap = Bitmap.createBitmap(300, 400, Bitmap.Config.ARGB_8888)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        assertEquals(Color.BLUE, bitmap.getPixel(150, 200))
                        bitmap.recycle()
                    }
                }
            }
        } finally { file.delete() }
    }
    @Test fun keyRoundTripsThroughKeystoreWithoutPlaintextPreference() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "drive-test-${UUID.randomUUID()}"
        val preferences = context.getSharedPreferences(name, 0)
        val settings = DriveSettings(context, name)
        try {
            val key = "not-a-real-api-key-for-local-keystore-test"
            settings.saveApiKey(key)
            assertEquals(key, settings.apiKey())
            assertFalse(preferences.getString("api_key", "")!!.contains(key))
            settings.saveApiKey("")
            assertEquals("", settings.apiKey())
        } finally { preferences.edit().clear().commit() }
    }
}
```


## app/src/androidTest/java/com/example/InterfaceTest.kt

```kotlin
package com.example

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.activity.ComponentActivity
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.repository.StudyViewModel
import com.example.ui.KepleraeApp
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class InterfaceTest {
    // Testa catálogo/tema diretamente, sem simular credenciais nem burlar o login em produção.
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun catalogAndThemeControlsWork() {
        lateinit var viewModel: StudyViewModel
        compose.activityRule.scenario.onActivity { activity ->
            viewModel = ViewModelProvider(activity)[StudyViewModel::class.java]
        }
        compose.setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            KepleraeTheme(state.theme, state.dynamicColor) { KepleraeApp(state, viewModel) }
        }
        compose.waitUntil(timeoutMillis = 20000) {
            compose.onAllNodesWithText("Seu percurso").fetchSemanticsNodes().isNotEmpty()
        }
        saveDevicePreview("inicio")
        compose.onNodeWithTag("settings").performClick()
        compose.onNodeWithTag("theme_DARK").performClick()
        compose.onNodeWithTag("theme_DARK").assertIsSelected()
        compose.onNodeWithTag("theme_LIGHT").performClick()
        compose.onNodeWithTag("theme_LIGHT").assertIsSelected()
        compose.onNodeWithTag("theme_SYSTEM").performClick()
        compose.onNodeWithTag("theme_SYSTEM").assertIsSelected()
        compose.activityRule.scenario.onActivity { it.onBackPressedDispatcher.onBackPressed() }
        compose.onNodeWithTag("nav_PDFS").performClick()
        compose.onNodeWithTag("catalog_search").performTextInput("AVALIAÇÃO FISIOTERAPÊUTICA")
        compose.onAllNodesWithText("AVALIAÇÃO FISIOTERAPÊUTICA EM TERAPIA INTENSIVA", substring = true)
            .onFirst().assertExists()
    }
}
```


## app/src/androidTest/java/com/example/LoginScreenTest.kt

```kotlin
package com.example

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.hasClickAction
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodes
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.repository.ThemeMode
import com.example.ui.login.LoginScreen
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LoginScreenTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    @Test fun offersOnlyGoogleAndInvokesTheEntryAction() {
        var calls = 0
        compose.setContent {
            KepleraeTheme(ThemeMode.LIGHT, dynamicColor = false) {
                LoginScreen(busy = false, error = null, onGoogleSignIn = { calls++ })
            }
        }
        compose.onNodeWithText("Kepleræ").assertIsDisplayed()
        compose.onNodeWithText("Desenvolvido por Madox Fênix").assertIsDisplayed()
        compose.onAllNodes(hasClickAction()).assertCountEquals(1)
        compose.onNodeWithTag("google_sign_in").performClick()
        compose.runOnIdle { assertEquals(1, calls) }
    }

    @Test fun preventsDuplicateRequestsWhileConnectingAndShowsErrorsInDarkTheme() {
        compose.setContent {
            KepleraeTheme(ThemeMode.DARK, dynamicColor = false) {
                LoginScreen(busy = true, error = "Sem conexão", onGoogleSignIn = {})
            }
        }
        compose.onNodeWithTag("google_sign_in").assertIsNotEnabled()
        compose.onNodeWithTag("login_error").assertIsDisplayed()
    }
}
```


## app/src/androidTest/java/com/example/NativePdfPagerTest.kt

```kotlin
package com.example

import android.graphics.pdf.PdfDocument
import androidx.activity.ComponentActivity
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.ui.NativePdf
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class NativePdfPagerTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun oneFingerSwipeAdvancesRealRenderedPdfPages() {
        val file = File.createTempFile("pager-test", ".pdf", compose.activity.cacheDir)
        PdfDocument().use { document ->
            repeat(3) { index ->
                val page = document.startPage(PdfDocument.PageInfo.Builder(300, 450, index + 1).create())
                page.canvas.drawText("Página ${index + 1}", 40f, 60f, android.graphics.Paint().apply { textSize = 24f })
                document.finishPage(page)
            }
            file.outputStream().use(document::writeTo)
        }
        compose.setContent { KepleraeTheme { NativePdf(file, Modifier.fillMaxSize()) } }
        compose.waitUntil(20000) { compose.onAllNodesWithContentDescription("Página 1").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("pdf_pager").performTouchInput { swipeLeft() }
        compose.waitUntil(10000) { compose.onAllNodesWithText("2 / 3").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("2 / 3").assertIsDisplayed()
        saveDevicePreview("pdf-pagina-2")
        compose.onNodeWithContentDescription("Página anterior").performClick()
        compose.waitUntil(10000) { compose.onAllNodesWithText("1 / 3").fetchSemanticsNodes().isNotEmpty() }
        file.delete()
    }
}
```


## app/src/androidTest/java/com/example/ProfileTest.kt

```kotlin
package com.example

import androidx.activity.ComponentActivity
import androidx.compose.runtime.getValue
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.auth.GoogleUser
import com.example.data.repository.StudyViewModel
import com.example.ui.KepleraeApp
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ProfileTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun profileUsesChosenAccountAndThemeAndConfirmsSignOut() {
        lateinit var model: StudyViewModel
        var signOutCalls = 0
        compose.activityRule.scenario.onActivity { model = ViewModelProvider(it)[StudyViewModel::class.java] }
        compose.setContent {
            val state by model.state.collectAsStateWithLifecycle()
            KepleraeTheme(state.theme, state.dynamicColor) {
                KepleraeApp(state, model, GoogleUser("user@example.com", "Conta de teste", null), { signOutCalls++ })
            }
        }
        compose.waitUntil(20000) { compose.onAllNodesWithTag("profile_open").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("profile_open").performClick()
        compose.onNodeWithText("Conta de teste").assertIsDisplayed()
        compose.onNodeWithTag("profile_theme_DARK").performClick().assertIsSelected()
        compose.waitForIdle()
        saveDevicePreview("perfil-escuro")
        compose.onNodeWithTag("profile_theme_LIGHT").performClick().assertIsSelected()
        compose.waitForIdle()
        saveDevicePreview("perfil-claro")
        compose.onNodeWithTag("sign_out").performScrollTo().performClick()
        compose.runOnIdle { assertEquals(0, signOutCalls) }
        compose.onNodeWithTag("confirm_sign_out").performClick()
        compose.runOnIdle { assertEquals(1, signOutCalls) }
    }
}
```


## app/src/debug/java/com/example/ui/DesignPreview.kt

```kotlin
@file:OptIn(androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import com.example.data.auth.GoogleUser
import com.example.data.model.*
import com.example.data.repository.StudyState
import com.example.data.repository.ThemeMode
import com.example.ui.components.SharedMotion
import com.example.ui.home.HomeScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.theme.KepleraeTheme
import org.json.JSONArray

/** Previews reais de Compose. Leem o catálogo empacotado e não acessam o Drive. */
@Composable private fun PreviewContent(profile: Boolean, dark: Boolean) {
    val context = LocalContext.current
    val state = remember(context, dark) {
        val rows = runCatching {
            val array = JSONArray(context.assets.open("catalog.json").bufferedReader().use { it.readText() })
            List(array.length()) { i ->
                val row = array.getJSONObject(i); val path = row.getJSONArray("folderPath")
                StudyItem(row.getString("id"), row.getString("title"), row.getString("filename"),
                    row.getString("subjectId"), List(path.length()) { path.getString(it) },
                    ContentType.valueOf(row.getString("type")), row.getString("url"),
                    LinkKind.valueOf(row.getString("linkKind")), row.getString("driveFileId"),
                    row.getString("note"), row.getString("source"))
            }
        }.getOrDefault(emptyList())
        StudyState(items = rows, theme = if (dark) ThemeMode.DARK else ThemeMode.LIGHT,
            dynamicColor = false, loading = false)
    }
    KepleraeTheme(state.theme, dynamicColor = false) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            SharedTransitionLayout {
                val shared = this
                AnimatedContent(profile, label = "preview_route") { showProfile ->
                    val motion = SharedMotion(shared, this)
                    val user = GoogleUser("exemplo@example.com", "Conta de exemplo", null)
                    if (showProfile) ProfileScreen(user, state, motion, {}, {}, {}, {})
                    else HomeScreen(state, user, motion, {}, {}, {}, {}, {})
                }
            }
        }
    }
}

@Preview(name = "Início claro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun HomeLightPreview() = PreviewContent(profile = false, dark = false)
@Preview(name = "Início escuro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun HomeDarkPreview() = PreviewContent(profile = false, dark = true)
@Preview(name = "Início tablet", widthDp = 1000, heightDp = 700, showBackground = true)
@Composable private fun TabletHomePreview() = PreviewContent(profile = false, dark = false)
@Preview(name = "Perfil claro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun ProfileLightPreview() = PreviewContent(profile = true, dark = false)
@Preview(name = "Perfil escuro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun ProfileDarkPreview() = PreviewContent(profile = true, dark = true)
@Preview(name = "Perfil fonte ampliada", widthDp = 360, heightDp = 800, fontScale = 1.5f)
@Composable private fun ProfileLargeFontPreview() = PreviewContent(profile = true, dark = false)
```


## app/src/debug/java/com/example/ui/login/LoginPreview.kt

```kotlin
package com.example.ui.login

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.data.repository.ThemeMode
import com.example.ui.theme.KepleraeTheme

@Preview(name = "Login claro", showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun LoginLightPreview() {
    KepleraeTheme(mode = ThemeMode.LIGHT, dynamicColor = false) {
        LoginScreen(busy = false, error = null, onGoogleSignIn = {})
    }
}

@Preview(name = "Login escuro", showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun LoginDarkPreview() {
    KepleraeTheme(mode = ThemeMode.DARK, dynamicColor = false) {
        LoginScreen(busy = false, error = null, onGoogleSignIn = {})
    }
}

@Preview(name = "Tablet", showBackground = true, widthDp = 960, heightDp = 600)
@Preview(name = "Texto ampliado", showBackground = true, widthDp = 360, heightDp = 740, fontScale = 1.5f)
@Composable
private fun LoginTabletPreview() {
    KepleraeTheme(mode = ThemeMode.LIGHT, dynamicColor = false) {
        LoginScreen(busy = true, error = null, onGoogleSignIn = {})
    }
}
```


## app/src/debug/java/com/example/ui/theme/ThemePreview.kt

```kotlin
package com.example.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.data.repository.ThemeMode

/** Amostra do tema; não é uma nova tela do app. */
@Composable
private fun ThemeSample(dark: Boolean) {
    KepleraeTheme(mode = if (dark) ThemeMode.DARK else ThemeMode.LIGHT, dynamicColor = false) {
        Surface {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Kepleræ", style = MaterialTheme.typography.displayLarge)
                Text("Seu espaço de estudo", style = MaterialTheme.typography.headlineSmall)
                Text("Aulas, PDFs e áudios no seu ritmo.", style = MaterialTheme.typography.bodyLarge)
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Continuar aprendendo", style = MaterialTheme.typography.titleLarge)
                        Text("Cores, formas e tipografia compartilhadas.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = {}) { Text("Começar") }
                    FilledTonalButton(onClick = {}) { Text("Biblioteca") }
                }
            }
        }
    }
}

@Preview(name = "Kepleræ · claro", widthDp = 420, showBackground = true)
@Composable private fun LightThemePreview() = ThemeSample(dark = false)

@Preview(name = "Kepleræ · escuro", widthDp = 420, showBackground = true)
@Composable private fun DarkThemePreview() = ThemeSample(dark = true)
```


## app/src/main/AndroidManifest.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />


    <!-- Visibilidade do provedor de fontes a partir do Android 11. -->
    <queries>
        <provider android:authorities="com.google.android.gms.fonts" />
    </queries>

    <application
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.MyApplication">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:theme="@style/Theme.MyApplication">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
```


## app/src/main/java/com/example/MainActivity.kt

```kotlin
package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.StudyViewModel
import com.example.data.auth.GoogleLoginViewModel
import com.example.ui.KepleraeApp
import com.example.ui.login.LoginRoute
import com.example.ui.theme.KepleraeTheme
import com.example.ui.theme.isDarkMode

class MainActivity : ComponentActivity() {
    private val viewModel: StudyViewModel by viewModels()
    private val loginViewModel: GoogleLoginViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            val login by loginViewModel.state.collectAsStateWithLifecycle()
            val dark = isDarkMode(state.theme)
            SideEffect {
                val style = if (dark) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                    else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            KepleraeTheme(state.theme, state.dynamicColor) {
                if (login.user == null) LoginRoute(loginViewModel)
                else KepleraeApp(state, viewModel, login.user, loginViewModel::signOut)
            }
        }
    }
}
```


## app/src/main/java/com/example/data/auth/GoogleLoginConfiguration.kt

```kotlin
package com.example.data.auth

/** Valida o formato do ID público. O tipo Web deve ser conferido no Google Cloud. */
internal object GoogleLoginConfiguration {
    fun isWebClientId(value: String): Boolean =
        value.matches(Regex("[A-Za-z0-9_-]+\\.apps\\.googleusercontent\\.com"))
}
```


## app/src/main/java/com/example/data/auth/GoogleLoginViewModel.kt

```kotlin
package com.example.data.auth

import android.accounts.Account
import android.app.Application
import android.app.PendingIntent
import android.content.Intent
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialProviderConfigurationException
import androidx.credentials.exceptions.GetCredentialUnsupportedException
import androidx.credentials.exceptions.NoCredentialException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.drive.DriveSession
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

data class GoogleLoginState(
    val user: GoogleUser? = null,
    val busy: Boolean = false,
    val error: String? = null,
    val driveResolution: PendingIntent? = null,
)

/**
 * Credential Manager identifica a conta; AuthorizationClient autoriza o Drive.
 * Um ID token do Google nunca é usado como access token da API do Drive.
 * Não há Activity, ID token ou refresh token guardado neste ViewModel.
 */
class GoogleLoginViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext = application.applicationContext
    private val authorizationClient = Identity.getAuthorizationClient(appContext)
    private val _state = MutableStateFlow(GoogleLoginState())
    val state = _state.asStateFlow()
    private var pendingUser: GoogleUser? = null
    private var operation = 0L

    fun beginSignIn(): Boolean {
        if (_state.value.busy) return false // Impede duas folhas de conta simultâneas.
        operation++
        pendingUser = null
        _state.value = GoogleLoginState(busy = true)
        return true
    }

    fun cancelCredentialRequest() {
        // Se o Credential Manager for cancelado pela recriação da tela, pode tentar de novo.
        if (pendingUser == null && _state.value.busy) {
            _state.value = GoogleLoginState()
        }
    }

    fun credentialFailure(error: Throwable) {
        pendingUser = null
        _state.value = GoogleLoginState(error = loginErrorMessage(error))
    }

    fun configurationMissing() {
        _state.value = GoogleLoginState(
            error = "A entrada Google ainda não foi configurada nesta versão do app. Preencha o ID OAuth do tipo Web antes de gerar o APK.",
        )
    }

    fun authorizeDrive(user: GoogleUser) {
        pendingUser = user
        val requestId = operation
        viewModelScope.launch {
            try {
                val request = AuthorizationRequest.builder()
                    // A mesma conta escolhida em Entrar com Google, inclusive com várias contas.
                    .setAccount(Account(user.email, "com.google"))
                    .setRequestedScopes(listOf(Scope(DRIVE_READONLY)))
                    .build()
                val result = authorizationClient.authorize(request).await()
                if (requestId != operation) return@launch
                if (result.hasResolution()) {
                    val pending = result.pendingIntent
                        ?: error("Não foi possível iniciar a autorização de leitura do Drive.")
                    _state.value = GoogleLoginState(busy = true, driveResolution = pending)
                } else {
                    completeDriveAuthorization(result)
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                if (requestId == operation) credentialFailure(error)
            }
        }
    }

    /** Consome a solicitação antes de abrir a folha, evitando repetições em recomposição. */
    fun consumeDriveResolution() {
        _state.value = _state.value.copy(driveResolution = null)
    }

    fun receiveDriveResult(data: Intent?, wasSuccessful: Boolean) {
        if (pendingUser == null) return // Ignora resultados de uma sessão já encerrada.
        if (!wasSuccessful || data == null) {
            pendingUser = null
            _state.value = GoogleLoginState(
                error = "A leitura do Drive não foi autorizada. Toque em Entrar com Google para tentar novamente.",
            )
            return
        }
        try {
            completeDriveAuthorization(authorizationClient.getAuthorizationResultFromIntent(data))
        } catch (error: Exception) {
            credentialFailure(error)
        }
    }

    private fun completeDriveAuthorization(result: AuthorizationResult) {
        val user = pendingUser ?: error("A conta escolhida não está mais disponível.")
        val token = result.accessToken.orEmpty()
        check(token.isNotBlank()) { "O Google não retornou a autorização de leitura do Drive." }
        // Mantém a integração nativa 1.2.2: o restante do app lê DriveSession.
        DriveSession.accessToken = token
        DriveSession.revision++
        pendingUser = null
        _state.value = GoogleLoginState(user = user)
    }

    /** Saída pelo perfil: encerra a sessão local e limpa a escolha de conta no provedor Google. */
    fun signOut() {
        operation++ // Respostas atrasadas não podem restaurar a sessão encerrada.
        pendingUser = null
        DriveSession.clear()
        _state.value = GoogleLoginState(busy = true)
        viewModelScope.launch {
            try {
                CredentialManager.create(appContext)
                    .clearCredentialState(ClearCredentialStateRequest())
                _state.value = GoogleLoginState()
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                // A sessão local sempre termina, mesmo se o provedor estiver indisponível.
                _state.value = GoogleLoginState(
                    error = "Você saiu do app. O Google não conseguiu limpar a seleção de conta; escolha a conta novamente na próxima entrada.",
                )
            }
        }
    }

    private companion object {
        const val DRIVE_READONLY = "https://www.googleapis.com/auth/drive.readonly"
    }
}

internal fun loginErrorMessage(error: Throwable): String = when (error) {
    is GetCredentialCancellationException -> "Entrada cancelada. Você pode tentar novamente."
    is NoCredentialException -> "Nenhuma conta foi disponibilizada. Confira os Serviços do Google Play e tente novamente."
    is GetCredentialProviderConfigurationException -> "O provedor Google não está disponível. Atualize os Serviços do Google Play neste aparelho."
    is GetCredentialUnsupportedException -> "Este aparelho não oferece o provedor de entrada Google necessário."
    is ApiException -> when (error.statusCode) {
        7 -> "Não foi possível conectar ao Google. Confira sua conexão e tente novamente."
        10 -> "O Google recusou o cadastro do app (10). Confira o cliente OAuth Android, o pacote e o SHA-1 deste APK."
        16 -> "Autorização cancelada. Toque em Entrar com Google para tentar novamente."
        8 -> "O Google retornou um erro interno (8). Tente novamente; esse código sozinho não identifica erro no OAuth."
        else -> "Não foi possível autorizar o Drive. Código Google: ${error.statusCode}. Confira os usuários de teste e os clientes OAuth no mesmo projeto."
    }
    else -> "Não foi possível concluir a entrada. Confira sua conexão, o ID OAuth Web e os clientes OAuth no Google Cloud."
}
```


## app/src/main/java/com/example/data/auth/GoogleUser.kt

```kotlin
package com.example.data.auth

/** Somente dados de apresentação. Tokens não são persistidos neste modelo. */
data class GoogleUser(
    val email: String,
    val displayName: String,
    val photoUrl: String?,
)
```


## app/src/main/java/com/example/data/drive/DriveRepository.kt

```kotlin
package com.example.data.drive

import android.content.Context
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class DriveFile(val id: String, val name: String, val mimeType: String, val resourceKey: String = "",
    val canDownload: Boolean = true, val size: Long = 0) {
    val folder: Boolean get() = mimeType == "application/vnd.google-apps.folder"
    val contentType: ContentType? get() = when {
        mimeType == "application/pdf" || name.endsWith(".pdf", true) -> ContentType.PDF
        mimeType.startsWith("video/") -> ContentType.VIDEO
        mimeType.startsWith("audio/") -> ContentType.AUDIO
        else -> null
    }
    fun studyItem(parent: StudyItem): StudyItem = parent.copy(
        id = if (name.equals(parent.filename, true)) parent.id else "drive-$id",
        title = name.substringBeforeLast('.'), filename = name,
        type = contentType ?: parent.type, linkKind = LinkKind.FILE, driveFileId = id,
        url = "https://drive.google.com/file/d/$id/view" + if (resourceKey.isBlank()) "" else "?resourcekey=$resourceKey",
        note = "")
}

class DriveRepository(private val context: Context, val credentials: DriveCredentials) {
    private val certificate = installedCertificate(context)
    fun headers(id: String, resourceKey: String) = credentials.headers(context.packageName, certificate, id, resourceKey)
    private fun connection(url: String, id: String, resourceKey: String): HttpURLConnection {
        check(credentials.configured) { "Configure sua chave de API ou autorize uma conta Google." }
        return (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 30000
            headers(id, resourceKey).forEach { (key, value) -> setRequestProperty(key, value) }
        }
    }
    private fun checkResponse(connection: HttpURLConnection) {
        if (connection.responseCode in 200..299) return
        val body = connection.errorStream?.bufferedReader()?.use { it.readText().take(65536) }.orEmpty()
        val reason = runCatching {
            val error = JSONObject(body).getJSONObject("error")
            error.optJSONArray("errors")?.optJSONObject(0)?.optString("reason").orEmpty().ifBlank {
                error.optJSONArray("details")?.optJSONObject(0)?.optString("reason").orEmpty()
            }
        }.getOrDefault("")
        throw IOException(DriveRequests.errorMessage(connection.responseCode, reason))
    }
    private suspend fun json(url: String, id: String, resourceKey: String): JSONObject = withContext(Dispatchers.IO) {
        val request = connection(url, id, resourceKey)
        try { checkResponse(request); currentCoroutineContext().ensureActive()
            JSONObject(request.inputStream.bufferedReader().use { it.readText() })
        } finally { request.disconnect() }
    }
    private fun parse(row: JSONObject): DriveFile {
        val shortcut = row.optJSONObject("shortcutDetails")
        return DriveFile(shortcut?.optString("targetId")?.takeIf { it.isNotBlank() } ?: row.getString("id"),
            row.getString("name"), shortcut?.optString("targetMimeType")?.takeIf { it.isNotBlank() } ?: row.getString("mimeType"),
            shortcut?.optString("targetResourceKey")?.takeIf { it.isNotBlank() } ?: row.optString("resourceKey"),
            row.optJSONObject("capabilities")?.optBoolean("canDownload", true) ?: true, row.optString("size").toLongOrNull() ?: 0)
    }
    suspend fun metadata(id: String, resourceKey: String): DriveFile {
        var file = parse(json(DriveRequests.file(id), id, resourceKey))
        if (file.id != id) return parse(json(DriveRequests.file(file.id), file.id, file.resourceKey))
        return file.copy(resourceKey = file.resourceKey.ifBlank { resourceKey })
    }
    suspend fun folder(id: String, resourceKey: String): List<DriveFile> {
        val files = mutableListOf<DriveFile>(); var token = ""
        do {
            currentCoroutineContext().ensureActive()
            val page = json(DriveRequests.folder(id, token), id, resourceKey)
            val rows = page.optJSONArray("files")
            if (rows != null) for (i in 0 until rows.length()) files += parse(rows.getJSONObject(i))
            token = page.optString("nextPageToken")
        } while (token.isNotBlank())
        return files.distinctBy { it.id }.sortedWith(compareBy<DriveFile> { !it.folder }.thenBy { searchable(it.name) })
    }
    suspend fun pdf(file: DriveFile, destination: File, onProgress: (Long, Long) -> Unit): File = withContext(Dispatchers.IO) {
        require(file.canDownload) { "O proprietário bloqueou o acesso ao conteúdo pela API." }
        val request = connection(DriveRequests.file(file.id, true), file.id, file.resourceKey)
        try {
            checkResponse(request)
            val size = request.contentLengthLong; var received = 0L; var lastUpdate = 0L
            request.inputStream.use { input -> destination.outputStream().use { output ->
                val buffer = ByteArray(32768)
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val count = input.read(buffer); if (count < 0) break
                    output.write(buffer, 0, count); received += count
                    if (received - lastUpdate >= 262144) { onProgress(received, size); lastUpdate = received }
                }
            } }
            currentCoroutineContext().ensureActive()
            require(destination.inputStream().use { String(it.readNBytesCompat(5), Charsets.US_ASCII) } == "%PDF-") {
                "O Drive não retornou um PDF válido." }
            onProgress(received, size); destination
        } catch (e: Exception) { destination.delete(); throw e }
        finally { request.disconnect() }
    }
}
private fun java.io.InputStream.readNBytesCompat(length: Int): ByteArray {
    val result = ByteArray(length); var offset = 0
    while (offset < length) { val n = read(result, offset, length - offset); if (n < 0) break; offset += n }
    return result.copyOf(offset)
}
```


## app/src/main/java/com/example/data/drive/DriveRequests.kt

```kotlin
package com.example.data.drive

import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder

data class DriveCredentials(val apiKey: String = "", val accessToken: String = "") {
    val configured: Boolean get() = apiKey.isNotBlank() || accessToken.isNotBlank()
    fun headers(packageName: String, certificate: String, id: String, resourceKey: String): Map<String, String> = buildMap {
        if (accessToken.isNotBlank()) put("Authorization", "Bearer $accessToken")
        else if (apiKey.isNotBlank()) put("X-Goog-Api-Key", apiKey)
        put("X-Android-Package", packageName)
        if (certificate.isNotBlank()) put("X-Android-Cert", certificate)
        if (resourceKey.isNotBlank()) put("X-Goog-Drive-Resource-Keys", "$id/$resourceKey")
    }
}

object DriveRequests {
    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8")
    fun file(id: String, media: Boolean = false): String {
        require(id.matches(Regex("[A-Za-z0-9_-]+"))) { "Identificador do arquivo inválido." }
        val fields = "id,name,mimeType,size,resourceKey,capabilities(canDownload),shortcutDetails(targetId,targetMimeType,targetResourceKey)"
        return "https://www.googleapis.com/drive/v3/files/$id?" +
            if (media) "alt=media&supportsAllDrives=true" else "supportsAllDrives=true&fields=${encode(fields)}"
    }
    fun folder(id: String, pageToken: String = ""): String {
        require(id.matches(Regex("[A-Za-z0-9_-]+")))
        val query = "'$id' in parents and trashed = false"
        val fields = "nextPageToken,files(id,name,mimeType,size,resourceKey,capabilities(canDownload),shortcutDetails(targetId,targetMimeType,targetResourceKey))"
        return "https://www.googleapis.com/drive/v3/files?q=${encode(query)}&pageSize=100" +
            "&supportsAllDrives=true&includeItemsFromAllDrives=true&fields=${encode(fields)}" +
            if (pageToken.isBlank()) "" else "&pageToken=${encode(pageToken)}"
    }
    fun resourceKey(url: String): String = runCatching {
        URI(url).rawQuery.orEmpty().split('&').firstNotNullOfOrNull { part ->
            val pair = part.split('=', limit = 2)
            if (pair.size == 2 && pair[0].equals("resourcekey", true)) URLDecoder.decode(pair[1], "UTF-8") else null
        }.orEmpty()
    }.getOrDefault("")
    fun folderId(url: String): String = runCatching {
        URI(url).path.substringAfter("/drive/folders/").substringBefore('/')
            .takeIf { it.matches(Regex("[A-Za-z0-9_-]+")) }.orEmpty()
    }.getOrDefault("")
    fun errorMessage(status: Int, reason: String): String = when {
        status == 401 -> "A autorização Google expirou. Autorize sua conta novamente."
        reason in setOf("keyInvalid", "API_KEY_INVALID", "badRequest") -> "Confira a chave de API nas configurações do Drive."
        reason in setOf("accessNotConfigured", "SERVICE_DISABLED") -> "Ative a Google Drive API no projeto da sua chave."
        reason in setOf("downloadQuotaExceeded", "rateLimitExceeded", "userRateLimitExceeded", "quotaExceeded") || status == 429 ->
            "O Drive atingiu um limite de acesso. Aguarde e tente novamente."
        reason in setOf("cannotDownloadFile", "fileNotDownloadable", "downloadRestrictedForRevision") ->
            "O proprietário bloqueou o acesso ao conteúdo pela API."
        status == 404 -> "Arquivo não encontrado ou sem acesso. Para arquivos privados, autorize a conta Google correta."
        status == 403 -> "Acesso negado. Confira as restrições da chave ou autorize a conta Google que pode acessar o arquivo."
        status >= 500 -> "O Drive está temporariamente indisponível. Tente novamente."
        else -> "Não foi possível carregar este material. Confira a conexão e tente novamente."
    }
    fun errorReason(body: String): String = Regex("\"reason\"\\s*:\\s*\"([^\"]+)\"")
        .find(body)?.groupValues?.get(1).orEmpty()
}
```


## app/src/main/java/com/example/data/drive/DriveSettings.kt

```kotlin
package com.example.data.drive

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object DriveSession {
    // Short-lived Google access tokens stay in memory; no refresh token or client secret is stored.
    var accessToken by mutableStateOf("")
    var revision by mutableStateOf(0)
    fun clear() { accessToken = ""; revision++ }
}

class DriveSettings(private val context: Context, preferenceName: String = "keplerae_drive") {
    private val prefs = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE)
    private fun secret(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey("keplerae_drive_key", null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder("keplerae_drive_key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    fun apiKey(): String = runCatching {
        val encrypted = prefs.getString("api_key", null) ?: return@runCatching ""
        val parts = encrypted.split(':', limit = 2)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secret(), GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)))
        String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), Charsets.UTF_8)
    }.getOrDefault("")
    fun saveApiKey(value: String) {
        if (value.isBlank()) prefs.edit().remove("api_key").apply()
        else {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, secret())
            val encrypted = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" +
                Base64.encodeToString(cipher.doFinal(value.trim().toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
            prefs.edit().putString("api_key", encrypted).apply()
        }
        DriveSession.revision++
    }
    fun credentials() = DriveCredentials(apiKey(), DriveSession.accessToken)
}

@Suppress("DEPRECATION")
fun installedCertificate(context: Context): String = runCatching {
    val signatures = if (Build.VERSION.SDK_INT >= 28) {
        val info = context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        info.signingInfo?.apkContentsSigners
    } else context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures
    val certificate = signatures?.firstOrNull()?.toByteArray() ?: return@runCatching ""
    MessageDigest.getInstance("SHA-1").digest(certificate).joinToString("") { "%02X".format(it) }
}.getOrDefault("")
```


## app/src/main/java/com/example/data/model/StudyItem.kt

```kotlin
package com.example.data.model

import java.net.URI
import java.text.Normalizer

enum class ContentType(val label: String) { VIDEO("Aulas"), PDF("PDFs"), AUDIO("Áudios") }
enum class LinkKind { FILE, FOLDER }

data class StudyItem(
    val id: String, val title: String, val filename: String,
    val subjectId: String, val folderPath: List<String>, val type: ContentType,
    val url: String, val linkKind: LinkKind, val driveFileId: String,
    val note: String, val source: String
) {
    val previewUrl: String get() = if (linkKind == LinkKind.FILE && driveFileId.isNotBlank())
        "https://drive.google.com/file/d/$driveFileId/preview" else url
    fun matches(query: String): Boolean = searchable("$title $filename ${folderPath.joinToString(" ")} $subjectId")
        .contains(searchable(query.trim()))
}
fun searchable(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
    .replace(Regex("\\p{M}+"), "").lowercase(java.util.Locale.ROOT)
fun isAllowedDriveUrl(url: String): Boolean = runCatching {
    val uri = URI(url)
    uri.scheme == "https" && uri.host == "drive.google.com" && uri.userInfo == null &&
        (uri.path.startsWith("/file/d/") || uri.path.startsWith("/drive/folders/"))
}.getOrDefault(false)
fun itemsInPath(items: List<StudyItem>, path: List<String>): List<StudyItem> =
    items.filter { it.folderPath.take(path.size) == path }

data class Subject(val id: String, val name: String, val subtitle: String, val monogram: String)
object Subjects {
    val all = listOf(
        Subject("fisioterapia", "Fisioterapia", "HU Brasil · módulos e simulados", "F"),
        Subject("portugues", "Português", "Gramática e interpretação", "P"),
        Subject("matematica", "Matemática e Raciocínio Lógico", "Lógica, teoria e questões", "M"),
        Subject("hu_legislacao", "HU Legislação", "Normas e legislação EBSERH", "H"),
        Subject("sus", "SUS", "Saúde pública e políticas", "S"),
        Subject("profisio", "Profisio", "Artigos, aulas e áudios por ciclo", "Pr")
    )
    fun get(id: String) = all.first { it.id == id }
}
```


## app/src/main/java/com/example/data/repository/AppearancePreferences.kt

```kotlin
package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.SharedPreferencesMigration
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

// Uma única instância por arquivo, inclusive após recriações da Activity.
private val Context.appearanceDataStore by preferencesDataStore(
    name = "keplerae_appearance",
    produceMigrations = { context ->
        // Migra apenas aparência. Favoritos, conclusões e histórico continuam intactos.
        listOf(SharedPreferencesMigration(context, "keplerae", setOf("theme", "dynamic_color")))
    },
)

data class Appearance(val theme: ThemeMode = ThemeMode.SYSTEM, val dynamicColor: Boolean = true)

class AppearancePreferences(context: Context) {
    private val store = context.applicationContext.appearanceDataStore
    private val themeKey = stringPreferencesKey("theme")
    private val dynamicKey = booleanPreferencesKey("dynamic_color")
    val appearance = store.data.catch { error ->
        if (error is IOException) emit(emptyPreferences()) else throw error
    }.map { prefs ->
        Appearance(
            runCatching { ThemeMode.valueOf(prefs[themeKey] ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM),
            prefs[dynamicKey] ?: true,
        )
    }
    suspend fun setTheme(theme: ThemeMode) { store.edit { it[themeKey] = theme.name } }
    suspend fun setDynamicColor(enabled: Boolean) { store.edit { it[dynamicKey] = enabled } }
}
```


## app/src/main/java/com/example/data/repository/ItemOrder.kt

```kotlin
package com.example.data.repository

/** Ignora IDs removidos, evita duplicatas e acrescenta novos materiais no fim. */
fun reconcileOrder(currentIds: List<String>, savedIds: List<String>): List<String> {
    val available = currentIds.toSet()
    return (savedIds.filter { it in available } + currentIds).distinct()
}

/** Reordena somente o conjunto visível; materiais ocultos mantêm sua posição. */
fun mergeVisibleOrder(fullOrder: List<String>, visibleOrder: List<String>): List<String> {
    val visible = visibleOrder.distinct().filter { it in fullOrder }.toSet()
    val iterator = visibleOrder.distinct().filter { it in visible }.iterator()
    return fullOrder.map { if (it in visible && iterator.hasNext()) iterator.next() else it }
}

/** Índices são resolvidos pelas chaves; cabeçalhos de LazyColumn não interferem. */
fun moveId(order: List<String>, from: String, to: String): List<String> {
    val source = order.indexOf(from)
    val target = order.indexOf(to)
    if (source < 0 || target < 0 || source == target) return order
    return order.toMutableList().apply { add(target, removeAt(source)) }
}
```


## app/src/main/java/com/example/data/repository/StudyViewModel.kt

```kotlin
package com.example.data.repository

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

enum class ThemeMode(val label: String) { SYSTEM("Sistema"), LIGHT("Claro"), DARK("Escuro") }
data class StudyState(
    val items: List<StudyItem> = emptyList(),
    val favorites: Set<String> = emptySet(),
    val completed: Set<String> = emptySet(),
    val accessed: Map<String, Long> = emptyMap(),
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val itemOrder: List<String> = emptyList(),
    val loading: Boolean = true,
    val error: String? = null
)
class StudyViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application
    private val preferences = application.getSharedPreferences("keplerae", 0)
    private val appearancePreferences = AppearancePreferences(application)
    private val mutableState = MutableStateFlow(StudyState(
        favorites = preferences.getStringSet("favorites", emptySet())!!.toSet(),
        completed = preferences.getStringSet("completed", emptySet())!!.toSet(),
        accessed = readAccessed(),
        theme = runCatching { ThemeMode.valueOf(preferences.getString("theme", "SYSTEM")!!) }.getOrDefault(ThemeMode.SYSTEM),
        dynamicColor = preferences.getBoolean("dynamic_color", true),
        itemOrder = runCatching {
            val array = JSONArray(preferences.getString("item_order", "[]")!!)
            List(array.length()) { array.getString(it) }
        }.getOrDefault(emptyList()),
    ))
    val state = mutableState.asStateFlow()
    init {
        reload()
        viewModelScope.launch {
            appearancePreferences.appearance.collect { appearance ->
                mutableState.update { it.copy(theme = appearance.theme, dynamicColor = appearance.dynamicColor) }
            }
        }
    }
    fun reload() {
        mutableState.value = mutableState.value.copy(loading = true, error = null)
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching {
                val json = JSONArray(app.assets.open("catalog.json").bufferedReader().use { it.readText() })
                List(json.length()) { index ->
                    val row = json.getJSONObject(index)
                    val path = row.getJSONArray("folderPath")
                    StudyItem(row.getString("id"), row.getString("title"), row.getString("filename"),
                        row.getString("subjectId"), List(path.length()) { path.getString(it) },
                        ContentType.valueOf(row.getString("type")), row.getString("url"),
                        LinkKind.valueOf(row.getString("linkKind")), row.getString("driveFileId"),
                        row.getString("note"), row.getString("source"))
                }.also { rows -> require(rows.all { isAllowedDriveUrl(it.url) }) }
            } }
            mutableState.value = result.fold(
                onSuccess = { mutableState.value.copy(items = it, loading = false) },
                onFailure = { mutableState.value.copy(loading = false, error = "Não foi possível carregar a biblioteca.") }
            )
        }
    }
    private fun readAccessed(): Map<String,Long> = runCatching {
        val json = JSONObject(preferences.getString("accessed", "{}")!!)
        json.keys().asSequence().associateWith { json.getLong(it) }
    }.getOrDefault(emptyMap())
    fun toggleFavorite(id: String) {
        val next = mutableState.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        preferences.edit().putStringSet("favorites", next).apply()
        mutableState.value = mutableState.value.copy(favorites = next)
    }
    fun toggleCompleted(id: String) {
        val next = mutableState.value.completed.toMutableSet().apply { if (!add(id)) remove(id) }
        preferences.edit().putStringSet("completed", next).apply()
        mutableState.value = mutableState.value.copy(completed = next)
    }
    fun recordAccess(id: String) {
        val next = mutableState.value.accessed + (id to System.currentTimeMillis())
        preferences.edit().putString("accessed", JSONObject(next).toString()).apply()
        mutableState.value = mutableState.value.copy(accessed = next)
    }
    fun setTheme(theme: ThemeMode) {
        mutableState.value = mutableState.value.copy(theme = theme)
        viewModelScope.launch { appearancePreferences.setTheme(theme) }
    }
    fun setDynamicColor(enabled: Boolean) {
        mutableState.value = mutableState.value.copy(dynamicColor = enabled)
        viewModelScope.launch { appearancePreferences.setDynamicColor(enabled) }
    }
    fun saveVisibleOrder(visibleIds: List<String>) {
        val current = mutableState.value
        val fullOrder = reconcileOrder(current.items.map { it.id }, current.itemOrder)
        val next = mergeVisibleOrder(fullOrder, visibleIds)
        preferences.edit().putString("item_order", JSONArray(next).toString()).apply()
        mutableState.update { it.copy(itemOrder = next) }
    }
}
```


## app/src/main/java/com/example/ui/CatalogScreen.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.components.*
import com.example.ui.home.SubjectTile
import com.example.ui.theme.isDarkMode
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState

private fun folderKey(subjectId: String, path: List<String>) = "folder/$subjectId/${path.joinToString("\u001f")}"

@Composable fun CatalogScreen(state: StudyState, destination: Destination, subject: Subject?, path: List<String>,
    motion: SharedMotion, onSelectSubject: (Subject) -> Unit, onFolder: (String) -> Unit,
    onOpen: (StudyItem) -> Unit, onFavorite: (String) -> Unit, onCompleted: (String) -> Unit,
    onRefresh: () -> Unit, onSaveOrder: (List<String>) -> Unit) {
    var query by rememberSaveable(destination, subject?.id) { mutableStateOf("") }
    var filter by rememberSaveable(destination, subject?.id) { mutableStateOf("all") }
    var typeName by rememberSaveable(destination, subject?.id) { mutableStateOf("") }
    val type = destination.type ?: typeName.takeIf { it.isNotBlank() }?.let(ContentType::valueOf)
    val base = remember(state.items, destination, subject, type) { state.items.filter {
        (subject == null || it.subjectId == subject.id) && (type == null || it.type == type)
    } }
    val filtered = remember(base, state.favorites, state.completed, filter, query) { base.filter {
        it.matches(query) && when (filter) {
            "favorites" -> it.id in state.favorites
            "completed" -> it.id in state.completed
            "pending" -> it.id !in state.completed
            else -> true
        }
    } }
    val browsing = query.isBlank() && filter == "all"
    val showSubjects = browsing && subject == null
    val scoped = if (subject != null && browsing) itemsInPath(filtered, path) else filtered
    val folders = if (subject != null && browsing)
        scoped.mapNotNull { it.folderPath.getOrNull(path.size) }.distinct() else emptyList()
    val leaves = if (subject != null && browsing) scoped.filter { it.folderPath.size == path.size } else scoped
    val availableIds = leaves.map { it.id }
    var orderedIds by remember(destination, subject?.id, path, query, filter, typeName) {
        mutableStateOf(reconcileOrder(availableIds, state.itemOrder))
    }
    LaunchedEffect(availableIds, state.itemOrder) { orderedIds = reconcileOrder(availableIds, state.itemOrder) }
    val byId = remember(leaves) { leaves.associateBy { it.id } }
    val orderedRows = orderedIds.mapNotNull(byId::get)
    val listState = rememberLazyListState()
    LaunchedEffect(path, query, filter, subject?.id, destination, typeName) { listState.scrollToItem(0) }
    val reorderState = rememberReorderableLazyListState(listState) { from, to ->
        orderedIds = moveId(orderedIds, from.key as? String ?: "", to.key as? String ?: "")
    }
    fun moveAccessible(id: String, direction: Int): Boolean {
        val index = orderedIds.indexOf(id)
        val target = orderedIds.getOrNull(index + direction) ?: return false
        orderedIds = moveId(orderedIds, id, target)
        onSaveOrder(orderedIds)
        return true
    }
    ExpressiveRefreshBox(state.loading, onRefresh, Modifier.fillMaxSize()) {
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item(key = "header") {
                CatalogHeader(state, subject, path, destination, scoped.size, motion)
            }
            item(key = "search") {
                OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("catalog_search"),
                    placeholder = { Text("Buscar aulas, arquivos e pastas") }, leadingIcon = { Icon(Icons.Outlined.Search, null) },
                    trailingIcon = { if (query.isNotBlank()) IconButton(onClick = { query = "" }) {
                        Icon(Icons.Filled.Close, "Limpar busca")
                    } }, shape = RoundedCornerShape(28.dp))
            }
            item(key = "filters") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("all" to "Todos", "favorites" to "Favoritos", "pending" to "Pendentes", "completed" to "Concluídos")) { (id, label) ->
                        FilterChip(selected = filter == id, onClick = { filter = id }, label = { Text(label) },
                            leadingIcon = { if (filter == id) Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) })
                    }
                }
            }
            if (subject != null && destination.type == null) item(key = "formats") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = typeName.isBlank(), onClick = { typeName = "" }, label = { Text("Todos os formatos") }) }
                    items(ContentType.entries) { t -> FilterChip(selected = typeName == t.name,
                        onClick = { typeName = t.name }, label = { Text(t.label) }) }
                }
            }
            if (showSubjects) {
                items(Subjects.all.filter { s -> base.any { it.subjectId == s.id } }.chunked(2),
                    key = { "subjects/${it.first().id}" }) { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { s -> SubjectTile(s, state.copy(items = base), motion, Modifier.weight(1f)) { onSelectSubject(s) } }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            } else {
                items(folders, key = { "folder_row/$it" }) { name ->
                    val count = scoped.count { it.folderPath.getOrNull(path.size) == name }
                    val sharedKey = folderKey(subject!!.id, path + name)
                    Card(onClick = { onFolder(name) },
                        modifier = Modifier.fillMaxWidth().then(motion.bounds("$sharedKey/container")),
                        colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerHigh)) {
                        Row(Modifier.padding(18.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.secondaryContainer) {
                                Icon(Icons.Outlined.Folder, null,
                                    motion.element("$sharedKey/art").padding(14.dp).size(28.dp),
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer)
                            }
                            Column(Modifier.weight(1f)) {
                                Text(name, style = MaterialTheme.typography.titleMedium, modifier = motion.bounds("$sharedKey/name"))
                                Text("$count materiais", style = MaterialTheme.typography.bodySmall)
                            }
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                        }
                    }
                }
                if (orderedRows.isNotEmpty()) item(key = "reorder_help") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Seus materiais", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        HelpTooltip("Organizar materiais", "Arraste a alça à direita para reordenar. " +
                            "Toque na seta para expandir os detalhes. A ordem fica salva neste aparelho.")
                    }
                }
                items(orderedRows, key = { it.id }) { item ->
                    ReorderableItem(reorderState, key = item.id) { dragging ->
                        val elevation by animateDpAsState(if (dragging) 8.dp else 0.dp, label = "drag_elevation")
                        MaterialRow(item, state, onOpen, onFavorite, onCompleted, elevation,
                            modifier = Modifier.semantics {
                                customActions = listOf(
                                    CustomAccessibilityAction("Mover para cima") { moveAccessible(item.id, -1) },
                                    CustomAccessibilityAction("Mover para baixo") { moveAccessible(item.id, 1) })
                            }, dragHandle = {
                                IconButton(onClick = {}, modifier = Modifier.draggableHandle(
                                    onDragStopped = { onSaveOrder(orderedIds) })) {
                                    Icon(Icons.Outlined.DragHandle, "Arrastar para reordenar")
                                }
                            })
                    }
                }
            }
            if (scoped.isEmpty()) item(key = "empty") {
                Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.SearchOff, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
                    Text("Nenhum material encontrado", style = MaterialTheme.typography.titleMedium)
                    Text("Tente outro termo ou ajuste os filtros.")
                }
            }
        }
    }
}

@Composable private fun CatalogHeader(state: StudyState, subject: Subject?, path: List<String>,
    destination: Destination, count: Int, motion: SharedMotion) {
    val sharedKey = when {
        subject == null -> null
        path.isEmpty() -> "subject/${subject.id}"
        else -> folderKey(subject.id, path)
    }
    val palette = subject?.let { subjectPalette(it.id, isDarkMode(state.theme)) }
    Surface(shape = MaterialTheme.shapes.extraLarge,
        color = palette?.first ?: MaterialTheme.colorScheme.primaryContainer,
        contentColor = palette?.second ?: MaterialTheme.colorScheme.onPrimaryContainer,
        modifier = Modifier.fillMaxWidth().then(if (sharedKey != null) motion.bounds("$sharedKey/container") else Modifier)) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (subject != null) {
                if (path.isEmpty()) SubjectArtwork(subject.id, palette!!.second,
                    motion.element("$sharedKey/art").size(96.dp))
                else Icon(Icons.Outlined.Folder, null, motion.element("$sharedKey/art").size(44.dp))
            }
            Text(path.lastOrNull() ?: subject?.name ?: destination.title,
                style = MaterialTheme.typography.headlineLarge,
                modifier = if (sharedKey != null) motion.bounds("$sharedKey/name") else Modifier)
            Text(if (path.isNotEmpty()) path.joinToString(" › ") else subject?.subtitle ?: when (destination) {
                Destination.PDFS -> "Artigos e materiais para sua leitura"
                Destination.AUDIO -> "Sua biblioteca de áudios"
                Destination.VIDEOS -> "Suas aulas, organizadas por matéria"
                else -> "Escolha uma matéria para começar"
            }, style = MaterialTheme.typography.bodyMedium)
            Text("$count materiais", style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable private fun MaterialRow(item: StudyItem, state: StudyState, onOpen: (StudyItem) -> Unit,
    onFavorite: (String) -> Unit, onCompleted: (String) -> Unit, elevation: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier, dragHandle: @Composable () -> Unit) {
    var expanded by rememberSaveable(item.id) { mutableStateOf(false) }
    val complete = item.id in state.completed
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow,
        shadowElevation = elevation, modifier = modifier.fillMaxWidth().animateContentSize()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(contentIcon(item.type), null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, style = MaterialTheme.typography.titleMedium)
                    Text(if (complete) "Concluído" else "${Subjects.get(item.subjectId).name} · ${item.type.label}",
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
                dragHandle()
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(onClick = { onOpen(item) }) {
                    Icon(if (item.linkKind == LinkKind.FOLDER) Icons.Outlined.FolderOpen else contentIcon(item.type), null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (item.linkKind == LinkKind.FOLDER) "Abrir pasta" else when (item.type) {
                        ContentType.VIDEO -> "Assistir"; ContentType.PDF -> "Ler PDF"; ContentType.AUDIO -> "Ouvir"
                    })
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { onFavorite(item.id) }) {
                    Icon(if (item.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        if (item.id in state.favorites) "Remover dos favoritos" else "Favoritar")
                }
                IconButton(onClick = { expanded = !expanded }, modifier = Modifier.testTag("expand_${item.id}")) {
                    Icon(if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                        if (expanded) "Recolher detalhes" else "Expandir detalhes")
                }
            }
            AnimatedVisibility(expanded, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 8.dp)) {
                    HorizontalDivider()
                    Text(item.filename, style = MaterialTheme.typography.bodySmall)
                    if (item.note.isNotBlank()) Text(item.note, style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(if (complete) "Material concluído" else "Marcar como concluído", style = MaterialTheme.typography.bodyMedium)
                        IconToggleButton(checked = complete, onCheckedChange = { onCompleted(item.id) }) {
                            Icon(if (complete) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircle,
                                if (complete) "Marcar como pendente" else "Marcar como concluído")
                        }
                    }
                }
            }
        }
    }
}

internal fun contentIcon(type: ContentType): ImageVector = when (type) {
    ContentType.VIDEO -> Icons.Outlined.PlayCircleOutline
    ContentType.PDF -> Icons.Outlined.Description
    ContentType.AUDIO -> Icons.Outlined.Headphones
}
```


## app/src/main/java/com/example/ui/DriveConfigDialog.kt

```kotlin
package com.example.ui

import android.accounts.Account
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Cloud
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.google.android.gms.common.api.ApiException
import androidx.compose.ui.unit.dp
import com.example.data.drive.*
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope

private fun authorizationFailure(error: Throwable): String {
    val code = (error as? ApiException)?.statusCode
    return when (code) {
        8 -> "O Google retornou erro interno (código 8). Tente novamente com conexão ativa. Esse código sozinho não identifica falha de cadastro OAuth."
        10 -> "Google recusou o cadastro do app (código 10). No Google Cloud, cadastre um cliente OAuth Android com o pacote e SHA-1 exibidos abaixo. Uma chave de API sozinha não permite conectar a conta."
        7 -> "Sem conexão com o Google (código 7). Confira a internet e tente novamente."
        16 -> "O Google devolveu cancelamento (código 16). Se você confirmou a conta, confira o cliente OAuth Android e os usuários de teste da tela de consentimento."
        else -> "Não foi possível autorizar a conta. Código Google: ${code ?: "indisponível"}. Confira o cliente OAuth Android, o SHA-1 e a tela de consentimento no Google Cloud."
    }
}

@Composable fun DriveConfigDialog(accountEmail: String? = null, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val settings = remember { DriveSettings(context) }
    var key by remember { mutableStateOf(settings.apiKey()) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    fun authorized(result: AuthorizationResult) {
        busy = false
        val token = result.accessToken.orEmpty()
        if (token.isBlank()) message = "A leitura dos arquivos não foi autorizada."
        else { DriveSession.accessToken = token; DriveSession.revision++; onDismiss() }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        runCatching { Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(result.data) }
            .onSuccess(::authorized).onFailure { busy = false; message = authorizationFailure(it) }
    }
    val fingerprint = remember { installedCertificate(context).chunked(2).joinToString(":") }
    AlertDialog(onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Cloud, null) },
        title = { Text("Conectar ao Google Drive") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Cole sua chave para abrir arquivos públicos diretamente no Kepleræ.")
                OutlinedTextField(value = key, onValueChange = { key = it; message = null },
                    label = { Text("Chave de API do Drive") }, singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Ocultar" else "Mostrar") } },
                    modifier = Modifier.fillMaxWidth())
                Text("A chave fica protegida neste dispositivo e não é incluída no projeto do GitHub.",
                    style = MaterialTheme.typography.bodySmall)
                HorizontalDivider()
                Text("Arquivos privados", style = MaterialTheme.typography.titleSmall)
                Text("Autorize a leitura pela conta Google que tem acesso aos materiais. Isso não permite alterar nem excluir seus arquivos.")
                OutlinedButton(enabled = !busy, onClick = {
                    busy = true; message = null
                    val request = AuthorizationRequest.builder()
                        .apply { accountEmail?.let { setAccount(Account(it, "com.google")) } }
                        .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.readonly"))).build()
                    Identity.getAuthorizationClient(context).authorize(request)
                        .addOnSuccessListener { result ->
                            if (result.hasResolution()) {
                                val pending = result.pendingIntent
                                if (pending == null) { busy = false; message = "Não foi possível iniciar a autorização." }
                                else runCatching { launcher.launch(IntentSenderRequest.Builder(pending.intentSender).build()) }
                                    .onFailure { busy = false; message = authorizationFailure(it) }
                            } else authorized(result)
                        }
                        .addOnFailureListener {
                            busy = false
                            message = authorizationFailure(it)
                        }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Aguardando Google…" else "Autorizar conta Google") }
                if (DriveSession.accessToken.isNotBlank()) TextButton(onClick = { DriveSession.clear(); message = "Acesso ao Drive desconectado. A conta do perfil não foi alterada." }) {
                    Text("Desconectar Drive")
                }
                if (message != null) Text(message!!, color = MaterialTheme.colorScheme.error)
                Text("Cadastro da chave / OAuth", style = MaterialTheme.typography.titleSmall)
                SelectionContainer { Column {
                    Text("Pacote: ${context.packageName}", style = MaterialTheme.typography.bodySmall)
                    Text("SHA-1: $fingerprint", style = MaterialTheme.typography.bodySmall)
                } }
                Text("Se sua chave tem restrição Android, use esses dados. A autorização de arquivos privados também exige um cliente OAuth Android com esse pacote e SHA-1.",
                    style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = {
            val cleaned = key.filterNot { it.isWhitespace() || Character.getType(it) == Character.FORMAT.toInt() }
                .trim('"', '\'')
            if (cleaned.isNotEmpty() && (cleaned.length < 20 || cleaned.any { !it.isLetterOrDigit() && it != '_' && it != '-' })) {
                message = "Cole apenas o valor da chave, sem endereço, JSON ou texto adicional. Use Mostrar para conferir."
            } else runCatching { settings.saveApiKey(cleaned) }
                .onSuccess { onDismiss() }.onFailure { message = "Não foi possível salvar a chave neste aparelho." }
        }) { Text("Salvar chave") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } })
}
```


## app/src/main/java/com/example/ui/DriveViewer.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.drive.*
import com.example.data.model.*
import com.example.data.repository.StudyState
import com.example.data.repository.reconcileOrder
import com.example.ui.components.ExpressiveRefreshBox
import com.example.ui.components.LoadingPane
import kotlinx.coroutines.CancellationException
import java.io.File

private data class MaterialLoad(val loading: Boolean = true, val file: DriveFile? = null,
    val pdf: File? = null, val progress: Float? = null, val error: String? = null)
private data class FolderLoad(val loading: Boolean = true, val files: List<DriveFile> = emptyList(),
    val error: String? = null)

@Composable fun DriveViewer(item: StudyItem, state: StudyState, onDismiss: () -> Unit,
    onFavorite: (String) -> Unit, onCompleted: (String) -> Unit, onAccess: (String) -> Unit,
    accountEmail: String? = null) {
    val context = LocalContext.current
    val revision = DriveSession.revision
    val token = DriveSession.accessToken
    val credentials = remember(revision, token) { DriveSettings(context).credentials() }
    val repository = remember(credentials) { DriveRepository(context, credentials) }
    var configure by remember { mutableStateOf(false) }
    var fullscreen by remember(item.id) { mutableStateOf(false) }
    var selected by remember(item.id) { mutableStateOf(if (item.linkKind == LinkKind.FILE) item else null) }
    val initialFolder = remember(item.id) {
        DriveFile(DriveRequests.folderId(item.url), item.title, "application/vnd.google-apps.folder", DriveRequests.resourceKey(item.url))
    }
    var folders by remember(item.id) { mutableStateOf(listOf(initialFolder)) }
    var folderTracks by remember(item.id) { mutableStateOf<List<StudyItem>>(emptyList()) }
    var autoPlay by remember(item.id) { mutableStateOf(false) }
    val order = reconcileOrder(state.items.map { it.id }, state.itemOrder)
    val catalogAudio = remember(state.items, order) {
        val byId = state.items.associateBy { it.id }
        order.mapNotNull(byId::get).filter { it.type == ContentType.AUDIO && it.linkKind == LinkKind.FILE }
    }
    val active = selected ?: item
    fun back() {
        when {
            fullscreen -> fullscreen = false
            selected != null && item.linkKind == LinkKind.FOLDER -> selected = null
            selected == null && folders.size > 1 -> folders = folders.dropLast(1)
            else -> onDismiss()
        }
    }
    BackHandler { back() }
    key(item.id) {
        Surface(Modifier.fillMaxSize()) {
            Scaffold(
                topBar = {
                    if (!fullscreen) TopAppBar(
                        title = { Text(if (selected != null) active.title else folders.last().name,
                            maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        navigationIcon = { IconButton(onClick = ::back) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar")
                        } },
                        actions = {
                            IconButton(onClick = { configure = true }) { Icon(Icons.Outlined.Settings, "Configurar Drive") }
                            if (selected != null) {
                                IconButton(onClick = { onFavorite(active.id) }) {
                                    Icon(if (active.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favoritar")
                                }
                                IconButton(onClick = { fullscreen = true }) { Icon(Icons.Outlined.Fullscreen, "Tela cheia") }
                            }
                        })
                },
                bottomBar = {
                    if (!fullscreen && selected != null) Surface(color = MaterialTheme.colorScheme.surfaceContainer) {
                        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (active.note.isNotBlank()) Text(active.note, style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(active.type.label, style = MaterialTheme.typography.labelLarge)
                                    Text("Seu progresso fica salvo no Kepleræ.", style = MaterialTheme.typography.bodySmall)
                                }
                                Button(onClick = { onCompleted(active.id) }) {
                                    Text(if (active.id in state.completed) "Concluído ✓" else "Concluir")
                                }
                            }
                        }
                    }
                }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when {
                        !credentials.configured -> ViewerMessage("Conecte seu Google Drive",
                            "Adicione sua chave de API para materiais públicos ou autorize a conta Google para arquivos privados.",
                            onConfigure = { configure = true })
                        selected != null -> MaterialContent(active, repository, Modifier.fillMaxSize(),
                            onConfigure = { configure = true },
                            playlist = if (folderTracks.isNotEmpty()) folderTracks else catalogAudio, autoPlay = autoPlay,
                            onSelectTrack = { track -> selected = track; autoPlay = true; onAccess(track.id) })
                        else -> FolderContent(folders.last(), item, repository,
                            onFolder = { folders = folders + it },
                            onFile = { file, files ->
                                folderTracks = files.filter { it.contentType == ContentType.AUDIO && !it.folder }.map { it.studyItem(item) }
                                selected = file.studyItem(item); autoPlay = false; onAccess(selected!!.id)
                            },
                            onConfigure = { configure = true })
                    }
                    if (fullscreen) FilledIconButton(onClick = { fullscreen = false },
                        modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(12.dp)) {
                        Icon(Icons.Outlined.FullscreenExit, "Sair da tela cheia")
                    }
                }
            }
        }
    }
    if (configure) DriveConfigDialog(accountEmail = accountEmail, onDismiss = { configure = false })
}

@Composable private fun MaterialContent(item: StudyItem, repository: DriveRepository,
    modifier: Modifier, onConfigure: () -> Unit, playlist: List<StudyItem>, autoPlay: Boolean,
    onSelectTrack: (StudyItem) -> Unit) {
    val context = LocalContext.current
    var retry by remember(item.id) { mutableIntStateOf(0) }
    val loaded by produceState(MaterialLoad(), item.id, repository, retry) {
        value = MaterialLoad()
        var temporary: File? = null
        try {
            val file = repository.metadata(item.driveFileId, DriveRequests.resourceKey(item.url))
            require(file.canDownload) { "O proprietário bloqueou a leitura do conteúdo pela API. A chave não altera essa permissão." }
            require(file.contentType != null) { "Este formato não é suportado pelo visualizador interno." }
            if (file.contentType == ContentType.PDF) {
                temporary = File.createTempFile("drive-pdf-", ".pdf", context.cacheDir)
                val pdf = repository.pdf(file, temporary!!) { received, size ->
                    value = MaterialLoad(file = file, progress = if (size > 0) (received.toFloat() / size).coerceIn(0f, 1f) else null)
                }
                value = MaterialLoad(loading = false, file = file, pdf = pdf)
            } else value = MaterialLoad(loading = false, file = file)
        } catch (e: CancellationException) { temporary?.delete(); throw e }
        catch (e: Exception) {
            temporary?.delete()
            value = MaterialLoad(loading = false, error = e.message ?: "Não foi possível carregar o material.")
        }
        awaitDispose { temporary?.delete() }
    }
    when {
        loaded.loading -> LoadingPane(
            if (loaded.file?.contentType == ContentType.PDF) "Preparando PDF…" else "Carregando material…",
            modifier, loaded.progress)
        loaded.error != null -> ViewerMessage("Não foi possível carregar", loaded.error!!,
            onRetry = { retry++ }, onConfigure = onConfigure)
        loaded.pdf != null -> NativePdf(loaded.pdf!!, modifier)
        loaded.file != null -> NativeMedia(item.copy(type = loaded.file!!.contentType!!), loaded.file!!, repository, modifier, onConfigure,
            playlist = playlist, autoPlay = autoPlay, onSelectTrack = onSelectTrack)
    }
}

@Composable private fun FolderContent(folder: DriveFile, item: StudyItem, repository: DriveRepository,
    onFolder: (DriveFile) -> Unit, onFile: (DriveFile, List<DriveFile>) -> Unit, onConfigure: () -> Unit) {
    var query by remember(folder.id) { mutableStateOf("") }
    var retry by remember(folder.id) { mutableIntStateOf(0) }
    val loaded by produceState(FolderLoad(), folder.id, repository, retry) {
        value = FolderLoad(files = value.files)
        try { value = FolderLoad(false, repository.folder(folder.id, folder.resourceKey)) }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { value = FolderLoad(false, error = e.message ?: "Não foi possível ler a pasta.") }
    }
    if (loaded.loading && loaded.files.isEmpty()) LoadingPane("Carregando pasta…")
    else if (loaded.error != null) ViewerMessage("Não foi possível abrir a pasta", loaded.error!!,
        onRetry = { retry++ }, onConfigure = onConfigure)
    else ExpressiveRefreshBox(loaded.loading, { retry++ }, Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Localize: ${item.filename}", style = MaterialTheme.typography.bodyMedium)
        OutlinedTextField(query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, label = { Text("Buscar nesta pasta") })
        val files = loaded.files.filter { searchable(it.name).contains(searchable(query)) }
        if (files.isEmpty()) Text("Nenhum arquivo encontrado nesta pasta.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(files, key = { it.id }) { file ->
                val supported = file.folder || file.contentType != null
                Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.fillMaxWidth().clickable(enabled = supported) {
                        if (file.folder) onFolder(file) else onFile(file, loaded.files)
                    }) {
                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(when {
                            file.folder -> Icons.Outlined.Folder
                            file.contentType == ContentType.AUDIO -> Icons.Outlined.Headphones
                            file.contentType == ContentType.PDF -> Icons.Outlined.Description
                            else -> Icons.Outlined.PlayCircleOutline
                        }, null, tint = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f)) {
                            Text(file.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(if (file.folder) "Pasta" else file.contentType?.label ?: "Formato não suportado",
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
    }
}

@Composable private fun ViewerMessage(title: String, detail: String, onRetry: (() -> Unit)? = null,
    onConfigure: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Outlined.CloudOff, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp)); Text(detail)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (onRetry != null) Button(onClick = onRetry) { Text("Tentar novamente") }
            OutlinedButton(onClick = onConfigure) { Text("Configurar Drive") }
        }
    }
}
```


## app/src/main/java/com/example/ui/KepleraeApp.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.LibraryBooks
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.auth.GoogleUser
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.components.LoadingPane
import com.example.ui.components.SharedMotion
import com.example.ui.home.HomeScreen
import com.example.ui.profile.ProfileScreen

enum class Destination(val title: String, val icon: ImageVector, val type: ContentType?) {
    HOME("Início", Icons.Outlined.Home, null),
    VIDEOS("Aulas", Icons.Outlined.PlayCircleOutline, ContentType.VIDEO),
    PDFS("PDFs", Icons.AutoMirrored.Filled.LibraryBooks, ContentType.PDF),
    AUDIO("Áudios", Icons.Outlined.Headphones, ContentType.AUDIO),
    SUBJECTS("Matérias", Icons.Outlined.GridView, null),
}

private data class AppRoute(val destination: Destination, val subjectId: String?,
    val path: List<String>, val profile: Boolean)

@Composable fun KepleraeApp(state: StudyState, model: StudyViewModel,
    user: GoogleUser? = null, onSignOut: () -> Unit = {}) {
    var destinationName by rememberSaveable { mutableStateOf(Destination.HOME.name) }
    var subjectId by rememberSaveable { mutableStateOf<String?>(null) }
    var pathKey by rememberSaveable { mutableStateOf("") }
    var settings by rememberSaveable { mutableStateOf(false) }
    var configureDrive by remember { mutableStateOf(false) }
    var profile by rememberSaveable { mutableStateOf(false) }
    var activeId by rememberSaveable { mutableStateOf<String?>(null) }
    val destination = Destination.valueOf(destinationName)
    val subject = subjectId?.let(Subjects::get)
    val path = if (pathKey.isBlank()) emptyList() else pathKey.split('\u001f')
    val activeItem = state.items.firstOrNull { it.id == activeId }
    fun navigate(next: Destination) {
        destinationName = next.name; subjectId = null; pathKey = ""; profile = false
    }
    fun select(next: Subject) { subjectId = next.id; pathKey = "" }
    fun open(item: StudyItem) { model.recordAccess(item.id); activeId = item.id }
    fun back() {
        when {
            profile -> profile = false
            path.isNotEmpty() -> pathKey = path.dropLast(1).joinToString("\u001f")
            subjectId != null -> subjectId = null
            destination != Destination.HOME -> navigate(Destination.HOME)
        }
    }
    BackHandler(enabled = (profile || subject != null || destination != Destination.HOME)
        && activeItem == null && !settings && !configureDrive) { back() }

    // Visualizador é uma página do próprio app, sem Custom Tab e sem navegador.
    if (activeItem != null) {
        DriveViewer(activeItem, state, onDismiss = { activeId = null },
            onFavorite = model::toggleFavorite, onCompleted = model::toggleCompleted,
            onAccess = model::recordAccess, accountEmail = user?.email)
        return
    }
    SharedTransitionLayout {
        val shared = this
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val expanded = maxWidth >= 700.dp
            Scaffold(topBar = {
                TopAppBar(title = {
                    if (profile) Text("Seu perfil")
                    else if (subject != null) Text(subject.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    else Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Image(painterResource(R.drawable.keplerae_logo), null,
                            Modifier.size(32.dp).clip(MaterialTheme.shapes.small))
                        Text(if (destination == Destination.HOME) "Kepleræ" else destination.title)
                    }
                }, navigationIcon = {
                    if (profile || subject != null || destination != Destination.HOME)
                        IconButton(onClick = ::back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                }, actions = {
                    IconButton(onClick = { settings = true }, modifier = Modifier.testTag("settings")) {
                        Icon(Icons.Outlined.Palette, "Aparência")
                    }
                }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface))
            }, bottomBar = {
                if (!expanded && !profile) NavigationBar {
                    Destination.entries.forEach { dest ->
                        NavigationBarItem(selected = destination == dest, onClick = { navigate(dest) },
                            icon = { Icon(dest.icon, null) }, label = { Text(dest.title) },
                            modifier = Modifier.testTag("nav_${dest.name}"))
                    }
                }
            }) { padding ->
                Row(Modifier.fillMaxSize().padding(padding)) {
                    if (expanded && !profile) NavigationRail(Modifier.fillMaxHeight(),
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
                        Spacer(Modifier.height(24.dp))
                        Destination.entries.forEach { dest ->
                            NavigationRailItem(selected = destination == dest, onClick = { navigate(dest) },
                                icon = { Icon(dest.icon, null) }, label = { Text(dest.title) },
                                modifier = Modifier.testTag("nav_${dest.name}"))
                        }
                    }
                    Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
                        AnimatedContent(targetState = AppRoute(destination, subjectId, path, profile),
                            modifier = Modifier.widthIn(max = 1120.dp).fillMaxSize(),
                            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(180)) },
                            label = "shared_destinations") { route ->
                            val motion = SharedMotion(shared, this)
                            when {
                                route.profile -> ProfileScreen(user, state, motion,
                                    onTheme = model::setTheme, onDynamicColor = model::setDynamicColor,
                                    onConfigureDrive = { configureDrive = true }, onSignOut = onSignOut)
                                state.loading && state.items.isEmpty() -> LoadingPane("Preparando sua biblioteca…")
                                state.error != null -> Column(Modifier.fillMaxSize().padding(24.dp),
                                    verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Outlined.CloudOff, null, Modifier.size(48.dp))
                                    Text(state.error)
                                    Button(onClick = model::reload) { Text("Tentar novamente") }
                                }
                                route.subjectId == null && route.destination == Destination.HOME ->
                                    HomeScreen(state, user, motion, ::navigate, ::select, ::open,
                                        onProfile = { profile = true }, onRefresh = model::reload)
                                else -> CatalogScreen(state, route.destination, route.subjectId?.let(Subjects::get),
                                    route.path, motion, ::select,
                                    onFolder = { pathKey = (route.path + it).joinToString("\u001f") },
                                    onOpen = ::open, onFavorite = model::toggleFavorite,
                                    onCompleted = model::toggleCompleted, onRefresh = model::reload,
                                    onSaveOrder = model::saveVisibleOrder)
                            }
                        }
                    }
                }
            }
        }
    }
    if (settings) AppearanceSheet(state, model, onDismiss = { settings = false },
        onConfigure = { settings = false; configureDrive = true })
    if (configureDrive) DriveConfigDialog(accountEmail = user?.email, onDismiss = { configureDrive = false })
}

/** Preserva o modo automático e o acesso às configurações anteriores. */
@Composable private fun AppearanceSheet(state: StudyState, model: StudyViewModel,
    onDismiss: () -> Unit, onConfigure: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Text("Do seu jeito", style = MaterialTheme.typography.headlineMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(selected = mode == state.theme, onClick = { model.setTheme(mode) },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("theme_${mode.name}"),
                        label = { Text(mode.label) })
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Cores do seu Android", style = MaterialTheme.typography.titleMedium)
                    Text(if (Build.VERSION.SDK_INT >= 31) "Use as cores do seu papel de parede."
                        else "Disponível no Android 12 ou superior.", style = MaterialTheme.typography.bodySmall)
                }
                Switch(state.dynamicColor, model::setDynamicColor, enabled = Build.VERSION.SDK_INT >= 31)
            }
            OutlinedButton(onClick = onConfigure, modifier = Modifier.fillMaxWidth()) { Text("Configurar Google Drive") }
            Text("Kepleræ 2.0", style = MaterialTheme.typography.titleMedium)
            Text("${state.items.size} materiais. Seu progresso é salvo neste aparelho.")
        }
    }
}
```


## app/src/main/java/com/example/ui/NativeMedia.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui

import android.view.ViewGroup
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.*
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.example.data.drive.*
import com.example.data.model.ContentType
import com.example.data.model.StudyItem
import com.example.ui.components.HelpTooltip
import kotlinx.coroutines.delay

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable fun NativeMedia(item: StudyItem, file: DriveFile, repository: DriveRepository,
    modifier: Modifier = Modifier, onConfigure: () -> Unit,
    playlist: List<StudyItem> = emptyList(), autoPlay: Boolean = false,
    onSelectTrack: (StudyItem) -> Unit = {}) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val preferences = remember { context.getSharedPreferences("keplerae_playback", 0) }
    var failure by remember(file.id, repository) { mutableStateOf<String?>(null) }
    var buffering by remember(file.id, repository) { mutableStateOf(true) }
    var playing by remember(file.id, repository) { mutableStateOf(false) }
    var position by remember(file.id) { mutableLongStateOf(0L) }
    var duration by remember(file.id) { mutableLongStateOf(0L) }
    var speed by remember(file.id) { mutableFloatStateOf(1f) }
    val player = remember(file.id, repository) {
        val dataSource = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(15000).setReadTimeoutMs(30000)
            .setDefaultRequestProperties(repository.headers(file.id, file.resourceKey))
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSource))
            .setSeekBackIncrementMs(10000).setSeekForwardIncrementMs(10000).build().apply {
                setAudioAttributes(AudioAttributes.DEFAULT, true)
                setHandleAudioBecomingNoisy(true)
                setMediaItem(MediaItem.Builder().setUri(DriveRequests.file(file.id, true))
                    .setMimeType(file.mimeType)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(item.title).build()).build())
                seekTo(preferences.getLong(file.id, 0).coerceAtLeast(0))
                playWhenReady = autoPlay
            }
    }
    DisposableEffect(player, lifecycle) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayerError(error: PlaybackException) {
                buffering = false
                val http = generateSequence<Throwable>(error) { it.cause }
                    .filterIsInstance<HttpDataSource.InvalidResponseCodeException>().firstOrNull()
                failure = if (http != null) DriveRequests.errorMessage(http.responseCode,
                    DriveRequests.errorReason(String(http.responseBody, Charsets.UTF_8)))
                else when (error.errorCode) {
                    PlaybackException.ERROR_CODE_DECODING_FAILED, PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ->
                        "Este aparelho não conseguiu decodificar o formato do arquivo."
                    else -> "Não foi possível reproduzir. Confira a conexão e as permissões no Drive."
                }
            }
        }
        fun savePosition() {
            preferences.edit().putLong(file.id,
                if (player.playbackState == Player.STATE_ENDED) 0 else player.currentPosition).apply()
        }
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) { player.pause(); savePosition() }
        }
        player.addListener(listener); lifecycle.addObserver(observer); player.prepare()
        onDispose { savePosition(); lifecycle.removeObserver(observer); player.removeListener(listener); player.release() }
    }
    // Valores vêm do ExoPlayer. Não há timer simulando porcentagens de reprodução.
    LaunchedEffect(player) {
        var lastSaved = 0L
        while (true) {
            position = player.currentPosition.coerceAtLeast(0)
            duration = player.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L
            if (player.isPlaying && kotlin.math.abs(position - lastSaved) >= 5000L) {
                preferences.edit().putLong(file.id, position).apply(); lastSaved = position
            }
            delay(250L)
        }
    }
    fun playPause() {
        if (player.isPlaying) player.pause() else {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.play()
        }
    }
    Column(modifier.fillMaxSize()) {
        if (item.type == ContentType.AUDIO) {
            AudioScreen(item, playlist, playing, buffering, position, duration,
                onPlayPause = ::playPause,
                onSeek = { player.seekTo(it); position = it }, onSelectTrack = onSelectTrack,
                modifier = Modifier.fillMaxWidth().weight(1f))
        } else {
            Box(Modifier.fillMaxWidth().weight(1f).heightIn(min = 100.dp)
                .clip(MaterialTheme.shapes.extraLarge).background(Color.Black), contentAlignment = Alignment.Center) {
                AndroidView(factory = { ctx -> PlayerView(ctx).also { it.player = player }.apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    setEnableComposeSurfaceSyncWorkaround(true)
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                    setShowNextButton(false); setShowPreviousButton(false)
                    setShowFastForwardButton(true); setShowRewindButton(true)
                    controllerShowTimeoutMs = 5000; controllerAutoShow = true; showController()
                } }, update = { it.player = player }, modifier = Modifier.fillMaxSize())
                if (buffering) CircularWavyProgressIndicator(Modifier.size(48.dp), color = Color.White)
            }
            LinearWavyProgressIndicator(progress = { if (duration <= 0) 0f else (position.toFloat() / duration).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp))
        }
        LazyRow(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(vertical = 4.dp)) {
            items(listOf(.75f, 1f, 1.25f, 1.5f, 2f)) { rate ->
                FilterChip(selected = speed == rate, onClick = { speed = rate; player.setPlaybackSpeed(rate) },
                    label = { Text("${rate}×") })
            }
        }
        if (failure != null) {
            Text(failure!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp))
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { failure = null; buffering = true; player.prepare() }) { Text("Tentar novamente") }
                OutlinedButton(onClick = onConfigure) { Text("Configurar Drive") }
            }
        }
    }
}

@Composable private fun AudioScreen(item: StudyItem, playlist: List<StudyItem>, playing: Boolean,
    buffering: Boolean, position: Long, duration: Long, onPlayPause: () -> Unit,
    onSeek: (Long) -> Unit, onSelectTrack: (StudyItem) -> Unit, modifier: Modifier) {
    val tracks = remember(playlist, item) { (playlist + item).distinctBy { it.driveFileId.ifBlank { it.id } } }
    val current = tracks.indexOfFirst { it.driveFileId == item.driveFileId && it.driveFileId.isNotBlank() || it.id == item.id }
    var scrub by remember(item.id) { mutableStateOf<Float?>(null) }
    BoxWithConstraints(modifier) {
        val compact = maxHeight < 480.dp
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            item {
                Box(Modifier.size(if (compact) 88.dp else 148.dp).clip(MaterialTheme.shapes.extraLarge)
                    .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer,
                        MaterialTheme.colorScheme.tertiaryContainer))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.Headphones, null, Modifier.size(if (compact) 48.dp else 72.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            item {
                Text(item.title, style = MaterialTheme.typography.headlineSmall)
                Text("Sua escuta, no seu ritmo.", style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
            }
            item {
                Column(Modifier.fillMaxWidth()) {
                    val realProgress = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
                    LinearWavyProgressIndicator(progress = { scrub ?: realProgress }, modifier = Modifier.fillMaxWidth())
                    Slider(value = scrub ?: realProgress, onValueChange = { scrub = it },
                        enabled = duration > 0, onValueChangeFinished = {
                            scrub?.let { onSeek((duration * it).toLong()) }; scrub = null
                        }, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(mediaTime(if (scrub == null) position else (duration * scrub!!).toLong()), style = MaterialTheme.typography.labelMedium)
                        Text(mediaTime(duration), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    IconButton(onClick = { tracks.getOrNull(current - 1)?.let(onSelectTrack) }, enabled = current > 0) {
                        Icon(Icons.Filled.SkipPrevious, "Faixa anterior", Modifier.size(30.dp))
                    }
                    FilledIconButton(onClick = onPlayPause, modifier = Modifier.size(72.dp), shape = CircleShape) {
                        if (buffering) CircularWavyProgressIndicator(Modifier.size(32.dp),
                            color = MaterialTheme.colorScheme.onPrimary)
                        else Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            if (playing) "Pausar" else "Reproduzir", Modifier.size(36.dp))
                    }
                    IconButton(onClick = { tracks.getOrNull(current + 1)?.let(onSelectTrack) },
                        enabled = current >= 0 && current < tracks.lastIndex) {
                        Icon(Icons.Filled.SkipNext, "Próxima faixa", Modifier.size(30.dp))
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Lista de faixas", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    HelpTooltip("Sua reprodução", "A barra acompanha o áudio real. Arraste para avançar ou voltar. " +
                        "A posição é salva ao sair do material. A reprodução pausa ao sair do app.")
                }
            }
            items(tracks, key = { it.id }) { track ->
                val selected = track.driveFileId == item.driveFileId && track.driveFileId.isNotBlank() || track.id == item.id
                Surface(onClick = { if (!selected) onSelectTrack(track) else onPlayPause() },
                    modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large,
                    color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerLow) {
                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (selected && playing) Icons.Outlined.GraphicEq else Icons.Outlined.MusicNote, null)
                        Column(Modifier.weight(1f)) {
                            Text(track.title, style = MaterialTheme.typography.titleMedium)
                            if (selected) Text(if (playing) "Reproduzindo" else "Selecionada", style = MaterialTheme.typography.labelSmall)
                        }
                        Icon(if (selected && playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                    }
                }
            }
        }
    }
}

internal fun mediaTime(milliseconds: Long): String {
    val total = milliseconds.coerceAtLeast(0) / 1000
    return if (total >= 3600) "%d:%02d:%02d".format(java.util.Locale.ROOT, total / 3600, total / 60 % 60, total % 60)
    else "%d:%02d".format(java.util.Locale.ROOT, total / 60, total % 60)
}
```


## app/src/main/java/com/example/ui/NativePdf.kt

```kotlin
package com.example.ui

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.ZoomOutMap
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.example.ui.components.HelpTooltip
import com.example.ui.components.LoadingPane
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.absoluteValue

private data class PdfDocument(val count: Int = 0, val error: String? = null)
private data class PdfBitmap(val bitmap: Bitmap? = null, val error: String? = null)
// Limita renderizações simultâneas e o pico de memória durante o gesto de paginação.
private val pdfRenderGate = Semaphore(1)

@Composable fun NativePdf(file: File, modifier: Modifier = Modifier) {
    var savedPage by rememberSaveable(file.path) { mutableIntStateOf(0) }
    val document by produceState(PdfDocument(), file.path) {
        value = withContext(Dispatchers.IO) {
            try {
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                    PdfRenderer(descriptor).use { renderer ->
                        check(renderer.pageCount > 0)
                        PdfDocument(renderer.pageCount)
                    }
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { PdfDocument(error = "Não foi possível ler este PDF. Ele pode estar danificado ou protegido por senha.") }
        }
    }
    when {
        document.error != null -> Box(modifier, contentAlignment = Alignment.Center) {
            Text(document.error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(24.dp))
        }
        document.count == 0 -> LoadingPane("Preparando páginas…", modifier)
        else -> {
            val pager = rememberPagerState(initialPage = savedPage.coerceIn(0, document.count - 1),
                pageCount = { document.count })
            var zoomed by remember(file.path) { mutableStateOf(false) }
            var resetZoom by remember(file.path) { mutableIntStateOf(0) }
            val scope = rememberCoroutineScope()
            LaunchedEffect(pager) { snapshotFlow { pager.currentPage }.collect { savedPage = it; zoomed = false } }
            Column(modifier.fillMaxSize()) {
                HorizontalPager(state = pager, userScrollEnabled = !zoomed,
                    beyondViewportPageCount = 0, pageSpacing = 12.dp,
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    modifier = Modifier.fillMaxWidth().weight(1f).testTag("pdf_pager"), key = { it }) { index ->
                    // O offset varia continuamente enquanto o usuário arrasta.
                    val offset = ((pager.currentPage - index) + pager.currentPageOffsetFraction).absoluteValue
                    val fraction = offset.coerceIn(0f, 1f)
                    PdfPageContent(file, index, active = index == pager.currentPage, resetZoom = resetZoom,
                        modifier = Modifier.fillMaxSize().graphicsLayer {
                            scaleX = 1f - .12f * fraction
                            scaleY = 1f - .12f * fraction
                            alpha = 1f - .45f * fraction
                            clip = true
                        }, onZoomChanged = { if (index == pager.currentPage) zoomed = it })
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { resetZoom++; scope.launch { pager.animateScrollToPage((pager.currentPage - 1).coerceAtLeast(0)) } },
                        enabled = pager.currentPage > 0) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Página anterior") }
                    Text("${pager.currentPage + 1} / ${document.count}", style = MaterialTheme.typography.labelLarge)
                    IconButton(onClick = { resetZoom++; scope.launch { pager.animateScrollToPage((pager.currentPage + 1).coerceAtMost(document.count - 1)) } },
                        enabled = pager.currentPage < document.count - 1) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Próxima página") }
                    IconButton(onClick = { resetZoom++ }) { Icon(Icons.Outlined.ZoomOutMap, "Restaurar zoom") }
                    HelpTooltip("Ler PDF", "Deslize com um dedo para trocar de página. Use dois dedos para ampliar. " +
                        "Com zoom ativo, arraste para mover a página ou toque em Restaurar zoom para voltar à paginação.")
                }
            }
        }
    }
}

@Composable private fun PdfPageContent(file: File, index: Int, active: Boolean, resetZoom: Int,
    modifier: Modifier, onZoomChanged: (Boolean) -> Unit) {
    var zoom by remember(file.path, index) { mutableFloatStateOf(1f) }
    var pan by remember(file.path, index) { mutableStateOf(Offset.Zero) }
    val zoomCallback by rememberUpdatedState(onZoomChanged)
    LaunchedEffect(resetZoom, active) { zoom = 1f; pan = Offset.Zero; zoomCallback(false) }
    val page by produceState(PdfBitmap(), file.path, index) {
        value = pdfRenderGate.withPermit {
            withContext(Dispatchers.IO) {
                try {
                    ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                        PdfRenderer(descriptor).use { renderer ->
                            renderer.openPage(index).use { opened ->
                                val scale = minOf(1440f / opened.width, 2048f / opened.height)
                                val bitmap = Bitmap.createBitmap((opened.width * scale).toInt().coerceAtLeast(1),
                                    (opened.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                                bitmap.eraseColor(android.graphics.Color.WHITE)
                                opened.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                PdfBitmap(bitmap)
                            }
                        }
                    }
                } catch (e: CancellationException) { throw e }
                catch (e: Exception) { PdfBitmap(error = "Não foi possível renderizar esta página.") }
            }
        }
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        when {
            page.error != null -> Text(page.error!!, color = MaterialTheme.colorScheme.error)
            page.bitmap == null -> LoadingPane("Carregando página ${index + 1}…")
            else -> Image(bitmap = page.bitmap!!.asImageBitmap(), contentDescription = "Página ${index + 1}",
                contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()
                    .pointerInput(file.path, index) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            do {
                                val event = awaitPointerEvent()
                                val transform = event.changes.count { it.pressed } >= 2 || zoom > 1.01f
                                // Um dedo, sem zoom, permanece disponível para o HorizontalPager.
                                if (transform) {
                                    zoom = (zoom * event.calculateZoom()).coerceIn(1f, 4f)
                                    val delta = event.calculatePan()
                                    val limitX = size.width * (zoom - 1f) / 2f
                                    val limitY = size.height * (zoom - 1f) / 2f
                                    pan = Offset((pan.x + delta.x).coerceIn(-limitX, limitX),
                                        (pan.y + delta.y).coerceIn(-limitY, limitY))
                                    zoomCallback(zoom > 1.01f)
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    }.graphicsLayer { scaleX = zoom; scaleY = zoom; translationX = pan.x; translationY = pan.y })
        }
    }
}
```


## app/src/main/java/com/example/ui/components/ExpressiveComponents.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** O mesmo indicador Expressive atende carregamento inicial e atualização por gesto. */
@Composable fun ExpressiveRefreshBox(refreshing: Boolean, onRefresh: () -> Unit,
    modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val pullState = rememberPullToRefreshState()
    PullToRefreshBox(isRefreshing = refreshing, onRefresh = onRefresh, state = pullState,
        modifier = modifier, indicator = {
            PullToRefreshDefaults.LoadingIndicator(state = pullState, isRefreshing = refreshing,
                modifier = Modifier.align(Alignment.TopCenter))
        }, content = content)
}

@Composable fun LoadingPane(label: String, modifier: Modifier = Modifier,
    progress: Float? = null) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        LoadingIndicator(Modifier.size(64.dp))
        Spacer(Modifier.height(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
        if (progress != null) {
            Spacer(Modifier.height(20.dp))
            LinearWavyProgressIndicator(progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.widthIn(max = 360.dp).fillMaxWidth())
            Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 8.dp))
        }
    }
}

/** Exibição manual: o clique chama show(), sem depender de pressionar e segurar. */
@Composable fun HelpTooltip(title: String, detail: String, modifier: Modifier = Modifier) {
    val state = rememberTooltipState(isPersistent = true)
    val scope = rememberCoroutineScope()
    TooltipBox(positionProvider = TooltipDefaults.rememberRichTooltipPositionProvider(),
        state = state, enableUserInput = false, tooltip = {
            RichTooltip(title = { Text(title) }, action = {
                TextButton(onClick = { state.dismiss() }) { Text("Entendi") }
            }) { Text(detail) }
        }) {
        IconButton(onClick = { scope.launch { state.show() } }, modifier = modifier) {
            Icon(Icons.Outlined.Info, "Ajuda: $title")
        }
    }
}
```


## app/src/main/java/com/example/ui/components/SharedMotion.kt

```kotlin
@file:OptIn(androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui.components

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect

/** Escopos vêm do mesmo AnimatedContent; chaves são estáveis nos dois destinos. */
@Immutable data class SharedMotion(
    val shared: SharedTransitionScope,
    val animated: AnimatedVisibilityScope,
) {
    @Composable fun element(key: String): Modifier = with(shared) {
        Modifier.sharedElement(rememberSharedContentState(key), animatedVisibilityScope = animated,
            boundsTransform = { _, _ -> spring<Rect>(dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessLow) })
    }
    @Composable fun bounds(key: String): Modifier = with(shared) {
        Modifier.sharedBounds(rememberSharedContentState(key), animatedVisibilityScope = animated,
            boundsTransform = { _, _ -> spring<Rect>(dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessLow) })
    }
}
```


## app/src/main/java/com/example/ui/components/SubjectArtwork.kt

```kotlin
package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

fun subjectPalette(id: String, dark: Boolean): Pair<Color, Color> {
    val colors = when (id) {
        "fisioterapia" -> listOf(0xFFD0F4E6, 0xFF064F3C, 0xFF173D33, 0xFFAFF0D5)
        "portugues" -> listOf(0xFFFFDFEB, 0xFF70324C, 0xFF4C2638, 0xFFFFB2D0)
        "matematica" -> listOf(0xFFDBE6FF, 0xFF274777, 0xFF23344F, 0xFFB6CEFF)
        "hu_legislacao" -> listOf(0xFFFFE8CA, 0xFF654512, 0xFF49351C, 0xFFF5D49D)
        "sus" -> listOf(0xFFE1EFC4, 0xFF3C4E17, 0xFF303D1B, 0xFFD4E9AA)
        else -> listOf(0xFFEBDFFF, 0xFF533777, 0xFF3D2C50, 0xFFE0C3FF)
    }
    return if (dark) Color(colors[2]) to Color(colors[3]) else Color(colors[0]) to Color(colors[1])
}

/** Ilustrações nativas: não dependem de imagens de terceiros nem de conexão. */
@Composable fun SubjectArtwork(id: String, tint: Color, modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension * .24f
            rotate(-12f) {
                repeat(6) { n ->
                    val angle = n * PI / 3
                    val p = center + Offset((cos(angle) * r).toFloat(), (sin(angle) * r).toFloat())
                    drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = .22f), tint.copy(alpha = .07f)),
                        center = p, radius = r), r, p)
                }
            }
            drawCircle(Color.White.copy(alpha = .20f), r * 1.12f, center - Offset(r * .15f, r * .17f))
        }
        Icon(when (id) {
            "fisioterapia" -> Icons.Outlined.AccessibilityNew
            "portugues" -> Icons.AutoMirrored.Outlined.MenuBook
            "matematica" -> Icons.Outlined.Functions
            "hu_legislacao" -> Icons.Outlined.Balance
            "sus" -> Icons.Outlined.HealthAndSafety
            else -> Icons.Outlined.Psychology
        }, null, Modifier.size(44.dp), tint = tint)
    }
}
```


## app/src/main/java/com/example/ui/home/HomeScreen.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.auth.GoogleUser
import com.example.data.model.*
import com.example.data.repository.StudyState
import com.example.ui.Destination
import com.example.ui.components.*
import com.example.ui.profile.ProfileButton
import com.example.ui.theme.isDarkMode

@Composable fun HomeScreen(state: StudyState, user: GoogleUser?, motion: SharedMotion,
    onNavigate: (Destination) -> Unit, onSubject: (Subject) -> Unit,
    onOpen: (StudyItem) -> Unit, onProfile: () -> Unit, onRefresh: () -> Unit) {
    val dark = isDarkMode(state.theme)
    val recent = remember(state.items, state.accessed) {
        state.items.filter { it.id in state.accessed }.sortedByDescending { state.accessed[it.id] }.take(4)
    }
    val complete = state.items.count { it.id in state.completed }
    val progress = if (state.items.isEmpty()) 0f else complete.toFloat() / state.items.size
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val columns = if (maxWidth >= 800.dp) 3 else 2
        val wideHeader = maxWidth >= 650.dp
        ExpressiveRefreshBox(state.loading, onRefresh, Modifier.fillMaxSize()) {
            LazyVerticalGrid(columns = GridCells.Fixed(columns), modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Box(Modifier.fillMaxWidth().background(Brush.linearGradient(
                        if (dark) listOf(Color(0xFF36344F), Color(0xFF23483E))
                        else listOf(Color(0xFFFFD7E8), Color(0xFFFFECC0), Color(0xFFD4F1DB))),
                        MaterialTheme.shapes.extraLarge).padding(24.dp)) {
                        Column(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("SEU ESPAÇO DE ESTUDO", style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(user?.displayName?.substringBefore(' ')?.let { "Olá, $it" } ?: "Vamos explorar?",
                                        style = MaterialTheme.typography.titleMedium)
                                }
                                ProfileButton(user, motion, onProfile)
                            }
                            Spacer(Modifier.height(24.dp))
                            Text("Kepleræ", style = MaterialTheme.typography.displayLarge.copy(
                                fontSize = if (wideHeader) 96.sp else 62.sp,
                                lineHeight = if (wideHeader) 104.sp else 70.sp,
                                letterSpacing = (-2).sp, fontWeight = FontWeight.Bold))
                            Text("Aprender, no seu ritmo.", style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Card(shape = RoundedCornerShape(32.dp),
                        colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLowest)) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Text("Seu percurso", style = MaterialTheme.typography.headlineSmall,
                                    modifier = Modifier.weight(1f))
                                HelpTooltip("Seu percurso", "As conclusões e os favoritos ficam salvos neste aparelho. " +
                                    "Abra um material e toque em Concluir para atualizar seu progresso.")
                            }
                            Text("$complete de ${state.items.size} materiais concluídos",
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            LinearWavyProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = { if (recent.isEmpty()) onNavigate(Destination.SUBJECTS)
                                else onOpen(recent.first()) }, modifier = Modifier.heightIn(min = 52.dp)) {
                                Icon(if (recent.isEmpty()) Icons.Outlined.GridView else Icons.Filled.PlayArrow, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (recent.isEmpty()) "Escolher uma matéria" else "Retomar estudo")
                            }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf(Destination.VIDEOS, Destination.PDFS, Destination.AUDIO).forEach { dest ->
                            Card(onClick = { onNavigate(dest) }, modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerHigh)) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(dest.icon, null, tint = MaterialTheme.colorScheme.primary)
                                    Text(state.items.count { it.type == dest.type }.toString(),
                                        style = MaterialTheme.typography.headlineMedium)
                                    Text(dest.title, style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Suas matérias", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onNavigate(Destination.SUBJECTS) }) { Text("Ver todas") }
                    }
                }
                items(Subjects.all, key = { it.id }) { subject ->
                    SubjectTile(subject, state, motion, Modifier.fillMaxWidth()) { onSubject(subject) }
                }
                if (recent.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text("Continue de onde parou", style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier.padding(top = 8.dp))
                    }
                    items(recent, key = { "recent/${it.id}" }, span = { GridItemSpan(maxLineSpan) }) { item ->
                        Card(onClick = { onOpen(item) }, modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLow)) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Icon(if (item.type == ContentType.AUDIO) Icons.Outlined.Headphones
                                    else if (item.type == ContentType.PDF) Icons.Outlined.Description
                                    else Icons.Outlined.PlayCircleOutline, null, tint = MaterialTheme.colorScheme.primary)
                                Column(Modifier.weight(1f)) {
                                    Text(item.title, style = MaterialTheme.typography.titleMedium)
                                    Text(Subjects.get(item.subjectId).name, style = MaterialTheme.typography.bodySmall)
                                }
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, "Abrir material")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun SubjectTile(subject: Subject, state: StudyState, motion: SharedMotion,
    modifier: Modifier = Modifier, onClick: () -> Unit) {
    val palette = subjectPalette(subject.id, isDarkMode(state.theme))
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .96f else 1f, label = "subject_press")
    val rows = state.items.filter { it.subjectId == subject.id }
    val complete = rows.count { it.id in state.completed }
    Card(onClick = onClick, interactionSource = interaction,
        modifier = modifier.then(motion.bounds("subject/${subject.id}/container"))
            .graphicsLayer { scaleX = scale; scaleY = scale },
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 16.dp, bottomEnd = 28.dp, bottomStart = 28.dp),
        colors = CardDefaults.cardColors(palette.first, palette.second)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                SubjectArtwork(subject.id, palette.second,
                    motion.element("subject/${subject.id}/art").size(76.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(20.dp))
            }
            Text(subject.name, style = MaterialTheme.typography.titleMedium, minLines = 2,
                modifier = motion.bounds("subject/${subject.id}/name"))
            Text("${rows.size} materiais", style = MaterialTheme.typography.labelLarge)
            LinearProgressIndicator(progress = { if (rows.isEmpty()) 0f else complete.toFloat() / rows.size },
                modifier = Modifier.fillMaxWidth(), color = palette.second,
                trackColor = palette.second.copy(alpha = .15f))
        }
    }
}
```


## app/src/main/java/com/example/ui/login/LoginRoute.kt

```kotlin
package com.example.ui.login

import android.app.Activity
import android.content.MutableContextWrapper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.auth.GoogleLoginViewModel
import com.example.data.auth.GoogleLoginConfiguration
import com.example.data.auth.GoogleUser
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** O lançamento de Credential Manager fica na tela e acompanha seu ciclo de vida. */
@Composable
fun LoginRoute(viewModel: GoogleLoginViewModel) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val credentials = remember(context.applicationContext) {
        CredentialManager.create(context.applicationContext)
    }
    val webClientId = context.getString(R.string.google_web_client_id).trim()
    val driveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult(),
    ) { result ->
        viewModel.receiveDriveResult(result.data, result.resultCode == Activity.RESULT_OK)
    }

    LaunchedEffect(state.driveResolution) {
        val pending = state.driveResolution ?: return@LaunchedEffect
        viewModel.consumeDriveResolution()
        try {
            driveLauncher.launch(IntentSenderRequest.Builder(pending.intentSender).build())
        } catch (error: Exception) {
            viewModel.credentialFailure(error)
        }
    }

    LoginScreen(busy = state.busy, error = state.error, onGoogleSignIn = {
        if (!viewModel.beginSignIn()) return@LoginScreen
        if (!GoogleLoginConfiguration.isWebClientId(webClientId)) {
            viewModel.configurationMissing()
            return@LoginScreen
        }
        scope.launch {
            try {
                // Fluxo explícito do botão: permite escolher/adicionar uma conta Google.
                val option = GetSignInWithGoogleOption.Builder(webClientId).build()
                val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                val response = credentials.getCredential(
                    context = MutableContextWrapper(context),
                    request = request,
                )
                val custom = response.credential as? CustomCredential
                    ?: error("Tipo de credencial inesperado")
                check(custom.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    "Tipo de credencial inesperado"
                }
                val google = GoogleIdTokenCredential.createFrom(custom.data)
                val user = GoogleUser(
                    email = google.id,
                    displayName = google.displayName?.takeIf { it.isNotBlank() } ?: google.id,
                    photoUrl = google.profilePictureUri?.toString(),
                )
                // O ID token não é salvo, não é registrado em log e não vai à API Drive.
                // Esta aplicação local não possui um servidor nem usa Firebase Auth.
                viewModel.authorizeDrive(user)
            } catch (error: CancellationException) {
                viewModel.cancelCredentialRequest()
                throw error
            } catch (error: Exception) {
                viewModel.credentialFailure(error)
            }
        }
    })
}
```


## app/src/main/java/com/example/ui/login/LoginScreen.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.login

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState

/**
 * Tela visual independente do Google: também pode ser usada em Preview e teste.
 * Texto, ícone e um único botão. Nenhum dado de autenticação pertence à UI.
 */
@Composable
fun LoginScreen(
    busy: Boolean,
    error: String?,
    onGoogleSignIn: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    // O padrão do Haze evita blur nos aparelhos em que ele não é confiável.
    // O fallbackTint mantém o vidro translúcido nessas versões/dispositivos.
    val haze = rememberHazeState()
    val preview = LocalInspectionMode.current
    var visible by remember { mutableStateOf(preview) }
    LaunchedEffect(Unit) { visible = true }

    BoxWithConstraints(modifier.fillMaxSize().background(colors.surface)) {
        val compact = maxHeight < 480.dp
        LoginBackdrop(haze, Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().safeDrawingPadding()
                .padding(horizontal = 28.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier.fillMaxWidth().weight(1f),
                contentAlignment = Alignment.Center,
            ) {
                AnimatedVisibility(
                    visible = visible,
                    // O rodapé fica no final; só o conteúdo central rola quando necessário.
                    modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    enter = fadeIn(tween(380)) + slideInVertically(
                        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy),
                        initialOffsetY = { it / 12 },
                    ),
                ) {
                    Column(
                        Modifier.widthIn(max = 420.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        val logoShape = RoundedCornerShape(if (compact) 34.dp else 48.dp)
                        Box(
                            Modifier.size(if (compact) 148.dp else 204.dp)
                                .shadow(24.dp, logoShape, clip = false,
                                    ambientColor = colors.primary.copy(alpha = .18f),
                                    spotColor = colors.primary.copy(alpha = .28f))
                                .clip(logoShape)
                                .hazeEffect(haze, glassStyle(.48f))
                                .border(1.dp, Brush.linearGradient(listOf(
                                    Color.White.copy(alpha = .75f), colors.primary.copy(alpha = .13f),
                                )), logoShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            // Arquivo definitivo enviado pelo usuário, sem redesenho.
                            Image(
                                painter = painterResource(R.drawable.keplerae_logo),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.size(if (compact) 112.dp else 160.dp)
                                    .clip(RoundedCornerShape(if (compact) 20.dp else 28.dp)),
                            )
                        }
                        Spacer(Modifier.height(if (compact) 20.dp else 36.dp))
                        Text(
                            text = stringResource(R.string.app_name),
                            style = if (compact) MaterialTheme.typography.displayMedium
                                else MaterialTheme.typography.displayLarge,
                            fontWeight = FontWeight.Bold,
                            color = colors.onSurface,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().semantics { heading() },
                        )
                        Spacer(Modifier.height(if (compact) 24.dp else 40.dp))
                        GoogleGlassButton(busy, onGoogleSignIn, haze)
                        AnimatedVisibility(visible = error != null) {
                            Text(
                                text = error.orEmpty(), color = colors.error,
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
                                    .semantics { liveRegion = LiveRegionMode.Polite }
                                    .testTag("login_error"),
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text(
                text = stringResource(R.string.developed_by),
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }
    }
}

@Composable
private fun GoogleGlassButton(busy: Boolean, onClick: () -> Unit, haze: HazeState) {
    val colors = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(32.dp)
    val interactions = remember { MutableInteractionSource() }
    val pressed by interactions.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .97f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium), label = "googleButtonScale",
    )
    Button(
        onClick = onClick, enabled = !busy, interactionSource = interactions, shape = shape,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent, contentColor = colors.onSurface,
            disabledContainerColor = Color.Transparent, disabledContentColor = colors.onSurface,
        ),
        contentPadding = PaddingValues(horizontal = 22.dp, vertical = 18.dp),
        modifier = Modifier.widthIn(max = 340.dp).fillMaxWidth().heightIn(min = 64.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(18.dp, shape, clip = false,
                ambientColor = colors.primary.copy(alpha = .16f),
                spotColor = colors.primary.copy(alpha = .24f))
            .clip(shape).hazeEffect(haze, glassStyle(.72f))
            .border(1.dp, Brush.linearGradient(listOf(
                Color.White.copy(alpha = .78f), colors.outline.copy(alpha = .30f),
            )), shape)
            .semantics { stateDescription = if (busy) "Conectando ao Google" else "Pronto para entrar" }
            .testTag("google_sign_in"),
    ) {
        // Mantém as cores do G: não usar Icon(tint = ...) neste recurso.
        Image(painterResource(R.drawable.ic_google_g), contentDescription = null,
            modifier = Modifier.size(28.dp).clip(CircleShape).background(Color.White).padding(4.dp))
        Text(
            text = stringResource(R.string.google_sign_in),
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
        )
        if (busy) LoadingIndicator(
            color = colors.primary,
            modifier = Modifier.size(20.dp),
        ) else Spacer(Modifier.size(20.dp))
    }
}

@Composable
private fun glassStyle(tintAlpha: Float): HazeStyle {
    val colors = MaterialTheme.colorScheme
    return HazeStyle(
        backgroundColor = colors.surface,
        tint = HazeTint(colors.surface.copy(alpha = tintAlpha)),
        blurRadius = 28.dp, noiseFactor = .025f,
        fallbackTint = HazeTint(colors.surface.copy(alpha = .88f)),
    )
}

/** Anéis grandes, recortados nas bordas, como na referência. Sem bitmap de fundo. */
@Composable
private fun LoginBackdrop(haze: HazeState, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    Canvas(modifier.hazeSource(haze)) {
        drawRect(Brush.verticalGradient(listOf(colors.surface, colors.primaryContainer.copy(alpha = .40f), colors.surface)))
        fun orb(center: Offset, radius: Float, color: Color) {
            drawCircle(Brush.radialGradient(listOf(
                color.copy(alpha = .08f), color.copy(alpha = .38f), Color.Transparent,
            ), center = center, radius = radius * 1.14f), radius * 1.14f, center)
            drawCircle(Brush.radialGradient(listOf(
                colors.surface.copy(alpha = .96f), colors.primaryContainer.copy(alpha = .82f),
            ), center = center - Offset(radius * .25f, radius * .30f), radius = radius * 1.35f), radius, center)
            drawCircle(Color.White.copy(alpha = .42f), radius, center, style = Stroke(1.5.dp.toPx()))
        }
        val radius = minOf(size.width * .62f, size.height * .36f)
        orb(Offset(-radius * .28f, -radius * .23f), radius, colors.primary)
        orb(Offset(size.width + radius * .40f, size.height * .36f), radius * .42f, colors.primary)
        orb(Offset(size.width + radius * .02f, size.height + radius * .10f), radius * 1.26f, colors.secondary)
        orb(Offset(-radius * .36f, size.height * .88f), radius * .72f, colors.primary)
    }
}
```


## app/src/main/java/com/example/ui/profile/ProfileScreen.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui.profile

import android.os.Build
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.example.data.auth.GoogleUser
import com.example.data.repository.StudyState
import com.example.data.repository.ThemeMode
import com.example.ui.components.SharedMotion
import com.example.ui.theme.isDarkMode
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable fun GoogleAvatar(user: GoogleUser?, modifier: Modifier = Modifier) {
    val placeholder = rememberVectorPainter(Icons.Outlined.Person)
    AsyncImage(model = ImageRequest.Builder(LocalContext.current).data(user?.photoUrl)
        .crossfade(true).build(), placeholder = placeholder, error = placeholder,
        fallback = placeholder, contentDescription = "Foto da conta Google",
        contentScale = ContentScale.Crop, modifier = modifier.clip(CircleShape))
}

@Composable fun ProfileButton(user: GoogleUser?, motion: SharedMotion, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer,
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.surface.copy(alpha = .8f)),
        modifier = motion.bounds("profile-container").size(56.dp).testTag("profile_open")) {
        GoogleAvatar(user, motion.element("profile-avatar").fillMaxSize().padding(3.dp))
    }
}

@Composable fun ProfileScreen(user: GoogleUser?, state: StudyState, motion: SharedMotion,
    onTheme: (ThemeMode) -> Unit, onDynamicColor: (Boolean) -> Unit,
    onConfigureDrive: () -> Unit, onSignOut: () -> Unit) {
    var confirmExit by remember { mutableStateOf(false) }
    val dark = isDarkMode(state.theme)
    Box(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentAlignment = Alignment.TopCenter) {
        Surface(shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.surfaceContainerLow,
            modifier = motion.bounds("profile-container").widthIn(max = 620.dp).fillMaxWidth()) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(3.dp, MaterialTheme.colorScheme.primary.copy(alpha = .3f))) {
                    GoogleAvatar(user, motion.element("profile-avatar").size(112.dp).padding(5.dp))
                }
                Text(user?.displayName?.takeIf { it.isNotBlank() } ?: "Minha conta",
                    style = MaterialTheme.typography.headlineMedium, modifier = Modifier.testTag("profile_name"))
                if (user != null) Text(user.email, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Seu espaço, do seu jeito.", style = MaterialTheme.typography.titleMedium)
                // Somente duas imagens. Os nomes ficam na semântica para acessibilidade.
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)) {
                    ThemeOrb(dark = false, selected = !dark, modifier = Modifier.weight(1f)) { onTheme(ThemeMode.LIGHT) }
                    ThemeOrb(dark = true, selected = dark, modifier = Modifier.weight(1f)) { onTheme(ThemeMode.DARK) }
                }
                HorizontalDivider()
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Cores do seu Android", style = MaterialTheme.typography.titleMedium)
                        Text(if (Build.VERSION.SDK_INT >= 31) "Combine com o papel de parede."
                            else "Paleta Kepleræ neste Android.", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = state.dynamicColor, onCheckedChange = onDynamicColor,
                        enabled = Build.VERSION.SDK_INT >= 31)
                }
                OutlinedButton(onClick = onConfigureDrive, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.Cloud, null); Spacer(Modifier.width(8.dp)); Text("Google Drive")
                }
                FilledTonalButton(onClick = { confirmExit = true }, modifier = Modifier.fillMaxWidth().testTag("sign_out")) {
                    Icon(Icons.AutoMirrored.Outlined.Logout, null)
                    Spacer(Modifier.width(8.dp)); Text("Desconectar")
                }
                Text("Kepleræ 2.0 · Madox Fênix", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (confirmExit) AlertDialog(onDismissRequest = { confirmExit = false },
        icon = { Icon(Icons.AutoMirrored.Outlined.Logout, null) },
        title = { Text("Desconectar do Kepleræ?") },
        text = { Text("Você voltará à tela de login. Favoritos, progresso e tema ficam salvos neste aparelho.") },
        confirmButton = { TextButton(onClick = { confirmExit = false; onSignOut() },
            modifier = Modifier.testTag("confirm_sign_out")) { Text("Desconectar") } },
        dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Cancelar") } })
}

/** Sol e lua com volume e brilho, inspirados na referência Cycle of Vitality. */
@Composable private fun ThemeOrb(dark: Boolean, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val scale by animateFloatAsState(if (selected) 1f else .90f,
        animationSpec = spring(dampingRatio = .8f), label = "theme_selection")
    Surface(onClick = onClick, shape = MaterialTheme.shapes.extraLarge,
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
        border = BorderStroke(if (selected) 2.dp else 1.dp,
            if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
        shadowElevation = if (selected) 8.dp else 0.dp,
        modifier = modifier.widthIn(max = 128.dp).aspectRatio(1f).graphicsLayer { scaleX = scale; scaleY = scale }
            .testTag(if (dark) "profile_theme_DARK" else "profile_theme_LIGHT")
            .then(Modifier.themeSemantics(dark, selected))) {
        Canvas(Modifier.fillMaxSize().padding(20.dp)) {
            val r = size.minDimension * .28f
            val colors = if (dark) listOf(Color(0xFFE8FFA5), Color(0xFF5DAC68), Color(0xFF205D44))
                else listOf(Color(0xFFFFF2A8), Color(0xFFFFB247), Color(0xFFE5732C))
            drawCircle(Brush.radialGradient(listOf(colors[1].copy(alpha = .26f), Color.Transparent),
                radius = size.minDimension * .52f), size.minDimension * .52f)
            val lighting = Brush.radialGradient(colors, center = center - Offset(r * .5f, r * .5f), radius = r * 2f)
            if (dark) {
                val outer = Path().apply { addOval(androidx.compose.ui.geometry.Rect(center - Offset(r * 1.3f, r * 1.3f),
                    center + Offset(r * 1.3f, r * 1.3f))) }
                val hole = Path().apply { addOval(androidx.compose.ui.geometry.Rect(
                    center + Offset(-r * .1f, -r * 1.55f), center + Offset(r * 1.7f, r * .85f))) }
                val crescent = Path.combine(PathOperation.Difference, outer, hole)
                drawPath(crescent, lighting)
                drawCircle(Color(0xFFE6FFC0), r * .13f, center + Offset(r * 1.25f, -r * .9f))
                drawCircle(Color(0xFFE6FFC0), r * .07f, center + Offset(r * .4f, -r * 1.4f))
            } else {
                repeat(12) { i ->
                    val a = i * PI / 6
                    val unit = Offset(cos(a).toFloat(), sin(a).toFloat())
                    drawLine(colors[1], center + unit * (r * 1.35f), center + unit * (r * 1.68f),
                        strokeWidth = r * .18f, cap = StrokeCap.Round)
                }
                drawCircle(lighting, r)
                drawCircle(Color.White.copy(alpha = .28f), r * .82f, center - Offset(r * .1f, r * .1f),
                    style = Stroke(width = r * .045f))
            }
        }
    }
}
```


## app/src/main/java/com/example/ui/profile/ThemeSemantics.kt

```kotlin
package com.example.ui.profile

import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics

internal fun Modifier.themeSemantics(dark: Boolean, isSelected: Boolean): Modifier = semantics {
    contentDescription = if (dark) "Tema escuro" else "Tema claro"
    selected = isSelected
}
```


## app/src/main/java/com/example/ui/theme/Color.kt

```kotlin
package com.example.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/** Paleta do Kepleræ para Android 7–11 e quando as cores dinâmicas estão desligadas. */
internal val KepleraeLightColors = lightColorScheme(
    primary = Color(0xFF245DA8),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD9E7FF),
    onPrimaryContainer = Color(0xFF071D3D),
    secondary = Color(0xFF006B63),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFA4F2E4),
    onSecondaryContainer = Color(0xFF00201C),
    tertiary = Color(0xFF5A4D85),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFE7DEFF),
    onTertiaryContainer = Color(0xFF21143F),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFF8F9FF),
    onBackground = Color(0xFF18202C),
    surface = Color(0xFFF8F9FF),
    onSurface = Color(0xFF18202C),
    surfaceVariant = Color(0xFFDFE4EF),
    onSurfaceVariant = Color(0xFF424854),
    outline = Color(0xFF737A88),
    outlineVariant = Color(0xFFC3C9D5),
    inverseSurface = Color(0xFF2D3542),
    inverseOnSurface = Color(0xFFEDF0FA),
    inversePrimary = Color(0xFFA7C8FF),
    scrim = Color(0xFF000000),
    surfaceTint = Color(0xFF245DA8),
    surfaceBright = Color(0xFFF8F9FF),
    surfaceDim = Color(0xFFD7DCE6),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF1F4FC),
    surfaceContainer = Color(0xFFEBEFF8),
    surfaceContainerHigh = Color(0xFFE5E9F2),
    surfaceContainerHighest = Color(0xFFDFE3ED),
)

internal val KepleraeDarkColors = darkColorScheme(
    primary = Color(0xFFA7C8FF),
    onPrimary = Color(0xFF003064),
    primaryContainer = Color(0xFF17457B),
    onPrimaryContainer = Color(0xFFD9E7FF),
    secondary = Color(0xFF86D5C8),
    onSecondary = Color(0xFF003731),
    secondaryContainer = Color(0xFF005047),
    onSecondaryContainer = Color(0xFFA4F2E4),
    tertiary = Color(0xFFCABEED),
    onTertiary = Color(0xFF332650),
    tertiaryContainer = Color(0xFF4B3D6A),
    onTertiaryContainer = Color(0xFFE7DEFF),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF0F1726),
    onBackground = Color(0xFFE0E6F2),
    surface = Color(0xFF0F1726),
    onSurface = Color(0xFFE0E6F2),
    surfaceVariant = Color(0xFF424854),
    onSurfaceVariant = Color(0xFFC3C9D5),
    outline = Color(0xFF8D95A4),
    outlineVariant = Color(0xFF424854),
    inverseSurface = Color(0xFFE0E6F2),
    inverseOnSurface = Color(0xFF2D3542),
    inversePrimary = Color(0xFF245DA8),
    scrim = Color(0xFF000000),
    surfaceTint = Color(0xFFA7C8FF),
    surfaceBright = Color(0xFF354052),
    surfaceDim = Color(0xFF0F1726),
    surfaceContainerLowest = Color(0xFF0A111E),
    surfaceContainerLow = Color(0xFF182132),
    surfaceContainer = Color(0xFF1C2637),
    surfaceContainerHigh = Color(0xFF273143),
    surfaceContainerHighest = Color(0xFF323D50),
)
```


## app/src/main/java/com/example/ui/theme/Shape.kt

```kotlin
package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/** Formas compartilhadas: os componentes usam MaterialTheme.shapes. */
internal val KepleraeShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(24.dp),
    large = RoundedCornerShape(32.dp),
    extraLarge = RoundedCornerShape(40.dp),
)
```


## app/src/main/java/com/example/ui/theme/Theme.kt

```kotlin
package com.example.ui.theme

import android.os.Build
import android.util.Log
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFontFamilyResolver
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.text.font.createFontFamilyResolver
import com.example.data.repository.ThemeMode
import kotlinx.coroutines.CoroutineExceptionHandler

@Composable
fun isDarkMode(mode: ThemeMode): Boolean = when (mode) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

/**
 * Mesma assinatura da versão 1.2.2: MainActivity e preferências continuam integradas.
 * Android 12+: cores do papel de parede. Android 7–11: paleta do ícone Kepleræ.
 */
@Composable
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
fun KepleraeTheme(
    mode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    val dark = isDarkMode(mode)
    val context = LocalContext.current
    val preview = LocalInspectionMode.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !preview -> {
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        dark -> KepleraeDarkColors
        else -> KepleraeLightColors
    }
    val fontResolver = remember(context) {
        createFontFamilyResolver(
            context,
            CoroutineExceptionHandler { _, error ->
                // Falhas no download não bloqueiam o app: o resolver usa o fallback.
                Log.w("KepleraeFonts", "Fonte Google indisponível; usando fonte local.", error)
            },
        )
    }
    CompositionLocalProvider(LocalFontFamilyResolver provides fontResolver) {
        MaterialExpressiveTheme(
            colorScheme = colorScheme,
            typography = if (preview) PreviewTypography else Typography,
            shapes = KepleraeShapes,
            content = content,
        )
    }
}
```


## app/src/main/java/com/example/ui/theme/Type.kt

```kotlin
package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.DeviceFontFamilyName
import androidx.compose.ui.text.font.Font as DeviceFont
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font as GoogleFontFace
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.unit.sp
import com.example.R

private val googleFontsProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs,
)

/** Roboto do Google Fonts, com fallback local por peso, inclusive sem internet. */
private val KepleraeFontFamily = FontFamily(
    *listOf(FontWeight.Normal, FontWeight.Medium, FontWeight.SemiBold, FontWeight.Bold)
        .flatMap { weight ->
            listOf(
                GoogleFontFace(
                    googleFont = GoogleFont("Roboto"),
                    fontProvider = googleFontsProvider,
                    weight = weight,
                ),
                DeviceFont(familyName = DeviceFontFamilyName("sans-serif"), weight = weight),
            )
        }.toTypedArray(),
)

private fun materialTypography(family: FontFamily): Typography {
    fun style(size: Int, height: Int, weight: FontWeight, spacing: Float = 0f) = TextStyle(
        fontFamily = family,
        fontWeight = weight,
        fontSize = size.sp,
        lineHeight = height.sp,
        letterSpacing = spacing.sp,
    )
    // A escala mantém os 15 papéis do Material 3. Não usa tamanhos em pixels.
    return Typography(
        displayLarge = style(57, 64, FontWeight.Bold, -0.25f),
        displayMedium = style(45, 52, FontWeight.Bold),
        displaySmall = style(36, 44, FontWeight.SemiBold),
        headlineLarge = style(32, 40, FontWeight.Bold),
        headlineMedium = style(28, 36, FontWeight.SemiBold),
        headlineSmall = style(24, 32, FontWeight.SemiBold),
        titleLarge = style(22, 28, FontWeight.Medium),
        titleMedium = style(16, 24, FontWeight.Medium, 0.15f),
        titleSmall = style(14, 20, FontWeight.Medium, 0.1f),
        bodyLarge = style(16, 24, FontWeight.Normal, 0.5f),
        bodyMedium = style(14, 20, FontWeight.Normal, 0.25f),
        bodySmall = style(12, 16, FontWeight.Normal, 0.4f),
        labelLarge = style(14, 20, FontWeight.Medium, 0.1f),
        labelMedium = style(12, 16, FontWeight.Medium, 0.5f),
        labelSmall = style(11, 16, FontWeight.Medium, 0.5f),
    )
}

// Nome preservado para os arquivos que já importam Typography no projeto atual.
val Typography: Typography = materialTypography(KepleraeFontFamily)

/** O preview do Android Studio usa a mesma escala sem iniciar downloads. */
internal val PreviewTypography: Typography = materialTypography(FontFamily.SansSerif)
```


## app/src/main/res/drawable/ic_google_g.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<!-- Marca Google G: manter cores e proporção; não aplicar tint. -->
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="20dp" android:height="20dp" android:viewportWidth="48" android:viewportHeight="48">
    <path android:fillColor="#4285F4" android:pathData="M43.61,24.46c0,-1.36 -0.12,-2.65 -0.35,-3.92H24v7.42h11.04c-0.48,2.43 -1.93,4.49 -4.10,5.88v4.90h6.64c3.88,-3.58 6.03,-8.87 6.03,-14.28z" />
    <path android:fillColor="#34A853" android:pathData="M24,44c5.40,0 9.93,-1.79 13.24,-4.86l-6.64,-4.90c-1.84,1.24 -4.21,1.99 -6.60,1.99c-5.23,0 -9.67,-3.52 -11.26,-8.25H5.89v5.06C9.18,39.54 16.02,44 24,44z" />
    <path android:fillColor="#FBBC05" android:pathData="M12.74,27.98A12.03,12.03 0,0 1,12.10 24c0,-1.39 0.24,-2.73 0.64,-3.98V14.96H5.89A19.80,19.80 0,0 0,4 24c0,3.24 0.77,6.31 1.89,9.04z" />
    <path android:fillColor="#EA4335" android:pathData="M24,11.77c2.94,0 5.57,1.01 7.65,3.02l5.74,-5.74C33.91,5.81 29.40,4 24,4C16.02,4 9.18,8.46 5.89,14.96l6.85,5.06C14.33,15.29 18.77,11.77 24,11.77z" />
</vector>
```


## app/src/main/res/drawable/ic_kepler_symbol.xml

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">
    <path android:fillColor="#FFFFFF" android:pathData="M3,5.5 C6.5,4.5 9,5 12,7 C15,5 17.5,4.5 21,5.5 L21,18 C17.5,17 15,17.5 12,19.5 C9,17.5 6.5,17 3,18 Z"/>
    <path android:strokeColor="#5146A4" android:strokeWidth="1.2" android:fillColor="#00000000" android:pathData="M12,7 L12,18"/>
    <path android:fillColor="#C7F3DA" android:pathData="M17.5,1 L18.4,3.1 L20.5,4 L18.4,4.9 L17.5,7 L16.6,4.9 L14.5,4 L16.6,3.1 Z"/>
</vector>
```


## app/src/main/res/drawable/ic_launcher_background.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <solid android:color="#0F1726" />
</shape>
```


## app/src/main/res/drawable/ic_launcher_foreground.xml

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#F7F1FF" android:pathData="M28,35 C39,32 46,34 54,40 C62,34 69,32 80,35 L80,72 C69,69 62,71 54,77 C46,71 39,69 28,72 Z"/>
    <path android:strokeColor="#5146A4" android:strokeWidth="3" android:strokeLineCap="round" android:fillColor="#00000000" android:pathData="M54,41 L54,71"/>
    <path android:fillColor="#C7F3DA" android:pathData="M71,22 L74,28 L80,31 L74,34 L71,40 L68,34 L62,31 L68,28 Z"/>
</vector>
```


## app/src/main/res/drawable/ic_launcher_monochrome.xml

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#FFFFFF" android:pathData="M28,35 C39,32 46,34 52,39 L52,76 C45,71 38,69 28,72 Z M56,39 C62,34 69,32 80,35 L80,72 C70,69 63,71 56,76 Z M71,22 L74,28 L80,31 L74,34 L71,40 L68,34 L62,31 L68,28 Z"/>
</vector>
```


## app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/keplerae_launcher_foreground" />
</adaptive-icon>
```


## app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/keplerae_launcher_foreground" />
</adaptive-icon>
```


## app/src/main/res/mipmap-anydpi-v33/ic_launcher.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/keplerae_launcher_foreground" />
    <monochrome android:drawable="@drawable/ic_launcher_monochrome" />
</adaptive-icon>
```


## app/src/main/res/mipmap-anydpi-v33/ic_launcher_round.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/keplerae_launcher_foreground" />
    <monochrome android:drawable="@drawable/ic_launcher_monochrome" />
</adaptive-icon>
```


## app/src/main/res/values/colors.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="purple_200">#FFBB86FC</color>
    <color name="purple_500">#FF6200EE</color>
    <color name="purple_700">#FF3700B3</color>
    <color name="teal_200">#FF03DAC5</color>
    <color name="teal_700">#FF018786</color>
    <color name="black">#FF000000</color>
    <color name="white">#FFFFFFFF</color>
</resources>
```


## app/src/main/res/values/font_certs.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<!--
  Copyright 2022 The Android Open Source Project

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->
<resources>
    <array name="com_google_android_gms_fonts_certs">
        <item>@array/com_google_android_gms_fonts_certs_dev</item>
        <item>@array/com_google_android_gms_fonts_certs_prod</item>
    </array>
    <string-array name="com_google_android_gms_fonts_certs_dev">
        <item>
            MIIEqDCCA5CgAwIBAgIJANWFuGx90071MA0GCSqGSIb3DQEBBAUAMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbTAeFw0wODA0MTUyMzM2NTZaFw0zNTA5MDEyMzM2NTZaMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbTCCASAwDQYJKoZIhvcNAQEBBQADggENADCCAQgCggEBANbOLggKv+IxTdGNs8/TGFy0PTP6DHThvbbR24kT9ixcOd9W+EaBPWW+wPPKQmsHxajtWjmQwWfna8mZuSeJS48LIgAZlKkpFeVyxW0qMBujb8X8ETrWy550NaFtI6t9+u7hZeTfHwqNvacKhp1RbE6dBRGWynwMVX8XW8N1+UjFaq6GCJukT4qmpN2afb8sCjUigq0GuMwYXrFVee74bQgLHWGJwPmvmLHC69EH6kWr22ijx4OKXlSIx2xT1AsSHee70w5iDBiK4aph27yH3TxkXy9V89TDdexAcKk/cVHYNnDBapcavl7y0RiQ4biu8ymM8Ga/nmzhRKya6G0cGw8CAQOjgfwwgfkwHQYDVR0OBBYEFI0cxb6VTEM8YYY6FbBMvAPyT+CyMIHJBgNVHSMEgcEwgb6AFI0cxb6VTEM8YYY6FbBMvAPyT+CyoYGapIGXMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbYIJANWFuGx90071MAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEEBQADggEBABnTDPEF+3iSP0wNfdIjIz1AlnrPzgAIHVvXxunW7SBrDhEglQZBbKJEk5kT0mtKoOD1JMrSu1xuTKEBahWRbqHsXclaXjoBADb0kkjVEJu/Lh5hgYZnOjvlba8Ld7HCKePCVePoTJBdI4fvugnL8TsgK05aIskyY0hKI9L8KfqfGTl1lzOv2KoWD0KWwtAWPoGChZxmQ+nBli+gwYMzM1vAkP+aayLe0a1EQimlOalO762r0GXO0ks+UeXde2Z4e+8S/pf7pITEI/tP+MxJTALw9QUWEv9lKTk+jkbqxbsh8nfBUapfKqYn0eidpwq2AzVp3juYl7//fKnaPhJD9gs=
        </item>
    </string-array>
    <string-array name="com_google_android_gms_fonts_certs_prod">
        <item>
            MIIEQzCCAyugAwIBAgIJAMLgh0ZkSjCNMA0GCSqGSIb3DQEBBAUAMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtHb29nbGUgSW5jLjEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDAeFw0wODA4MjEyMzEzMzRaFw0zNjAxMDcyMzEzMzRaMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtHb29nbGUgSW5jLjEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDCCASAwDQYJKoZIhvcNAQEBBQADggENADCCAQgCggEBAKtWLgDYO6IIrgqWbxJOKdoR8qtW0I9Y4sypEwPpt1TTcvZApxsdyxMJZ2JORland2qSGT2y5b+3JKkedxiLDmpHpDsz2WCbdxgxRczfey5YZnTJ4VZbH0xqWVW/8lGmPav5xVwnIiJS6HXk+BVKZF+JcWjAsb/GEuq/eFdpuzSqeYTcfi6idkyugwfYwXFU1+5fZKUaRKYCwkkFQVfcAs1fXA5V+++FGfvjJ/CxURaSxaBvGdGDhfXE28LWuT9ozCl5xw4Yq5OGazvV24mZVSoOO0yZ31j7kYvtwYK6NeADwbSxDdJEqO4k//0zOHKrUiGYXtqw/A0LFFtqoZKFjnkCAQOjgdkwgdYwHQYDVR0OBBYEFMd9jMIhF1Ylmn/Tgt9r45jk14alMIGmBgNVHSMEgZ4wgZuAFMd9jMIhF1Ylmn/Tgt9r45jk14aloXikdjB0MQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLR29vZ2xlIEluYy4xEDAOBgNVBAsTB0FuZHJvaWQxEDAOBgNVBAMTB0FuZHJvaWSCCQDC4IdGZEowjTAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBAUAA4IBAQBt0lLO74UwLDYKqs6Tm8/yzKkEu116FmH4rkaymUIE0P9KaMftGlMexFlaYjzmB2OxZyl6euNXEsQH8gjwyxCUKRJNexBiGcCEyj6z+a1fuHHvkiaai+KL8W1EyNmgjmyy8AW7P+LLlkR+ho5zEHatRbM/YAnqGcFh5iZBqpknHf1SKMXFh4dd239FJ1jWYfbMDMy3NS5CTMQ2XFI1MvcyUTdZPErjQfTbQe3aDQsQcafEQPD+nqActifKZ0Np0IS9L9kR/wbNvyz6ENwPiTrjV2KRkEjH78ZMcUQXg0L3BYHJ3lc69Vs5Ddf9uUGGMYldX3WfMBEmh/9iFBDAaTCK
        </item>
    </string-array>
</resources>
```


## app/src/main/res/values/google_login.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- ID público de cliente OAuth do tipo Web, no MESMO projeto do cliente Android.
         Exemplo de formato: 123456789-abc.apps.googleusercontent.com.
         Preencha antes de gerar o APK. Não coloque aqui chave de API ou client secret. -->
    <string name="google_web_client_id" translatable="false"></string>
    <string name="google_sign_in">Entrar com Google</string>
    <string name="developed_by">Desenvolvido por Madox Fênix</string>
</resources>
```


## app/src/main/res/values/strings.xml

```xml
<resources><string name="app_name">Kepleræ</string></resources>
```


## app/src/main/res/values/themes.xml

```xml
<resources>
    <style name="Theme.MyApplication" parent="Theme.AppCompat.Light.NoActionBar">
        <item name="android:windowLightStatusBar">true</item>
        <item name="android:windowActionModeOverlay">true</item>
        <item name="android:fontFamily">sans</item>
        <item name="android:windowBackground">#FCF8FF</item>
    </style>
</resources>
```


## app/src/main/res/values-night/themes.xml

```xml
<resources><style name="Theme.MyApplication" parent="Theme.AppCompat.NoActionBar">
<item name="android:windowLightStatusBar">false</item><item name="android:fontFamily">sans</item><item name="android:windowBackground">#141218</item>
</style></resources>
```


## app/src/main/res/xml/backup_rules.xml

```xml
<?xml version="1.0" encoding="utf-8"?><!--
   Sample backup rules file; uncomment and customize as necessary.
   See https://developer.android.com/guide/topics/data/autobackup
   for details.
   Note: This file is ignored for devices older than API 31
   See https://developer.android.com/about/versions/12/backup-restore
-->
<full-backup-content>
    <exclude domain="sharedpref" path="keplerae_drive.xml" />
    <!--
   <include domain="sharedpref" path="."/>
   <exclude domain="sharedpref" path="device.xml"/>
-->
</full-backup-content>
```


## app/src/main/res/xml/data_extraction_rules.xml

```xml
<?xml version="1.0" encoding="utf-8"?><!--
   Sample data extraction rules file; uncomment and customize as necessary.
   See https://developer.android.com/about/versions/12/backup-restore#xml-changes
   for details.
-->
<data-extraction-rules>
    <cloud-backup>
        <exclude domain="sharedpref" path="keplerae_drive.xml" />
        <!-- TODO: Use <include> and <exclude> to control what is backed up.
        <include .../>
        <exclude .../>
        -->
    </cloud-backup>
    <device-transfer>
        <exclude domain="sharedpref" path="keplerae_drive.xml" />
    </device-transfer>
</data-extraction-rules>
```


## app/src/test/java/com/example/DriveRequestsTest.kt

```kotlin
package com.example

import com.example.data.drive.*
import org.junit.Assert.*
import org.junit.Test
import java.net.URLDecoder

class DriveRequestsTest {
    @Test fun mediaUsesApiAndCredentialsStayOutOfUrl() {
        val url = DriveRequests.file("real-ID_1", true)
        assertTrue(url.startsWith("https://www.googleapis.com/drive/v3/files/real-ID_1?"))
        assertTrue(url.contains("alt=media"))
        val headers = DriveCredentials("test-key").headers("app", "cert", "real-ID_1", "resource-key")
        assertEquals("test-key", headers["X-Goog-Api-Key"])
        assertEquals("real-ID_1/resource-key", headers["X-Goog-Drive-Resource-Keys"])
        assertFalse(url.contains("test-key"))
    }
    @Test fun googleAuthorizationReplacesAnonymousKey() {
        val headers = DriveCredentials("key", "token").headers("app", "cert", "id", "")
        assertEquals("Bearer token", headers["Authorization"])
        assertFalse(headers.containsKey("X-Goog-Api-Key"))
        assertFalse(headers.containsKey("X-Goog-Drive-Resource-Keys"))
    }
    @Test fun folderQueriesPreserveRealIdsAndPagination() {
        val url = URLDecoder.decode(DriveRequests.folder("folder_ID", "next+token"), "UTF-8")
        assertTrue(url.contains("'folder_ID' in parents and trashed = false"))
        assertTrue(url.contains("pageToken=next+token"))
        assertEquals("abc-def_1", DriveRequests.folderId("https://drive.google.com/drive/folders/abc-def_1?usp=sharing"))
        assertEquals("0-real_key", DriveRequests.resourceKey("https://drive.google.com/file/d/id/view?usp=sharing&resourcekey=0-real_key"))
    }
    @Test fun permissionsAndQuotaHaveDifferentRecoveryInstructions() {
        assertEquals("downloadQuotaExceeded", DriveRequests.errorReason("{\"error\":{\"errors\":[{\"reason\":\"downloadQuotaExceeded\"}]}}"))
        assertTrue(DriveRequests.errorMessage(404, "notFound").contains("autorize"))
        assertTrue(DriveRequests.errorMessage(403, "downloadQuotaExceeded").contains("limite"))
        assertTrue(DriveRequests.errorMessage(401, "authError").contains("expirou"))
        assertTrue(DriveRequests.errorMessage(403, "fileNotDownloadable").contains("proprietário"))
        assertTrue(DriveRequests.errorMessage(403, "accessNotConfigured").contains("Ative"))
    }
    @Test(expected = IllegalArgumentException::class) fun rejectInjectedFileIds() {
        DriveRequests.file("id?key=untrusted")
    }
}
```


## app/src/test/java/com/example/GoogleLoginConfigurationTest.kt

```kotlin
package com.example

import com.example.data.auth.GoogleLoginConfiguration
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GoogleLoginConfigurationTest {
    @Test fun acceptsPublicWebClientId() {
        assertTrue(GoogleLoginConfiguration.isWebClientId("1234567890-abc_def-123.apps.googleusercontent.com"))
        // Não restringir IDs antigos a um único formato de prefixo.
        assertTrue(GoogleLoginConfiguration.isWebClientId("1234567890.apps.googleusercontent.com"))
    }

    @Test fun rejectsApiKeysSecretsAndCopiedConfigurationText() {
        listOf("", "AIzaExampleKey", "GOCSPX-example", "{\"client_id\":\"123-a.apps.googleusercontent.com\"}",
            "https://123-a.apps.googleusercontent.com", "123-a.apps.googleusercontent.com\nextra")
            .forEach { assertFalse(GoogleLoginConfiguration.isWebClientId(it)) }
    }
}
```


## app/src/test/java/com/example/ItemOrderTest.kt

```kotlin
package com.example

import com.example.data.repository.mergeVisibleOrder
import com.example.data.repository.moveId
import com.example.data.repository.reconcileOrder
import org.junit.Assert.assertEquals
import org.junit.Test

class ItemOrderTest {
    @Test fun savedOrderSurvivesCatalogAdditionsAndRemovals() {
        assertEquals(listOf("b", "a", "new"),
            reconcileOrder(listOf("a", "b", "new"), listOf("removed", "b", "b", "a")))
    }
    @Test fun reorderingFilteredRowsDoesNotMoveHiddenRows() {
        assertEquals(listOf("c", "hidden", "a", "b"),
            mergeVisibleOrder(listOf("a", "hidden", "b", "c"), listOf("c", "a", "b")))
    }
    @Test fun dragUsesItemKeysAndIgnoresHeadersOrRemovedItems() {
        val order = listOf("a", "b", "c")
        assertEquals(listOf("b", "c", "a"), moveId(order, "a", "c"))
        assertEquals(order, moveId(order, "header", "b"))
        assertEquals(order, moveId(order, "a", "removed"))
    }
}
```


## app/src/test/java/com/example/StudyItemTest.kt

```kotlin
package com.example

import com.example.data.model.*
import org.junit.Assert.*
import org.junit.Test

class StudyItemTest {
    private fun item(kind: LinkKind = LinkKind.FILE) = StudyItem("id", "Fonética e acentuação", "01.mp4", "portugues",
        listOf("Aula 01"), ContentType.VIDEO, if (kind == LinkKind.FILE) "https://drive.google.com/file/d/realId/view?usp=drivesdk"
        else "https://drive.google.com/drive/folders/folderId", kind, if (kind == LinkKind.FILE) "realId" else "", "", "planilha.xlsx")
    @Test fun folderLinksAreNeverChangedToFilePreviews() {
        val folder = item(LinkKind.FOLDER)
        assertEquals(folder.url, folder.previewUrl)
        assertEquals("https://drive.google.com/file/d/realId/preview", item().previewUrl)
    }
    @Test fun onlyExpectedDriveLinksAreAllowed() {
        assertTrue(isAllowedDriveUrl(item().url))
        assertTrue(isAllowedDriveUrl(item(LinkKind.FOLDER).url))
        assertFalse(isAllowedDriveUrl("https://drive.google.com.evil.test/file/d/x"))
        assertFalse(isAllowedDriveUrl("http://drive.google.com/file/d/x"))
        assertFalse(isAllowedDriveUrl("javascript:alert(1)"))
        assertFalse(isAllowedDriveUrl("https://user@drive.google.com/file/d/x"))
    }
    @Test fun accentInsensitiveSearchAndExactFolderPrefixes() {
        assertTrue(item().matches("FONETICA"))
        assertTrue(item().matches("acentuacao"))
        assertFalse(item().matches("cardiologia"))
        assertEquals(1, itemsInPath(listOf(item()), listOf("Aula 01")).size)
        assertEquals(0, itemsInPath(listOf(item()), listOf("Aula 0")).size)
    }
}
```


## build.gradle.kts

```kotlin
plugins {
    id("com.android.application") version "8.11.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.21" apply false
}
```


## gradle/wrapper/gradle-wrapper.properties

```properties
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.13-bin.zip
networkTimeout=60000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
```


## gradle.properties

```properties
org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
```


## scripts/configure_google_login.py

```python
"""Preenche o ID público Web pelo Actions ou confere o valor já salvo no XML."""
import os
import re
from pathlib import Path
from xml.etree import ElementTree

PATH = Path("app/src/main/res/values/google_login.xml")


def configure():
    document = ElementTree.parse(PATH)
    node = document.find(".//string[@name='google_web_client_id']")
    if node is None:
        raise ValueError("Recurso google_web_client_id ausente")
    value = (os.environ.get("GOOGLE_WEB_CLIENT_ID") or node.text or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]+\.apps\.googleusercontent\.com", value):
        raise ValueError(
            "Configure a variável GOOGLE_WEB_CLIENT_ID no GitHub ou preencha "
            "google_web_client_id em google_login.xml. Use o ID público OAuth do tipo Web "
            "no mesmo projeto do cliente Android. Chave de API e client secret não servem."
        )
    node.text = value
    document.write(PATH, encoding="utf-8", xml_declaration=True)
    # Não registrar valores de credenciais em logs, mesmo quando são IDs públicos.
    print("ID OAuth Web configurado; tipo de cliente deve ser Web no Google Cloud.")


if __name__ == "__main__":
    configure()
```


## scripts/generate_icons.py

```python
#!/usr/bin/env python3
"""Reescala os originais definitivos, sem redesenhar o logo. Requer Pillow.

Não é uma etapa do build. Foreground adaptativo, monocromático e logo de login
já estão nos recursos Android; este utilitário regenera os PNGs legados e de design.
"""
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parents[1]
square = Image.open(root / "design/keplerae-original-square.png").convert("RGBA")
circle = Image.open(root / "design/keplerae-original-circle.png").convert("RGBA")
for density, size in [("mdpi", 48), ("hdpi", 72), ("xhdpi", 96), ("xxhdpi", 144), ("xxxhdpi", 192)]:
    dest = root / "app/src/main/res" / f"mipmap-{density}"
    dest.mkdir(exist_ok=True)
    square.resize((size, size), Image.Resampling.LANCZOS).save(dest / "ic_launcher.png")
    circle.resize((size, size), Image.Resampling.LANCZOS).save(dest / "ic_launcher_round.png")
circle.resize((512, 512), Image.Resampling.LANCZOS).save(root / "design/icon-512.png")
print("Ícone definitivo preservado: 10 PNGs de launcher e prévia 512 px.")
```


## scripts/import_catalog.py

```python
#!/usr/bin/env python3
"""Importa as planilhas originais sem inventar URLs, títulos ou durações."""
import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse
from openpyxl import load_workbook

SOURCES = [
 ('Hu_Brasil_Fisioterapia_modulos_0_a_32(1).xlsx', 'fisioterapia', ['Fisioterapia']),
 ('Portugues_Adriana_Referencia-5-1(1).xlsx', 'portugues', ['Aulas']),
 ('Aulas_Raciocinio_Logico_e_Matematica(1).xlsx', 'matematica', ['Raciocínio Lógico e Matemática']),
 ('Aulas_Raciocinio_Logico_e_Matematica(2).xlsx', 'matematica', ['Raciocínio Lógico e Matemática']),
 ('Aulas_Legislacao_EBSERH(1).xlsx', 'hu_legislacao', ['Legislação EBSERH']),
 ('Aulas_SUS-1(1).xlsx', 'sus', ['Aulas SUS']),
 ('Aulas_Profisio(1).xlsx', 'profisio', ['Vídeos', 'Artigos', 'Áudios']),
]

def build(source_dir):
    items, seen, duplicates, skipped = [], set(), 0, []
    for name, subject, sheets in SOURCES:
        book = load_workbook(source_dir / name, data_only=True)
        for sheet_name in sheets:
            sheet = book[sheet_name]
            for row_no, row in enumerate(sheet.iter_rows(min_row=2), start=2):
                values = [c.value for c in row]
                if not any(values): continue
                module = str(values[0] or 'Geral').strip()
                portuguese = subject == 'portugues'
                filename = str(values[2 if portuguese else 1] or '').strip()
                link_cell = row[3]
                url = str(link_cell.hyperlink.target if link_cell.hyperlink else values[3] or '').strip()
                parsed = urlparse(url)
                if parsed.scheme != 'https' or parsed.hostname != 'drive.google.com':
                    skipped.append({'source':name,'sheet':sheet_name,'row':row_no,'reason':'Sem URL válida do Drive'})
                    continue
                folder = '/folders/' in parsed.path
                title_ref = str(values[5] or '').strip() if portuguese else ''
                title = title_ref if title_ref and title_ref != 'Nome individual a identificar' else re.sub(r'\.(mp4|pdf|mp3|m4a|wav)$','',filename,flags=re.I)
                ext = filename.lower().rsplit('.',1)[-1]
                kind = 'PDF' if ext == 'pdf' else 'AUDIO' if ext in ['mp3','m4a','wav'] else 'VIDEO'
                key = (subject,url,filename,module) if folder else (subject,parsed.path)
                if key in seen:
                    duplicates += 1
                    continue
                seen.add(key)
                notes = [str(values[6])] if portuguese and len(values)>6 and values[6] else []
                if folder: notes.append('A planilha fornece o link da pasta. Localize '+filename+' no Google Drive.')
                path = module.split(' / ') if subject == 'profisio' else [module]
                file_id = re.search(r'/file/d/([^/]+)',parsed.path)
                uid = hashlib.sha256(repr(key).encode()).hexdigest()[:20]
                items.append(dict(id=uid,title=title or filename,filename=filename,subjectId=subject,
                    folderPath=path,type=kind,url=url,linkKind='FOLDER' if folder else 'FILE',
                    driveFileId=file_id.group(1) if file_id else '',note=' '.join(notes),
                    source=name,sheet=sheet_name,row=row_no))
    report = dict(total=len(items),bySubject=dict(Counter(x['subjectId'] for x in items)),
                  byType=dict(Counter(x['type'] for x in items)),
                  fileLinks=sum(x['linkKind']=='FILE' for x in items),
                  folderLinks=sum(x['linkKind']=='FOLDER' for x in items),
                  duplicateRowsRemoved=duplicates,skippedRows=skipped)
    return items,report

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('source_dir',type=Path)
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'app/src/main/assets/catalog.json')
    args=parser.parse_args()
    items,report=build(args.source_dir)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n')
    (args.output.parent/'catalog_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False))
```


## scripts/validate_catalog.py

```python
#!/usr/bin/env python3
import json
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse
root=Path(__file__).resolve().parents[1]
rows=json.loads((root/'app/src/main/assets/catalog.json').read_text())
report=json.loads((root/'app/src/main/assets/catalog_report.json').read_text())
assert len(rows)==report['total']==1022
assert len({r['id'] for r in rows})==len(rows)
assert set(r['subjectId'] for r in rows)=={'fisioterapia','portugues','matematica','hu_legislacao','sus','profisio'}
assert dict(Counter(r['type'] for r in rows))==report['byType']
for r in rows:
    u=urlparse(r['url'])
    assert u.scheme=='https' and u.hostname=='drive.google.com' and u.username is None
    assert r['title'] and r['filename'] and r['folderPath'] and r['source']
    assert all(p.strip() for p in r['folderPath'])
    if r['linkKind']=='FILE':
        assert '/file/d/' in u.path and r['driveFileId'] == u.path.split('/file/d/')[1].split('/')[0]
    else:
        assert '/drive/folders/' in u.path and not r['driveFileId']
        assert 'link da pasta' in r['note']
assert sum(r['linkKind']=='FOLDER' for r in rows)==342
assert not any('Keplerae_DriveFolderId' in r['url'] for r in rows)
assert sum(r['subjectId']=='matematica' for r in rows)==17
assert sum(r['type']=='AUDIO' for r in rows)==13
assert sum(r['subjectId']=='profisio' and r['type']=='PDF' for r in rows)==284
print('Catálogo validado: 1.022 itens; URLs, formatos, pastas e deduplicação consistentes.')
```


## scripts/validate_network_permissions.py

```python
import os
import re
import subprocess
import sys
from pathlib import Path
from xml.etree import ElementTree

REQUIRED = {"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"}
ANDROID_NAME = "{http://schemas.android.com/apk/res/android}name"


def validate(permissions):
    missing = REQUIRED - set(permissions)
    if missing:
        raise ValueError("Permissões de rede ausentes: " + ", ".join(sorted(missing)))


if __name__ == "__main__":
    if len(sys.argv) == 2:
        sdk = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
        if not sdk:
            raise RuntimeError("SDK Android não encontrado")
        aapt = Path(sdk) / "build-tools" / "36.0.0" / "aapt"
        output = subprocess.check_output([str(aapt), "dump", "permissions", sys.argv[1]], text=True)
        validate(re.findall(r"uses-permission: name='([^']+)'", output))
        print("APK final: permissões de internet e estado da rede presentes.")
    else:
        manifest = ElementTree.parse("app/src/main/AndroidManifest.xml").getroot()
        validate(node.get(ANDROID_NAME) for node in manifest.findall("uses-permission"))
        print("Manifesto: permissões de rede corretas.")
```


## settings.gradle.kts

```kotlin
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "Keplerae"
include(":app")
```
