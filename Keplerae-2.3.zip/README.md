# Kepleræ 2.3.0

Projeto Android completo em Jetpack Compose, Material You / Material 3 Expressive.
Pacote: `com.aistudio.keplerae.stdy`; versionCode 24; minSdk 24; compile/targetSdk 36.

## Subir e compilar no repositório existente

1. Envie **Keplerae-2.3.zip** intacto para a raiz de `flubdugnton-rgb/Keplermadox`.
2. Substitua o conteúdo de **.github/workflows/compilar-apk.yml** pelo workflow 2.3 entregue junto do ZIP. O mesmo workflow está dentro do projeto.
3. Mantenha a variável de repositório **GOOGLE_WEB_CLIENT_ID** já configurada, com seu OAuth Web client ID terminado em `.apps.googleusercontent.com`. Nenhuma nova chave ou cliente Google é necessário para esta atualização.
4. O commit inicia **Compilar Keplerae 2.3 - Estudos e foco**. Para executar manualmente: Actions → workflow → Run workflow.
5. Após sucesso do job APK, baixe **Keplerae-2.3-APK**, extraia o ZIP do artifact e instale **Keplerae-2.3.0-debug.apk** como atualização.
6. O job de interface executa testes no emulador e publica relatórios. Falha de testes precisa ser analisada; não significa que o usuário validou o funcionamento real.

O cache `keplerae-native-debug-signing-v1` e o SHA-1 anterior são preservados. O workflow recusa uma chave diferente para proteger atualização e OAuth. Não desinstale a versão anterior para atualizar. Não coloque client secret ou API key no repositório.

## O que mudou

Veja CHANGELOG-2.3.md. Na inicial foi removida somente a barra duplicada marcada na referência; o hero, a foto e os materiais permanecem.
Os menus seguem Início → Aulas → PDFs → Áudios → Matérias → Pomodoro → Questões. Em telas pequenas, o menu inferior rola horizontalmente para manter alvos de toque confortáveis.

## Sessão Google

A versão 2.0 não gravava o perfil para reabrir o processo. Na primeira entrada na 2.3, faça login uma vez; as entradas seguintes restauram o perfil salvo no mesmo aparelho.
O token Drive continua apenas em memória e é solicitado novamente ao Google sem interação quando o consentimento permanece válido. Falta de internet não apaga o perfil. Se as permissões forem revogadas ou a conta sair do aparelho, pode ser necessário autorizar o Drive de novo em Configurar Drive.
Desconectar pelo perfil limpa a sessão local e o Credential Manager. O perfil é excluído de backup/transferência para outro aparelho.

## Pomodoro

Presets e ciclo personalizado. Faixas: foco 1–180 minutos, pausas 1–90, 1–12 focos por ciclo. A pausa longa começa após o número escolhido de focos completos; depois dela o ciclo volta ao início. Por padrão a próxima fase aguarda você tocar em iniciar; avanço automático é opcional.
O cronômetro usa prazo monotônico e restaura o prazo salvo ao reabrir. O serviço fica ativo enquanto o contador roda, com notificação persistente e ações Pausar/Parar. Requer permissão de notificações no Android 13+. Forçar parada, desligar o aparelho ou restrições do fabricante podem interromper o alerta; ao reabrir, o app reconcilia o prazo e registra uma conclusão de fase sem duplicar.
Só o foco completo entra nas estatísticas. Zerar/pular não adiciona um foco incompleto; histórico e totais permanecem. Todos os registros são locais ao aparelho. Veja design/POMODORO-ASSETS.md para arte, animações, sons e licenças.

## Questões

Crie um bloco com o nome da matéria. Registre acertos e erros (inteiros de 0 a 1.000.000 em cada campo, total maior que zero); Calcular e salvar registra também a data/hora local. Filtre pela matéria ou veja Geral. O histórico pode ser excluído individualmente com confirmação.
Taxa de acerto = soma de acertos / soma de questões × 100; taxa de erro é complementar. Não usamos média simples de percentuais de sessões. Gráficos agrupam por dia, com até 14 dias registrados visíveis; cartões e histórico usam todos os registros filtrados. Totais em Long evitam estouro de Int. Dados não são sincronizados com Google Drive nem enviados a terceiros.

## Dependências e ferramentas

Java 17; Gradle 8.13; Android Gradle Plugin 8.11.1; Kotlin/Compose plugin 2.2.21.
Compose UI/Foundation/Animation 1.9.4; Material3 **1.5.0-alpha07** (já autorizada); Haze 1.7.0; Coil 3.3.0; DataStore 1.1.7; Reorderable 2.5.1; Credentials 1.6.0; GoogleID 1.1.1; Play Services Auth 22.0.0; Coroutines 1.10.2; Media3 1.8.1.
As novas funcionalidades usam bibliotecas já presentes, Android NotificationCompat, serviço nativo e gráficos Canvas: nenhuma biblioteca adicional de gráfico/animação é necessária.
O projeto usa `gradle` instalado pelo workflow; não inclui gradlew/wrapper JAR.

## Arquivos principais alterados/adicionados

- MainActivity.kt; ui/KepleraeApp.kt: inicial, sete menus, navegação por notificação.
- data/auth/GoogleLoginViewModel.kt; GoogleSessionStore.kt: perfil persistido, renovação, logout.
- data/productivity/PomodoroModel.kt; PomodoroStore.kt; PomodoroService.kt: cronômetro, estado, histórico, notificação, áudio.
- ui/productivity/PomodoroScreen.kt; PomodoroArtwork.kt: telas e arte em movimento.
- data/productivity/QuestionModel.kt; QuestionStore.kt: validação e persistência de registros.
- ui/productivity/QuestionsScreen.kt; StudyCharts.kt: dashboard, filtros, gráficos, registros.
- AndroidManifest.xml; res/xml/backup_rules.xml; res/xml/data_extraction_rules.xml: serviço, permissões, backup do perfil.
- res/drawable-nodpi/pomo_*.png; res/raw/pomo_*.wav; drawable/ic_pomodoro_notification.xml.
- scripts/fetch_pomodoro_sounds.py; .github/workflows/compilar-apk.yml; app/build.gradle.kts.
- Tests: ProductivityMathTest.kt; GoogleSessionStoreTest.kt; InterfaceTest.kt adaptado à inicial sem barra.

## Verificação desta entrega

Catálogo e permissões de rede validados; XML, PNG, WAV e scripts/workflow verificados localmente; arquivos protegidos do catálogo/Drive comparados com a base.
**A versão 2.3 ainda não foi compilada nem executada neste ambiente**, que não dispõe de SDK/Gradle. Os testes Kotlin/Android, lint e APK serão produzidos pelo GitHub após subir o ZIP e o workflow. A compilação anterior da versão 2.0 não valida o novo código 2.3.
