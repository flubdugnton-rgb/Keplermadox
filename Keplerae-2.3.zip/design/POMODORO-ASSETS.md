# Arte e sons do Pomodoro 2.3

As duas ilustrações originais foram criadas para o Kepleræ com a ferramenta de geração de imagens.
Arquivos finais usados pelo app:

- `app/src/main/res/drawable-nodpi/pomo_fishing.png`
- `app/src/main/res/drawable-nodpi/pomo_rest.png`

Prompt da cena de foco: tomate astronauta vermelho com folhas verdes, capacete transparente, traje branco e barquinha de madeira, pescando uma estrela e um planeta em um mar de estrelas; estilo 3D suave; fundo transparente; sem texto.
Prompt da cena de repouso: o mesmo tomate astronauta deitado em Saturno com os olhos fechados, anéis do planeta e pequenas estrelas; mesmo estilo e transparência.

`PomodoroArtwork.kt` anima a barquinha com oscilação/rotação suave e estrelas cintilantes em loop apenas durante o foco em andamento. Ao pausar ou durante a pausa, usa a cena estática de Saturno. O app não depende de GIF nem de vídeo remoto.

Os dois WAVs incluídos no ZIP são tons originais sintetizados para o app, dedicados ao domínio público (CC0). Funcionam offline.
Durante a compilação, `scripts/fetch_pomodoro_sounds.py` tenta substituir esses tons por amostras públicas de `code4fukui/sound-cc0`, commit `0bdbbe370c42897e12b7c5b0b26d96228e0d2931`: `bell1.wav` e `metal1.wav`.

Origem: https://github.com/code4fukui/sound-cc0
Licença da origem: https://github.com/code4fukui/sound-cc0/blob/0bdbbe370c42897e12b7c5b0b26d96228e0d2931/LICENSE

O script confere o hash do blob Git antes de converter o áudio em WAV PCM mono, normalizar o volume, limitar a duração a 2,4 segundos e aplicar entrada/saída suaves. Se a origem estiver indisponível, mantém os sons originais incluídos. A proveniência efetivamente usada fica em `design/pomodoro-sound-provenance.json` na árvore compilada.

O seletor de som e a opção de desativar ficam em Pomodoro → Ajustes. O Android pode silenciar sons pelo volume/modo do aparelho.
