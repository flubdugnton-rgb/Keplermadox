# Alterações da versão 2.3

- `.github/workflows/compilar-apk.yml`
- `CHANGELOG-2.3.md`
- `README.md`
- `VERIFICACAO.json`
- `app/build.gradle.kts`
- `app/src/androidTest/java/com/example/GoogleSessionStoreTest.kt`
- `app/src/androidTest/java/com/example/InterfaceTest.kt`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/example/MainActivity.kt`
- `app/src/main/java/com/example/data/auth/GoogleLoginViewModel.kt`
- `app/src/main/java/com/example/data/auth/GoogleSessionStore.kt`
- `app/src/main/java/com/example/data/productivity/PomodoroModel.kt`
- `app/src/main/java/com/example/data/productivity/PomodoroService.kt`
- `app/src/main/java/com/example/data/productivity/PomodoroStore.kt`
- `app/src/main/java/com/example/data/productivity/QuestionModel.kt`
- `app/src/main/java/com/example/data/productivity/QuestionStore.kt`
- `app/src/main/java/com/example/ui/KepleraeApp.kt`
- `app/src/main/java/com/example/ui/productivity/PomodoroArtwork.kt`
- `app/src/main/java/com/example/ui/productivity/PomodoroScreen.kt`
- `app/src/main/java/com/example/ui/productivity/QuestionsScreen.kt`
- `app/src/main/java/com/example/ui/productivity/StudyCharts.kt`
- `app/src/main/java/com/example/ui/profile/ProfileScreen.kt`
- `app/src/main/res/drawable-nodpi/pomo_fishing.png`
- `app/src/main/res/drawable-nodpi/pomo_rest.png`
- `app/src/main/res/drawable/ic_pomodoro_notification.xml`
- `app/src/main/res/raw/pomo_bell.wav`
- `app/src/main/res/raw/pomo_soft.wav`
- `app/src/main/res/xml/backup_rules.xml`
- `app/src/main/res/xml/data_extraction_rules.xml`
- `app/src/test/java/com/example/ProductivityMathTest.kt`
- `design/POMODORO-ASSETS.md`
- `scripts/fetch_pomodoro_sounds.py`
- `verification.json`

O restante do projeto completo está incluído no ZIP.
