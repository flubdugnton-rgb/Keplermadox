package com.example.ui.productivity

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

data class ChartPoint(val label: String, val primary: Float, val secondary: Float = 0f)
fun dateLabel(time: Long, pattern: String="dd/MM HH:mm"): String=SimpleDateFormat(pattern,Locale("pt","BR")).format(Date(time))

/** Valores reais, sem dados de demonstração; descrição acessível contém todos os pontos. */
@Composable fun StudyChart(points: List<ChartPoint>, percent: Boolean=false, modifier: Modifier=Modifier,
    metricLabel: String = if(percent) "Acertos por dia" else "Acertos e erros por dia", unit: String = "acertos") {
    val primary=MaterialTheme.colorScheme.primary
    val secondary=MaterialTheme.colorScheme.error
    val grid=MaterialTheme.colorScheme.outlineVariant
    if(points.isEmpty()) { Text("Seus registros aparecerão aqui.",color=MaterialTheme.colorScheme.onSurfaceVariant);return }
    val shown=points.takeLast(14)
    val max=if(percent) 100f else shown.maxOf { it.primary+it.secondary }.coerceAtLeast(1f)
    Column(modifier) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(if(percent) "100%" else max.toInt().toString(),style=MaterialTheme.typography.labelSmall)
            Text(metricLabel,style=MaterialTheme.typography.labelSmall)
        }
        Canvas(Modifier.fillMaxWidth().height(156.dp).padding(vertical=10.dp)
            .semantics { contentDescription=shown.joinToString("; ") {
                "${it.label}: ${it.primary}${if(percent) "%" else " $unit"}" + if(!percent&&it.secondary>0) ", ${it.secondary} erros" else ""
            } }) {
            for(i in 0..4) {
                val y=size.height*i/4
                drawLine(grid,Offset(0f,y),Offset(size.width,y),1.dp.toPx())
            }
            if(percent) {
                val line=Path()
                shown.forEachIndexed { i,p ->
                    val x=if(shown.size==1) size.width/2 else size.width*i/(shown.size-1)
                    val y=size.height*(1-p.primary.coerceIn(0f,100f)/100f)
                    if(i==0) line.moveTo(x,y) else line.lineTo(x,y)
                }
                drawPath(line,primary,style=Stroke(3.dp.toPx()))
                shown.forEachIndexed { i,p ->
                    val x=if(shown.size==1) size.width/2 else size.width*i/(shown.size-1)
                    drawCircle(primary,4.dp.toPx(),Offset(x,size.height*(1-p.primary.coerceIn(0f,100f)/100f)))
                }
            } else {
                val cell=size.width/shown.size;val bar=cell*.62f
                shown.forEachIndexed { i,p ->
                    val h=size.height*p.primary/max;val e=size.height*p.secondary/max
                    val x=cell*i+(cell-bar)/2
                    drawRect(primary,Offset(x,size.height-h),Size(bar,h))
                    drawRect(secondary,Offset(x,size.height-h-e),Size(bar,e))
                }
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(shown.first().label,style=MaterialTheme.typography.labelSmall)
            Text(shown.last().label,style=MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable fun StatTile(label: String, value: String, modifier: Modifier=Modifier) {
    Card(modifier,colors=CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Text(value,style=MaterialTheme.typography.headlineSmall)
            Text(label,style=MaterialTheme.typography.labelLarge)
        }
    }
}
