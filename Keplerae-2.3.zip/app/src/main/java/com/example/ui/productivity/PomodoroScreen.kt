@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.productivity

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.productivity.*
import kotlinx.coroutines.delay
import java.util.Calendar

@Composable fun PomodoroScreen() {
    val context=LocalContext.current
    val store=remember { PomodoroStore.get(context) }
    val state by store.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var custom by rememberSaveable { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var elapsed by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var wall by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var message by remember { mutableStateOf<String?>(null) }
    fun startTimer() {
        runCatching { PomodoroService.command(context,PomodoroService.START) }
            .onFailure { message="Não foi possível iniciar o cronômetro. ${it.localizedMessage.orEmpty()}" }
    }
    val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if(!granted) message="O cronômetro funciona no app. Permita notificações nas configurações do Android para ver o tempo fora dele."
        startTimer()
    }
    LaunchedEffect(state.running) {
        if(state.running) {
            runCatching { PomodoroService.command(context,PomodoroService.RESTORE) }
            while(true) { wall=System.currentTimeMillis();elapsed=SystemClock.elapsedRealtime();delay(250) }
        }
    }
    val remaining=remainingAt(state,wall,elapsed)
    val total=state.history.sumOf { it.durationMs }
    val progress=(1f-remaining.toFloat()/state.phaseDurationMs.coerceAtLeast(1)).coerceIn(0f,1f)
    val weeks=remember(state.history) { (6 downTo 0).map { ago ->
        val cal=Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR,-ago) }
        val key=dateLabel(cal.timeInMillis,"yyyy-MM-dd")
        val minutes=state.history.filter { dateLabel(it.finishedAt,"yyyy-MM-dd")==key }.sumOf { it.durationMs }/60_000f
        ChartPoint(dateLabel(cal.timeInMillis,"dd/MM"),minutes) } }
    LazyColumn(Modifier.fillMaxSize().testTag("pomodoro_screen"),contentPadding=PaddingValues(20.dp),
        horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth()) {
                Text("Pomodoro",style=MaterialTheme.typography.displaySmall)
                Text("Uma estrela de cada vez.",color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                listOf("Foco","Progresso","Ajustes").forEachIndexed { index,title ->
                    FilterChip(selected=tab==index,onClick={tab=index},label={Text(title)},modifier=Modifier.weight(1f))
                }
            }
        }
        if(tab==0) {
            item { PomodoroArtwork(state.running&&state.phase==PomodoroPhase.FOCUS,Modifier.fillMaxWidth().height(260.dp)) }
            item {
                Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text(state.phase.label,style=MaterialTheme.typography.titleLarge)
                    Text(formatTimer(remaining),style=MaterialTheme.typography.displayLarge.copy(fontSize=76.sp,lineHeight=86.sp,
                        fontWeight=FontWeight.Bold),maxLines=1,modifier=Modifier.testTag("pomodoro_time"))
                    Text(if(state.paused) "Pausado" else if(state.running) "Em andamento" else "Pronto para começar",
                        color=MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${state.cycle.coerceAtMost(state.settings.cycles)} de ${state.settings.cycles} focos do ciclo concluídos",
                        style=MaterialTheme.typography.bodySmall)
                }
            }
            item { LinearWavyProgressIndicator(progress={progress},modifier=Modifier.fillMaxWidth()) }
            item {
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(20.dp)) {
                    OutlinedIconButton(onClick={confirmReset=true},modifier=Modifier.size(52.dp)) {Icon(Icons.Outlined.RestartAlt,"Zerar etapa")}
                    FilledIconButton(onClick={
                        if(state.running) PomodoroService.command(context,PomodoroService.PAUSE)
                        else if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        else startTimer()
                    },modifier=Modifier.size(76.dp).testTag("pomodoro_start")) {
                        Icon(if(state.running) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            if(state.running) "Pausar" else "Iniciar",Modifier.size(36.dp))
                    }
                    OutlinedIconButton(onClick={PomodoroService.command(context,PomodoroService.SKIP)},modifier=Modifier.size(52.dp)) {
                        Icon(Icons.Outlined.SkipNext,"Pular etapa sem registrar foco") }
                }
            }
            item { Text("Só focos completos entram no seu total. Pular ou zerar não registra um pomodoro.",style=MaterialTheme.typography.bodySmall) }
        }
        if(tab==1) {
            item {
                Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    StatTile("Pomodoros",state.history.size.toString(),Modifier.weight(1f))
                    StatTile("Tempo de foco",formatStudyTime(total),Modifier.weight(1f))
                }
            }
            item {
                Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLowest)) {
                    Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
                        Text("Últimos 7 dias",style=MaterialTheme.typography.titleLarge)
                        Text("Minutos de foco concluídos",style=MaterialTheme.typography.bodySmall)
                        StudyChart(weeks,metricLabel="Minutos de foco por dia",unit="minutos de foco")
                    }
                }
            }
            item { Text("Seu histórico",style=MaterialTheme.typography.titleLarge,modifier=Modifier.fillMaxWidth()) }
            if(state.history.isEmpty()) item {Text("Seu primeiro foco concluído aparecerá aqui.")}
            items(state.history.sortedByDescending { it.finishedAt }.take(50),key={it.id}) { record ->
                ListItem(headlineContent={Text("Foco concluído")},supportingContent={Text(dateLabel(record.finishedAt))},
                    leadingContent={Icon(Icons.Outlined.CheckCircle,null)},trailingContent={Text(formatStudyTime(record.durationMs))})
            }
        }
        if(tab==2) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("Ciclos fixos",style=MaterialTheme.typography.titleLarge)
                        listOf(PomodoroSettings(),PomodoroSettings(50,10,20,4),PomodoroSettings(90,15,30,2)).forEach { preset ->
                            OutlinedButton(onClick={store.configure(preset.copy(sounds=state.settings.sounds,sound=state.settings.sound,autoAdvance=state.settings.autoAdvance))},
                                enabled=!state.running&&!state.paused,modifier=Modifier.fillMaxWidth()) {
                                Text("${preset.focusMinutes} / ${preset.shortMinutes} / ${preset.longMinutes} min • ${preset.cycles} focos") }
                        }
                        Text("Foco / pausa curta / pausa longa",style=MaterialTheme.typography.bodySmall)
                        FilledTonalButton(onClick={custom=true},enabled=!state.running&&!state.paused,modifier=Modifier.fillMaxWidth()) {
                            Icon(Icons.Outlined.Tune,null);Spacer(Modifier.width(8.dp));Text("Personalizar ciclo") }
                        Text("Atual: ${state.settings.focusMinutes} / ${state.settings.shortMinutes} / ${state.settings.longMinutes} min • ${state.settings.cycles} focos")
                        if(state.running||state.paused) Text("Zere a etapa para alterar suas durações.",style=MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {Text("Sons do Pomodoro",style=MaterialTheme.typography.titleMedium);Text("Toque ao concluir uma etapa",style=MaterialTheme.typography.bodySmall)}
                            Switch(state.settings.sounds,{store.configure(state.settings.copy(sounds=it))})
                        }
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            listOf("bell" to "Sino","soft" to "Suave").forEach { (id,name) ->
                                FilterChip(selected=state.settings.sound==id,onClick={store.configure(state.settings.copy(sound=id));if(state.settings.sounds) PomodoroAudio.play(context,id)},label={Text(name)}) }
                        }
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {Text("Avançar automaticamente",style=MaterialTheme.typography.titleMedium);Text("Iniciar foco e pausas em sequência",style=MaterialTheme.typography.bodySmall)}
                            Switch(state.settings.autoAdvance,{store.configure(state.settings.copy(autoAdvance=it))})
                        }
                        Text("O tempo aparece na notificação enquanto o cronômetro está rodando. O Android precisa permitir notificações.",style=MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        message?.let { text -> item {Text(text,color=MaterialTheme.colorScheme.error)} }
    }
    if(confirmReset) AlertDialog(onDismissRequest={confirmReset=false},icon={Icon(Icons.Outlined.RestartAlt,null)},
        title={Text("Zerar esta etapa?")},text={Text("O histórico permanece salvo. O foco incompleto não será contado.")},
        confirmButton={TextButton(onClick={PomodoroService.command(context,PomodoroService.RESET);confirmReset=false}) {Text("Zerar")}},
        dismissButton={TextButton(onClick={confirmReset=false}) {Text("Cancelar")}})
    if(custom) PomodoroSettingsDialog(state.settings,onDismiss={custom=false},onSave={store.configure(it);custom=false})
}

fun formatStudyTime(ms: Long): String { val minutes=ms/60_000;return if(minutes>=60) "${minutes/60}h ${minutes%60}min" else "${minutes}min" }

@Composable private fun PomodoroSettingsDialog(current: PomodoroSettings,onDismiss:()->Unit,onSave:(PomodoroSettings)->Unit) {
    var focus by rememberSaveable {mutableStateOf(current.focusMinutes.toString())}
    var short by rememberSaveable {mutableStateOf(current.shortMinutes.toString())}
    var long by rememberSaveable {mutableStateOf(current.longMinutes.toString())}
    var cycles by rememberSaveable {mutableStateOf(current.cycles.toString())}
    var error by remember {mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,icon={Icon(Icons.Outlined.Tune,null)},title={Text("Seu ciclo")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(focus,{focus=it.take(3)},label={Text("Foco (1–180 min)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            OutlinedTextField(short,{short=it.take(2)},label={Text("Pausa curta (1–90 min)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            OutlinedTextField(long,{long=it.take(2)},label={Text("Pausa longa (1–90 min)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            OutlinedTextField(cycles,{cycles=it.take(2)},label={Text("Focos por ciclo (1–12)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            if(error) Text("Confira os limites de cada campo.",color=MaterialTheme.colorScheme.error)
        }},confirmButton={TextButton(onClick={
            val settings=current.copy(focusMinutes=focus.toIntOrNull()?:0,shortMinutes=short.toIntOrNull()?:0,
                longMinutes=long.toIntOrNull()?:0,cycles=cycles.toIntOrNull()?:0)
            if(settings.valid()) onSave(settings) else error=true
        }) {Text("Salvar")}},dismissButton={TextButton(onClick=onDismiss) {Text("Cancelar")}})
}
