package com.example.ui.productivity

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import kotlin.math.sin

/** Arte real do app + movimento procedural. Nenhuma animação continua quando parado. */
@Composable fun PomodoroArtwork(active: Boolean, modifier: Modifier=Modifier) {
    Crossfade(active,modifier,label="tomato_scene") { moving ->
        if(moving) {
            val loop=rememberInfiniteTransition(label="cosmic_pomodoro")
            val phase by loop.animateFloat(0f,6.283185f,infiniteRepeatable(tween(5000,easing=LinearEasing),RepeatMode.Restart),label="boat_wave")
            Box(Modifier.fillMaxSize()) {
                Canvas(Modifier.fillMaxSize()) {
                    repeat(18) { i ->
                        val x=size.width*((i*37%97)/100f)
                        val y=size.height*((i*29%89)/100f)
                        val sparkle=(.35f+.35f*sin(phase+i)).coerceIn(.05f,.7f)
                        drawCircle(Color(0xFFAFDDE5).copy(alpha=sparkle),2f+i%3,Offset(x,y))
                    }
                }
                Image(painterResource(R.drawable.pomo_fishing),"Tomate astronauta pescando estrelas e planetas",
                    Modifier.fillMaxSize().graphicsLayer { translationY=sin(phase)*8f;rotationZ=sin(phase)*1.8f },contentScale=ContentScale.Fit)
            }
        } else Image(painterResource(R.drawable.pomo_rest),"Tomate astronauta descansando sobre Saturno",
            Modifier.fillMaxSize(),contentScale=ContentScale.Fit)
    }
}
