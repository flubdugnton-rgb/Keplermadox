@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui.productivity

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.productivity.*
import com.example.ui.components.HelpTooltip
import java.util.Locale

@Composable fun QuestionsScreen() {
    val context=LocalContext.current
    val store=remember { QuestionStore.get(context) }
    val state by store.state.collectAsStateWithLifecycle()
    var subjectId by rememberSaveable { mutableStateOf<String?>(null) }
    var create by rememberSaveable { mutableStateOf(false) }
    var adding by rememberSaveable { mutableStateOf(false) }
    var deleteId by remember { mutableStateOf<String?>(null) }
    val records=remember(state.records,subjectId) { state.records.filter { subjectId==null||it.subjectId==subjectId } }
    val totals=remember(records) { questionTotals(records) }
    val daily=remember(records) { records.sortedBy { it.recordedAt }.groupBy { dateLabel(it.recordedAt,"yyyy-MM-dd") }.map { (_,r) ->
        val total=questionTotals(r)
        Triple(dateLabel(r.first().recordedAt,"dd/MM"),total,r.size) } }
    LazyColumn(Modifier.fillMaxSize().testTag("questions_screen"),contentPadding=PaddingValues(20.dp),
        verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Questões",style=MaterialTheme.typography.displaySmall)
                    Text("Cada registro conta sua evolução.",color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick={create=true}) { Icon(Icons.Outlined.CreateNewFolder,"Criar bloco de matéria") }
            }
        }
        item {
            LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                item { FilterChip(selected=subjectId==null,onClick={subjectId=null},label={Text("Geral")}) }
                items(state.subjects,key={it.id}) { s -> FilterChip(selected=subjectId==s.id,onClick={subjectId=s.id},label={Text(s.name)}) }
                item { AssistChip(onClick={create=true},label={Text("Nova matéria")},leadingIcon={Icon(Icons.Outlined.Add,null)}) }
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                StatTile("Questões",totals.total.toString(),Modifier.weight(1f))
                StatTile("Taxa de acerto",if(totals.total==0L) "—" else String.format(Locale("pt","BR"),"%.1f%%",totals.accuracy),Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                StatTile("Acertos",totals.correct.toString(),Modifier.weight(1f))
                StatTile("Erros",totals.wrong.toString(),Modifier.weight(1f))
            }
        }
        item {
            FilledTonalButton(onClick={if(state.subjects.isEmpty()) create=true else adding=true},Modifier.fillMaxWidth().heightIn(min=52.dp)) {
                Icon(Icons.Outlined.Calculate,null);Spacer(Modifier.width(8.dp));Text("Registrar e calcular")
            }
        }
        item {
            Card(colors=CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLowest)) {
                Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("Evolução",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f))
                        HelpTooltip("Como calculamos","Taxa = acertos ÷ (acertos + erros) × 100. O total soma as questões de todos os registros selecionados; não usa média simples de percentuais. O gráfico agrupa por data e mostra até 14 dias registrados.")
                    }
                    StudyChart(daily.map { ChartPoint(it.first,it.second.accuracy.toFloat()) },percent=true)
                    HorizontalDivider()
                    StudyChart(daily.map { ChartPoint(it.first,it.second.correct.toFloat(),it.second.wrong.toFloat()) })
                    Row(horizontalArrangement=Arrangement.spacedBy(20.dp)) {
                        Text("● Acertos",color=MaterialTheme.colorScheme.primary)
                        Text("● Erros",color=MaterialTheme.colorScheme.error)
                    }
                    Text("${records.size} registros • ${daily.size} dias de prática",style=MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Text("Histórico",style=MaterialTheme.typography.headlineSmall) }
        if(records.isEmpty()) item { Text("Crie uma matéria e registre sua primeira sessão de questões.") }
        items(records.sortedByDescending { it.recordedAt },key={it.id}) { r ->
            val name=state.subjects.firstOrNull { it.id==r.subjectId }?.name ?: "Matéria"
            val percent=100.0*r.correct/(r.correct.toLong()+r.wrong)
            Card(Modifier.fillMaxWidth().animateItem()) {
                Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                        Text(name,style=MaterialTheme.typography.titleMedium)
                        Text(dateLabel(r.recordedAt),style=MaterialTheme.typography.labelMedium)
                        Text("${r.correct} acertos • ${r.wrong} erros • ${String.format(Locale("pt","BR"),"%.1f%%",percent)}")
                    }
                    IconButton(onClick={deleteId=r.id}) { Icon(Icons.Outlined.DeleteOutline,"Excluir registro") }
                }
            }
        }
    }
    if(create) {
        var name by rememberSaveable { mutableStateOf("") };var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(onDismissRequest={create=false},icon={Icon(Icons.Outlined.CreateNewFolder,null)},title={Text("Nova matéria")},
            text={Column { OutlinedTextField(name,{name=it.take(80);error=null},label={Text("Nome do bloco")},singleLine=true)
                error?.let { Text(it,color=MaterialTheme.colorScheme.error) } }},
            confirmButton={TextButton(onClick={runCatching { store.createSubject(name) }.onSuccess { subjectId=it;create=false }
                .onFailure { error=it.message }}) {Text("Criar")}},dismissButton={TextButton(onClick={create=false}) {Text("Cancelar")}})
    }
    if(adding) {
        var chosen by rememberSaveable { mutableStateOf(subjectId ?: state.subjects.first().id) }
        var correct by rememberSaveable { mutableStateOf("") };var wrong by rememberSaveable { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(onDismissRequest={adding=false},icon={Icon(Icons.Outlined.Calculate,null)},title={Text("Registrar questões")},
            text={Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
                LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)) { items(state.subjects) { s ->
                    FilterChip(selected=chosen==s.id,onClick={chosen=s.id},label={Text(s.name)}) } }
                OutlinedTextField(correct,{correct=it.take(7);error=null},label={Text("Acertos")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                OutlinedTextField(wrong,{wrong=it.take(7);error=null},label={Text("Erros")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                Text("Data: ${dateLabel(System.currentTimeMillis())}",style=MaterialTheme.typography.bodySmall)
                error?.let { Text(it,color=MaterialTheme.colorScheme.error) }
            }},confirmButton={TextButton(onClick={
                val c=correct.toIntOrNull();val w=wrong.toIntOrNull()
                if(!validQuestionCounts(c,w)) error="Use inteiros de 0 a 1.000.000. O total deve ser maior que zero."
                else { store.add(chosen,c!!,w!!);adding=false }
            }) {Text("Calcular e salvar")}},dismissButton={TextButton(onClick={adding=false}) {Text("Cancelar")}})
    }
    if(deleteId!=null) AlertDialog(onDismissRequest={deleteId=null},icon={Icon(Icons.Outlined.DeleteOutline,null)},
        title={Text("Excluir este registro?")},text={Text("Os totais e os gráficos serão recalculados.")},
        confirmButton={TextButton(onClick={store.deleteRecord(deleteId!!);deleteId=null}) {Text("Excluir")}},
        dismissButton={TextButton(onClick={deleteId=null}) {Text("Cancelar")}})
}
