package com.example.data.auth

import android.accounts.Account
import android.app.Application
import android.app.PendingIntent
import android.content.Intent
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialProviderConfigurationException
import androidx.credentials.exceptions.GetCredentialUnsupportedException
import androidx.credentials.exceptions.NoCredentialException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.drive.DriveSession
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.tasks.await

data class GoogleLoginState(
    val user: GoogleUser? = null,
    val busy: Boolean = false,
    val error: String? = null,
    val driveResolution: PendingIntent? = null,
)

/**
 * Credential Manager identifica a conta; AuthorizationClient autoriza o Drive.
 * Um ID token do Google nunca é usado como access token da API do Drive.
 * Não há Activity, ID token ou refresh token guardado neste ViewModel.
 */
class GoogleLoginViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext = application.applicationContext
    private val authorizationClient = Identity.getAuthorizationClient(appContext)
    private val sessionStore = GoogleSessionStore(appContext)
    private val _state = MutableStateFlow(GoogleLoginState(user = sessionStore.read()))
    val state = _state.asStateFlow()
    private var pendingUser: GoogleUser? = null
    private var operation = 0L

    init {
        refreshSavedAuthorization()
        viewModelScope.launch {
            while (true) { delay(45 * 60_000L); refreshSavedAuthorization() }
        }
    }

    /** Restaura o perfil imediatamente e renova o token sem abrir folhas de login. */
    fun refreshSavedAuthorization() {
        val user = _state.value.user ?: return
        val requestId = operation
        viewModelScope.launch {
            try {
                val result = authorizationClient.authorize(AuthorizationRequest.builder()
                    .setAccount(Account(user.email, "com.google"))
                    .setRequestedScopes(listOf(Scope(DRIVE_READONLY))).build()).await()
                if (requestId != operation || _state.value.user?.email != user.email) return@launch
                if (!result.hasResolution() && !result.accessToken.isNullOrBlank()) {
                    DriveSession.accessToken = result.accessToken.orEmpty()
                    DriveSession.revision++
                }
                // Se o consentimento foi revogado, o visualizador oferece Configurar Drive.
                // Falta de internet não apaga a conta nem obriga login ao abrir o app.
            } catch (error: CancellationException) { throw error }
            catch (_: Exception) { /* Perfil local permanece disponível offline. */ }
        }
    }

    fun beginSignIn(): Boolean {
        if (_state.value.busy) return false // Impede duas folhas de conta simultâneas.
        operation++
        pendingUser = null
        _state.value = GoogleLoginState(busy = true)
        return true
    }

    fun cancelCredentialRequest() {
        // Se o Credential Manager for cancelado pela recriação da tela, pode tentar de novo.
        if (pendingUser == null && _state.value.busy) {
            _state.value = GoogleLoginState()
        }
    }

    fun credentialFailure(error: Throwable) {
        pendingUser = null
        _state.value = GoogleLoginState(error = loginErrorMessage(error))
    }

    fun configurationMissing() {
        _state.value = GoogleLoginState(
            error = "A entrada Google ainda não foi configurada nesta versão do app. Preencha o ID OAuth do tipo Web antes de gerar o APK.",
        )
    }

    fun authorizeDrive(user: GoogleUser) {
        pendingUser = user
        val requestId = operation
        viewModelScope.launch {
            try {
                val request = AuthorizationRequest.builder()
                    // A mesma conta escolhida em Entrar com Google, inclusive com várias contas.
                    .setAccount(Account(user.email, "com.google"))
                    .setRequestedScopes(listOf(Scope(DRIVE_READONLY)))
                    .build()
                val result = authorizationClient.authorize(request).await()
                if (requestId != operation) return@launch
                if (result.hasResolution()) {
                    val pending = result.pendingIntent
                        ?: error("Não foi possível iniciar a autorização de leitura do Drive.")
                    _state.value = GoogleLoginState(busy = true, driveResolution = pending)
                } else {
                    completeDriveAuthorization(result)
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                if (requestId == operation) credentialFailure(error)
            }
        }
    }

    /** Consome a solicitação antes de abrir a folha, evitando repetições em recomposição. */
    fun consumeDriveResolution() {
        _state.value = _state.value.copy(driveResolution = null)
    }

    fun receiveDriveResult(data: Intent?, wasSuccessful: Boolean) {
        if (pendingUser == null) return // Ignora resultados de uma sessão já encerrada.
        if (!wasSuccessful || data == null) {
            pendingUser = null
            _state.value = GoogleLoginState(
                error = "A leitura do Drive não foi autorizada. Toque em Entrar com Google para tentar novamente.",
            )
            return
        }
        try {
            completeDriveAuthorization(authorizationClient.getAuthorizationResultFromIntent(data))
        } catch (error: Exception) {
            credentialFailure(error)
        }
    }

    private fun completeDriveAuthorization(result: AuthorizationResult) {
        val user = pendingUser ?: error("A conta escolhida não está mais disponível.")
        val token = result.accessToken.orEmpty()
        check(token.isNotBlank()) { "O Google não retornou a autorização de leitura do Drive." }
        // Mantém a integração nativa 1.2.2: o restante do app lê DriveSession.
        DriveSession.accessToken = token
        DriveSession.revision++
        pendingUser = null
        sessionStore.save(user)
        _state.value = GoogleLoginState(user = user)
    }

    /** Saída pelo perfil: encerra a sessão local e limpa a escolha de conta no provedor Google. */
    fun signOut() {
        operation++ // Respostas atrasadas não podem restaurar a sessão encerrada.
        pendingUser = null
        DriveSession.clear()
        sessionStore.clear()
        _state.value = GoogleLoginState(busy = true)
        viewModelScope.launch {
            try {
                CredentialManager.create(appContext)
                    .clearCredentialState(ClearCredentialStateRequest())
                _state.value = GoogleLoginState()
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                // A sessão local sempre termina, mesmo se o provedor estiver indisponível.
                _state.value = GoogleLoginState(
                    error = "Você saiu do app. O Google não conseguiu limpar a seleção de conta; escolha a conta novamente na próxima entrada.",
                )
            }
        }
    }

    private companion object {
        const val DRIVE_READONLY = "https://www.googleapis.com/auth/drive.readonly"
    }
}

internal fun loginErrorMessage(error: Throwable): String = when (error) {
    is GetCredentialCancellationException -> "Entrada cancelada. Você pode tentar novamente."
    is NoCredentialException -> "Nenhuma conta foi disponibilizada. Confira os Serviços do Google Play e tente novamente."
    is GetCredentialProviderConfigurationException -> "O provedor Google não está disponível. Atualize os Serviços do Google Play neste aparelho."
    is GetCredentialUnsupportedException -> "Este aparelho não oferece o provedor de entrada Google necessário."
    is ApiException -> when (error.statusCode) {
        7 -> "Não foi possível conectar ao Google. Confira sua conexão e tente novamente."
        10 -> "O Google recusou o cadastro do app (10). Confira o cliente OAuth Android, o pacote e o SHA-1 deste APK."
        16 -> "Autorização cancelada. Toque em Entrar com Google para tentar novamente."
        8 -> "O Google retornou um erro interno (8). Tente novamente; esse código sozinho não identifica erro no OAuth."
        else -> "Não foi possível autorizar o Drive. Código Google: ${error.statusCode}. Confira os usuários de teste e os clientes OAuth no mesmo projeto."
    }
    else -> "Não foi possível concluir a entrada. Confira sua conexão, o ID OAuth Web e os clientes OAuth no Google Cloud."
}
