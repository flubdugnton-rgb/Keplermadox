# Arquivos alterados — 2.6.0

Comparação com a base 2.5 instalada. Recursos binários completos ficam no ZIP.

| Ação | Arquivo |
|---|---|
| Alterado | `.github/workflows/compilar-apk.yml` |
| Removido | `.github/workflows/resgatar-assinatura.yml` |
| Novo | `CHANGELOG-2.6.md` |
| Novo | `CHECKS-2.6.md` |
| Alterado | `README.md` |
| Alterado | `VERIFICACAO.json` |
| Alterado | `app/build.gradle.kts` |
| Novo | `app/src/androidTest/java/com/example/FloatingNavigationTest.kt` |
| Alterado | `app/src/androidTest/java/com/example/InterfaceTest.kt` |
| Alterado | `app/src/androidTest/java/com/example/NotesScreenTest.kt` |
| Novo | `app/src/androidTest/java/com/example/PomodoroCustomizationTest.kt` |
| Alterado | `app/src/androidTest/java/com/example/ProfileTest.kt` |
| Novo | `app/src/androidTest/java/com/example/QuestionsDeletionTest.kt` |
| Novo | `app/src/androidTest/java/com/example/ReactiveThemeTest.kt` |
| Alterado | `app/src/main/assets/pomodoro_sound_credits.txt` |
| Alterado | `app/src/main/java/com/example/data/productivity/PomodoroAmbience.kt` |
| Alterado | `app/src/main/java/com/example/data/productivity/PomodoroModel.kt` |
| Alterado | `app/src/main/java/com/example/data/productivity/PomodoroStore.kt` |
| Alterado | `app/src/main/java/com/example/data/productivity/QuestionModel.kt` |
| Alterado | `app/src/main/java/com/example/data/productivity/QuestionStore.kt` |
| Alterado | `app/src/main/java/com/example/data/repository/StudyViewModel.kt` |
| Alterado | `app/src/main/java/com/example/ui/KepleraeApp.kt` |
| Novo | `app/src/main/java/com/example/ui/components/FloatingAppNavigation.kt` |
| Alterado | `app/src/main/java/com/example/ui/notes/NotesScreen.kt` |
| Alterado | `app/src/main/java/com/example/ui/productivity/PomodoroScreen.kt` |
| Alterado | `app/src/main/java/com/example/ui/productivity/ProductivityDesign.kt` |
| Alterado | `app/src/main/java/com/example/ui/productivity/QuestionsScreen.kt` |
| Alterado | `app/src/main/java/com/example/ui/profile/ProfileScreen.kt` |
| Alterado | `app/src/main/java/com/example/ui/theme/Theme.kt` |
| Novo | `app/src/main/res/raw/ambient_fire.ogg` |
| Removido | `app/src/main/res/raw/ambient_fire.wav` |
| Novo | `app/src/main/res/raw/ambient_library.ogg` |
| Removido | `app/src/main/res/raw/ambient_library.wav` |
| Novo | `app/src/main/res/raw/ambient_rain.ogg` |
| Removido | `app/src/main/res/raw/ambient_rain.wav` |
| Novo | `app/src/main/res/raw/ambient_room.ogg` |
| Removido | `app/src/main/res/raw/ambient_room.wav` |
| Novo | `app/src/main/res/raw/ambient_storm.ogg` |
| Removido | `app/src/main/res/raw/ambient_storm.wav` |
| Novo | `app/src/main/res/raw/ambient_wind.ogg` |
| Removido | `app/src/main/res/raw/ambient_wind.wav` |
| Novo | `app/src/test/java/com/example/StudyAdjustmentsTest.kt` |
| Alterado | `design/ambient-sound-provenance.json` |
| Alterado | `scripts/fetch_ambient_sounds.py` |
| Alterado | `scripts/generate_ambient_fallbacks.py` |
| Novo | `scripts/validate_ambient_sounds.py` |
| Novo | `scripts/validate_v26.py` |
| Alterado | `verification.json` |

`CODIGO_COMPLETO.md` foi regenerado com os arquivos textuais atuais. Nenhuma dependência Android foi acrescentada.
