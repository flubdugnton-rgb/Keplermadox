# Verificações — 2.5.0

Revisão local em 09/10/2026 UTC. Base 2.4 instalada e confirmada pelo usuário.

| Verificação | Resultado |
|---|---|
| Catálogo de 1.022 materiais, URLs e deduplicação | Validador local passou |
| Permissões de rede no manifesto | Validador local passou |
| XMLs, referências de recursos e declaração do serviço de áudio | Validador local passou |
| Delimitadores de 74 arquivos Kotlin/Gradle | Inspeção lexical passou; não é compilação Kotlin |
| YAML e comandos shell dos dois workflows | Parse YAML e `bash -n` passaram |
| Restauração base64 do Secret | Fixture conferida: bytes, modo 0600 e rejeição de valor ausente; conteúdo não apareceu em logs |
| Resgate cifrado | RSA-OAEP e AES-256-CBC/PBKDF2 conferidos com fixture e com a chave original; SHA-1 original confirmado |
| Catálogo, stores de estudo/aparência/Pomodoro/questões e sessão Google | Comparação de bytes passou; preservados da 2.4 |
| Python | Scripts compilam com `compileall` |
| Testes JUnit de Notas e geometria/identidade do PDF | Adicionados; execução pendente |
| Testes de dispositivo de persistência de anotações, página lembrada e CRUD de Notas | Adicionados; execução pendente |
| Tela cheia, dois dedos/caneta, bloqueio de tela e notificação Pomodoro | Código revisado; teste em aparelho/emulador pendente |
| Áudio em segundo plano, controle de playlist, token vencido e foco de áudio | Código revisado; teste com Google/Drive real pendente |
| R8, lint release, APK e instalação release no emulador | Preparados no workflow; execução pendente |

Não existe APK 2.5 compilado nesta entrega. Este ambiente não tem SDK Android/Gradle/Kotlin instalado. A conexão GitHub lê o repositório e os logs, mas publicar o workflow retornou HTTP 403 (`Resource not accessible by integration`); não há ferramenta para administrar Secrets. O usuário publicou os arquivos e criou o Secret. A assinatura original foi recuperada e a execução #25 passou na restauração, no SHA-1, na configuração Google e no download dos sons. Falhou em `Validar projeto` antes da compilação, pois a validação pública encontrou a chave restaurada. O workflow foi corrigido para validar antes da restauração. A publicação automática da correção continua bloqueada por HTTP 403.

O APK debug da 2.4 compilou; o job de dispositivo da 2.4 falhou em `InterfaceTest` (Activity encerrada antes do próximo clique, após dois Back) e `NativePdfPagerTest` (timeout depois do swipe). O teste de navegação agora espera a sheet fechar e sai do perfil pelo botão. O teste de PDF usa arrasto controlado para limitar o fling. Essas alterações ainda não foram executadas; não permitem declarar os testes de dispositivo aprovados.

Os testes locais não garantem que a compilação Android passe. O workflow deve completar compilação, lint, testes e instalação do release antes de distribuir a versão.

## Conferência no aparelho

- Abra um PDF, avance páginas, desenhe e coloque um pin. Feche e abra: página, traços e notas precisam permanecer. Bloqueie a rede: o PDF já baixado precisa abrir.
- Caneta/marca-texto: um dedo desenha; dois dedos ampliam/movem. Em “só a caneta desenha”, o dedo pode trocar de página. Borracha remove um traço; desfazer restaura a última operação.
- Tela cheia: status e navegação somem; um gesto mostra barras transitórias; sair do visualizador restaura as barras.
- Áudio: bloqueie a tela, toque próxima/anterior na notificação e retome o app. Reprodução e posição devem acompanhar a faixa atual. Desconectar a conta encerra o serviço.
- Pomodoro: cronômetro da notificação continua descendo sem reconstruções por segundo; fase e prazo mudam no avanço automático; pausar/retomar mantém o tempo.
- Navegação: trocar Início/Aulas/PDFs/Áudios/Matérias faz fade curto; entrar em uma matéria/pasta conserva o morph dentro da mesma aba.
- Notas: crie/edite/exclua uma nota, altere bloco/cor, busque texto, feche e abra o app. Verifique FAB e contraste em claro/escuro.

## Correção da execução #25

YAML e sintaxe shell do workflow corrigido passaram. Ordem verificada: validar projeto → restaurar Secret → conferir SHA-1 → compilar. Nova execução Android pendente. Não é necessário substituir o ZIP remoto para aplicar essa correção; basta o workflow externo.
