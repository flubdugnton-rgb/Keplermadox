# 2.5.0 — notas, leitura e reprodução

Base 2.4.0 / código 25 → 2.5.0 / código 26.

Notificação Pomodoro sem atualizações por segundo; shared elements por aba; fade curto; fullscreen do sistema; cache offline e última página do PDF; ferramentas de anotação normalizadas com persistência atômica; áudio em segundo plano e atualização de token; aba Notas importada seletivamente; novo FAB e animação; superfícies de pastas claras/escuras; ícone claro; build release R8 com a assinatura anterior; Secret nos dois jobs; resgate cifrado manual; remoção do workflow antigo no pacote.

Catálogo de 1.022 materiais e os stores de estudo, aparência, Pomodoro e questões preservados. A única alteração no ViewModel de login é encerrar também o serviço de áudio ao desconectar.

Estado da entrega: fonte preparada; compilação, testes Android e operações remotas da assinatura pendentes de restaurar acesso GitHub.
