# Arte e sons do Pomodoro 2.4

## Arte

Duas artes PNG RGBA de 1536 × 1024, editadas a partir das ilustrações originais da 2.3. Modo da geração: edição de imagem com referência, transparência preservada.

- Arquivo final: `app/src/main/res/drawable-nodpi/pomo_fishing.png`.
  Prompt de edição: preservar exatamente o tomate astronauta, a barquinha, a vara, o mar de estrelas, as cores e a composição; remover apenas a linha pendurada e a grande estrela dourada na ponta, deixando a ponta da vara livre para animação procedural. Sem texto e com fundo transparente.
- Arquivo final: `app/src/main/res/drawable-nodpi/pomo_rest.png`.
  Prompt de edição: preservar o tomate astronauta deitado em Saturno e a composição original; acrescentar verde militar em detalhes do traje e em uma faixa dos anéis, mantendo lavanda e menta. Sem texto e com fundo transparente.

`PomodoroArtwork.kt` combina as artes com Canvas: brilho/movimento das estrelas nos dois estados, linha curva e estrela dourada animadas, barquinha oscilante e passagem ocasional de estrela cadente durante o foco. No repouso, os reflexos percorrem os anéis para sugerir rotação sem girar o personagem. As âncoras usam as dimensões reais do PNG e ContentScale.Fit para preservar o alinhamento. Não há GIF, vídeo remoto ou rede necessária para animar.

## Áudio

Todos os recursos sonoros estão incluídos no projeto e podem tocar offline. Serviço nativo MediaPlayer com foco de áudio do Android, silêncio nas pausas e liberação dos players ao parar. O timer mantém sua notificação e o tipo de serviço de mídia é declarado para o ambiente de foco.

Fontes públicas efetivamente incluídas:

| Recurso | Autor / origem | Licença |
| --- | --- | --- |
| Lareira | ezwa / SoundBible 1543, via Blanket | Domínio público |
| Vento | felix.blume / Freesound 217506; edição Porrumentzio | CC0 1.0 |
| Sala | stephan / SoundBible 1664, via Blanket | Domínio público |
| Trovões | digifishmusic / Freesound 41739; edição Porrumentzio | CC BY 4.0 |

Blanket fixado no commit `775f2a767230a9681850d1b1e085be58656f1382`. Hash do blob de cada fonte conferido; duração limitada a 30s, mono 22050Hz, normalização de volume e costura de loop. A atribuição CC BY está incluída no app, em Ajustes → Créditos dos sons.

Relógio, chuva e ruído de leitura incluídos neste ZIP são sínteses originais CC0, criadas por `scripts/generate_ambient_fallbacks.py`. Durante a compilação, `scripts/fetch_ambient_sounds.py` tenta baixar:

- Relógio CC0 de AntumDeluge: https://opengameart.org/content/ticking-clock-0
- Chuva CC0 de SFXProducer via Noisekun, conferindo o hash do arquivo: https://www.youtube.com/watch?v=3oMcTXhXOpc

Se o download falhar, mantém o recurso incluído. A proveniência e os créditos são atualizados para refletir o áudio efetivamente usado; nenhuma fonte indisponível é apresentada como se tivesse sido baixada.

Os salões de Grifinória, Sonserina, Corvinal e Lufa-Lufa e a biblioteca são combinações inspiradas dos loops incluídos (lareira, sala, vento, chuva, relógio e páginas). Não são gravações dos filmes ou trilhas de Harry Potter.

Licenças/fontes:
- https://github.com/rafaelmardojai/blanket/blob/775f2a767230a9681850d1b1e085be58656f1382/SOUNDS_LICENSING.md
- https://soundbible.com/1543-Fireplace.html
- https://soundbible.com/1664-Restaurant-Ambiance.html
- https://freesound.org/people/felix.blume/sounds/217506/
- https://freesound.org/people/digifishmusic/sounds/41739/
- https://github.com/mateusfg7/Noisekun
- https://creativecommons.org/licenses/by/4.0/
- https://creativecommons.org/publicdomain/zero/1.0/

Os alarmes curtos da 2.3 são preservados. `fetch_pomodoro_sounds.py` continua instalando amostras CC0 públicas com fallback para os tons originais incluídos.
