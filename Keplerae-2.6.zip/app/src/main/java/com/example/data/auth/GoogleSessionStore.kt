package com.example.data.auth

import android.content.Context

/** Guarda apenas o perfil local. Tokens do Google continuam somente em memória. */
class GoogleSessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("keplerae_google_session", Context.MODE_PRIVATE)
    fun read(): GoogleUser? {
        val email = prefs.getString("email", null)?.takeIf { it.isNotBlank() } ?: return null
        return GoogleUser(email, prefs.getString("name", email) ?: email, prefs.getString("photo", null))
    }
    fun save(user: GoogleUser) {
        prefs.edit().putString("email", user.email).putString("name", user.displayName)
            .putString("photo", user.photoUrl).commit()
    }
    fun clear() { prefs.edit().clear().commit() }
}
