package com.example.data.productivity

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class QuestionStore private constructor(context: Context) {
    private val prefs=context.applicationContext.getSharedPreferences("keplerae_questions",Context.MODE_PRIVATE)
    private val mutable=MutableStateFlow(read())
    val state=mutable.asStateFlow()
    private fun read(): QuestionState = runCatching {
        val j=JSONObject(prefs.getString("state","{}")?:"{}")
        val subjects=j.optJSONArray("subjects")?:JSONArray(); val records=j.optJSONArray("records")?:JSONArray()
        QuestionState((0 until subjects.length()).map { subjects.getJSONObject(it) }.map {
            QuestionSubject(it.getString("id"),it.getString("name")) },
            (0 until records.length()).map { records.getJSONObject(it) }.map {
                QuestionRecord(it.getString("id"),it.getString("subject"),it.getInt("correct"),it.getInt("wrong"),it.getLong("at")) })
    }.getOrDefault(QuestionState())
    private fun save(state: QuestionState) {
        val j=JSONObject().put("subjects",JSONArray().apply { state.subjects.forEach {
            put(JSONObject().put("id",it.id).put("name",it.name)) } })
            .put("records",JSONArray().apply { state.records.forEach {
                put(JSONObject().put("id",it.id).put("subject",it.subjectId).put("correct",it.correct).put("wrong",it.wrong).put("at",it.recordedAt)) } })
        prefs.edit().putString("state",j.toString()).commit(); mutable.value=state
    }
    @Synchronized fun createSubject(name: String): String {
        val clean=name.trim().replace(Regex("\\s+")," ")
        require(clean.isNotBlank()&&clean.length<=80) { "Use um nome de 1 a 80 caracteres." }
        require(mutable.value.subjects.none { it.name.equals(clean,true) }) { "Essa matéria já existe." }
        val subject=QuestionSubject(UUID.randomUUID().toString(),clean)
        save(mutable.value.copy(subjects=mutable.value.subjects+subject));return subject.id
    }
    @Synchronized fun add(subjectId: String, correct: Int, wrong: Int) {
        require(mutable.value.subjects.any { it.id==subjectId })
        require(validQuestionCounts(correct,wrong)) { "Informe números inteiros positivos ou zero; o total deve ser maior que zero." }
        save(mutable.value.copy(records=mutable.value.records+
            QuestionRecord(UUID.randomUUID().toString(),subjectId,correct,wrong,System.currentTimeMillis())))
    }
    @Synchronized fun deleteRecord(id: String) { save(mutable.value.copy(records=mutable.value.records.filterNot { it.id==id })) }
    @Synchronized fun deleteSubject(id: String) { save(withoutQuestionSubject(mutable.value, id)) }
    /** Um único save apaga blocos e histórico; outros módulos não são acessados. */
    @Synchronized fun resetAll() { save(QuestionState()) }
    companion object {
        @Volatile private var instance: QuestionStore?=null
        fun get(context: Context): QuestionStore = instance?:synchronized(this) {
            instance?:QuestionStore(context).also { instance=it } }
    }
}
