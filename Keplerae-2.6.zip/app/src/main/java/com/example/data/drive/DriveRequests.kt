package com.example.data.drive

import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder

data class DriveCredentials(val apiKey: String = "", val accessToken: String = "") {
    val configured: Boolean get() = apiKey.isNotBlank() || accessToken.isNotBlank()
    fun headers(packageName: String, certificate: String, id: String, resourceKey: String): Map<String, String> = buildMap {
        if (accessToken.isNotBlank()) put("Authorization", "Bearer $accessToken")
        else if (apiKey.isNotBlank()) put("X-Goog-Api-Key", apiKey)
        put("X-Android-Package", packageName)
        if (certificate.isNotBlank()) put("X-Android-Cert", certificate)
        if (resourceKey.isNotBlank()) put("X-Goog-Drive-Resource-Keys", "$id/$resourceKey")
    }
}

object DriveRequests {
    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8")
    fun file(id: String, media: Boolean = false): String {
        require(id.matches(Regex("[A-Za-z0-9_-]+"))) { "Identificador do arquivo inválido." }
        val fields = "id,name,mimeType,size,resourceKey,capabilities(canDownload),shortcutDetails(targetId,targetMimeType,targetResourceKey)"
        return "https://www.googleapis.com/drive/v3/files/$id?" +
            if (media) "alt=media&supportsAllDrives=true" else "supportsAllDrives=true&fields=${encode(fields)}"
    }
    fun folder(id: String, pageToken: String = ""): String {
        require(id.matches(Regex("[A-Za-z0-9_-]+")))
        val query = "'$id' in parents and trashed = false"
        val fields = "nextPageToken,files(id,name,mimeType,size,resourceKey,capabilities(canDownload),shortcutDetails(targetId,targetMimeType,targetResourceKey))"
        return "https://www.googleapis.com/drive/v3/files?q=${encode(query)}&pageSize=100" +
            "&supportsAllDrives=true&includeItemsFromAllDrives=true&fields=${encode(fields)}" +
            if (pageToken.isBlank()) "" else "&pageToken=${encode(pageToken)}"
    }
    fun resourceKey(url: String): String = runCatching {
        URI(url).rawQuery.orEmpty().split('&').firstNotNullOfOrNull { part ->
            val pair = part.split('=', limit = 2)
            if (pair.size == 2 && pair[0].equals("resourcekey", true)) URLDecoder.decode(pair[1], "UTF-8") else null
        }.orEmpty()
    }.getOrDefault("")
    fun folderId(url: String): String = runCatching {
        URI(url).path.substringAfter("/drive/folders/").substringBefore('/')
            .takeIf { it.matches(Regex("[A-Za-z0-9_-]+")) }.orEmpty()
    }.getOrDefault("")
    fun errorMessage(status: Int, reason: String): String = when {
        status == 401 -> "A autorização Google expirou. Autorize sua conta novamente."
        reason in setOf("keyInvalid", "API_KEY_INVALID", "badRequest") -> "Confira a chave de API nas configurações do Drive."
        reason in setOf("accessNotConfigured", "SERVICE_DISABLED") -> "Ative a Google Drive API no projeto da sua chave."
        reason in setOf("downloadQuotaExceeded", "rateLimitExceeded", "userRateLimitExceeded", "quotaExceeded") || status == 429 ->
            "O Drive atingiu um limite de acesso. Aguarde e tente novamente."
        reason in setOf("cannotDownloadFile", "fileNotDownloadable", "downloadRestrictedForRevision") ->
            "O proprietário bloqueou o acesso ao conteúdo pela API."
        status == 404 -> "Arquivo não encontrado ou sem acesso. Para arquivos privados, autorize a conta Google correta."
        status == 403 -> "Acesso negado. Confira as restrições da chave ou autorize a conta Google que pode acessar o arquivo."
        status >= 500 -> "O Drive está temporariamente indisponível. Tente novamente."
        else -> "Não foi possível carregar este material. Confira a conexão e tente novamente."
    }
    fun errorReason(body: String): String = Regex("\"reason\"\\s*:\\s*\"([^\"]+)\"")
        .find(body)?.groupValues?.get(1).orEmpty()
}
