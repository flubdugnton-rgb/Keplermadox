package com.example.data.auth

/** Somente dados de apresentação. Tokens não são persistidos neste modelo. */
data class GoogleUser(
    val email: String,
    val displayName: String,
    val photoUrl: String?,
)
