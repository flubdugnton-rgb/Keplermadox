package com.example.data.pdf

import android.content.Context
import com.example.data.auth.GoogleSessionStore
import com.example.data.drive.DriveFile
import com.example.data.drive.DriveRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/** Arquivos privados são separados por conta; a chave do Drive nunca vira caminho de disco. */
fun pdfAccountKey(context: Context): String = GoogleSessionStore(context).read()?.email ?: "public"
fun pdfStorageKey(account: String, id: String): String = MessageDigest.getInstance("SHA-256")
    .digest("$account\u0000$id".toByteArray()).joinToString("") { "%02x".format(it) }

data class CachedPdf(val metadata: DriveFile, val file: File, val key: String)

class PdfCache(context: Context) {
    private val directory = File(context.filesDir, "pdfs").apply { mkdirs() }
    private val account = pdfAccountKey(context)
    fun key(id: String) = pdfStorageKey(account, id)
    suspend fun find(id: String): CachedPdf? = withContext(Dispatchers.IO) {
        val key = key(id)
        val file = File(directory, "$key.pdf")
        runCatching {
            if (!validPdf(file)) return@runCatching null
            val json = JSONObject(File(directory, "$key.json").readText())
            CachedPdf(DriveFile(json.getString("id"), json.getString("name"), "application/pdf",
                json.optString("resourceKey")), file, key)
        }.getOrNull()
    }
    /** Download atômico: nunca expõe um PDF incompleto como cache válido. */
    suspend fun download(id: String, metadata: DriveFile, repository: DriveRepository,
        onProgress: (Long, Long) -> Unit): CachedPdf = gate.withLock {
        find(id)?.let { return@withLock it }
        withContext(Dispatchers.IO) {
            val key = key(id)
            val target = File(directory, "$key.pdf")
            val part = File(directory, "$key.part")
            try {
                repository.pdf(metadata, part, onProgress)
                check(part.renameTo(target)) { "Não foi possível salvar este PDF no aparelho." }
                File(directory, "$key.json").writeText(JSONObject().put("id", metadata.id)
                    .put("name", metadata.name).put("resourceKey", metadata.resourceKey).toString())
                CachedPdf(metadata, target, key)
            } finally { part.delete() }
        }
    }
    companion object { private val gate = Mutex() }
}
private fun validPdf(file: File): Boolean = file.isFile && file.length() > 5 &&
    file.inputStream().use { input ->
        val magic = ByteArray(5)
        input.read(magic) == 5 && String(magic, Charsets.US_ASCII) == "%PDF-"
    }
