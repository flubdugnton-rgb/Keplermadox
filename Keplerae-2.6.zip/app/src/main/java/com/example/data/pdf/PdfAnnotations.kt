package com.example.data.pdf

import android.content.Context
import android.util.AtomicFile
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Coordenadas normalizadas sobre a página real, independentes do zoom e da tela. */
data class InkPoint(val x: Float, val y: Float) {
    fun clamped() = InkPoint(x.coerceIn(0f, 1f), y.coerceIn(0f, 1f))
}
data class InkStroke(val id: String, val points: List<InkPoint>, val highlight: Boolean,
    val color: Long, val width: Float)
data class PdfNote(val id: String, val point: InkPoint, val text: String)
data class PageAnnotations(val strokes: List<InkStroke> = emptyList(), val notes: List<PdfNote> = emptyList())
data class AnnotationDocument(val pages: Map<Int, PageAnnotations> = emptyMap())

/** JSON próprio. AtomicFile preserva a versão anterior caso a gravação seja interrompida. */
class PdfAnnotationStore(context: Context, key: String) {
    private val file = AtomicFile(File(File(context.filesDir, "annotations").apply { mkdirs() }, "$key.json"))
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val gate = Mutex()
    private val mutable = MutableStateFlow(AnnotationDocument())
    val state = mutable.asStateFlow()
    private val failure = MutableStateFlow<String?>(null)
    val error = failure.asStateFlow()
    private var lastWrite: Job? = null
    suspend fun load() = withContext(Dispatchers.IO) {
        gate.withLock {
            mutable.value = runCatching {
                val root = JSONObject(file.openRead().bufferedReader().use { it.readText() })
                val pages = root.optJSONArray("pages") ?: JSONArray()
                AnnotationDocument((0 until pages.length()).associate { i ->
                    val p = pages.getJSONObject(i)
                    val strokes = p.optJSONArray("strokes") ?: JSONArray()
                    val notes = p.optJSONArray("notes") ?: JSONArray()
                    p.getInt("page") to PageAnnotations(
                        (0 until strokes.length()).map { j ->
                            val s = strokes.getJSONObject(j); val points = s.getJSONArray("points")
                            InkStroke(s.getString("id"), (0 until points.length()).map { k ->
                                val a = points.getJSONArray(k); InkPoint(a.getDouble(0).toFloat(), a.getDouble(1).toFloat()).clamped()
                            }, s.optBoolean("highlight"), s.getLong("color"), s.getDouble("width").toFloat())
                        }, (0 until notes.length()).map { j ->
                            val n = notes.getJSONObject(j)
                            PdfNote(n.getString("id"), InkPoint(n.getDouble("x").toFloat(), n.getDouble("y").toFloat()).clamped(), n.getString("text"))
                        })
                })
            }.getOrDefault(AnnotationDocument())
        }
    }
    fun replace(page: Int, annotations: PageAnnotations) {
        val next = mutable.value.copy(pages = mutable.value.pages + (page to annotations))
        mutable.value = next
        val previous = lastWrite
        lastWrite = scope.launch {
            previous?.join()
            gate.withLock {
                val root = JSONObject().put("version", 1).put("pages", JSONArray().apply {
                    next.pages.toSortedMap().forEach { (index, a) ->
                        put(JSONObject().put("page", index).put("strokes", JSONArray().apply {
                            a.strokes.forEach { s -> put(JSONObject().put("id", s.id).put("highlight", s.highlight)
                                .put("color", s.color).put("width", s.width).put("points", JSONArray().apply {
                                    s.points.forEach { put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble())) }
                                })) }
                        }).put("notes", JSONArray().apply {
                            a.notes.forEach { n -> put(JSONObject().put("id", n.id).put("x", n.point.x.toDouble())
                                .put("y", n.point.y.toDouble()).put("text", n.text)) }
                        }))
                    }
                })
                var output: java.io.FileOutputStream? = null
                try {
                    output = file.startWrite(); output.write(root.toString().toByteArray()); file.finishWrite(output)
                    failure.value = null
                } catch (_: Exception) {
                    output?.let { file.failWrite(it) }
                    failure.value = "Não foi possível salvar as anotações. Confira o espaço livre no aparelho."
                }
            }
        }
    }
    suspend fun flush() { lastWrite?.join() }
    fun close() { scope.launch { lastWrite?.join(); scope.cancel() } }
}

/** Distância ao segmento: a borracha encontra também os intervalos entre pontos. */
fun strokeHit(stroke: InkStroke, point: InkPoint, radius: Float = .025f): Boolean {
    fun squareDistance(a: InkPoint, b: InkPoint): Float = (a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)
    val distance = radius + stroke.width / 2
    if (stroke.points.size == 1) return squareDistance(stroke.points[0], point) <= distance*distance
    return stroke.points.zipWithNext().any { (a,b) ->
        val dx=b.x-a.x; val dy=b.y-a.y; val length=dx*dx+dy*dy
        val t=if(length==0f) 0f else (((point.x-a.x)*dx+(point.y-a.y)*dy)/length).coerceIn(0f,1f)
        squareDistance(InkPoint(a.x+t*dx,a.y+t*dy),point) <= distance*distance
    }
}
