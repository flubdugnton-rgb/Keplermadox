package com.example.data.repository

/** Ignora IDs removidos, evita duplicatas e acrescenta novos materiais no fim. */
fun reconcileOrder(currentIds: List<String>, savedIds: List<String>): List<String> {
    val available = currentIds.toSet()
    return (savedIds.filter { it in available } + currentIds).distinct()
}

/** Reordena somente o conjunto visível; materiais ocultos mantêm sua posição. */
fun mergeVisibleOrder(fullOrder: List<String>, visibleOrder: List<String>): List<String> {
    val visible = visibleOrder.distinct().filter { it in fullOrder }.toSet()
    val iterator = visibleOrder.distinct().filter { it in visible }.iterator()
    return fullOrder.map { if (it in visible && iterator.hasNext()) iterator.next() else it }
}

/** Índices são resolvidos pelas chaves; cabeçalhos de LazyColumn não interferem. */
fun moveId(order: List<String>, from: String, to: String): List<String> {
    val source = order.indexOf(from)
    val target = order.indexOf(to)
    if (source < 0 || target < 0 || source == target) return order
    return order.toMutableList().apply { add(target, removeAt(source)) }
}
