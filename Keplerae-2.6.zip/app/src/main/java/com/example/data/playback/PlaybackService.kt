package com.example.data.playback

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.example.MainActivity

/** O serviço é dono do player. Fechar o visualizador não destrói o áudio. */
@androidx.annotation.OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private val preferences by lazy { getSharedPreferences("keplerae_playback", 0) }
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val saveTick = object : Runnable {
        override fun run() { savePosition(); handler.postDelayed(this, 5000L) }
    }
    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DrivePlaybackSource(this)))
            .setSeekBackIncrementMs(10000).setSeekForwardIncrementMs(10000).build().apply {
                setAudioAttributes(AudioAttributes.DEFAULT, true)
                setHandleAudioBecomingNoisy(true)
                setWakeMode(C.WAKE_MODE_LOCAL)
            }
        player.addListener(object : Player.Listener {
            override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo, reason: Int) {
                oldPosition.mediaItem?.mediaId?.takeIf { it.isNotBlank() }?.let { id ->
                    preferences.edit().putLong(id, if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION)
                        0L else oldPosition.positionMs.coerceAtLeast(0)).apply()
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { savePosition() }
            override fun onPlaybackStateChanged(playbackState: Int) { savePosition() }
        })
        val open = PendingIntent.getActivity(this, 2500, Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        session = MediaSession.Builder(this, player).setSessionActivity(open)
            .setCallback(object : MediaSession.Callback {
                override fun onConnect(session: MediaSession, controller: MediaSession.ControllerInfo): MediaSession.ConnectionResult {
                    return if (controller.packageName == packageName || controller.isTrusted)
                        super.onConnect(session, controller) else MediaSession.ConnectionResult.reject()
                }
            }).build()
        handler.post(saveTick)
    }
    private fun savePosition() {
        val player = session?.player ?: return
        val id = player.currentMediaItem?.mediaId?.takeIf { it.isNotBlank() } ?: return
        val position = if (player.playbackState == Player.STATE_ENDED) 0L else player.currentPosition.coerceAtLeast(0)
        preferences.edit().putLong(id, position).apply()
    }
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session
    override fun onTaskRemoved(rootIntent: Intent?) {
        // Uma sessão tocando continua; uma sessão parada libera o serviço.
        val player = session?.player
        if (player == null || !player.playWhenReady || player.playbackState == Player.STATE_ENDED || player.mediaItemCount == 0) stopSelf()
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null); savePosition()
        session?.run { player.release(); release() }; session = null
        super.onDestroy()
    }
}
