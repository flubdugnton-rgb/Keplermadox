package com.example.data.model

import java.net.URI
import java.text.Normalizer

enum class ContentType(val label: String) { VIDEO("Aulas"), PDF("PDFs"), AUDIO("Áudios") }
enum class LinkKind { FILE, FOLDER }

data class StudyItem(
    val id: String, val title: String, val filename: String,
    val subjectId: String, val folderPath: List<String>, val type: ContentType,
    val url: String, val linkKind: LinkKind, val driveFileId: String,
    val note: String, val source: String
) {
    val previewUrl: String get() = if (linkKind == LinkKind.FILE && driveFileId.isNotBlank())
        "https://drive.google.com/file/d/$driveFileId/preview" else url
    fun matches(query: String): Boolean = searchable("$title $filename ${folderPath.joinToString(" ")} $subjectId")
        .contains(searchable(query.trim()))
}
fun searchable(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
    .replace(Regex("\\p{M}+"), "").lowercase(java.util.Locale.ROOT)
fun isAllowedDriveUrl(url: String): Boolean = runCatching {
    val uri = URI(url)
    uri.scheme == "https" && uri.host == "drive.google.com" && uri.userInfo == null &&
        (uri.path.startsWith("/file/d/") || uri.path.startsWith("/drive/folders/"))
}.getOrDefault(false)
fun itemsInPath(items: List<StudyItem>, path: List<String>): List<StudyItem> =
    items.filter { it.folderPath.take(path.size) == path }

data class Subject(val id: String, val name: String, val subtitle: String, val monogram: String)
object Subjects {
    val all = listOf(
        Subject("fisioterapia", "Fisioterapia", "HU Brasil · módulos e simulados", "F"),
        Subject("portugues", "Português", "Gramática e interpretação", "P"),
        Subject("matematica", "Matemática e Raciocínio Lógico", "Lógica, teoria e questões", "M"),
        Subject("hu_legislacao", "HU Legislação", "Normas e legislação EBSERH", "H"),
        Subject("sus", "SUS", "Saúde pública e políticas", "S"),
        Subject("profisio", "Profisio", "Artigos, aulas e áudios por ciclo", "Pr")
    )
    fun get(id: String) = all.first { it.id == id }
}
