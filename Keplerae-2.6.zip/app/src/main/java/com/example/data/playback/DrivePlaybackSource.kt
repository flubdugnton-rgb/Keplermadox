package com.example.data.playback

import android.accounts.Account
import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.*
import com.example.data.auth.GoogleSessionStore
import com.example.data.drive.*
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.ClearTokenRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Executado na thread de carregamento do Media3, nunca na thread de UI. */
@androidx.annotation.OptIn(UnstableApi::class)
internal class DrivePlaybackSource(private val context: Context) : DataSource.Factory {
    private val authorization = Identity.getAuthorizationClient(context.applicationContext)
    @Volatile private var lastToken = ""
    @Synchronized private fun credentials(): DriveCredentials {
        val account = GoogleSessionStore(context).read()
        val key = DriveSettings(context).apiKey()
        if (account != null) {
            try {
                val result = Tasks.await(authorization.authorize(AuthorizationRequest.builder()
                    .setAccount(Account(account.email, "com.google"))
                    .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.readonly"))).build()), 20, TimeUnit.SECONDS)
                if (!result.hasResolution() && !result.accessToken.isNullOrBlank()) {
                    // Não guarda tokens na fila, no disco ou nos metadados da notificação.
                    lastToken = result.accessToken.orEmpty()
                    return DriveCredentials(key, lastToken)
                }
            } catch (e: Exception) {
                if (e is InterruptedException) Thread.currentThread().interrupt()
                if (key.isBlank()) throw IOException("Não foi possível renovar o acesso ao Drive. Confira a conexão ou autorize a conta.", e)
            }
        }
        if (key.isBlank()) throw IOException("Autorize sua conta Google nas configurações do Drive.")
        return DriveCredentials(apiKey = key)
    }
    private fun invalidate() {
        val invalid = lastToken
        lastToken = ""
        if (invalid.isNotBlank()) runCatching {
            Tasks.await(authorization.clearToken(ClearTokenRequest.builder().setToken(invalid).build()), 10, TimeUnit.SECONDS)
        }
    }
    override fun createDataSource(): DataSource {
        val resolved = ResolvingDataSource.Factory(DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(15000).setReadTimeoutMs(30000), ResolvingDataSource.Resolver { spec ->
            val uri = spec.uri
            val id = uri.lastPathSegment.orEmpty()
            require(uri.scheme == "https" && uri.host == "www.googleapis.com" &&
                uri.path == "/drive/v3/files/$id" && id.matches(Regex("[A-Za-z0-9_-]+"))) { "Endereço de reprodução inválido." }
            val resourceKey = spec.key.orEmpty().substringAfter('|', "")
            spec.withRequestHeaders(credentials().headers(context.packageName, installedCertificate(context), id, resourceKey))
        }).createDataSource()
        return object : DataSource by resolved {
            override fun open(dataSpec: DataSpec): Long {
                try { return resolved.open(dataSpec) }
                catch (e: HttpDataSource.InvalidResponseCodeException) {
                    if (e.responseCode != 401 || lastToken.isBlank()) throw e
                    resolved.close(); invalidate()
                    return resolved.open(dataSpec) // Apenas uma nova tentativa, com token renovado.
                }
            }
        }
    }
}
