package com.example.data.productivity

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import android.os.Build
import com.example.R

data class AmbientLayer(val resource: Int, val gain: Float = 1f)
data class AmbientPreset(val id: String, val title: String, val detail: String,
    val palette: Int, val layers: List<AmbientLayer>)

/** Camadas locais: nenhuma página externa ou streaming é necessário durante o foco. */
object AmbientPresets {
    val all = listOf(
        AmbientPreset("clock","Relógio","Tique-taque ritmado",0,listOf(AmbientLayer(R.raw.ambient_clock))),
        AmbientPreset("wind","Ar e vento","Uma brisa constante",1,listOf(AmbientLayer(R.raw.ambient_wind))),
        AmbientPreset("rain","Chuva","Gotas para concentrar",2,listOf(AmbientLayer(R.raw.ambient_rain))),
        AmbientPreset("storm","Tempestade","Chuva e trovões",3,listOf(AmbientLayer(R.raw.ambient_storm,.65f),AmbientLayer(R.raw.ambient_rain,.35f))),
        AmbientPreset("fire","Lareira","Madeira crepitando",0,listOf(AmbientLayer(R.raw.ambient_fire))),
        AmbientPreset("gryffindor","Grifinória","Salão comunal • lareira e conversa",0,listOf(AmbientLayer(R.raw.ambient_fire,.65f),AmbientLayer(R.raw.ambient_room,.30f))),
        AmbientPreset("slytherin","Sonserina","Salão comunal • brisa e chuva",3,listOf(AmbientLayer(R.raw.ambient_wind,.55f),AmbientLayer(R.raw.ambient_rain,.35f))),
        AmbientPreset("ravenclaw","Corvinal","Salão comunal • vento e relógio",1,listOf(AmbientLayer(R.raw.ambient_wind,.45f),AmbientLayer(R.raw.ambient_clock,.30f))),
        AmbientPreset("hufflepuff","Lufa-Lufa","Salão comunal • calor e tranquilidade",2,listOf(AmbientLayer(R.raw.ambient_fire,.55f),AmbientLayer(R.raw.ambient_wind,.20f))),
        AmbientPreset("library","Biblioteca de Hogwarts","Leitura • páginas e relógio",1,listOf(AmbientLayer(R.raw.ambient_library,.65f),AmbientLayer(R.raw.ambient_clock,.20f)))
    )
    fun get(id: String): AmbientPreset = all.firstOrNull { it.id == id } ?: all.first { it.id == "rain" }
}

/** Propriedade exclusiva do serviço: pausa/descarte liberam todos os players e o foco. */
@androidx.annotation.OptIn(UnstableApi::class)
class PomodoroAmbience(context: Context) {
    private val app = context.applicationContext
    private val manager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val players = mutableListOf<Pair<ExoPlayer,Float>>()
    private var id: String? = null
    private var volume = .35f
    private var resumeAfterInterruption = false
    private var focusHeld = false
    private var duckFactor=1f
    private var blocked=false
    private val attributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
    private val listener = AudioManager.OnAudioFocusChangeListener { change ->
        when(change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                if(resumeAfterInterruption) players.forEach { runCatching { it.first.play() } }
                resumeAfterInterruption=false
                duckFactor=1f;applyVolume(duckFactor)
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeAfterInterruption=players.any { runCatching { it.first.isPlaying }.getOrDefault(false) }
                players.forEach { runCatching { it.first.pause() } }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {duckFactor=.15f;applyVolume(duckFactor)}
            AudioManager.AUDIOFOCUS_LOSS -> {blocked=true;stop()}
        }
    }
    private val request: AudioFocusRequest? = if(Build.VERSION.SDK_INT>=26)
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attributes)
            .setOnAudioFocusChangeListener(listener).build() else null

    @Suppress("DEPRECATION")
    fun update(settings: PomodoroSettings, activeFocus: Boolean) {
        if(!activeFocus||!settings.ambienceEnabled) {stop();if(!settings.ambienceEnabled)blocked=false;return}
        if(blocked)return
        volume=settings.ambienceVolume
        val preset=AmbientPresets.get(settings.ambienceId)
        if(id==preset.id && players.isNotEmpty()) {applyVolume(duckFactor);return}
        stop()
        val granted=if(Build.VERSION.SDK_INT>=26) manager.requestAudioFocus(request!!)
            else manager.requestAudioFocus(listener,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN)
        if(granted!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED) return
        focusHeld=true;id=preset.id;duckFactor=1f
        for(layer in preset.layers) {
            try {
                // Repeat ONE conserva o pipeline entre voltas. OGGs têm costura
                // de três segundos; não recriamos o player em cada conclusão.
                val player=ExoPlayer.Builder(app)
                    .setAudioAttributes(androidx.media3.common.AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), false)
                    .setHandleAudioBecomingNoisy(false).setWakeMode(C.WAKE_MODE_LOCAL).build()
                players.add(player to layer.gain)
                player.repeatMode=Player.REPEAT_MODE_ONE
                player.volume=(volume*layer.gain).coerceIn(0f,1f)
                player.addListener(object:Player.Listener {
                    override fun onPlayerError(error:PlaybackException) { stop() }
                })
                player.setMediaItem(MediaItem.fromUri(Uri.parse("android.resource://${app.packageName}/${layer.resource}")))
                player.prepare()
                player.play()
            } catch(_:Exception) {stop();return}
        }
    }
    fun muteForNoisyOutput() {blocked=true;stop()}
    fun allowUserStart() {blocked=false}
    private fun applyVolume(factor: Float) = players.forEach { (p,gain) ->
        runCatching { p.volume=(volume*gain*factor).coerceIn(0f,1f) }
    }
    @Suppress("DEPRECATION")
    fun stop() {
        val old=players.toList();players.clear()
        old.forEach { runCatching { it.first.release() } }
        id=null;resumeAfterInterruption=false
        if(focusHeld) {
            focusHeld=false
            if(Build.VERSION.SDK_INT>=26) manager.abandonAudioFocusRequest(request!!)
            else manager.abandonAudioFocus(listener)
        }
    }
}
