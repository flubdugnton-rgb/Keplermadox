package com.example.data.drive

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object DriveSession {
    // Short-lived Google access tokens stay in memory; no refresh token or client secret is stored.
    var accessToken by mutableStateOf("")
    var revision by mutableStateOf(0)
    fun clear() { accessToken = ""; revision++ }
}

class DriveSettings(private val context: Context, preferenceName: String = "keplerae_drive") {
    private val prefs = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE)
    private fun secret(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey("keplerae_drive_key", null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder("keplerae_drive_key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    fun apiKey(): String = runCatching {
        val encrypted = prefs.getString("api_key", null) ?: return@runCatching ""
        val parts = encrypted.split(':', limit = 2)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secret(), GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)))
        String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), Charsets.UTF_8)
    }.getOrDefault("")
    fun saveApiKey(value: String) {
        if (value.isBlank()) prefs.edit().remove("api_key").apply()
        else {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, secret())
            val encrypted = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" +
                Base64.encodeToString(cipher.doFinal(value.trim().toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
            prefs.edit().putString("api_key", encrypted).apply()
        }
        DriveSession.revision++
    }
    fun credentials() = DriveCredentials(apiKey(), DriveSession.accessToken)
}

@Suppress("DEPRECATION")
fun installedCertificate(context: Context): String = runCatching {
    val signatures = if (Build.VERSION.SDK_INT >= 28) {
        val info = context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        info.signingInfo?.apkContentsSigners
    } else context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures
    val certificate = signatures?.firstOrNull()?.toByteArray() ?: return@runCatching ""
    MessageDigest.getInstance("SHA-1").digest(certificate).joinToString("") { "%02X".format(it) }
}.getOrDefault("")
