package com.example.data.productivity

enum class PomodoroPhase(val label: String) { FOCUS("Foco"), SHORT_BREAK("Pausa curta"), LONG_BREAK("Pausa longa") }
data class PomodoroSettings(val focusMinutes: Int = 25, val shortMinutes: Int = 5,
    val longMinutes: Int = 15, val cycles: Int = 4, val sounds: Boolean = true,
    val sound: String = "bell", val autoAdvance: Boolean = false,
    val ambienceEnabled: Boolean = false, val ambienceId: String = "rain",
    val ambienceVolume: Float = .35f) {
    fun valid() = focusMinutes in 1..180 && shortMinutes in 1..90 && longMinutes in 1..90 && cycles in 1..12 &&
        ambienceVolume.isFinite() && ambienceVolume in 0f..1f
    fun duration(phase: PomodoroPhase): Long = when (phase) {
        PomodoroPhase.FOCUS -> focusMinutes
        PomodoroPhase.SHORT_BREAK -> shortMinutes
        PomodoroPhase.LONG_BREAK -> longMinutes
    } * 60_000L
}
data class FocusRecord(val id: String, val finishedAt: Long, val durationMs: Long)
data class PomodoroState(val settings: PomodoroSettings = PomodoroSettings(),
    val phase: PomodoroPhase = PomodoroPhase.FOCUS, val running: Boolean = false,
    val paused: Boolean = false, val remainingMs: Long = 25 * 60_000L,
    val phaseDurationMs: Long = 25 * 60_000L, val deadlineWall: Long = 0,
    val deadlineElapsed: Long = 0, val bootEpoch: Long = 0,
    val cycle: Int = 0, val sessionId: String = "", val history: List<FocusRecord> = emptyList())

/** Durações/ciclos podem ser escolhidos sempre. A etapa ativa mantém seu prazo. */
fun applyPomodoroSettings(state: PomodoroState, settings: PomodoroSettings): PomodoroState {
    require(settings.valid())
    val durationsChanged = state.settings.focusMinutes != settings.focusMinutes ||
        state.settings.shortMinutes != settings.shortMinutes ||
        state.settings.longMinutes != settings.longMinutes || state.settings.cycles != settings.cycles
    return if (durationsChanged && !state.running && !state.paused) state.copy(
        settings=settings, phase=PomodoroPhase.FOCUS, cycle=0,
        remainingMs=settings.duration(PomodoroPhase.FOCUS), phaseDurationMs=settings.duration(PomodoroPhase.FOCUS),
        sessionId="", deadlineWall=0, deadlineElapsed=0,
    ) else state.copy(settings=settings)
}

/** Relógio monotônico enquanto o aparelho não reinicia; parede como recuperação após reboot. */
fun remainingAt(state: PomodoroState, wall: Long, elapsed: Long): Long {
    if (!state.running) return state.remainingMs
    val sameBoot = kotlin.math.abs((wall - elapsed) - state.bootEpoch) < 60_000
    return ((if (sameBoot) state.deadlineElapsed - elapsed else state.deadlineWall - wall)
        .coerceIn(0, state.phaseDurationMs))
}

/** Conclusão idempotente: apenas fases inteiras de foco contam como pomodoros. */
fun finishPhase(state: PomodoroState, now: Long): PomodoroState {
    if (!state.running) return state
    val focus = state.phase == PomodoroPhase.FOCUS
    val cycle = if (focus) state.cycle + 1 else state.cycle
    val next = when (state.phase) {
        PomodoroPhase.FOCUS -> if (cycle >= state.settings.cycles) PomodoroPhase.LONG_BREAK else PomodoroPhase.SHORT_BREAK
        else -> PomodoroPhase.FOCUS
    }
    val history = if (focus && state.history.none { it.id == state.sessionId })
        state.history + FocusRecord(state.sessionId, now, state.phaseDurationMs) else state.history
    return state.copy(phase = next, running = false, paused = false, remainingMs = state.settings.duration(next),
        phaseDurationMs = state.settings.duration(next), cycle = if (state.phase == PomodoroPhase.LONG_BREAK) 0 else cycle,
        deadlineWall = 0, deadlineElapsed = 0, sessionId = "", history = history)
}
