package com.example.data.notes

import com.example.data.model.searchable

/** Quantidade de cores disponíveis para os cartões; a paleta fica em ui/notes. */
const val NOTE_TONE_COUNT = 5

/** Bloco (categoria) de anotações, exibido como #nome. */
data class NoteTag(val id: String, val name: String)

data class Note(
    val id: String,
    val title: String,
    val body: String,
    val tagId: String?,
    val tone: Int,
    val createdAt: Long,
    val updatedAt: Long,
)

data class NoteState(val tags: List<NoteTag> = emptyList(), val notes: List<Note> = emptyList())

/** Remove # inicial e espaços repetidos: "  #Plantão   UTI " vira "Plantão UTI". */
fun cleanTagName(raw: String): String =
    raw.trim().removePrefix("#").trim().replace(Regex("\\s+"), " ")

fun noteIsBlank(title: String, body: String): Boolean = title.isBlank() && body.isBlank()

/** Filtra por bloco e busca (sem acento, sem maiúsculas); mais recentes primeiro. */
fun visibleNotes(notes: List<Note>, tagId: String?, query: String): List<Note> {
    val needle = searchable(query.trim())
    return notes.filter { note ->
        (tagId == null || note.tagId == tagId) &&
            (needle.isEmpty() || searchable("${note.title} ${note.body}").contains(needle))
    }.sortedByDescending { it.updatedAt }
}
