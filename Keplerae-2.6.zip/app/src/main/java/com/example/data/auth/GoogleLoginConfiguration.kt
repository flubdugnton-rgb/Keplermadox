package com.example.data.auth

/** Valida o formato do ID público. O tipo Web deve ser conferido no Google Cloud. */
internal object GoogleLoginConfiguration {
    fun isWebClientId(value: String): Boolean =
        value.matches(Regex("[A-Za-z0-9_-]+\\.apps\\.googleusercontent\\.com"))
}
