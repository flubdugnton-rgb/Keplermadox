package com.example.data.drive

import android.content.Context
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class DriveFile(val id: String, val name: String, val mimeType: String, val resourceKey: String = "",
    val canDownload: Boolean = true, val size: Long = 0) {
    val folder: Boolean get() = mimeType == "application/vnd.google-apps.folder"
    val contentType: ContentType? get() = when {
        mimeType == "application/pdf" || name.endsWith(".pdf", true) -> ContentType.PDF
        mimeType.startsWith("video/") -> ContentType.VIDEO
        mimeType.startsWith("audio/") -> ContentType.AUDIO
        else -> null
    }
    fun studyItem(parent: StudyItem): StudyItem = parent.copy(
        id = if (name.equals(parent.filename, true)) parent.id else "drive-$id",
        title = name.substringBeforeLast('.'), filename = name,
        type = contentType ?: parent.type, linkKind = LinkKind.FILE, driveFileId = id,
        url = "https://drive.google.com/file/d/$id/view" + if (resourceKey.isBlank()) "" else "?resourcekey=$resourceKey",
        note = "")
}

class DriveRepository(private val context: Context, val credentials: DriveCredentials) {
    private val certificate = installedCertificate(context)
    fun headers(id: String, resourceKey: String) = credentials.headers(context.packageName, certificate, id, resourceKey)
    private fun connection(url: String, id: String, resourceKey: String): HttpURLConnection {
        check(credentials.configured) { "Configure sua chave de API ou autorize uma conta Google." }
        return (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 30000
            headers(id, resourceKey).forEach { (key, value) -> setRequestProperty(key, value) }
        }
    }
    private fun checkResponse(connection: HttpURLConnection) {
        if (connection.responseCode in 200..299) return
        val body = connection.errorStream?.bufferedReader()?.use { it.readText().take(65536) }.orEmpty()
        val reason = runCatching {
            val error = JSONObject(body).getJSONObject("error")
            error.optJSONArray("errors")?.optJSONObject(0)?.optString("reason").orEmpty().ifBlank {
                error.optJSONArray("details")?.optJSONObject(0)?.optString("reason").orEmpty()
            }
        }.getOrDefault("")
        throw IOException(DriveRequests.errorMessage(connection.responseCode, reason))
    }
    private suspend fun json(url: String, id: String, resourceKey: String): JSONObject = withContext(Dispatchers.IO) {
        val request = connection(url, id, resourceKey)
        try { checkResponse(request); currentCoroutineContext().ensureActive()
            JSONObject(request.inputStream.bufferedReader().use { it.readText() })
        } finally { request.disconnect() }
    }
    private fun parse(row: JSONObject): DriveFile {
        val shortcut = row.optJSONObject("shortcutDetails")
        return DriveFile(shortcut?.optString("targetId")?.takeIf { it.isNotBlank() } ?: row.getString("id"),
            row.getString("name"), shortcut?.optString("targetMimeType")?.takeIf { it.isNotBlank() } ?: row.getString("mimeType"),
            shortcut?.optString("targetResourceKey")?.takeIf { it.isNotBlank() } ?: row.optString("resourceKey"),
            row.optJSONObject("capabilities")?.optBoolean("canDownload", true) ?: true, row.optString("size").toLongOrNull() ?: 0)
    }
    suspend fun metadata(id: String, resourceKey: String): DriveFile {
        var file = parse(json(DriveRequests.file(id), id, resourceKey))
        if (file.id != id) return parse(json(DriveRequests.file(file.id), file.id, file.resourceKey))
        return file.copy(resourceKey = file.resourceKey.ifBlank { resourceKey })
    }
    suspend fun folder(id: String, resourceKey: String): List<DriveFile> {
        val files = mutableListOf<DriveFile>(); var token = ""
        do {
            currentCoroutineContext().ensureActive()
            val page = json(DriveRequests.folder(id, token), id, resourceKey)
            val rows = page.optJSONArray("files")
            if (rows != null) for (i in 0 until rows.length()) files += parse(rows.getJSONObject(i))
            token = page.optString("nextPageToken")
        } while (token.isNotBlank())
        return files.distinctBy { it.id }.sortedWith(compareBy<DriveFile> { !it.folder }.thenBy { searchable(it.name) })
    }
    suspend fun pdf(file: DriveFile, destination: File, onProgress: (Long, Long) -> Unit): File = withContext(Dispatchers.IO) {
        require(file.canDownload) { "O proprietário bloqueou o acesso ao conteúdo pela API." }
        val request = connection(DriveRequests.file(file.id, true), file.id, file.resourceKey)
        try {
            checkResponse(request)
            val size = request.contentLengthLong; var received = 0L; var lastUpdate = 0L
            request.inputStream.use { input -> destination.outputStream().use { output ->
                val buffer = ByteArray(32768)
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val count = input.read(buffer); if (count < 0) break
                    output.write(buffer, 0, count); received += count
                    if (received - lastUpdate >= 262144) { onProgress(received, size); lastUpdate = received }
                }
            } }
            currentCoroutineContext().ensureActive()
            require(destination.inputStream().use { String(it.readNBytesCompat(5), Charsets.US_ASCII) } == "%PDF-") {
                "O Drive não retornou um PDF válido." }
            onProgress(received, size); destination
        } catch (e: Exception) { destination.delete(); throw e }
        finally { request.disconnect() }
    }
}
private fun java.io.InputStream.readNBytesCompat(length: Int): ByteArray {
    val result = ByteArray(length); var offset = 0
    while (offset < length) { val n = read(result, offset, length - offset); if (n < 0) break; offset += n }
    return result.copyOf(offset)
}
