package com.example.ui.productivity

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

data class CalmColors(val background:Color,val surface:Color,val ink:Color,val muted:Color,
    val lilac:Color,val sky:Color,val mint:Color,val blush:Color,val accent:Color,val border:Color)

/** Paleta da referência de meditação, preservando contraste nos dois temas. */
@Composable fun calmColors():CalmColors {
    val dark=com.example.ui.theme.LocalKepleraeDarkTheme.current
    return if(dark) CalmColors(Color(0xFF15161D),Color(0xFF23252F),Color(0xFFF4F0FF),Color(0xFFC0BDCF),
        Color(0xFF38314E),Color(0xFF273D4C),Color(0xFF283F3A),Color(0xFF49363F),Color(0xFFC9BAFF),Color(0xFF494551))
    else CalmColors(Color(0xFFF3F4F8),Color(0xFFFCFCFF),Color(0xFF303041),Color(0xFF636277),
        Color(0xFFE8E0F7),Color(0xFFDDECF6),Color(0xFFDDF3ED),Color(0xFFF5E0E9),Color(0xFF7163A7),Color.White)
}

@Composable fun CalmCard(modifier:Modifier=Modifier,color:Color=calmColors().surface,
    content:@Composable ColumnScope.()->Unit) {
    val c=calmColors()
    Surface(modifier.shadow(9.dp,RoundedCornerShape(30.dp),ambientColor=c.accent.copy(alpha=.08f),
        spotColor=c.accent.copy(alpha=.10f)),shape=RoundedCornerShape(30.dp),color=color,
        border=BorderStroke(1.dp,c.border.copy(alpha=.72f))) {
        Column(Modifier.padding(22.dp),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)
    }
}

/** Uma única cápsula com seleção sólida; os rótulos continuam acessíveis. */
@Composable fun ProductivityTabs(selected:Int,onSelect:(Int)->Unit,modifier:Modifier=Modifier) {
    val c=calmColors()
    val titles=listOf("Foco","Progresso","Ajustes")
    val icons=listOf(Icons.Outlined.Timer,Icons.Outlined.BarChart,Icons.Outlined.Tune)
    Surface(modifier,shape=RoundedCornerShape(26.dp),color=c.surface,
        border=BorderStroke(1.dp,c.border),shadowElevation=3.dp) {
        Row(Modifier.selectableGroup().padding(6.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
            titles.forEachIndexed { index,title ->
                val bg by animateColorAsState(if(index==selected)c.lilac else Color.Transparent,label="focus_tab_color")
                Row(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(bg)
                    .selectable(index==selected,onClick={onSelect(index)},role=Role.Tab).padding(vertical=13.dp),
                    horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically) {
                    Icon(icons[index],null,Modifier.size(18.dp),tint=if(index==selected)c.accent else c.muted)
                    Spacer(Modifier.width(5.dp));Text(title,style=MaterialTheme.typography.labelLarge,maxLines=1,color=c.ink)
                }
            }
        }
    }
}

/** Onda com amplitude constante: permanece visível até no primeiro segundo do foco. */
@Composable fun CosmicWavyProgress(progress:Float,running:Boolean,modifier:Modifier=Modifier) {
    val c=calmColors()
    val phase=if(running) {
        val loop=rememberInfiniteTransition(label="pomodoro_wave")
        val value by loop.animateFloat(0f,6.283185f,infiniteRepeatable(tween(1800,easing=LinearEasing)),label="wave_phase")
        value
    } else 0f
    Canvas(modifier.height(28.dp).semantics { progressBarRangeInfo=ProgressBarRangeInfo(progress.coerceIn(0f,1f),0f..1f) }) {
        val path=Path();val wave=32.dp.toPx();val amplitude=4.dp.toPx()
        var x=0f
        while(x<=size.width+2f) {
            val y=size.height/2+sin(x/wave*(2*PI).toFloat()-phase)*amplitude
            if(x==0f)path.moveTo(x,y)else path.lineTo(x,y)
            x+=2f
        }
        drawPath(path,c.accent.copy(alpha=.20f),style=Stroke(3.dp.toPx(),cap=StrokeCap.Round))
        clipRect(right=size.width*progress.coerceIn(0f,1f)) {
            drawPath(path,c.accent,style=Stroke(4.dp.toPx(),cap=StrokeCap.Round))
        }
        val end=size.width*progress.coerceIn(0f,1f)
        drawCircle(c.accent,3.dp.toPx(),Offset(end,size.height/2+sin(end/wave*(2*PI).toFloat()-phase)*amplitude))
    }
}
