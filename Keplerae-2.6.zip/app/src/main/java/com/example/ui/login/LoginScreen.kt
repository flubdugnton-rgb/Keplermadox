@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.login

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState

/**
 * Tela visual independente do Google: também pode ser usada em Preview e teste.
 * Texto, ícone e um único botão. Nenhum dado de autenticação pertence à UI.
 */
@Composable
fun LoginScreen(
    busy: Boolean,
    error: String?,
    onGoogleSignIn: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    // O padrão do Haze evita blur nos aparelhos em que ele não é confiável.
    // O fallbackTint mantém o vidro translúcido nessas versões/dispositivos.
    val haze = rememberHazeState()
    val preview = LocalInspectionMode.current
    var visible by remember { mutableStateOf(preview) }
    LaunchedEffect(Unit) { visible = true }

    BoxWithConstraints(modifier.fillMaxSize().background(colors.surface)) {
        val compact = maxHeight < 480.dp
        LoginBackdrop(haze, Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().safeDrawingPadding()
                .padding(horizontal = 28.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier.fillMaxWidth().weight(1f),
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = visible,
                    // O rodapé fica no final; só o conteúdo central rola quando necessário.
                    modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    enter = fadeIn(tween(380)) + slideInVertically(
                        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy),
                        initialOffsetY = { it / 12 },
                    ),
                ) {
                    Column(
                        Modifier.widthIn(max = 420.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        val logoShape = RoundedCornerShape(if (compact) 34.dp else 48.dp)
                        Box(
                            Modifier.size(if (compact) 148.dp else 204.dp)
                                .shadow(24.dp, logoShape, clip = false,
                                    ambientColor = colors.primary.copy(alpha = .18f),
                                    spotColor = colors.primary.copy(alpha = .28f))
                                .clip(logoShape)
                                .hazeEffect(haze, glassStyle(.48f))
                                .border(1.dp, Brush.linearGradient(listOf(
                                    Color.White.copy(alpha = .75f), colors.primary.copy(alpha = .13f),
                                )), logoShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            // Arquivo definitivo enviado pelo usuário, sem redesenho.
                            Image(
                                painter = painterResource(R.drawable.keplerae_logo),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.size(if (compact) 112.dp else 160.dp)
                                    .clip(RoundedCornerShape(if (compact) 20.dp else 28.dp)),
                            )
                        }
                        Spacer(Modifier.height(if (compact) 20.dp else 36.dp))
                        Text(
                            text = stringResource(R.string.app_name),
                            style = if (compact) MaterialTheme.typography.displayMedium
                                else MaterialTheme.typography.displayLarge,
                            fontWeight = FontWeight.Bold,
                            color = colors.onSurface,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().semantics { heading() },
                        )
                        Spacer(Modifier.height(if (compact) 24.dp else 40.dp))
                        GoogleGlassButton(busy, onGoogleSignIn, haze)
                        AnimatedVisibility(visible = error != null) {
                            Text(
                                text = error.orEmpty(), color = colors.error,
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
                                    .semantics { liveRegion = LiveRegionMode.Polite }
                                    .testTag("login_error"),
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text(
                text = stringResource(R.string.developed_by),
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }
    }
}

@Composable
private fun GoogleGlassButton(busy: Boolean, onClick: () -> Unit, haze: HazeState) {
    val colors = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(32.dp)
    val interactions = remember { MutableInteractionSource() }
    val pressed by interactions.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .97f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium), label = "googleButtonScale",
    )
    Button(
        onClick = onClick, enabled = !busy, interactionSource = interactions, shape = shape,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent, contentColor = colors.onSurface,
            disabledContainerColor = Color.Transparent, disabledContentColor = colors.onSurface,
        ),
        contentPadding = PaddingValues(horizontal = 22.dp, vertical = 18.dp),
        modifier = Modifier.widthIn(max = 340.dp).fillMaxWidth().heightIn(min = 64.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(18.dp, shape, clip = false,
                ambientColor = colors.primary.copy(alpha = .16f),
                spotColor = colors.primary.copy(alpha = .24f))
            .clip(shape).hazeEffect(haze, glassStyle(.72f))
            .border(1.dp, Brush.linearGradient(listOf(
                Color.White.copy(alpha = .78f), colors.outline.copy(alpha = .30f),
            )), shape)
            .semantics { stateDescription = if (busy) "Conectando ao Google" else "Pronto para entrar" }
            .testTag("google_sign_in"),
    ) {
        // Mantém as cores do G: não usar Icon(tint = ...) neste recurso.
        Image(painterResource(R.drawable.ic_google_g), contentDescription = null,
            modifier = Modifier.size(28.dp).clip(CircleShape).background(Color.White).padding(4.dp))
        Text(
            text = stringResource(R.string.google_sign_in),
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
        )
        if (busy) LoadingIndicator(
            color = colors.primary,
            modifier = Modifier.size(20.dp),
        ) else Spacer(Modifier.size(20.dp))
    }
}

@Composable
private fun glassStyle(tintAlpha: Float): HazeStyle {
    val colors = MaterialTheme.colorScheme
    return HazeStyle(
        backgroundColor = colors.surface,
        tint = HazeTint(colors.surface.copy(alpha = tintAlpha)),
        blurRadius = 28.dp, noiseFactor = .025f,
        fallbackTint = HazeTint(colors.surface.copy(alpha = .88f)),
    )
}

/** Anéis grandes, recortados nas bordas, como na referência. Sem bitmap de fundo. */
@Composable
private fun LoginBackdrop(haze: HazeState, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    Canvas(modifier.hazeSource(haze)) {
        drawRect(Brush.verticalGradient(listOf(colors.surface, colors.primaryContainer.copy(alpha = .40f), colors.surface)))
        fun orb(center: Offset, radius: Float, color: Color) {
            drawCircle(Brush.radialGradient(listOf(
                color.copy(alpha = .08f), color.copy(alpha = .38f), Color.Transparent,
            ), center = center, radius = radius * 1.14f), radius * 1.14f, center)
            drawCircle(Brush.radialGradient(listOf(
                colors.surface.copy(alpha = .96f), colors.primaryContainer.copy(alpha = .82f),
            ), center = center - Offset(radius * .25f, radius * .30f), radius = radius * 1.35f), radius, center)
            drawCircle(Color.White.copy(alpha = .42f), radius, center, style = Stroke(1.5.dp.toPx()))
        }
        val radius = minOf(size.width * .62f, size.height * .36f)
        orb(Offset(-radius * .28f, -radius * .23f), radius, colors.primary)
        orb(Offset(size.width + radius * .40f, size.height * .36f), radius * .42f, colors.primary)
        orb(Offset(size.width + radius * .02f, size.height + radius * .10f), radius * 1.26f, colors.secondary)
        orb(Offset(-radius * .36f, size.height * .88f), radius * .72f, colors.primary)
    }
}
