package com.example.ui.theme

import android.os.Build
import android.util.Log
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFontFamilyResolver
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.text.font.createFontFamilyResolver
import com.example.data.repository.ThemeMode
import kotlinx.coroutines.CoroutineExceptionHandler

/** Modo aplicado ao app, inclusive quando a escolha diverge do tema do aparelho. */
val LocalKepleraeDarkTheme = staticCompositionLocalOf { false }

@Composable
fun isDarkMode(mode: ThemeMode): Boolean = when (mode) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

/**
 * Mesma assinatura da versão 1.2.2: MainActivity e preferências continuam integradas.
 * Android 12+: cores do papel de parede. Android 7–11: paleta do ícone Kepleræ.
 */
@Composable
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
fun KepleraeTheme(
    mode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    val dark = isDarkMode(mode)
    val context = LocalContext.current
    val preview = LocalInspectionMode.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !preview -> {
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        dark -> KepleraeDarkColors
        else -> KepleraeLightColors
    }
    val fontResolver = remember(context) {
        createFontFamilyResolver(
            context,
            CoroutineExceptionHandler { _, error ->
                // Falhas no download não bloqueiam o app: o resolver usa o fallback.
                Log.w("KepleraeFonts", "Fonte Google indisponível; usando fonte local.", error)
            },
        )
    }
    CompositionLocalProvider(LocalFontFamilyResolver provides fontResolver,
        LocalKepleraeDarkTheme provides dark) {
        MaterialExpressiveTheme(
            colorScheme = colorScheme,
            typography = if (preview) PreviewTypography else Typography,
            shapes = KepleraeShapes,
        ) {
            // A camada Expressive fornece movimento; esta camada reage às cores
            // imediatamente, sem recriar a Activity ou perder a navegação.
            MaterialTheme(colorScheme = colorScheme,
                typography = if (preview) PreviewTypography else Typography,
                shapes = KepleraeShapes, content = content)
        }
    }
}
