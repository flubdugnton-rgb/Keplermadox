package com.example.ui.login

import android.app.Activity
import android.content.MutableContextWrapper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.auth.GoogleLoginViewModel
import com.example.data.auth.GoogleLoginConfiguration
import com.example.data.auth.GoogleUser
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** O lançamento de Credential Manager fica na tela e acompanha seu ciclo de vida. */
@Composable
fun LoginRoute(viewModel: GoogleLoginViewModel) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val credentials = remember(context.applicationContext) {
        CredentialManager.create(context.applicationContext)
    }
    val webClientId = context.getString(R.string.google_web_client_id).trim()
    val driveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult(),
    ) { result ->
        viewModel.receiveDriveResult(result.data, result.resultCode == Activity.RESULT_OK)
    }

    LaunchedEffect(state.driveResolution) {
        val pending = state.driveResolution ?: return@LaunchedEffect
        viewModel.consumeDriveResolution()
        try {
            driveLauncher.launch(IntentSenderRequest.Builder(pending.intentSender).build())
        } catch (error: Exception) {
            viewModel.credentialFailure(error)
        }
    }

    LoginScreen(busy = state.busy, error = state.error, onGoogleSignIn = {
        if (!viewModel.beginSignIn()) return@LoginScreen
        if (!GoogleLoginConfiguration.isWebClientId(webClientId)) {
            viewModel.configurationMissing()
            return@LoginScreen
        }
        scope.launch {
            try {
                // Fluxo explícito do botão: permite escolher/adicionar uma conta Google.
                val option = GetSignInWithGoogleOption.Builder(webClientId).build()
                val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                val response = credentials.getCredential(
                    context = MutableContextWrapper(context),
                    request = request,
                )
                val custom = response.credential as? CustomCredential
                    ?: error("Tipo de credencial inesperado")
                check(custom.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    "Tipo de credencial inesperado"
                }
                val google = GoogleIdTokenCredential.createFrom(custom.data)
                val user = GoogleUser(
                    email = google.id,
                    displayName = google.displayName?.takeIf { it.isNotBlank() } ?: google.id,
                    photoUrl = google.profilePictureUri?.toString(),
                )
                // O ID token não é salvo, não é registrado em log e não vai à API Drive.
                // Esta aplicação local não possui um servidor nem usa Firebase Auth.
                viewModel.authorizeDrive(user)
            } catch (error: CancellationException) {
                viewModel.cancelCredentialRequest()
                throw error
            } catch (error: Exception) {
                viewModel.credentialFailure(error)
            }
        }
    })
}
