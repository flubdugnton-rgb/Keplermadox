package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.DeviceFontFamilyName
import androidx.compose.ui.text.font.Font as DeviceFont
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font as GoogleFontFace
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.unit.sp
import com.example.R

private val googleFontsProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs,
)

/** Roboto do Google Fonts, com fallback local por peso, inclusive sem internet. */
private val KepleraeFontFamily = FontFamily(
    *listOf(FontWeight.Normal, FontWeight.Medium, FontWeight.SemiBold, FontWeight.Bold)
        .flatMap { weight ->
            listOf(
                GoogleFontFace(
                    googleFont = GoogleFont("Roboto"),
                    fontProvider = googleFontsProvider,
                    weight = weight,
                ),
                DeviceFont(familyName = DeviceFontFamilyName("sans-serif"), weight = weight),
            )
        }.toTypedArray(),
)

private fun materialTypography(family: FontFamily): Typography {
    fun style(size: Int, height: Int, weight: FontWeight, spacing: Float = 0f) = TextStyle(
        fontFamily = family,
        fontWeight = weight,
        fontSize = size.sp,
        lineHeight = height.sp,
        letterSpacing = spacing.sp,
    )
    // A escala mantém os 15 papéis do Material 3. Não usa tamanhos em pixels.
    return Typography(
        displayLarge = style(57, 64, FontWeight.Bold, -0.25f),
        displayMedium = style(45, 52, FontWeight.Bold),
        displaySmall = style(36, 44, FontWeight.SemiBold),
        headlineLarge = style(32, 40, FontWeight.Bold),
        headlineMedium = style(28, 36, FontWeight.SemiBold),
        headlineSmall = style(24, 32, FontWeight.SemiBold),
        titleLarge = style(22, 28, FontWeight.Medium),
        titleMedium = style(16, 24, FontWeight.Medium, 0.15f),
        titleSmall = style(14, 20, FontWeight.Medium, 0.1f),
        bodyLarge = style(16, 24, FontWeight.Normal, 0.5f),
        bodyMedium = style(14, 20, FontWeight.Normal, 0.25f),
        bodySmall = style(12, 16, FontWeight.Normal, 0.4f),
        labelLarge = style(14, 20, FontWeight.Medium, 0.1f),
        labelMedium = style(12, 16, FontWeight.Medium, 0.5f),
        labelSmall = style(11, 16, FontWeight.Medium, 0.5f),
    )
}

// Nome preservado para os arquivos que já importam Typography no projeto atual.
val Typography: Typography = materialTypography(KepleraeFontFamily)

/** O preview do Android Studio usa a mesma escala sem iniciar downloads. */
internal val PreviewTypography: Typography = materialTypography(FontFamily.SansSerif)
