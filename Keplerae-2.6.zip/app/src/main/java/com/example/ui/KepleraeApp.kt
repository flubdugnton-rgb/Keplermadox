@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui

import android.os.Build

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.LibraryBooks
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.example.data.auth.GoogleUser
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.components.FloatingAppNavigation
import com.example.ui.components.LoadingPane
import com.example.ui.components.SharedMotion
import com.example.ui.home.HomeScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.productivity.PomodoroScreen
import com.example.ui.productivity.QuestionsScreen
import com.example.ui.notes.NotesScreen

enum class Destination(val title: String, val icon: ImageVector, val type: ContentType?) {
    HOME("Início", Icons.Outlined.Home, null),
    VIDEOS("Aulas", Icons.Outlined.PlayCircleOutline, ContentType.VIDEO),
    PDFS("PDFs", Icons.AutoMirrored.Filled.LibraryBooks, ContentType.PDF),
    AUDIO("Áudios", Icons.Outlined.Headphones, ContentType.AUDIO),
    SUBJECTS("Matérias", Icons.Outlined.GridView, null),
    POMODORO("Pomodoro", Icons.Outlined.Timer, null),
    QUESTIONS("Questões", Icons.Outlined.Quiz, null),
    NOTES("Notas", Icons.Outlined.EditNote, null),
}

private data class AppRoute(val destination: Destination, val subjectId: String?,
    val path: List<String>, val profile: Boolean)

@Composable fun KepleraeApp(state: StudyState, model: StudyViewModel,
    user: GoogleUser? = null, onSignOut: () -> Unit = {}, openPomodoro: Boolean = false) {
    var destinationName by rememberSaveable { mutableStateOf(if(openPomodoro) Destination.POMODORO.name else Destination.HOME.name) }
    var subjectId by rememberSaveable { mutableStateOf<String?>(null) }
    var pathKey by rememberSaveable { mutableStateOf("") }
    var settings by rememberSaveable { mutableStateOf(false) }
    var configureDrive by remember { mutableStateOf(false) }
    var profile by rememberSaveable { mutableStateOf(false) }
    var activeId by rememberSaveable { mutableStateOf<String?>(null) }
    val destination = Destination.valueOf(destinationName)
    val subject = subjectId?.let(Subjects::get)
    val path = if (pathKey.isBlank()) emptyList() else pathKey.split('\u001f')
    val activeItem = state.items.firstOrNull { it.id == activeId }
    fun navigate(next: Destination) {
        destinationName = next.name; subjectId = null; pathKey = ""; profile = false
    }
    fun select(next: Subject) { subjectId = next.id; pathKey = "" }
    fun open(item: StudyItem) { model.recordAccess(item.id); activeId = item.id }
    fun back() {
        when {
            profile -> profile = false
            path.isNotEmpty() -> pathKey = path.dropLast(1).joinToString("\u001f")
            subjectId != null -> subjectId = null
            destination != Destination.HOME -> navigate(Destination.HOME)
        }
    }
    BackHandler(enabled = (profile || subject != null || destination != Destination.HOME)
        && activeItem == null && !settings && !configureDrive) { back() }

    BackHandler(enabled = settings) { settings = false }

    // Visualizador é uma página do próprio app, sem Custom Tab e sem navegador.
    if (activeItem != null) {
        DriveViewer(activeItem, state, onDismiss = { activeId = null },
            onFavorite = model::toggleFavorite, onCompleted = model::toggleCompleted,
            onAccess = model::recordAccess, accountEmail = user?.email)
        return
    }
    SharedTransitionLayout {
        val shared = this
        BoxWithConstraints(Modifier.fillMaxSize()) {
            // Uma navegação flutuante também em tablets, sem barra lateral.
            Scaffold(bottomBar = {
                if (!profile) FloatingAppNavigation(destination, ::navigate)
            }) { padding ->
                Row(Modifier.fillMaxSize().padding(padding)) {
                    Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
                        AnimatedContent(targetState = AppRoute(destination, subjectId, path, profile),
                            modifier = Modifier.widthIn(max = 1120.dp).fillMaxSize(),
                            transitionSpec = {
                                if (initialState.destination != targetState.destination)
                                    fadeIn(tween(120)) togetherWith fadeOut(tween(80))
                                else fadeIn(tween(220)) togetherWith fadeOut(tween(180))
                            },
                            label = "shared_destinations") { route ->
                            val motion = SharedMotion(shared, this, route.destination.name)
                            when {
                                route.profile -> ProfileScreen(user, state, motion,
                                    onTheme = model::setTheme, onDynamicColor = model::setDynamicColor,
                                    onConfigureDrive = { configureDrive = true }, onSignOut = onSignOut,
                                    onBack = ::back, onAppearance = { settings = true })
                                route.destination == Destination.POMODORO -> PomodoroScreen()
                                route.destination == Destination.QUESTIONS -> QuestionsScreen()
                                route.destination == Destination.NOTES -> NotesScreen()
                                state.loading && state.items.isEmpty() -> LoadingPane("Preparando sua biblioteca…")
                                state.error != null -> Column(Modifier.fillMaxSize().padding(24.dp),
                                    verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Outlined.CloudOff, null, Modifier.size(48.dp))
                                    Text(state.error)
                                    Button(onClick = model::reload) { Text("Tentar novamente") }
                                }
                                route.subjectId == null && route.destination == Destination.HOME ->
                                    HomeScreen(state, user, motion, ::navigate, ::select, ::open,
                                        onProfile = { profile = true }, onRefresh = model::reload)
                                else -> CatalogScreen(state, route.destination, route.subjectId?.let(Subjects::get),
                                    route.path, motion, ::select,
                                    onFolder = { pathKey = (route.path + it).joinToString("\u001f") },
                                    onOpen = ::open, onFavorite = model::toggleFavorite,
                                    onCompleted = model::toggleCompleted, onRefresh = model::reload,
                                    onSaveOrder = model::saveVisibleOrder, onBack = ::back)
                            }
                        }
                    }
                }
            }
        }
    }
    if (settings) AppearanceSheet(state, model, onDismiss = { settings = false },
        onConfigure = { settings = false; configureDrive = true })
    if (configureDrive) DriveConfigDialog(accountEmail = user?.email, onDismiss = { configureDrive = false })
}

/** Preserva o modo automático e o acesso às configurações anteriores. */
@Composable private fun AppearanceSheet(state: StudyState, model: StudyViewModel,
    onDismiss: () -> Unit, onConfigure: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, modifier = Modifier.testTag("appearance_sheet")) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Do seu jeito", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss, modifier = Modifier.testTag("appearance_close")) {
                    Icon(Icons.Outlined.Close, "Fechar preferências")
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(selected = mode == state.theme, onClick = { model.setTheme(mode) },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("theme_${mode.name}"),
                        label = { Text(mode.label) })
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Cores do seu Android", style = MaterialTheme.typography.titleMedium)
                    Text(if (Build.VERSION.SDK_INT >= 31) "Use as cores do seu papel de parede."
                        else "Disponível no Android 12 ou superior.", style = MaterialTheme.typography.bodySmall)
                }
                Switch(state.dynamicColor, model::setDynamicColor, enabled = Build.VERSION.SDK_INT >= 31)
            }
            OutlinedButton(onClick = onConfigure, modifier = Modifier.fillMaxWidth()) { Text("Configurar Google Drive") }
            Text("Kepleræ 2.6", style = MaterialTheme.typography.titleMedium)
            Text("${state.items.size} materiais. Seu progresso é salvo neste aparelho.")
        }
    }
}
