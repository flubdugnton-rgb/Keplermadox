@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.example.ui.notes

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.notes.*
import com.example.ui.productivity.calmColors
import java.util.UUID

private data class NoteTone(val container: Color, val onContainer: Color)

private val ToneNames = listOf("Lilás", "Verde", "Azul", "Laranja", "Rosa")

/** Cinco cores pastel, com versão escura que mantém o contraste do texto. */
@Composable private fun noteTones(): List<NoteTone> {
    val dark = com.example.ui.theme.LocalKepleraeDarkTheme.current
    return if (dark) listOf(
        NoteTone(Color(0xFF3B2F5C), Color(0xFFEDE3FF)),
        NoteTone(Color(0xFF2B4A2C), Color(0xFFDDF8D2)),
        NoteTone(Color(0xFF26455C), Color(0xFFDCEFFF)),
        NoteTone(Color(0xFF5C4526), Color(0xFFFFEBCB)),
        NoteTone(Color(0xFF5C2E43), Color(0xFFFFE0EE)),
    ) else listOf(
        NoteTone(Color(0xFFD9C6F8), Color(0xFF2E2347)),
        NoteTone(Color(0xFFBFF0A0), Color(0xFF1F3A12)),
        NoteTone(Color(0xFFB8DFF8), Color(0xFF12344D)),
        NoteTone(Color(0xFFF8D9A0), Color(0xFF4A3410)),
        NoteTone(Color(0xFFF8C9DE), Color(0xFF4D1E34)),
    )
}

private fun formatDate(millis: Long): String =
    java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.forLanguageTag("pt-BR"))
        .format(java.util.Date(millis))

/** Aba Anotações: lista em grade/lista de cartões coloridos e editor em tela cheia. */
@Composable fun NotesScreen() {
    val context = LocalContext.current
    val store = remember { NoteStore.get(context) }
    val state by store.state.collectAsStateWithLifecycle()
    // null = lista; qualquer outro valor é o id da anotação aberta (nova ou existente).
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    val editing = editingId
    if (editing != null) {
        NoteEditor(
            existing = state.notes.firstOrNull { it.id == editing }, id = editing,
            tags = state.tags, store = store, defaultTone = state.notes.size % NOTE_TONE_COUNT,
            onSave = { store.upsert(it); editingId = null },
            onDelete = { store.delete(editing); editingId = null },
            onCancel = { editingId = null },
        )
    } else {
        NotesList(state, store, onOpen = { editingId = it }, onNew = { editingId = UUID.randomUUID().toString() })
    }
}

@Composable private fun NotesList(state: NoteState, store: NoteStore, onOpen: (String) -> Unit, onNew: () -> Unit) {
    val c = calmColors()
    val tones = noteTones()
    var query by rememberSaveable { mutableStateOf("") }
    var selectedTag by rememberSaveable { mutableStateOf<String?>(null) }
    var grid by rememberSaveable { mutableStateOf(true) }
    var newTag by remember { mutableStateOf(false) }
    var renameTag by remember { mutableStateOf(false) }
    var deleteTag by remember { mutableStateOf(false) }
    val activeTag = state.tags.firstOrNull { it.id == selectedTag }
    val visible = remember(state.notes, activeTag?.id, query) { visibleNotes(state.notes, activeTag?.id, query) }
    val tagNames = remember(state.tags) { state.tags.associate { it.id to it.name } }

    CompositionLocalProvider(LocalContentColor provides c.ink) {
        Box(Modifier.fillMaxSize()) {
        LazyVerticalStaggeredGrid(
            columns = if (grid) StaggeredGridCells.Adaptive(170.dp) else StaggeredGridCells.Fixed(1),
            modifier = Modifier.fillMaxSize().background(c.background).testTag("notes_screen"),
            contentPadding = PaddingValues(start = 20.dp, top = 20.dp, end = 20.dp, bottom = 110.dp),
            verticalItemSpacing = 12.dp,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(span = StaggeredGridItemSpan.FullLine) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Notas", style = MaterialTheme.typography.displaySmall)
                        Text("Seus blocos de notas.", color = c.muted)
                    }
                    IconButton(onClick = { grid = !grid }) {
                        Icon(
                            if (grid) Icons.Outlined.ViewAgenda else Icons.Outlined.GridView,
                            if (grid) "Mostrar em lista" else "Mostrar em grade",
                        )
                    }
                }
            }
            item(span = StaggeredGridItemSpan.FullLine) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("notes_search"),
                    placeholder = { Text("Buscar anotações") },
                    leadingIcon = { Icon(Icons.Outlined.Search, null) },
                    trailingIcon = {
                        if (query.isNotBlank()) IconButton(onClick = { query = "" }) {
                            Icon(Icons.Outlined.Close, "Limpar busca")
                        }
                    },
                    shape = RoundedCornerShape(28.dp),
                )
            }
            item(span = StaggeredGridItemSpan.FullLine) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(selected = activeTag == null, onClick = { selectedTag = null },
                            label = { Text("#Todas") })
                    }
                    items(state.tags, key = { it.id }) { tag ->
                        FilterChip(selected = activeTag?.id == tag.id, onClick = { selectedTag = tag.id },
                            label = { Text("#${tag.name}") })
                    }
                    item {
                        AssistChip(onClick = { newTag = true }, label = { Text("Novo bloco") },
                            leadingIcon = { Icon(Icons.Outlined.Add, null, Modifier.size(18.dp)) })
                    }
                }
            }
            if (activeTag != null) item(span = StaggeredGridItemSpan.FullLine) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { renameTag = true }) {
                        Icon(Icons.Outlined.Edit, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Renomear bloco")
                    }
                    TextButton(onClick = { deleteTag = true }) {
                        Icon(Icons.Outlined.Delete, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Excluir bloco")
                    }
                }
            }
            if (visible.isEmpty()) item(span = StaggeredGridItemSpan.FullLine) {
                val filtering = query.isNotBlank() || activeTag != null
                Column(
                    Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Icon(Icons.Outlined.EditNote, null, Modifier.size(44.dp), tint = c.accent)
                    Text(
                        if (filtering) "Nenhuma anotação encontrada" else "Crie sua primeira anotação",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        if (filtering) "Tente outro termo ou escolha outro bloco."
                        else "Guarde resumos, macetes e lembretes de estudo.",
                        color = c.muted,
                    )
                    if (!filtering) Button(onClick = onNew) { Text("Nova anotação") }
                }
            }
            items(visible, key = { it.id }) { note ->
                NoteCard(
                    note = note, tone = tones.getOrElse(note.tone) { tones[0] },
                    tagName = note.tagId?.let { tagNames[it] }, onClick = { onOpen(note.id) },
                )
            }
        }
        ExtendedFloatingActionButton(onClick = onNew, icon = { Icon(Icons.Outlined.Add, null) },
            text = { Text("Nova nota") }, modifier = Modifier.align(Alignment.BottomEnd)
                .padding(20.dp).testTag("note_new"))
        }
    }

    if (newTag) NameDialog("Novo bloco", "", onDismiss = { newTag = false }) { name ->
        try { selectedTag = store.createTag(name); null }
        catch (e: IllegalArgumentException) { e.message ?: "Nome inválido." }
    }
    if (renameTag && activeTag != null) NameDialog("Renomear bloco", activeTag.name, onDismiss = { renameTag = false }) { name ->
        try { store.renameTag(activeTag.id, name); null }
        catch (e: IllegalArgumentException) { e.message ?: "Nome inválido." }
    }
    if (deleteTag && activeTag != null) AlertDialog(
        onDismissRequest = { deleteTag = false },
        icon = { Icon(Icons.Outlined.Delete, null) },
        title = { Text("Excluir bloco?") },
        text = { Text("As anotações de #${activeTag.name} continuam salvas, apenas sem bloco.") },
        confirmButton = {
            TextButton(onClick = { store.deleteTag(activeTag.id); selectedTag = null; deleteTag = false }) { Text("Excluir") }
        },
        dismissButton = { TextButton(onClick = { deleteTag = false }) { Text("Cancelar") } },
    )
}

@Composable private fun NoteCard(note: Note, tone: NoteTone, tagName: String?, onClick: () -> Unit) {
    val tilt = remember(note.id) { Animatable(0f) }
    LaunchedEffect(note.id) {
        delay((note.id.hashCode().toLong().and(0x7fffffff) % 160))
        tilt.animateTo(-2.5f, tween(130)); tilt.animateTo(2f, tween(170))
        tilt.animateTo(0f, spring(dampingRatio = .65f, stiffness = 300f))
    }
    Surface(
        onClick = onClick, shape = RoundedCornerShape(20.dp), color = tone.container,
        border = BorderStroke(1.dp, tone.onContainer.copy(alpha = .3f)), shadowElevation = 1.dp,
        contentColor = tone.onContainer, modifier = Modifier.fillMaxWidth().graphicsLayer { rotationZ = tilt.value }.testTag("note_${note.id}"),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                note.title.ifBlank { "Sem título" }, style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Text(
                formatDate(note.updatedAt), style = MaterialTheme.typography.labelSmall,
                color = tone.onContainer.copy(alpha = .65f),
            )
            if (note.body.isNotBlank()) Text(
                note.body, style = MaterialTheme.typography.bodySmall, maxLines = 6,
                overflow = TextOverflow.Ellipsis, color = tone.onContainer.copy(alpha = .85f),
            )
            if (tagName != null) Text("#$tagName", style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable private fun transparentFieldColors(ink: Color) = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    disabledContainerColor = Color.Transparent, errorContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    disabledIndicatorColor = Color.Transparent, errorIndicatorColor = Color.Transparent,
    focusedTextColor = ink, unfocusedTextColor = ink, cursorColor = ink,
    focusedPlaceholderColor = ink.copy(alpha = .5f), unfocusedPlaceholderColor = ink.copy(alpha = .5f),
)

@Composable private fun NoteEditor(
    existing: Note?, id: String, tags: List<NoteTag>, store: NoteStore, defaultTone: Int,
    onSave: (Note) -> Unit, onDelete: () -> Unit, onCancel: () -> Unit,
) {
    val c = calmColors()
    val tones = noteTones()
    var title by rememberSaveable(id) { mutableStateOf(existing?.title.orEmpty()) }
    var body by rememberSaveable(id) { mutableStateOf(existing?.body.orEmpty()) }
    var tone by rememberSaveable(id) { mutableIntStateOf(existing?.tone ?: defaultTone) }
    var tagId by rememberSaveable(id) { mutableStateOf(existing?.tagId) }
    var menu by remember { mutableStateOf(false) }
    var newTag by remember { mutableStateOf(false) }
    var discard by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val current = tones.getOrElse(tone) { tones[0] }
    val tagName = tags.firstOrNull { it.id == tagId }?.name
    val changed = title != (existing?.title ?: "") || body != (existing?.body ?: "") ||
        tone != (existing?.tone ?: defaultTone) || tagId != existing?.tagId

    fun cancel() { if (changed) discard = true else onCancel() }
    fun save() {
        if (noteIsBlank(title, body)) return
        if (existing != null && !changed) { onCancel(); return }
        val now = System.currentTimeMillis()
        onSave(Note(id, title.trim(), body.trimEnd(), tagId, tone, existing?.createdAt ?: now, now))
    }
    BackHandler { cancel() }

    CompositionLocalProvider(LocalContentColor provides c.ink) {
        Column(
            Modifier.fillMaxSize().background(c.background).imePadding()
                .padding(horizontal = 16.dp, vertical = 12.dp).testTag("note_editor"),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { cancel() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                Spacer(Modifier.weight(1f))
                Box {
                    AssistChip(
                        onClick = { menu = true }, label = { Text(tagName?.let { "#$it" } ?: "Sem bloco") },
                        leadingIcon = { Icon(Icons.Outlined.Folder, null, Modifier.size(18.dp)) },
                    )
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Sem bloco") }, onClick = { tagId = null; menu = false })
                        tags.forEach { tag ->
                            DropdownMenuItem(text = { Text("#${tag.name}") }, onClick = { tagId = tag.id; menu = false })
                        }
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Novo bloco…") },
                            leadingIcon = { Icon(Icons.Outlined.Add, null) },
                            onClick = { menu = false; newTag = true },
                        )
                    }
                }
                if (existing != null) IconButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Outlined.Delete, "Excluir anotação")
                }
            }
            Surface(
                Modifier.weight(1f).fillMaxWidth(), shape = RoundedCornerShape(32.dp),
                color = current.container, contentColor = current.onContainer,
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 16.dp)) {
                    val fieldColors = transparentFieldColors(current.onContainer)
                    TextField(
                        value = title, onValueChange = { title = it },
                        modifier = Modifier.fillMaxWidth().testTag("note_title"),
                        textStyle = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
                        placeholder = { Text("Título", style = MaterialTheme.typography.headlineSmall) },
                        maxLines = 3, colors = fieldColors,
                    )
                    Text(
                        formatDate(existing?.updatedAt ?: System.currentTimeMillis()),
                        modifier = Modifier.padding(horizontal = 16.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = current.onContainer.copy(alpha = .65f),
                    )
                    TextField(
                        value = body, onValueChange = { body = it },
                        modifier = Modifier.fillMaxWidth().weight(1f).testTag("note_body"),
                        placeholder = { Text("Escreva sua anotação…") }, colors = fieldColors,
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                tones.forEachIndexed { index, option ->
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(option.container)
                            .border(if (index == tone) 3.dp else 1.dp, if (index == tone) c.accent else c.border, CircleShape)
                            .selectable(index == tone, onClick = { tone = index }, role = Role.RadioButton)
                            .semantics { contentDescription = "Cor ${ToneNames.getOrElse(index) { "${index + 1}" }}" },
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { cancel() }) { Text("Cancelar") }
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = { save() }, enabled = !noteIsBlank(title, body),
                    modifier = Modifier.testTag("note_confirm"),
                ) { Text("Confirmar") }
            }
        }
    }

    if (newTag) NameDialog("Novo bloco", "", onDismiss = { newTag = false }) { name ->
        try { tagId = store.createTag(name); null }
        catch (e: IllegalArgumentException) { e.message ?: "Nome inválido." }
    }
    if (discard) AlertDialog(
        onDismissRequest = { discard = false },
        icon = { Icon(Icons.Outlined.EditNote, null) },
        title = { Text("Descartar alterações?") },
        text = { Text("O que você escreveu nesta anotação não será salvo.") },
        confirmButton = { TextButton(onClick = { discard = false; onCancel() }) { Text("Descartar") } },
        dismissButton = { TextButton(onClick = { discard = false }) { Text("Continuar editando") } },
    )
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        icon = { Icon(Icons.Outlined.Delete, null) },
        title = { Text("Excluir anotação?") },
        text = { Text("Esta ação não pode ser desfeita.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Excluir") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } },
    )
}

/** [onConfirm] devolve a mensagem de erro, ou null quando salvou e o diálogo pode fechar. */
@Composable private fun NameDialog(
    title: String, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> String?,
) {
    var name by remember { mutableStateOf(initial) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Folder, null) },
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name, onValueChange = { name = it; error = null }, singleLine = true,
                label = { Text("Nome do bloco") }, isError = error != null,
                supportingText = { error?.let { Text(it) } },
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val result = onConfirm(name)
                error = result
                if (result == null) onDismiss()
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
