package com.example.ui

import android.accounts.Account
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Cloud
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.google.android.gms.common.api.ApiException
import androidx.compose.ui.unit.dp
import com.example.data.drive.*
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope

private fun authorizationFailure(error: Throwable): String {
    val code = (error as? ApiException)?.statusCode
    return when (code) {
        8 -> "O Google retornou erro interno (código 8). Tente novamente com conexão ativa. Esse código sozinho não identifica falha de cadastro OAuth."
        10 -> "Google recusou o cadastro do app (código 10). No Google Cloud, cadastre um cliente OAuth Android com o pacote e SHA-1 exibidos abaixo. Uma chave de API sozinha não permite conectar a conta."
        7 -> "Sem conexão com o Google (código 7). Confira a internet e tente novamente."
        16 -> "O Google devolveu cancelamento (código 16). Se você confirmou a conta, confira o cliente OAuth Android e os usuários de teste da tela de consentimento."
        else -> "Não foi possível autorizar a conta. Código Google: ${code ?: "indisponível"}. Confira o cliente OAuth Android, o SHA-1 e a tela de consentimento no Google Cloud."
    }
}

@Composable fun DriveConfigDialog(accountEmail: String? = null, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val settings = remember { DriveSettings(context) }
    var key by remember { mutableStateOf(settings.apiKey()) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    fun authorized(result: AuthorizationResult) {
        busy = false
        val token = result.accessToken.orEmpty()
        if (token.isBlank()) message = "A leitura dos arquivos não foi autorizada."
        else { DriveSession.accessToken = token; DriveSession.revision++; onDismiss() }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        runCatching { Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(result.data) }
            .onSuccess(::authorized).onFailure { busy = false; message = authorizationFailure(it) }
    }
    val fingerprint = remember { installedCertificate(context).chunked(2).joinToString(":") }
    AlertDialog(onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Cloud, null) },
        title = { Text("Conectar ao Google Drive") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Cole sua chave para abrir arquivos públicos diretamente no Kepleræ.")
                OutlinedTextField(value = key, onValueChange = { key = it; message = null },
                    label = { Text("Chave de API do Drive") }, singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Ocultar" else "Mostrar") } },
                    modifier = Modifier.fillMaxWidth())
                Text("A chave fica protegida neste dispositivo e não é incluída no projeto do GitHub.",
                    style = MaterialTheme.typography.bodySmall)
                HorizontalDivider()
                Text("Arquivos privados", style = MaterialTheme.typography.titleSmall)
                Text("Autorize a leitura pela conta Google que tem acesso aos materiais. Isso não permite alterar nem excluir seus arquivos.")
                OutlinedButton(enabled = !busy, onClick = {
                    busy = true; message = null
                    val request = AuthorizationRequest.builder()
                        .apply { accountEmail?.let { setAccount(Account(it, "com.google")) } }
                        .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.readonly"))).build()
                    Identity.getAuthorizationClient(context).authorize(request)
                        .addOnSuccessListener { result ->
                            if (result.hasResolution()) {
                                val pending = result.pendingIntent
                                if (pending == null) { busy = false; message = "Não foi possível iniciar a autorização." }
                                else runCatching { launcher.launch(IntentSenderRequest.Builder(pending.intentSender).build()) }
                                    .onFailure { busy = false; message = authorizationFailure(it) }
                            } else authorized(result)
                        }
                        .addOnFailureListener {
                            busy = false
                            message = authorizationFailure(it)
                        }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Aguardando Google…" else "Autorizar conta Google") }
                if (DriveSession.accessToken.isNotBlank()) TextButton(onClick = { DriveSession.clear(); message = "Acesso ao Drive desconectado. A conta do perfil não foi alterada." }) {
                    Text("Desconectar Drive")
                }
                if (message != null) Text(message!!, color = MaterialTheme.colorScheme.error)
                Text("Cadastro da chave / OAuth", style = MaterialTheme.typography.titleSmall)
                SelectionContainer { Column {
                    Text("Pacote: ${context.packageName}", style = MaterialTheme.typography.bodySmall)
                    Text("SHA-1: $fingerprint", style = MaterialTheme.typography.bodySmall)
                } }
                Text("Se sua chave tem restrição Android, use esses dados. A autorização de arquivos privados também exige um cliente OAuth Android com esse pacote e SHA-1.",
                    style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = {
            val cleaned = key.filterNot { it.isWhitespace() || Character.getType(it) == Character.FORMAT.toInt() }
                .trim('"', '\'')
            if (cleaned.isNotEmpty() && (cleaned.length < 20 || cleaned.any { !it.isLetterOrDigit() && it != '_' && it != '-' })) {
                message = "Cole apenas o valor da chave, sem endereço, JSON ou texto adicional. Use Mostrar para conferir."
            } else runCatching { settings.saveApiKey(cleaned) }
                .onSuccess { onDismiss() }.onFailure { message = "Não foi possível salvar a chave neste aparelho." }
        }) { Text("Salvar chave") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } })
}
