package com.example.ui.productivity

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

data class ChartPoint(val label: String, val primary: Float, val secondary: Float = 0f)
fun dateLabel(time: Long, pattern: String="dd/MM HH:mm"): String=SimpleDateFormat(pattern,Locale("pt","BR")).format(Date(time))

/** Valores reais, sem dados de demonstração; descrição acessível contém todos os pontos. */
@Composable fun StudyChart(points: List<ChartPoint>, percent: Boolean=false, modifier: Modifier=Modifier,
    metricLabel: String = if(percent) "Acertos por dia" else "Acertos e erros por dia", unit: String = "acertos") {
    val primary=MaterialTheme.colorScheme.primary
    val secondary=MaterialTheme.colorScheme.error
    val grid=MaterialTheme.colorScheme.outlineVariant
    if(points.isEmpty()) { Text("Seus registros aparecerão aqui.",color=MaterialTheme.colorScheme.onSurfaceVariant);return }
    val shown=points.takeLast(14)
    val max=if(percent) 100f else shown.maxOf { it.primary+it.secondary }.coerceAtLeast(1f)
    Column(modifier) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(if(percent) "100%" else max.toInt().toString(),style=MaterialTheme.typography.labelSmall)
            Text(metricLabel,style=MaterialTheme.typography.labelSmall)
        }
        Canvas(Modifier.fillMaxWidth().height(156.dp).padding(vertical=10.dp)
            .semantics { contentDescription=shown.joinToString("; ") {
                "${it.label}: ${it.primary}${if(percent) "%" else " $unit"}" + if(!percent&&it.secondary>0) ", ${it.secondary} erros" else ""
            } }) {
            for(i in 0..4) {
                val y=size.height*i/4
                drawLine(grid,Offset(0f,y),Offset(size.width,y),1.dp.toPx())
            }
            if(percent) {
                val line=Path()
                shown.forEachIndexed { i,p ->
                    val x=if(shown.size==1) size.width/2 else size.width*i/(shown.size-1)
                    val y=size.height*(1-p.primary.coerceIn(0f,100f)/100f)
                    if(i==0) line.moveTo(x,y) else line.lineTo(x,y)
                }
                drawPath(line,primary,style=Stroke(3.dp.toPx()))
                shown.forEachIndexed { i,p ->
                    val x=if(shown.size==1) size.width/2 else size.width*i/(shown.size-1)
                    drawCircle(primary,4.dp.toPx(),Offset(x,size.height*(1-p.primary.coerceIn(0f,100f)/100f)))
                }
            } else {
                val cell=size.width/shown.size;val bar=cell*.62f
                shown.forEachIndexed { i,p ->
                    val h=size.height*p.primary/max;val e=size.height*p.secondary/max
                    val x=cell*i+(cell-bar)/2
                    drawRect(primary,Offset(x,size.height-h),Size(bar,h))
                    drawRect(secondary,Offset(x,size.height-h-e),Size(bar,e))
                }
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(shown.first().label,style=MaterialTheme.typography.labelSmall)
            Text(shown.last().label,style=MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable fun StatTile(label: String, value: String, modifier: Modifier=Modifier) {
    Card(modifier,colors=CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Text(value,style=MaterialTheme.typography.headlineSmall)
            Text(label,style=MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable fun questionSeriesColors():List<androidx.compose.ui.graphics.Color> {
    val dark=calmColors().background.luminance()<.35f
    return if(dark)listOf(androidx.compose.ui.graphics.Color(0xFF94B9F5),androidx.compose.ui.graphics.Color(0xFF82CCAB),androidx.compose.ui.graphics.Color(0xFFF0A19A))
    else listOf(androidx.compose.ui.graphics.Color(0xFF456FB4),androidx.compose.ui.graphics.Color(0xFF31735B),androidx.compose.ui.graphics.Color(0xFFB95450))
}

/** Três séries reais e acumuladas. Sem média de percentuais ou dados de demonstração. */
@Composable fun QuestionEvolutionChart(points:List<com.example.data.productivity.CumulativeQuestionDay>) {
    val c=calmColors();val colors=questionSeriesColors()
    if(points.isEmpty()) {
        Box(Modifier.fillMaxWidth().height(160.dp),contentAlignment=androidx.compose.ui.Alignment.Center) {
            Text("O gráfico começa no primeiro registro.",style=MaterialTheme.typography.bodyMedium,color=c.muted) }
        return
    }
    val shown=points.takeLast(14);val max=shown.maxOf {it.total}.coerceAtLeast(1).toFloat()
    val description=shown.joinToString("; ") { "${dateLabel(it.recordedAt,"dd/MM/yyyy")}: total ${it.total}, acertos ${it.correct}, erros ${it.wrong}" }
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("Evolução acumulada • escala 0–${shown.maxOf {it.total}}",style=MaterialTheme.typography.labelSmall,color=c.muted)
        Canvas(Modifier.fillMaxWidth().height(178.dp).padding(8.dp).semantics {contentDescription=description}) {
            for(i in 0..3) {
                val y=size.height*i/3
                drawLine(c.muted.copy(alpha=.12f),Offset(0f,y),Offset(size.width,y),1.dp.toPx()) }
            listOf<(com.example.data.productivity.CumulativeQuestionDay)->Long>({it.total},{it.correct},{it.wrong}).forEachIndexed { series,value ->
                val line=Path()
                shown.forEachIndexed { index,p ->
                    val x=if(shown.size==1)size.width/2 else size.width*index/(shown.size-1)
                    val y=size.height*(1-value(p).toFloat()/max)
                    if(index==0)line.moveTo(x,y)else line.lineTo(x,y)
                }
                drawPath(line,colors[series],style=Stroke(2.5.dp.toPx(),cap=androidx.compose.ui.graphics.StrokeCap.Round))
                shown.forEachIndexed { index,p ->
                    val x=if(shown.size==1)size.width/2 else size.width*index/(shown.size-1)
                    val y=size.height*(1-value(p).toFloat()/max)
                    drawCircle(c.surface,4.5.dp.toPx(),Offset(x,y))
                    drawCircle(colors[series],3.dp.toPx(),Offset(x,y)) }
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(dateLabel(shown.first().recordedAt,"dd/MM"),style=MaterialTheme.typography.labelSmall,color=c.muted)
            Text(dateLabel(shown.last().recordedAt,"dd/MM"),style=MaterialTheme.typography.labelSmall,color=c.muted) }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(16.dp)) {
            listOf("Total","Acertos","Erros").forEachIndexed { i,label ->
                Text("● $label",style=MaterialTheme.typography.labelMedium,color=colors[i]) }
        }
    }
}
