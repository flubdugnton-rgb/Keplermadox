@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui.productivity

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.productivity.*
import com.example.ui.components.HelpTooltip
import java.util.Locale

@Composable fun QuestionsScreen() {
    val context=LocalContext.current
    val store=remember { QuestionStore.get(context) }
    val state by store.state.collectAsStateWithLifecycle()
    val c=calmColors()
    var subjectId by rememberSaveable { mutableStateOf<String?>(null) }
    var create by rememberSaveable { mutableStateOf(false) }
    var adding by rememberSaveable { mutableStateOf(false) }
    var deleteId by remember { mutableStateOf<String?>(null) }
    var deleteSubjectId by rememberSaveable { mutableStateOf<String?>(null) }
    var confirmReset by rememberSaveable { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val records=remember(state.records,subjectId) { state.records.filter { subjectId==null||it.subjectId==subjectId } }
    val totals=remember(records) { questionTotals(records) }
    val daily=remember(records) { cumulativeQuestionDays(records) }
    val colors=questionSeriesColors()
    val title=state.subjects.firstOrNull {it.id==subjectId}?.name ?: "Todas as matérias"
    CompositionLocalProvider(LocalContentColor provides c.ink) {
        LazyColumn(Modifier.fillMaxSize().background(c.background).testTag("questions_screen"),contentPadding=PaddingValues(20.dp),
            verticalArrangement=Arrangement.spacedBy(20.dp)) {
            item {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Questões",style=MaterialTheme.typography.displaySmall)
                        Text("Cada registro conta sua evolução.",color=c.muted) }
                    FilledTonalIconButton(onClick={create=true}, modifier=Modifier.testTag("questions_new_block")) { Icon(Icons.Outlined.CreateNewFolder,"Criar bloco de matéria") }
                    Box {
                        IconButton(onClick={menu=true}, modifier=Modifier.testTag("questions_menu")) { Icon(Icons.Outlined.MoreVert,"Opções de questões") }
                        DropdownMenu(expanded=menu,onDismissRequest={menu=false}) {
                            DropdownMenuItem(text={Text("Zerar tudo",color=MaterialTheme.colorScheme.error)},
                                leadingIcon={Icon(Icons.Outlined.DeleteSweep,null)},
                                enabled=state.subjects.isNotEmpty()||state.records.isNotEmpty(),
                                onClick={menu=false;confirmReset=true},modifier=Modifier.testTag("questions_reset"))
                        }
                    }
                }
            }
            item {
                Surface(shape=RoundedCornerShape(26.dp),color=c.surface,border=BorderStroke(1.dp,c.border),shadowElevation=3.dp) {
                    LazyRow(contentPadding=PaddingValues(horizontal=10.dp,vertical=4.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        item { FilterChip(selected=subjectId==null,onClick={subjectId=null},label={Text("Geral")}) }
                        items(state.subjects,key={it.id}) { s -> FilterChip(selected=subjectId==s.id,onClick={subjectId=s.id},label={Text(s.name)}) }
                        item { AssistChip(onClick={create=true},label={Text("Nova matéria")},leadingIcon={Icon(Icons.Outlined.Add,null)}) }
                    }
                }
            }
            item {
                // Duas superfícies deslocadas reproduzem a profundidade da referência, sem números fictícios.
                Box(Modifier.fillMaxWidth().padding(bottom=14.dp)) {
                    Surface(Modifier.matchParentSize().padding(horizontal=22.dp).offset(y=14.dp),
                        shape=RoundedCornerShape(32.dp),color=c.surface.copy(alpha=.55f),shadowElevation=2.dp) {}
                    CalmCard(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {Text("Seu desempenho",style=MaterialTheme.typography.titleLarge)
                                Text(title,style=MaterialTheme.typography.bodySmall,color=c.muted)}
                            HelpTooltip("Como calculamos","Taxa = soma de acertos ÷ soma de questões × 100. As três curvas mostram os totais acumulados por dia. O filtro é aplicado a todos os cartões, curvas e registros.") }
                        HorizontalDivider(color=c.border)
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            DashboardMetric("Questões",totals.total,colors[0],Modifier.weight(1f))
                            DashboardMetric("Acertos",totals.correct,colors[1],Modifier.weight(1f))
                            DashboardMetric("Erros",totals.wrong,colors[2],Modifier.weight(1f)) }
                        QuestionEvolutionChart(daily)
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                            Text("${records.size} registros • ${daily.size} dias",style=MaterialTheme.typography.labelMedium,color=c.muted)
                            Text("Acerto: ${if(totals.total==0L)"—" else String.format(Locale("pt","BR"),"%.1f%%",totals.accuracy)}",
                                style=MaterialTheme.typography.labelLarge,color=colors[1]) }
                    }
                }
            }
            item {
                FilledTonalButton(onClick={if(state.subjects.isEmpty())create=true else adding=true},
                    modifier=Modifier.fillMaxWidth().heightIn(min=56.dp),
                    colors=ButtonDefaults.filledTonalButtonColors(containerColor=c.lilac,contentColor=c.ink)) {
                    Icon(Icons.Outlined.Calculate,null);Spacer(Modifier.width(8.dp));Text("Registrar e calcular") }
            }
            if(state.subjects.isNotEmpty()) {
                item {Text("Seus blocos",style=MaterialTheme.typography.headlineSmall)}
                items(state.subjects.chunked(2),key={it.first().id}) { pair ->
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        pair.forEachIndexed { index,s ->
                            val t=questionTotals(state.records.filter {it.subjectId==s.id})
                            Card(onClick={subjectId=s.id},modifier=Modifier.weight(1f),shape=RoundedCornerShape(28.dp),
                                colors=CardDefaults.cardColors(containerColor=if(index==0)c.sky else c.mint,contentColor=c.ink),
                                border=if(subjectId==s.id)BorderStroke(2.dp,c.accent)else null) {
                                Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                                        Icon(Icons.Outlined.Folder,null,tint=c.accent)
                                        Spacer(Modifier.weight(1f))
                                        IconButton(onClick={deleteSubjectId=s.id}, modifier=Modifier.testTag("delete_block_${s.id}")) {
                                            Icon(Icons.Outlined.DeleteOutline,"Apagar bloco ${s.name}",tint=c.muted)
                                        }
                                    }
                                    Text(s.name,style=MaterialTheme.typography.titleMedium)
                                    Text("${t.total} questões",style=MaterialTheme.typography.bodySmall,color=c.muted)
                                    Text(if(t.total==0L)"Sem registros" else String.format(Locale("pt","BR"),"%.1f%% de acerto",t.accuracy),
                                        style=MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                        if(pair.size==1)Spacer(Modifier.weight(1f))
                    }
                }
            }
            item {Text("Histórico",style=MaterialTheme.typography.headlineSmall)}
            if(records.isEmpty()) item {CalmCard(Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Insights,null,tint=c.accent)
                Text("Seu próximo passo começa aqui.",style=MaterialTheme.typography.titleMedium)
                Text("Crie uma matéria e registre sua primeira sessão de questões.",color=c.muted) } }
            items(records.sortedByDescending {it.recordedAt},key={it.id}) { r ->
                val name=state.subjects.firstOrNull {it.id==r.subjectId}?.name ?: "Matéria"
                val percent=100.0*r.correct/(r.correct.toLong()+r.wrong)
                CalmCard(Modifier.fillMaxWidth().animateItem()) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                            Text(name,style=MaterialTheme.typography.titleMedium)
                            Text(dateLabel(r.recordedAt),style=MaterialTheme.typography.labelMedium,color=c.muted)
                            Text("${r.correct} acertos • ${r.wrong} erros • ${String.format(Locale("pt","BR"),"%.1f%%",percent)}") }
                        IconButton(onClick={deleteId=r.id}) {Icon(Icons.Outlined.DeleteOutline,"Excluir registro")}
                    }
                }
            }
        }
    }
    if(create) {
        var name by rememberSaveable { mutableStateOf("") };var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(onDismissRequest={create=false},icon={Icon(Icons.Outlined.CreateNewFolder,null)},title={Text("Nova matéria")},
            text={Column { OutlinedTextField(name,{name=it.take(80);error=null},label={Text("Nome do bloco")},singleLine=true)
                error?.let { Text(it,color=MaterialTheme.colorScheme.error) } }},
            confirmButton={TextButton(onClick={runCatching { store.createSubject(name) }.onSuccess { subjectId=it;create=false }
                .onFailure { error=it.message }}) {Text("Criar")}},dismissButton={TextButton(onClick={create=false}) {Text("Cancelar")}})
    }
    if(adding) {
        var chosen by rememberSaveable { mutableStateOf(subjectId ?: state.subjects.first().id) }
        var correct by rememberSaveable { mutableStateOf("") };var wrong by rememberSaveable { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(onDismissRequest={adding=false},icon={Icon(Icons.Outlined.Calculate,null)},title={Text("Registrar questões")},
            text={Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
                LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)) { items(state.subjects) { s ->
                    FilterChip(selected=chosen==s.id,onClick={chosen=s.id},label={Text(s.name)}) } }
                OutlinedTextField(correct,{correct=it.take(7);error=null},label={Text("Acertos")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                OutlinedTextField(wrong,{wrong=it.take(7);error=null},label={Text("Erros")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                Text("Data: ${dateLabel(System.currentTimeMillis())}",style=MaterialTheme.typography.bodySmall)
                error?.let { Text(it,color=MaterialTheme.colorScheme.error) }
            }},confirmButton={TextButton(onClick={
                val c=correct.toIntOrNull();val w=wrong.toIntOrNull()
                if(!validQuestionCounts(c,w)) error="Use inteiros de 0 a 1.000.000. O total deve ser maior que zero."
                else { store.add(chosen,c!!,w!!);adding=false }
            }) {Text("Calcular e salvar")}},dismissButton={TextButton(onClick={adding=false}) {Text("Cancelar")}})
    }
    if(deleteId!=null) AlertDialog(onDismissRequest={deleteId=null},icon={Icon(Icons.Outlined.DeleteOutline,null)},
        title={Text("Excluir este registro?")},text={Text("Os totais e os gráficos serão recalculados.")},
        confirmButton={TextButton(onClick={store.deleteRecord(deleteId!!);deleteId=null}) {Text("Excluir")}},
        dismissButton={TextButton(onClick={deleteId=null}) {Text("Cancelar")}})
    deleteSubjectId?.let { id ->
        val block=state.subjects.firstOrNull { it.id==id }
        val count=state.records.count { it.subjectId==id }
        AlertDialog(onDismissRequest={deleteSubjectId=null},icon={Icon(Icons.Outlined.DeleteOutline,null)},
            title={Text("Apagar ${block?.name ?: "bloco"}?")},
            text={Text("O bloco e seus $count registros serão apagados. Os totais e gráficos serão recalculados. Essa ação não pode ser desfeita.")},
            confirmButton={TextButton(onClick={store.deleteSubject(id);if(subjectId==id)subjectId=null;deleteSubjectId=null},
                modifier=Modifier.testTag("confirm_delete_block")) {Text("Apagar bloco")}},
            dismissButton={TextButton(onClick={deleteSubjectId=null}) {Text("Cancelar")}})
    }
    if(confirmReset) AlertDialog(onDismissRequest={confirmReset=false},icon={Icon(Icons.Outlined.DeleteSweep,null)},
        title={Text("Zerar todas as questões?")},
        text={Text("Todos os blocos e registros de questões serão apagados. Esta ação não pode ser desfeita. Materiais, notas e Pomodoro permanecem salvos.")},
        confirmButton={TextButton(onClick={store.resetAll();subjectId=null;confirmReset=false},
            modifier=Modifier.testTag("confirm_reset_questions")) {Text("Zerar tudo")}},
        dismissButton={TextButton(onClick={confirmReset=false}) {Text("Cancelar")}})
}

@Composable private fun DashboardMetric(label:String,value:Long,color:Color,modifier:Modifier) {
    val c=calmColors()
    Column(modifier,verticalArrangement=Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(color,RoundedCornerShape(50)));Spacer(Modifier.width(5.dp))
            Text(label,style=MaterialTheme.typography.labelMedium,color=c.muted) }
        Text(value.toString(),style=MaterialTheme.typography.headlineSmall,maxLines=1)
    }
}
