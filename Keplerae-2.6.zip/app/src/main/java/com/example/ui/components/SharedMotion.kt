@file:OptIn(androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui.components

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect

/** Escopos vêm do mesmo AnimatedContent; chaves são estáveis nos dois destinos. */
@Immutable data class SharedMotion(
    val shared: SharedTransitionScope,
    val animated: AnimatedVisibilityScope,
    val scope: String = "",
) {
    private fun k(key: String) = if (scope.isEmpty()) key else "$scope/$key"
    @Composable fun element(key: String): Modifier = with(shared) {
        Modifier.sharedElement(rememberSharedContentState(k(key)), animatedVisibilityScope = animated,
            boundsTransform = { _, _ -> spring<Rect>(dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessLow) })
    }
    @Composable fun bounds(key: String): Modifier = with(shared) {
        Modifier.sharedBounds(rememberSharedContentState(k(key)), animatedVisibilityScope = animated,
            boundsTransform = { _, _ -> spring<Rect>(dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessLow) })
    }
}
