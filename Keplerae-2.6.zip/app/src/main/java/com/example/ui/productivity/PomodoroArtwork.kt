package com.example.ui.productivity

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.painterResource
import com.example.R
import kotlin.math.*

/** Cena em camadas: a vara pertence à arte; linha, estrela e partículas são animadas. */
@Composable fun PomodoroArtwork(active: Boolean, modifier: Modifier=Modifier) {
    val c=calmColors()
    val dark=c.background.luminance()<.35f
    val loop=rememberInfiniteTransition(label="cosmic_scene")
    val phase by loop.animateFloat(0f,(2*PI).toFloat(),infiniteRepeatable(tween(6000,easing=LinearEasing)),label="fishing_motion")
    val orbit by loop.animateFloat(0f,(2*PI).toFloat(),infiniteRepeatable(tween(18000,easing=LinearEasing)),label="saturn_ring")
    val meteor by loop.animateFloat(0f,1f,infiniteRepeatable(tween(11000,easing=LinearEasing)),label="shooting_star")
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            repeat(28) { i ->
                val x=size.width*((i*37%97+1)/100f)
                val y=size.height*((i*29%89+3)/100f)+sin(orbit+i)*5.dp.toPx()
                val alpha=if(dark).58f+.25f*sin(phase+i)else .72f+.20f*sin(phase+i)
                val color=if(dark)Color(0xFFC2DCCE)else if(i%3==0)Color(0xFF586541)else c.accent
                val p=Offset(x,y)
                if(i%4==0) {
                    val r=(2+i%3).dp.toPx()
                    drawLine(color.copy(alpha=alpha),p-Offset(r,0f),p+Offset(r,0f),1.4.dp.toPx())
                    drawLine(color.copy(alpha=alpha),p-Offset(0f,r),p+Offset(0f,r),1.4.dp.toPx())
                } else drawCircle(color.copy(alpha=alpha),(1.2f+i%2).dp.toPx(),p)
            }
            // Uma passagem curta, seguida de vários segundos de céu tranquilo.
            if(active&&meteor<.12f) {
                val t=meteor/.12f
                val head=Offset(size.width*(.08f+.72f*t),size.height*(.07f+.20f*t))
                val tail=head-Offset(size.width*.13f,size.height*.036f)
                val color=if(dark)Color(0xFFEDE4BB)else Color(0xFF72623F)
                drawLine(Brush.linearGradient(listOf(Color.Transparent,color),tail,head),tail,head,2.dp.toPx(),StrokeCap.Round)
                drawCircle(color,2.5.dp.toPx(),head)
            }
        }
        Crossfade(active,Modifier.fillMaxSize(),label="tomato_scene") { fishing ->
            Box(Modifier.fillMaxSize().graphicsLayer {
                if(fishing) {translationY=sin(phase)*5.dp.toPx();rotationZ=sin(phase)*1.2f}
            }) {
                Image(painterResource(if(fishing)R.drawable.pomo_fishing else R.drawable.pomo_rest),
                    if(fishing)"Tomate astronauta pescando estrelas" else "Tomate astronauta descansando em Saturno",
                    Modifier.fillMaxSize(),contentScale=ContentScale.Fit)
                Canvas(Modifier.fillMaxSize()) {
                    // ContentScale.Fit para as duas artes 1536 × 1024. Mantém as âncoras em qualquer tela.
                    val w=min(size.width,size.height*1.5f);val h=w/1.5f
                    val left=(size.width-w)/2;val top=(size.height-h)/2
                    fun point(x:Float,y:Float)=Offset(left+x*w,top+y*h)
                    if(fishing) {
                        val tip=point(.741f,.107f)
                        val catch=point(.785f+sin(phase)*.014f,.39f+sin(phase)*.072f)
                        val line=Path().apply {
                            moveTo(tip.x,tip.y)
                            quadraticBezierTo(tip.x+w*.03f,catch.y-h*.09f,catch.x,catch.y)
                        }
                        drawPath(line,if(dark)Color(0xFFE7D399)else Color(0xFF887445),style=Stroke(1.4.dp.toPx()))
                        val radius=w*.042f
                        drawCircle(Color(0xFFFFC966).copy(alpha=.15f),radius*1.8f,catch)
                        drawCircle(Color(0xFFFFD37C).copy(alpha=.22f),radius*1.3f,catch)
                        val star=Path()
                        repeat(10) { i ->
                            val a=-PI/2+i*PI/5;val r=if(i%2==0)radius else radius*.47f
                            val x=catch.x+cos(a).toFloat()*r;val y=catch.y+sin(a).toFloat()*r
                            if(i==0)star.moveTo(x,y)else star.lineTo(x,y)
                        }
                        star.close();drawPath(star,Color(0xFFFFD777))
                        drawPath(star,Color(0xFFB58A36),style=Stroke(1.dp.toPx()))
                    } else {
                        // Reflexos percorrem os anéis; o personagem continua descansando.
                        rotate(-19f,point(.51f,.60f)) {
                            repeat(9) { i ->
                                val a=orbit+i*(2*PI/9).toFloat()
                                val p=point(.51f+cos(a)*.34f,.60f+sin(a)*.10f)
                                val col=if(i%3==0)Color(0xFF788657)else if(dark)Color(0xFFC7ECDA)else Color(0xFF72628B)
                                drawCircle(col.copy(alpha=.5f),2.8.dp.toPx(),p)
                                drawCircle(col.copy(alpha=.16f),5.dp.toPx(),p)
                            }
                        }
                    }
                }
            }
        }
    }
}
