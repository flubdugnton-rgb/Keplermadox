package com.example.ui.profile

import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics

internal fun Modifier.themeSemantics(dark: Boolean, isSelected: Boolean): Modifier = semantics {
    contentDescription = if (dark) "Tema escuro" else "Tema claro"
    selected = isSelected
}
