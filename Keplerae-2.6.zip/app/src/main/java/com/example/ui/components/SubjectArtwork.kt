package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

fun subjectPalette(id: String, dark: Boolean): Pair<Color, Color> {
    val colors = when (id) {
        "fisioterapia" -> listOf(0xFFD0F4E6, 0xFF064F3C, 0xFF173D33, 0xFFAFF0D5)
        "portugues" -> listOf(0xFFFFDFEB, 0xFF70324C, 0xFF4C2638, 0xFFFFB2D0)
        "matematica" -> listOf(0xFFDBE6FF, 0xFF274777, 0xFF23344F, 0xFFB6CEFF)
        "hu_legislacao" -> listOf(0xFFFFE8CA, 0xFF654512, 0xFF49351C, 0xFFF5D49D)
        "sus" -> listOf(0xFFE1EFC4, 0xFF3C4E17, 0xFF303D1B, 0xFFD4E9AA)
        else -> listOf(0xFFEBDFFF, 0xFF533777, 0xFF3D2C50, 0xFFE0C3FF)
    }
    return if (dark) Color(colors[2]) to Color(colors[3]) else Color(colors[0]) to Color(colors[1])
}

/** Ilustrações nativas: não dependem de imagens de terceiros nem de conexão. */
@Composable fun SubjectArtwork(id: String, tint: Color, modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension * .24f
            rotate(-12f) {
                repeat(6) { n ->
                    val angle = n * PI / 3
                    val p = center + Offset((cos(angle) * r).toFloat(), (sin(angle) * r).toFloat())
                    drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = .22f), tint.copy(alpha = .07f)),
                        center = p, radius = r), r, p)
                }
            }
            drawCircle(Color.White.copy(alpha = .20f), r * 1.12f, center - Offset(r * .15f, r * .17f))
        }
        Icon(when (id) {
            "fisioterapia" -> Icons.Outlined.AccessibilityNew
            "portugues" -> Icons.AutoMirrored.Outlined.MenuBook
            "matematica" -> Icons.Outlined.Functions
            "hu_legislacao" -> Icons.Outlined.Balance
            "sus" -> Icons.Outlined.HealthAndSafety
            else -> Icons.Outlined.Psychology
        }, null, Modifier.size(44.dp), tint = tint)
    }
}
