@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.ui.Destination

val MainDestinations = listOf(Destination.HOME, Destination.SUBJECTS,
    Destination.POMODORO, Destination.QUESTIONS, Destination.NOTES)

/** Cápsula Expressive em qualquer largura; os formatos continuam nos filtros de Matérias. */
@Composable fun FloatingAppNavigation(current: Destination, onNavigate: (Destination) -> Unit) {
    var expanded by rememberSaveable { mutableStateOf(true) }
    val active = current.takeIf { it in MainDestinations } ?: Destination.SUBJECTS
    BoxWithConstraints(Modifier.fillMaxWidth().navigationBarsPadding()
        .padding(horizontal = 8.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
        val labels = maxWidth >= 480.dp
        HorizontalFloatingToolbar(expanded = expanded,
            modifier = Modifier.testTag("floating_navigation").selectableGroup(),
            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
            leadingContent = {
                MainDestinations.takeWhile { it != active }.forEach { destination ->
                    DestinationButton(destination, false, labels) { onNavigate(destination) }
                }
            },
            trailingContent = {
                MainDestinations.dropWhile { it != active }.drop(1).forEach { destination ->
                    DestinationButton(destination, false, labels) { onNavigate(destination) }
                }
            }) {
            DestinationButton(active, true, labels) { onNavigate(active) }
            IconButton(onClick = { expanded = !expanded }, modifier = Modifier.size(48.dp)
                .testTag("navigation_expand")) {
                Icon(if (expanded) Icons.Outlined.ChevronLeft else Icons.Outlined.ChevronRight,
                    if (expanded) "Recolher navegação" else "Expandir navegação")
            }
        }
    }
}

@Composable private fun DestinationButton(destination: Destination, chosen: Boolean,
    labels: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = MaterialTheme.shapes.extraLarge,
        color = if (chosen) MaterialTheme.colorScheme.secondaryContainer
            else androidx.compose.ui.graphics.Color.Transparent,
        contentColor = if (chosen) MaterialTheme.colorScheme.onSecondaryContainer
            else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.width(if (labels) 68.dp else 48.dp).height(if (labels) 64.dp else 48.dp)
            .testTag("nav_${destination.name}").semantics { role = Role.Tab; selected = chosen }) {
        Column(horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Icon(destination.icon, destination.title, Modifier.size(24.dp))
            if (labels) Text(destination.title, style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 3.dp), maxLines = 1)
        }
    }
}
