@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui

import android.view.ViewGroup
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.data.playback.PlaybackService
import com.example.ui.components.LoadingPane
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.*
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.example.data.drive.*
import com.example.data.model.ContentType
import com.example.data.model.StudyItem
import com.example.ui.components.HelpTooltip
import kotlinx.coroutines.delay

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable fun NativeMedia(item: StudyItem, file: DriveFile, repository: DriveRepository,
    modifier: Modifier = Modifier, onConfigure: () -> Unit,
    playlist: List<StudyItem> = emptyList(), autoPlay: Boolean = false,
    onSelectTrack: (StudyItem) -> Unit = {}) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val preferences = remember { context.getSharedPreferences("keplerae_playback", 0) }
    var failure by remember(file.id, repository) { mutableStateOf<String?>(null) }
    var buffering by remember(file.id, repository) { mutableStateOf(true) }
    var playing by remember(file.id, repository) { mutableStateOf(false) }
    var position by remember(file.id) { mutableLongStateOf(0L) }
    var duration by remember(file.id) { mutableLongStateOf(0L) }
    var speed by remember(file.id) { mutableFloatStateOf(1f) }
    val audio = item.type == ContentType.AUDIO
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var connectionError by remember { mutableStateOf<String?>(null) }
    DisposableEffect(audio) {
        if (audio) {
            val future = MediaController.Builder(context,
                SessionToken(context, ComponentName(context, PlaybackService::class.java))).buildAsync()
            var disposed = false
            future.addListener({
                if (!disposed) runCatching { future.get() }.onSuccess { controller = it }
                    .onFailure { connectionError = "Não foi possível conectar ao serviço de áudio. Abra novamente o material." }
            }, ContextCompat.getMainExecutor(context))
            onDispose { disposed = true; controller = null; MediaController.releaseFuture(future) }
        } else onDispose { }
    }
    val videoPlayer = remember(file.id, repository, audio) {
        if (audio) null else {
            val dataSource = DefaultHttpDataSource.Factory().setConnectTimeoutMs(15000).setReadTimeoutMs(30000)
                .setDefaultRequestProperties(repository.headers(file.id, file.resourceKey))
            ExoPlayer.Builder(context).setMediaSourceFactory(DefaultMediaSourceFactory(dataSource))
                .setSeekBackIncrementMs(10000).setSeekForwardIncrementMs(10000).build().apply {
                    setAudioAttributes(AudioAttributes.DEFAULT, true); setHandleAudioBecomingNoisy(true)
                    setMediaItem(MediaItem.Builder().setMediaId(file.id).setUri(DriveRequests.file(file.id, true))
                        .setMimeType(file.mimeType).setMediaMetadata(MediaMetadata.Builder().setTitle(item.title).build()).build())
                    seekTo(preferences.getLong(file.id, 0).coerceAtLeast(0)); playWhenReady = autoPlay
                }
        }
    }
    val player: Player? = if (audio) controller else videoPlayer
    val tracks = remember(playlist, item, file) {
        val current = item.copy(driveFileId = file.id)
        (playlist.map { if (it.id == item.id) current else it } + current)
            .filter { it.driveFileId.isNotBlank() }.distinctBy { it.driveFileId }
    }
    val trackCallback by rememberUpdatedState(onSelectTrack)
    val activeMediaId by rememberUpdatedState(file.id)
    LaunchedEffect(controller, audio, file.id, tracks) {
        val c = controller ?: return@LaunchedEffect
        if (!audio) return@LaunchedEffect
        val existing = c.currentMediaItem?.mediaId == file.id
        val expectedIds = tracks.map { it.driveFileId }
        val actualIds = (0 until c.mediaItemCount).map { c.getMediaItemAt(it).mediaId }
        if (!existing || actualIds != expectedIds) {
            val resumeAt = if (existing) c.currentPosition else preferences.getLong(file.id, 0).coerceAtLeast(0)
            val resumePlaying = if (existing) c.playWhenReady else autoPlay
            val selectedIndex = tracks.indexOfFirst { it.driveFileId == file.id }.coerceAtLeast(0)
            val queue = tracks.map { track ->
                val resourceKey = if (track.driveFileId == file.id) file.resourceKey else DriveRequests.resourceKey(track.url)
                MediaItem.Builder().setMediaId(track.driveFileId).setUri(DriveRequests.file(track.driveFileId, true))
                    .setCustomCacheKey("${track.driveFileId}|$resourceKey")
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(track.title).setArtist("Kepleræ • ${track.subjectId}").build()).build()
            }
            c.setMediaItems(queue, selectedIndex, resumeAt)
            c.prepare(); c.playWhenReady = resumePlaying
        }
        speed = c.playbackParameters.speed
    }
    DisposableEffect(player, lifecycle, audio, file.id, repository) {
        val connected = player
        if (connected == null) onDispose { }
        else {
            val listener = object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
                override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    if (audio && mediaItem?.mediaId != activeMediaId) {
                        tracks.firstOrNull { it.driveFileId == mediaItem?.mediaId }?.let(trackCallback)
                    }
                }
                override fun onPlayerError(error: PlaybackException) {
                    buffering = false
                    val http = generateSequence<Throwable>(error) { it.cause }
                        .filterIsInstance<HttpDataSource.InvalidResponseCodeException>().firstOrNull()
                    failure = if (http != null) DriveRequests.errorMessage(http.responseCode,
                        DriveRequests.errorReason(String(http.responseBody, Charsets.UTF_8)))
                    else when (error.errorCode) {
                        PlaybackException.ERROR_CODE_DECODING_FAILED, PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ->
                            "Este aparelho não conseguiu decodificar o formato do arquivo."
                        else -> "Não foi possível reproduzir. Confira a conexão e as permissões no Drive."
                    }
                }
            }
            fun savePosition() {
                val id = connected.currentMediaItem?.mediaId?.takeIf { it.isNotBlank() } ?: file.id
                preferences.edit().putLong(id,
                    if (connected.playbackState == Player.STATE_ENDED) 0 else connected.currentPosition.coerceAtLeast(0)).apply()
            }
            val observer = LifecycleEventObserver { _, event ->
                if (!audio && event == Lifecycle.Event.ON_STOP) { connected.pause(); savePosition() }
            }
            connected.addListener(listener)
            playing = connected.isPlaying; buffering = connected.playbackState == Player.STATE_BUFFERING
            connected.playerError?.let(listener::onPlayerError)
            lifecycle.addObserver(observer)
            if (!audio) connected.prepare()
            onDispose {
                savePosition(); lifecycle.removeObserver(observer); connected.removeListener(listener)
                if (!audio) connected.release()
            }
        }
    }
    if (player == null) {
        if (connectionError == null) LoadingPane("Conectando ao áudio…", modifier)
        else Text(connectionError!!, modifier.padding(24.dp), color = MaterialTheme.colorScheme.error)
        return
    }
    // Valores vêm do ExoPlayer. Não há timer simulando porcentagens de reprodução.
    LaunchedEffect(player) {
        var lastSaved = 0L
        while (true) {
            position = player.currentPosition.coerceAtLeast(0)
            duration = player.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L
            if (!audio && player.isPlaying && kotlin.math.abs(position - lastSaved) >= 5000L) {
                preferences.edit().putLong(file.id, position).apply(); lastSaved = position
            }
            delay(250L)
        }
    }
    fun playPause() {
        if (player.isPlaying) player.pause() else {
            if (player.playbackState == Player.STATE_IDLE || player.playerError != null) player.prepare()
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.play()
        }
    }
    Column(modifier.fillMaxSize()) {
        if (item.type == ContentType.AUDIO) {
            AudioScreen(item, playlist, playing, buffering, position, duration,
                onPlayPause = ::playPause,
                onSeek = { player.seekTo(it); position = it }, onSelectTrack = { track ->
                    val index = (0 until player.mediaItemCount).firstOrNull { player.getMediaItemAt(it).mediaId == track.driveFileId }
                    if (index != null) { player.seekToDefaultPosition(index); player.play() } else onSelectTrack(track)
                },
                modifier = Modifier.fillMaxWidth().weight(1f))
        } else {
            Box(Modifier.fillMaxWidth().weight(1f).heightIn(min = 100.dp)
                .clip(MaterialTheme.shapes.extraLarge).background(Color.Black), contentAlignment = Alignment.Center) {
                AndroidView(factory = { ctx -> PlayerView(ctx).also { it.player = player }.apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    setEnableComposeSurfaceSyncWorkaround(true)
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                    setShowNextButton(false); setShowPreviousButton(false)
                    setShowFastForwardButton(true); setShowRewindButton(true)
                    controllerShowTimeoutMs = 5000; controllerAutoShow = true; showController()
                } }, update = { it.player = player }, modifier = Modifier.fillMaxSize())
                if (buffering) CircularWavyProgressIndicator(Modifier.size(48.dp), color = Color.White)
            }
            LinearWavyProgressIndicator(progress = { if (duration <= 0) 0f else (position.toFloat() / duration).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp))
        }
        LazyRow(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(vertical = 4.dp)) {
            items(listOf(.75f, 1f, 1.25f, 1.5f, 2f)) { rate ->
                FilterChip(selected = speed == rate, onClick = { speed = rate; player.setPlaybackSpeed(rate) },
                    label = { Text("${rate}×") })
            }
        }
        if (failure != null) {
            Text(failure!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp))
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { failure = null; buffering = true; player.prepare() }) { Text("Tentar novamente") }
                OutlinedButton(onClick = onConfigure) { Text("Configurar Drive") }
            }
        }
    }
}

@Composable private fun AudioScreen(item: StudyItem, playlist: List<StudyItem>, playing: Boolean,
    buffering: Boolean, position: Long, duration: Long, onPlayPause: () -> Unit,
    onSeek: (Long) -> Unit, onSelectTrack: (StudyItem) -> Unit, modifier: Modifier) {
    val tracks = remember(playlist, item) { (playlist + item).distinctBy { it.driveFileId.ifBlank { it.id } } }
    val current = tracks.indexOfFirst { it.driveFileId == item.driveFileId && it.driveFileId.isNotBlank() || it.id == item.id }
    var scrub by remember(item.id) { mutableStateOf<Float?>(null) }
    BoxWithConstraints(modifier) {
        val compact = maxHeight < 480.dp
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            item {
                Box(Modifier.size(if (compact) 88.dp else 148.dp).clip(MaterialTheme.shapes.extraLarge)
                    .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer,
                        MaterialTheme.colorScheme.tertiaryContainer))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.Headphones, null, Modifier.size(if (compact) 48.dp else 72.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            item {
                Text(item.title, style = MaterialTheme.typography.headlineSmall)
                Text("Sua escuta, no seu ritmo.", style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
            }
            item {
                Column(Modifier.fillMaxWidth()) {
                    val realProgress = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
                    LinearWavyProgressIndicator(progress = { scrub ?: realProgress }, modifier = Modifier.fillMaxWidth())
                    Slider(value = scrub ?: realProgress, onValueChange = { scrub = it },
                        enabled = duration > 0, onValueChangeFinished = {
                            scrub?.let { onSeek((duration * it).toLong()) }; scrub = null
                        }, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(mediaTime(if (scrub == null) position else (duration * scrub!!).toLong()), style = MaterialTheme.typography.labelMedium)
                        Text(mediaTime(duration), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    IconButton(onClick = { tracks.getOrNull(current - 1)?.let(onSelectTrack) }, enabled = current > 0) {
                        Icon(Icons.Filled.SkipPrevious, "Faixa anterior", Modifier.size(30.dp))
                    }
                    FilledIconButton(onClick = onPlayPause, modifier = Modifier.size(72.dp), shape = CircleShape) {
                        if (buffering) CircularWavyProgressIndicator(Modifier.size(32.dp),
                            color = MaterialTheme.colorScheme.onPrimary)
                        else Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            if (playing) "Pausar" else "Reproduzir", Modifier.size(36.dp))
                    }
                    IconButton(onClick = { tracks.getOrNull(current + 1)?.let(onSelectTrack) },
                        enabled = current >= 0 && current < tracks.lastIndex) {
                        Icon(Icons.Filled.SkipNext, "Próxima faixa", Modifier.size(30.dp))
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Lista de faixas", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    HelpTooltip("Sua reprodução", "A barra acompanha o áudio real. Arraste para avançar ou voltar. " +
                        "O áudio continua com a tela bloqueada. Controle também pela notificação, incluindo próxima e anterior.")
                }
            }
            items(tracks, key = { it.id }) { track ->
                val selected = track.driveFileId == item.driveFileId && track.driveFileId.isNotBlank() || track.id == item.id
                Surface(onClick = { if (!selected) onSelectTrack(track) else onPlayPause() },
                    modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large,
                    color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerLow) {
                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (selected && playing) Icons.Outlined.GraphicEq else Icons.Outlined.MusicNote, null)
                        Column(Modifier.weight(1f)) {
                            Text(track.title, style = MaterialTheme.typography.titleMedium)
                            if (selected) Text(if (playing) "Reproduzindo" else "Selecionada", style = MaterialTheme.typography.labelSmall)
                        }
                        Icon(if (selected && playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                    }
                }
            }
        }
    }
}

internal fun mediaTime(milliseconds: Long): String {
    val total = milliseconds.coerceAtLeast(0) / 1000
    return if (total >= 3600) "%d:%02d:%02d".format(java.util.Locale.ROOT, total / 3600, total / 60 % 60, total % 60)
    else "%d:%02d".format(java.util.Locale.ROOT, total / 60, total % 60)
}
