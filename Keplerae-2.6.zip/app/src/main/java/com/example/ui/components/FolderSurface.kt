package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

data class FolderTone(val top: Color, val bottom: Color, val ink: Color, val accent: Color)

/** Superfícies claras de vidro colorido; no escuro, tons profundos e progresso luminoso. */
fun folderTone(id: String, dark: Boolean): FolderTone {
    val names = listOf("fisioterapia", "portugues", "matematica", "hu_legislacao", "sus", "profisio")
    val index = names.indexOf(id).takeIf { it >= 0 }
        ?: ((id.hashCode().toLong().and(0x7fffffff)) % 6).toInt()
    val light = listOf(
        FolderTone(Color(0xFFE0F5EE), Color(0xFFB5D8CA), Color(0xFF174B3F), Color(0xFF166D58)),
        FolderTone(Color(0xFFFFE8F1), Color(0xFFEDB8D3), Color(0xFF662C4C), Color(0xFFA42765)),
        FolderTone(Color(0xFFDCEBFF), Color(0xFFA6C0E8), Color(0xFF263F69), Color(0xFF285CAF)),
        FolderTone(Color(0xFFFFECDC), Color(0xFFDBB993), Color(0xFF613C17), Color(0xFF986022)),
        FolderTone(Color(0xFFEBF3D9), Color(0xFFBECD94), Color(0xFF3F501F), Color(0xFF577223)),
        FolderTone(Color(0xFFEBE1FF), Color(0xFFC2AFE9), Color(0xFF473268), Color(0xFF7050AC))
    )
    val night = listOf(
        FolderTone(Color(0xFF223C37), Color(0xFF0E2520), Color(0xFFD5F5E8), Color(0xFF49D9AA)),
        FolderTone(Color(0xFF4A263C), Color(0xFF2E1027), Color(0xFFFFDFED), Color(0xFFF478B2)),
        FolderTone(Color(0xFF263B5C), Color(0xFF10213E), Color(0xFFDDEAFF), Color(0xFF70B3FF)),
        FolderTone(Color(0xFF4C3424), Color(0xFF301C0C), Color(0xFFFFE3C4), Color(0xFFFFAB59)),
        FolderTone(Color(0xFF354128), Color(0xFF1A2711), Color(0xFFE4EFCE), Color(0xFFB4D56C)),
        FolderTone(Color(0xFF382951), Color(0xFF211136), Color(0xFFEEE1FF), Color(0xFFC092FF))
    )
    return (if (dark) night else light)[index]
}

@Composable fun FolderSurface(tone: FolderTone, modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null, interactionSource: MutableInteractionSource? = null, content: @Composable BoxScope.() -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    val border = BorderStroke(1.dp, tone.ink.copy(alpha = .12f))
    val body: @Composable () -> Unit = {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(tone.top, tone.bottom))), content = content)
    }
    if (onClick == null) Surface(modifier, shape = shape, color = Color.Transparent,
        contentColor = tone.ink, border = border, shadowElevation = 2.dp, content = body)
    else Surface(onClick = onClick, interactionSource = interactionSource, modifier = modifier, shape = shape, color = Color.Transparent,
        contentColor = tone.ink, border = border, shadowElevation = 2.dp, content = body)
}
