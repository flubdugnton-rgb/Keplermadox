@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** O mesmo indicador Expressive atende carregamento inicial e atualização por gesto. */
@Composable fun ExpressiveRefreshBox(refreshing: Boolean, onRefresh: () -> Unit,
    modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val pullState = rememberPullToRefreshState()
    PullToRefreshBox(isRefreshing = refreshing, onRefresh = onRefresh, state = pullState,
        modifier = modifier, indicator = {
            PullToRefreshDefaults.LoadingIndicator(state = pullState, isRefreshing = refreshing,
                modifier = Modifier.align(Alignment.TopCenter))
        }, content = content)
}

@Composable fun LoadingPane(label: String, modifier: Modifier = Modifier,
    progress: Float? = null) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        LoadingIndicator(Modifier.size(64.dp))
        Spacer(Modifier.height(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
        if (progress != null) {
            Spacer(Modifier.height(20.dp))
            LinearWavyProgressIndicator(progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.widthIn(max = 360.dp).fillMaxWidth())
            Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 8.dp))
        }
    }
}

/** Exibição manual: o clique chama show(), sem depender de pressionar e segurar. */
@Composable fun HelpTooltip(title: String, detail: String, modifier: Modifier = Modifier) {
    val state = rememberTooltipState(isPersistent = true)
    val scope = rememberCoroutineScope()
    TooltipBox(positionProvider = TooltipDefaults.rememberRichTooltipPositionProvider(),
        state = state, enableUserInput = false, tooltip = {
            RichTooltip(title = { Text(title) }, action = {
                TextButton(onClick = { state.dismiss() }) { Text("Entendi") }
            }) { Text(detail) }
        }) {
        IconButton(onClick = { scope.launch { state.show() } }, modifier = modifier) {
            Icon(Icons.Outlined.Info, "Ajuda: $title")
        }
    }
}
