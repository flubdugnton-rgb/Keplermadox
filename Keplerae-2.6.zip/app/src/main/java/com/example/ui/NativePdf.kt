@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.pdf.*
import com.example.ui.components.HelpTooltip
import com.example.ui.components.LoadingPane
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.util.UUID
import kotlin.math.absoluteValue

private data class PdfDocument(val count: Int = 0, val error: String? = null)
private data class PdfBitmap(val bitmap: Bitmap? = null, val error: String? = null)
private val pdfRenderGate = Semaphore(1)
private enum class PdfTool { HAND, PEN, HIGHLIGHT, ERASER, NOTE }
private data class PendingPdfNote(val page: Int, val point: InkPoint, val existing: PdfNote? = null)

@Composable fun NativePdf(file: File, modifier: Modifier = Modifier, documentKey: String = file.nameWithoutExtension) {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("keplerae_pdf_reading", 0) }
    var savedPage by rememberSaveable(documentKey) { mutableIntStateOf(preferences.getInt(documentKey, 0)) }
    val annotations = remember(documentKey) { PdfAnnotationStore(context, documentKey) }
    val ink by annotations.state.collectAsStateWithLifecycle()
    val writeError by annotations.error.collectAsStateWithLifecycle()
    var inkReady by remember(documentKey) { mutableStateOf(false) }
    var tool by rememberSaveable(documentKey) { mutableStateOf(PdfTool.HAND) }
    var stylusOnly by remember { mutableStateOf(preferences.getBoolean("stylus_only", false)) }
    var straight by remember { mutableStateOf(preferences.getBoolean("straight_highlight", true)) }
    var inkColor by rememberSaveable { mutableLongStateOf(0xFF2457B8L) }
    var pendingNote by remember { mutableStateOf<PendingPdfNote?>(null) }
    var noteList by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    // Cada gesto é uma operação de desfazer, incluindo borracha e edição de nota.
    val history = remember(documentKey) { mutableStateMapOf<Int, List<PageAnnotations>>() }
    fun updatePage(index: Int, next: PageAnnotations) {
        val before = ink.pages[index] ?: PageAnnotations()
        if (before != next) {
            history[index] = (history[index].orEmpty() + before).takeLast(50)
            annotations.replace(index, next)
        }
    }
    LaunchedEffect(annotations) { annotations.load(); inkReady = true }
    DisposableEffect(annotations) { onDispose { annotations.close() } }
    val document by produceState(PdfDocument(), file.path) {
        value = withContext(Dispatchers.IO) {
            try {
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                    PdfRenderer(descriptor).use { renderer ->
                        check(renderer.pageCount > 0); PdfDocument(renderer.pageCount)
                    }
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { PdfDocument(error = "Não foi possível ler este PDF. Ele pode estar danificado ou protegido por senha.") }
        }
    }
    when {
        document.error != null -> Box(modifier, contentAlignment = Alignment.Center) {
            Text(document.error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(24.dp))
        }
        document.count == 0 || !inkReady -> LoadingPane("Preparando páginas…", modifier)
        else -> {
            val pager = rememberPagerState(initialPage = savedPage.coerceIn(0, document.count - 1), pageCount = { document.count })
            var zoomed by remember(documentKey) { mutableStateOf(false) }
            var resetZoom by remember(documentKey) { mutableIntStateOf(0) }
            val scope = rememberCoroutineScope()
            LaunchedEffect(pager) {
                snapshotFlow { pager.settledPage }.collect {
                    savedPage = it; preferences.edit().putInt(documentKey, it).apply(); zoomed = false
                }
            }
            Column(modifier.fillMaxSize()) {
                writeError?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }
                HorizontalPager(state = pager, userScrollEnabled = !zoomed && (tool == PdfTool.HAND || stylusOnly),
                    beyondViewportPageCount = 0, pageSpacing = 12.dp, contentPadding = PaddingValues(horizontal = 8.dp),
                    modifier = Modifier.fillMaxWidth().weight(1f).testTag("pdf_pager"), key = { it }) { index ->
                    PdfPageContent(file, index, index == pager.currentPage, resetZoom,
                        ink.pages[index] ?: PageAnnotations(), tool, stylusOnly, straight, inkColor,
                        Modifier.fillMaxSize().graphicsLayer {
                            val fraction = ((pager.currentPage - index) + pager.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                            scaleX = 1f - .12f * fraction; scaleY = scaleX; alpha = 1f - .45f * fraction; clip = true
                        }, onZoomChanged = { if (index == pager.currentPage) zoomed = it },
                        onChange = { updatePage(index, it) },
                        onNote = { point, existing -> pendingNote = PendingPdfNote(index, point, existing) })
                }
                Surface(shape = MaterialTheme.shapes.extraLarge, tonalElevation = 6.dp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp).fillMaxWidth()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        PdfTool.entries.forEach { candidate ->
                            FilledTonalIconToggleButton(checked = tool == candidate, onCheckedChange = { tool = candidate },
                                modifier = Modifier.testTag("pdf_tool_${candidate.name}")) {
                                Icon(when (candidate) {
                                    PdfTool.HAND -> Icons.Outlined.PanTool
                                    PdfTool.PEN -> Icons.Outlined.Edit
                                    PdfTool.HIGHLIGHT -> Icons.Outlined.BorderColor
                                    PdfTool.ERASER -> Icons.Outlined.AutoFixNormal
                                    PdfTool.NOTE -> Icons.Outlined.StickyNote2
                                }, when (candidate) {
                                    PdfTool.HAND -> "Mover página"; PdfTool.PEN -> "Caneta"; PdfTool.HIGHLIGHT -> "Marca-texto"
                                    PdfTool.ERASER -> "Borracha"; PdfTool.NOTE -> "Adicionar nota no PDF"
                                })
                            }
                        }
                        IconButton(enabled = history[pager.currentPage].orEmpty().isNotEmpty(), onClick = {
                            val undo = history[pager.currentPage].orEmpty()
                            annotations.replace(pager.currentPage, undo.last()); history[pager.currentPage] = undo.dropLast(1)
                        }) { Icon(Icons.AutoMirrored.Filled.Undo, "Desfazer") }
                        IconButton(onClick = { noteList = true }) { Icon(Icons.Outlined.ListAlt, "Notas deste PDF") }
                        IconButton(onClick = { settings = true }) { Icon(Icons.Outlined.Tune, "Ajustar ferramentas") }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically) {
                    IconButton(enabled = pager.currentPage > 0, onClick = { resetZoom++; scope.launch { pager.animateScrollToPage(pager.currentPage - 1) } }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Página anterior")
                    }
                    Text("${pager.currentPage + 1} / ${document.count}", style = MaterialTheme.typography.labelLarge)
                    IconButton(enabled = pager.currentPage < document.count - 1, onClick = { resetZoom++; scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, "Próxima página")
                    }
                    IconButton(onClick = { resetZoom++ }) { Icon(Icons.Outlined.ZoomOutMap, "Restaurar zoom") }
                    HelpTooltip("Ler e anotar", "A mão permite trocar páginas. Caneta e marca-texto desenham; dois dedos ampliam e movem. " +
                        "Na borracha, toque no traço para removê-lo. Tudo fica salvo neste aparelho, sem mudar o PDF do Drive.")
                }
            }
            if (noteList) ModalBottomSheet(onDismissRequest = { noteList = false }) {
                val notes = ink.pages.toSortedMap().flatMap { (page, a) -> a.notes.map { page to it } }
                Text("Notas deste PDF", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(24.dp))
                if (notes.isEmpty()) Text("Use a ferramenta Nota e toque na página.", Modifier.padding(24.dp))
                LazyColumn(contentPadding = PaddingValues(16.dp)) {
                    items(notes, key = { it.second.id }) { (index, note) ->
                        ListItem(headlineContent = { Text(note.text) }, supportingContent = { Text("Página ${index+1}") },
                            trailingContent = { TextButton(onClick = { noteList = false; resetZoom++; scope.launch { pager.animateScrollToPage(index) } }) { Text("Ir") } })
                    }
                }
            }
        }
    }
    pendingNote?.let { pending ->
        var text by remember(pending) { mutableStateOf(pending.existing?.text.orEmpty()) }
        AlertDialog(onDismissRequest = { pendingNote = null }, icon = { Icon(Icons.Outlined.StickyNote2, null) },
            title = { Text("Nota • página ${pending.page+1}") }, text = {
                OutlinedTextField(text, { text = it.take(4000) }, label = { Text("Anotação") }, minLines = 3, maxLines = 8)
            }, confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = {
                val a = ink.pages[pending.page] ?: PageAnnotations()
                val note = PdfNote(pending.existing?.id ?: UUID.randomUUID().toString(), pending.point, text.trim())
                updatePage(pending.page, a.copy(notes = a.notes.filterNot { it.id == note.id } + note)); pendingNote = null
            }) { Text("Salvar") } }, dismissButton = {
                Row {
                    if (pending.existing != null) TextButton(onClick = {
                        val a = ink.pages[pending.page] ?: PageAnnotations()
                        updatePage(pending.page, a.copy(notes = a.notes.filterNot { it.id == pending.existing.id })); pendingNote = null
                    }) { Text("Excluir") }
                    TextButton(onClick = { pendingNote = null }) { Text("Cancelar") }
                }
            })
    }
    if (settings) AlertDialog(onDismissRequest = { settings = false }, icon = { Icon(Icons.Outlined.Tune, null) },
        title = { Text("Ferramentas do PDF") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Só a caneta desenha", Modifier.weight(1f))
                    Switch(stylusOnly, { stylusOnly = it; preferences.edit().putBoolean("stylus_only", it).apply() })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Marca-texto em linha reta", Modifier.weight(1f))
                    Switch(straight, { straight = it; preferences.edit().putBoolean("straight_highlight", it).apply() })
                }
                Text("Cor da caneta")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0xFF2457B8L, 0xFF242424L, 0xFFC33F54L, 0xFF137C62L).forEach { value ->
                        FilledTonalIconToggleButton(inkColor == value, { inkColor = value }) {
                            Icon(Icons.Outlined.Circle, "Cor ${value.toString(16)}", tint = Color(value))
                        }
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { settings = false }) { Text("Pronto") } })
}

@Composable private fun PdfPageContent(file: File, index: Int, active: Boolean, resetZoom: Int,
    annotation: PageAnnotations, tool: PdfTool, stylusOnly: Boolean, straight: Boolean, color: Long,
    modifier: Modifier, onZoomChanged: (Boolean) -> Unit, onChange: (PageAnnotations) -> Unit,
    onNote: (InkPoint, PdfNote?) -> Unit) {
    var zoom by remember(file.path, index) { mutableFloatStateOf(1f) }
    var pan by remember(file.path, index) { mutableStateOf(Offset.Zero) }
    var draft by remember(file.path, index) { mutableStateOf<List<InkPoint>>(emptyList()) }
    val currentAnnotation by rememberUpdatedState(annotation)
    val zoomCallback by rememberUpdatedState(onZoomChanged)
    val changeCallback by rememberUpdatedState(onChange)
    val noteCallback by rememberUpdatedState(onNote)
    LaunchedEffect(resetZoom, active) { zoom = 1f; pan = Offset.Zero; zoomCallback(false) }
    val page by produceState(PdfBitmap(), file.path, index) {
        value = pdfRenderGate.withPermit { withContext(Dispatchers.IO) {
            try {
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                    PdfRenderer(descriptor).use { renderer -> renderer.openPage(index).use { opened ->
                        val scale = minOf(1440f/opened.width, 2048f/opened.height)
                        val bitmap = Bitmap.createBitmap((opened.width*scale).toInt().coerceAtLeast(1),
                            (opened.height*scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(android.graphics.Color.WHITE)
                        opened.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); PdfBitmap(bitmap)
                    } }
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { PdfBitmap(error = "Não foi possível renderizar esta página.") }
        } }
    }
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val bitmap = page.bitmap
        when {
            page.error != null -> Text(page.error!!, color = MaterialTheme.colorScheme.error)
            bitmap == null -> LoadingPane("Carregando página ${index+1}…")
            else -> {
                val ratio = bitmap.width.toFloat()/bitmap.height
                val width = minOf(maxWidth, maxHeight*ratio); val height = width/ratio
                Box(Modifier.size(width, height).graphicsLayer {
                    scaleX = zoom; scaleY = zoom; translationX = pan.x; translationY = pan.y
                    compositingStrategy = CompositingStrategy.Offscreen
                }.background(Color.White).pointerInput(file.path, index, tool, stylusOnly, straight, color) {
                    fun normalized(p: Offset) = InkPoint(p.x/size.width, p.y/size.height).clamped()
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val canDraw = tool != PdfTool.HAND && (!stylusOnly || down.type == PointerType.Stylus || down.type == PointerType.Eraser)
                        val start = normalized(down.position)
                        var last = start; var transformed = false; var moved = false
                        var erased = currentAnnotation
                        if (canDraw) { down.consume(); if (tool == PdfTool.PEN || tool == PdfTool.HIGHLIGHT) draft = listOf(start) }
                        do {
                            val event = awaitPointerEvent()
                            event.changes.firstOrNull { it.id == down.id }?.let { pointer ->
                                last = normalized(pointer.position)
                                if (kotlin.math.hypot(last.x-start.x, last.y-start.y) > .012f) moved = true
                            }
                            val multi = event.changes.count { it.pressed } >= 2
                            val transform = multi || (!canDraw && zoom > 1.01f)
                            if (transform) {
                                transformed = true; draft = emptyList()
                                zoom = (zoom * event.calculateZoom()).coerceIn(1f, 4f)
                                val delta = event.calculatePan()
                                val limitX = size.width*(zoom-1f)/2; val limitY = size.height*(zoom-1f)/2
                                pan = Offset((pan.x+delta.x).coerceIn(-limitX, limitX), (pan.y+delta.y).coerceIn(-limitY, limitY))
                                zoomCallback(zoom > 1.01f); event.changes.forEach { it.consume() }
                            } else if (canDraw && !transformed) {
                                event.changes.firstOrNull { it.id == down.id }?.let { pointer ->
                                    last = normalized(pointer.position)
                                    when (tool) {
                                        PdfTool.PEN, PdfTool.HIGHLIGHT -> if (pointer.pressed) {
                                            draft = if (straight && tool == PdfTool.HIGHLIGHT) listOf(start, last)
                                                else if (draft.lastOrNull() != last) draft + last else draft
                                        }
                                        PdfTool.ERASER -> erased = erased.copy(strokes = erased.strokes.filterNot { strokeHit(it, last) })
                                        else -> Unit
                                    }
                                    pointer.consume()
                                }
                            }
                        } while (event.changes.any { it.pressed })
                        if (!transformed && canDraw) {
                            when (tool) {
                                PdfTool.PEN, PdfTool.HIGHLIGHT -> if (draft.isNotEmpty()) changeCallback(currentAnnotation.copy(
                                    strokes = currentAnnotation.strokes + InkStroke(UUID.randomUUID().toString(), draft,
                                        tool == PdfTool.HIGHLIGHT, if (tool == PdfTool.HIGHLIGHT) 0xFFFFD54FL else color,
                                        if (tool == PdfTool.HIGHLIGHT) .027f else .0035f)))
                                PdfTool.ERASER -> changeCallback(erased)
                                PdfTool.NOTE -> {
                                    val existing = currentAnnotation.notes.firstOrNull { kotlin.math.hypot(it.point.x-last.x, it.point.y-last.y) < .045f }
                                    noteCallback(existing?.point ?: last, existing)
                                }
                                else -> Unit
                            }
                        } else if (!transformed && !moved && tool == PdfTool.HAND) {
                            currentAnnotation.notes.firstOrNull { kotlin.math.hypot(it.point.x-last.x, it.point.y-last.y) < .045f }
                                ?.let { noteCallback(it.point, it) }
                        }
                        draft = emptyList()
                    }
                }) {
                    Image(bitmap.asImageBitmap(), "Página ${index+1}", Modifier.fillMaxSize())
                    Canvas(Modifier.fillMaxSize()) {
                        fun paint(s: InkStroke) {
                            if (s.points.isEmpty()) return
                            val strokeColor = Color(s.color).copy(alpha = if (s.highlight) .42f else 1f)
                            val blend = if (s.highlight) BlendMode.Multiply else BlendMode.SrcOver
                            val w = s.width*size.width
                            if (s.points.size == 1) drawCircle(strokeColor, w/2,
                                Offset(s.points[0].x*size.width,s.points[0].y*size.height), blendMode = blend)
                            else {
                                val path = Path().apply {
                                    moveTo(s.points[0].x*size.width,s.points[0].y*size.height)
                                    s.points.drop(1).forEach { lineTo(it.x*size.width,it.y*size.height) }
                                }
                                drawPath(path, strokeColor, style = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = blend)
                            }
                        }
                        annotation.strokes.forEach(::paint)
                        if (draft.isNotEmpty()) paint(InkStroke("draft", draft, tool == PdfTool.HIGHLIGHT,
                            if(tool==PdfTool.HIGHLIGHT) 0xFFFFD54FL else color, if(tool==PdfTool.HIGHLIGHT) .027f else .0035f))
                        annotation.notes.forEach { n ->
                            val center=Offset(n.point.x*size.width,n.point.y*size.height)
                            drawCircle(Color(0xFF7955C3),12.dp.toPx(),center)
                            drawLine(Color.White,center-Offset(5.dp.toPx(),0f),center+Offset(5.dp.toPx(),0f),2.dp.toPx())
                            drawLine(Color.White,center-Offset(0f,5.dp.toPx()),center+Offset(0f,5.dp.toPx()),2.dp.toPx())
                        }
                    }
                }
            }
        }
    }
}
