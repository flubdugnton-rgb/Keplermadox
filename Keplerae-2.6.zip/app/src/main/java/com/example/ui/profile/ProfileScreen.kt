@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui.profile

import android.os.Build
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.example.data.auth.GoogleUser
import com.example.data.repository.StudyState
import com.example.data.repository.ThemeMode
import com.example.ui.components.SharedMotion
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable fun GoogleAvatar(user: GoogleUser?, modifier: Modifier = Modifier) {
    val placeholder = rememberVectorPainter(Icons.Outlined.Person)
    AsyncImage(model = ImageRequest.Builder(LocalContext.current).data(user?.photoUrl)
        .crossfade(true).build(), placeholder = placeholder, error = placeholder,
        fallback = placeholder, contentDescription = "Foto da conta Google",
        contentScale = ContentScale.Crop, modifier = modifier.clip(CircleShape))
}

@Composable fun ProfileButton(user: GoogleUser?, motion: SharedMotion, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer,
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.surface.copy(alpha = .8f)),
        modifier = motion.bounds("profile-container").size(56.dp).testTag("profile_open")) {
        GoogleAvatar(user, motion.element("profile-avatar").fillMaxSize().padding(3.dp))
    }
}

@Composable fun ProfileScreen(user: GoogleUser?, state: StudyState, motion: SharedMotion,
    onTheme: (ThemeMode) -> Unit, onDynamicColor: (Boolean) -> Unit,
    onConfigureDrive: () -> Unit, onSignOut: () -> Unit,
    onBack: () -> Unit = {}, onAppearance: () -> Unit = {}) {
    var confirmExit by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentAlignment = Alignment.TopCenter) {
        Surface(shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.surfaceContainerLow,
            modifier = motion.bounds("profile-container").widthIn(max = 620.dp).fillMaxWidth()) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("profile_back")) { Icon(Icons.AutoMirrored.Filled.ArrowBack,"Voltar") }
                    IconButton(onClick = onAppearance, modifier = Modifier.testTag("settings")) {
                        Icon(Icons.Outlined.Tune,"Preferências")
                    }
                }
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(3.dp, MaterialTheme.colorScheme.primary.copy(alpha = .3f))) {
                    GoogleAvatar(user, motion.element("profile-avatar").size(112.dp).padding(5.dp))
                }
                Text(user?.displayName?.takeIf { it.isNotBlank() } ?: "Minha conta",
                    style = MaterialTheme.typography.headlineMedium, modifier = Modifier.testTag("profile_name"))
                if (user != null) Text(user.email, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Seu espaço, do seu jeito.", style = MaterialTheme.typography.titleMedium)
                // O destaque representa a preferência, incluindo o modo automático.
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)) {
                    ThemeOrb(dark = false, selected = state.theme == ThemeMode.LIGHT, modifier = Modifier.weight(1f)) { onTheme(ThemeMode.LIGHT) }
                    ThemeOrb(dark = true, selected = state.theme == ThemeMode.DARK, modifier = Modifier.weight(1f)) { onTheme(ThemeMode.DARK) }
                }
                FilterChip(selected = state.theme == ThemeMode.SYSTEM,
                    onClick = { onTheme(ThemeMode.SYSTEM) },
                    label = { Text("Acompanhar o sistema") },
                    leadingIcon = { Icon(Icons.Outlined.Devices, null) },
                    modifier = Modifier.testTag("profile_theme_SYSTEM"))
                HorizontalDivider()
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Cores do seu Android", style = MaterialTheme.typography.titleMedium)
                        Text(if (Build.VERSION.SDK_INT >= 31) "Combine com o papel de parede."
                            else "Paleta Kepleræ neste Android.", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = state.dynamicColor, onCheckedChange = onDynamicColor,
                        enabled = Build.VERSION.SDK_INT >= 31)
                }
                OutlinedButton(onClick = onConfigureDrive, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.Cloud, null); Spacer(Modifier.width(8.dp)); Text("Google Drive")
                }
                FilledTonalButton(onClick = { confirmExit = true }, modifier = Modifier.fillMaxWidth().testTag("sign_out")) {
                    Icon(Icons.AutoMirrored.Outlined.Logout, null)
                    Spacer(Modifier.width(8.dp)); Text("Desconectar")
                }
                Text("Kepleræ 2.6 · Madox Fênix", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (confirmExit) AlertDialog(onDismissRequest = { confirmExit = false },
        icon = { Icon(Icons.AutoMirrored.Outlined.Logout, null) },
        title = { Text("Desconectar do Kepleræ?") },
        text = { Text("Você voltará à tela de login. Favoritos, progresso e tema ficam salvos neste aparelho.") },
        confirmButton = { TextButton(onClick = { confirmExit = false; onSignOut() },
            modifier = Modifier.testTag("confirm_sign_out")) { Text("Desconectar") } },
        dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Cancelar") } })
}

/** Sol e lua com volume e brilho, inspirados na referência Cycle of Vitality. */
@Composable private fun ThemeOrb(dark: Boolean, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var tap by remember { mutableIntStateOf(0) }
    val pulse = remember { Animatable(0f) }
    LaunchedEffect(tap) {
        if (tap > 0) {
            pulse.snapTo(0f)
            pulse.animateTo(1f, tween(1100))
            pulse.snapTo(0f)
        }
    }
    val scale by animateFloatAsState(if (selected) 1f else .90f,
        animationSpec = spring(dampingRatio = .8f), label = "theme_selection")
    Surface(onClick = { tap++; onClick() }, shape = MaterialTheme.shapes.extraLarge,
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
        border = BorderStroke(if (selected) 2.dp else 1.dp,
            if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
        shadowElevation = if (selected) 8.dp else 0.dp,
        modifier = modifier.widthIn(max = 128.dp).aspectRatio(1f).graphicsLayer { scaleX = scale; scaleY = scale }
            .testTag(if (dark) "profile_theme_DARK" else "profile_theme_LIGHT")
            .then(Modifier.themeSemantics(dark, selected))) {
        Canvas(Modifier.fillMaxSize().padding(20.dp)) {
            val progress = pulse.value
            val motion = sin(PI * progress).toFloat()
            val r = size.minDimension * .28f
            val colors = if (dark) listOf(Color(0xFFE8FFA5), Color(0xFF5DAC68), Color(0xFF205D44))
                else listOf(Color(0xFFFFF2A8), Color(0xFFFFB247), Color(0xFFE5732C))
            drawCircle(Brush.radialGradient(listOf(colors[1].copy(alpha = .26f), Color.Transparent),
                radius = size.minDimension * .52f), size.minDimension * .52f)
            val lighting = Brush.radialGradient(colors, center = center - Offset(r * .5f, r * .5f), radius = r * 2f)
            if (dark) {
                val outer = Path().apply { addOval(androidx.compose.ui.geometry.Rect(center - Offset(r * 1.3f, r * 1.3f),
                    center + Offset(r * 1.3f, r * 1.3f))) }
                val hole = Path().apply { addOval(androidx.compose.ui.geometry.Rect(
                    center + Offset(-r * .1f, -r * 1.55f), center + Offset(r * 1.7f, r * .85f))) }
                val crescent = Path.combine(PathOperation.Difference, outer, hole)
                drawPath(crescent, lighting)
                listOf(Offset(1.25f, -.9f), Offset(.4f, -1.4f), Offset(1.5f, .35f)).forEachIndexed { i, star ->
                    val blink = (1f - .65f * motion * (.5f + .5f * sin(progress * 6 * PI + i))).toFloat()
                    val point = center + star * r
                    val radius = r * (if (i == 0) .13f else .08f) * (1f + motion * .22f)
                    drawCircle(Color(0xFFE6FFC0).copy(alpha = blink), radius, point)
                    drawLine(Color(0xFFE6FFC0).copy(alpha = blink * motion),
                        point - Offset(radius * 2, 0f), point + Offset(radius * 2, 0f), r * .025f)
                    drawLine(Color(0xFFE6FFC0).copy(alpha = blink * motion),
                        point - Offset(0f, radius * 2), point + Offset(0f, radius * 2), r * .025f)
                }
            } else {
                rotate(motion * 18f) { repeat(12) { i ->
                    val a = i * PI / 6
                    val unit = Offset(cos(a).toFloat(), sin(a).toFloat())
                    val reach = 1f + motion * .12f * sin(progress * 6 * PI + i).toFloat()
                    drawLine(colors[1], center + unit * (r * 1.35f), center + unit * (r * 1.68f * reach),
                        strokeWidth = r * .18f, cap = StrokeCap.Round)
                } }
                drawCircle(lighting, r)
                drawCircle(Color.White.copy(alpha = .28f), r * .82f, center - Offset(r * .1f, r * .1f),
                    style = Stroke(width = r * .045f))
            }
        }
    }
}
