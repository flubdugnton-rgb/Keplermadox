package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.StudyViewModel
import com.example.data.auth.GoogleLoginViewModel
import com.example.ui.KepleraeApp
import com.example.ui.login.LoginRoute
import com.example.ui.theme.KepleraeTheme
import com.example.ui.theme.isDarkMode
import com.example.data.productivity.PomodoroStore
import com.example.data.productivity.PomodoroService

class MainActivity : ComponentActivity() {
    private val viewModel: StudyViewModel by viewModels()
    private val loginViewModel: GoogleLoginViewModel by viewModels()
    override fun onResume() {
        super.onResume()
        loginViewModel.refreshSavedAuthorization()
        if(PomodoroStore.get(this).state.value.running) {
            runCatching { PomodoroService.command(this,PomodoroService.RESTORE) }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            val login by loginViewModel.state.collectAsStateWithLifecycle()
            val dark = isDarkMode(state.theme)
            SideEffect {
                val style = if (dark) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                    else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            KepleraeTheme(state.theme, state.dynamicColor) {
                if (login.user == null) LoginRoute(loginViewModel)
                else KepleraeApp(state, viewModel, login.user, loginViewModel::signOut,
                    openPomodoro = intent?.getBooleanExtra("open_pomodoro",false)==true)
            }
        }
    }
}
