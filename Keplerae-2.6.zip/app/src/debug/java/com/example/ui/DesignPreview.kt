@file:OptIn(androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import com.example.data.auth.GoogleUser
import com.example.data.model.*
import com.example.data.repository.StudyState
import com.example.data.repository.ThemeMode
import com.example.ui.components.SharedMotion
import com.example.ui.home.HomeScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.theme.KepleraeTheme
import org.json.JSONArray

/** Previews reais de Compose. Leem o catálogo empacotado e não acessam o Drive. */
@Composable private fun PreviewContent(profile: Boolean, dark: Boolean) {
    val context = LocalContext.current
    val state = remember(context, dark) {
        val rows = runCatching {
            val array = JSONArray(context.assets.open("catalog.json").bufferedReader().use { it.readText() })
            List(array.length()) { i ->
                val row = array.getJSONObject(i); val path = row.getJSONArray("folderPath")
                StudyItem(row.getString("id"), row.getString("title"), row.getString("filename"),
                    row.getString("subjectId"), List(path.length()) { path.getString(it) },
                    ContentType.valueOf(row.getString("type")), row.getString("url"),
                    LinkKind.valueOf(row.getString("linkKind")), row.getString("driveFileId"),
                    row.getString("note"), row.getString("source"))
            }
        }.getOrDefault(emptyList())
        StudyState(items = rows, theme = if (dark) ThemeMode.DARK else ThemeMode.LIGHT,
            dynamicColor = false, loading = false)
    }
    KepleraeTheme(state.theme, dynamicColor = false) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            SharedTransitionLayout {
                val shared = this
                AnimatedContent(profile, label = "preview_route") { showProfile ->
                    val motion = SharedMotion(shared, this)
                    val user = GoogleUser("exemplo@example.com", "Conta de exemplo", null)
                    if (showProfile) ProfileScreen(user, state, motion, {}, {}, {}, {})
                    else HomeScreen(state, user, motion, {}, {}, {}, {}, {})
                }
            }
        }
    }
}

@Preview(name = "Início claro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun HomeLightPreview() = PreviewContent(profile = false, dark = false)
@Preview(name = "Início escuro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun HomeDarkPreview() = PreviewContent(profile = false, dark = true)
@Preview(name = "Início tablet", widthDp = 1000, heightDp = 700, showBackground = true)
@Composable private fun TabletHomePreview() = PreviewContent(profile = false, dark = false)
@Preview(name = "Perfil claro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun ProfileLightPreview() = PreviewContent(profile = true, dark = false)
@Preview(name = "Perfil escuro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun ProfileDarkPreview() = PreviewContent(profile = true, dark = true)
@Preview(name = "Perfil fonte ampliada", widthDp = 360, heightDp = 800, fontScale = 1.5f)
@Composable private fun ProfileLargeFontPreview() = PreviewContent(profile = true, dark = false)
