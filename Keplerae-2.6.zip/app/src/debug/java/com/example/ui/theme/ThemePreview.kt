package com.example.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.data.repository.ThemeMode

/** Amostra do tema; não é uma nova tela do app. */
@Composable
private fun ThemeSample(dark: Boolean) {
    KepleraeTheme(mode = if (dark) ThemeMode.DARK else ThemeMode.LIGHT, dynamicColor = false) {
        Surface {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Kepleræ", style = MaterialTheme.typography.displayLarge)
                Text("Seu espaço de estudo", style = MaterialTheme.typography.headlineSmall)
                Text("Aulas, PDFs e áudios no seu ritmo.", style = MaterialTheme.typography.bodyLarge)
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Continuar aprendendo", style = MaterialTheme.typography.titleLarge)
                        Text("Cores, formas e tipografia compartilhadas.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = {}) { Text("Começar") }
                    FilledTonalButton(onClick = {}) { Text("Biblioteca") }
                }
            }
        }
    }
}

@Preview(name = "Kepleræ · claro", widthDp = 420, showBackground = true)
@Composable private fun LightThemePreview() = ThemeSample(dark = false)

@Preview(name = "Kepleræ · escuro", widthDp = 420, showBackground = true)
@Composable private fun DarkThemePreview() = ThemeSample(dark = true)
