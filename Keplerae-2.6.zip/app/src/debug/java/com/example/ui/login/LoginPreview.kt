package com.example.ui.login

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.data.repository.ThemeMode
import com.example.ui.theme.KepleraeTheme

@Preview(name = "Login claro", showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun LoginLightPreview() {
    KepleraeTheme(mode = ThemeMode.LIGHT, dynamicColor = false) {
        LoginScreen(busy = false, error = null, onGoogleSignIn = {})
    }
}

@Preview(name = "Login escuro", showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun LoginDarkPreview() {
    KepleraeTheme(mode = ThemeMode.DARK, dynamicColor = false) {
        LoginScreen(busy = false, error = null, onGoogleSignIn = {})
    }
}

@Preview(name = "Tablet", showBackground = true, widthDp = 960, heightDp = 600)
@Preview(name = "Texto ampliado", showBackground = true, widthDp = 360, heightDp = 740, fontScale = 1.5f)
@Composable
private fun LoginTabletPreview() {
    KepleraeTheme(mode = ThemeMode.LIGHT, dynamicColor = false) {
        LoginScreen(busy = true, error = null, onGoogleSignIn = {})
    }
}
