package com.example

import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.repository.ThemeMode
import com.example.ui.productivity.*
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ProductivityDesignTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    @Test fun focusSettingsAndDashboardRenderInBothThemes() {
        val dark=mutableStateOf(false);val questions=mutableStateOf(false)
        compose.setContent {
            KepleraeTheme(if(dark.value)ThemeMode.DARK else ThemeMode.LIGHT,false) {
                if(questions.value)QuestionsScreen()else PomodoroScreen()
            }
        }
        compose.onNodeWithTag("pomodoro_time").assertExists()
        saveDevicePreview("pomodoro-claro-2.4")
        compose.runOnIdle {dark.value=true}
        compose.onNodeWithTag("pomodoro_time").assertExists()
        saveDevicePreview("pomodoro-escuro-2.4")
        compose.onNodeWithText("Ajustes").performClick()
        compose.onNodeWithText("Som durante o foco").assertExists()
        saveDevicePreview("ajustes-escuro-2.4")
        compose.runOnIdle {dark.value=false}
        compose.onNodeWithText("Som durante o foco").assertExists()
        saveDevicePreview("ajustes-claro-2.4")
        compose.runOnIdle {questions.value=true}
        compose.onNodeWithTag("questions_screen").assertExists()
        compose.onNodeWithText("Seu desempenho").assertExists()
        saveDevicePreview("questoes-claro-2.4")
        compose.runOnIdle {dark.value=true}
        compose.onNodeWithText("Seu desempenho").assertExists()
        saveDevicePreview("questoes-escuro-2.4")
    }
}
