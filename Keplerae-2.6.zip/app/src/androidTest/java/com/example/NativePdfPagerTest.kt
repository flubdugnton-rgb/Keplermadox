package com.example

import android.graphics.pdf.PdfDocument
import androidx.activity.ComponentActivity
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.ui.NativePdf
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class NativePdfPagerTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun reopeningSameDocumentRestoresSettledPage() {
        val key = "page-test-${java.util.UUID.randomUUID()}"
        val file = File.createTempFile("remember-page", ".pdf", compose.activity.cacheDir)
        val pdf = PdfDocument()
        repeat(3) { index ->
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(300,450,index+1).create())
            pdf.finishPage(page)
        }
        file.outputStream().use(pdf::writeTo);pdf.close()
        var opened by mutableStateOf(true)
        compose.setContent { KepleraeTheme { if (opened) NativePdf(file,Modifier.fillMaxSize(),documentKey=key) } }
        compose.waitUntil(20000) { compose.onAllNodesWithText("1 / 3").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Próxima página").performClick()
        compose.waitUntil(10000) { compose.onAllNodesWithText("2 / 3").fetchSemanticsNodes().isNotEmpty() }
        compose.waitForIdle()
        compose.runOnIdle { opened = false };compose.waitForIdle()
        compose.runOnIdle { opened = true }
        compose.waitUntil(20000) { compose.onAllNodesWithText("2 / 3").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("2 / 3").assertIsDisplayed()
        compose.runOnIdle { opened = false };compose.waitForIdle()
        compose.activity.getSharedPreferences("keplerae_pdf_reading",0).edit().remove(key).commit()
        file.delete()
    }
    @Test fun oneFingerSwipeAdvancesRealRenderedPdfPages() {
        val file = File.createTempFile("pager-test", ".pdf", compose.activity.cacheDir)
        val document = PdfDocument()
        try {
            repeat(3) { index ->
                val page = document.startPage(PdfDocument.PageInfo.Builder(300, 450, index + 1).create())
                page.canvas.drawText("Página ${index + 1}", 40f, 60f, android.graphics.Paint().apply { textSize = 24f })
                document.finishPage(page)
            }
            file.outputStream().use(document::writeTo)
        } finally {
            document.close()
        }
        compose.setContent { KepleraeTheme { NativePdf(file, Modifier.fillMaxSize()) } }
        compose.waitUntil(20000) { compose.onAllNodesWithContentDescription("Página 1").fetchSemanticsNodes().isNotEmpty() }
        // Arrasto controlado, sem fling que possa saltar mais de uma página.
        compose.onNodeWithTag("pdf_pager").performTouchInput {
            swipe(start = androidx.compose.ui.geometry.Offset(width * .8f, height * .5f),
                end = androidx.compose.ui.geometry.Offset(width * .2f, height * .5f), durationMillis = 450)
        }
        compose.waitUntil(10000) { compose.onAllNodesWithText("2 / 3").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("2 / 3").assertIsDisplayed()
        saveDevicePreview("pdf-pagina-2")
        compose.onNodeWithContentDescription("Página anterior").performClick()
        compose.waitUntil(10000) { compose.onAllNodesWithText("1 / 3").fetchSemanticsNodes().isNotEmpty() }
        file.delete()
    }
}
