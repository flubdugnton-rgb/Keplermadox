package com.example

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.example.data.pdf.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class PdfPersistenceTest {
    @Test fun inkAndPinsSurviveReopeningAndSnapshotReplacement() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val key = "test-${UUID.randomUUID()}"
        val data = PageAnnotations(listOf(InkStroke("stroke",listOf(InkPoint(.1f,.3f),InkPoint(.8f,.3f)),
            true,0xFFFFD54FL,.027f)),listOf(PdfNote("note",InkPoint(.4f,.6f),"Revisar este conceito")))
        val first = PdfAnnotationStore(context,key)
        first.load();first.replace(4,data);first.flush();first.close()
        val reopened = PdfAnnotationStore(context,key)
        try {
            reopened.load();assertEquals(data,reopened.state.value.pages[4])
            reopened.replace(4,PageAnnotations());reopened.flush()
            val third = PdfAnnotationStore(context,key)
            third.load();assertEquals(PageAnnotations(),third.state.value.pages[4]);third.close()
        } finally {
            reopened.close();File(context.filesDir,"annotations/$key.json").delete()
        }
    }
}
