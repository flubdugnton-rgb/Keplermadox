package com.example

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.ui.notes.NotesScreen
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class NotesScreenTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun floatingActionCreatesSearchableNoteAndDeleteRemovesIt() {
        val title = "Nota ${UUID.randomUUID()}"
        compose.setContent { KepleraeTheme { NotesScreen() } }
        compose.onNodeWithTag("note_new").performClick()
        compose.onNodeWithTag("note_title").performTextInput(title)
        compose.onNodeWithTag("note_body").performTextInput("Revisar matéria amanhã")
        compose.onNodeWithTag("note_confirm").performClick()
        compose.onNodeWithTag("notes_search").performTextInput(title)
        compose.onNode(hasText(title) and !hasTestTag("notes_search")).performClick()
        compose.onNodeWithContentDescription("Excluir anotação").performClick()
        compose.onNodeWithText("Excluir",useUnmergedTree=true).performClick()
        compose.onNode(hasText(title) and !hasTestTag("notes_search")).assertDoesNotExist()
    }
}
