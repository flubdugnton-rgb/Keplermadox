package com.example

import android.content.res.Configuration
import androidx.activity.ComponentActivity
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.repository.ThemeMode
import com.example.ui.theme.KepleraeTheme
import com.example.ui.theme.LocalKepleraeDarkTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ReactiveThemeTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    @Test fun themeColorsChangeImmediatelyAndSystemModeFollowsConfiguration() {
        val mode=mutableStateOf(ThemeMode.LIGHT)
        val systemDark=mutableStateOf(true)
        var luminance=0f; var appliedDark=false
        compose.setContent {
            val configuration=Configuration(LocalConfiguration.current).apply {
                uiMode=(uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or
                    (if(systemDark.value)Configuration.UI_MODE_NIGHT_YES else Configuration.UI_MODE_NIGHT_NO)
            }
            CompositionLocalProvider(LocalConfiguration provides configuration) {
                KepleraeTheme(mode.value,false) {
                    val surface=MaterialTheme.colorScheme.surface
                    val dark=LocalKepleraeDarkTheme.current
                    SideEffect { luminance=surface.luminance();appliedDark=dark }
                }
            }
        }
        compose.runOnIdle {assertTrue(luminance>.35f);assertFalse(appliedDark);mode.value=ThemeMode.DARK}
        compose.runOnIdle {assertTrue(luminance<.35f);assertTrue(appliedDark);mode.value=ThemeMode.LIGHT}
        compose.runOnIdle {assertTrue(luminance>.35f);mode.value=ThemeMode.SYSTEM}
        compose.runOnIdle {assertTrue(luminance<.35f);systemDark.value=false}
        compose.runOnIdle {assertTrue(luminance>.35f);assertFalse(appliedDark)}
    }
}
