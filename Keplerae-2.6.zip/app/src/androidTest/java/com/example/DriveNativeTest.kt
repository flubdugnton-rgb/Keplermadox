package com.example

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.example.data.drive.DriveSettings
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class DriveNativeTest {
    @Test fun installedAppHasNetworkPermissionAndCanCreateSocket() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals(android.content.pm.PackageManager.PERMISSION_GRANTED,
            context.checkPermission(android.Manifest.permission.INTERNET, android.os.Process.myPid(), android.os.Process.myUid()))
        java.net.ServerSocket(0, 1, java.net.InetAddress.getLoopbackAddress()).use { server ->
            java.net.Socket().use { client ->
                client.connect(java.net.InetSocketAddress(java.net.InetAddress.getLoopbackAddress(), server.localPort), 2000)
                server.accept().use { peer -> assertTrue(peer.isConnected) }
            }
        }
    }
    @Test fun pdfCanBeRenderedOnDeviceWithoutBrowser() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val file = File.createTempFile("native-pdf-test-", ".pdf", context.cacheDir)
        try {
            val document = PdfDocument()
            try {
                repeat(2) { index ->
                    val page = document.startPage(PdfDocument.PageInfo.Builder(300, 400, index + 1).create())
                    page.canvas.drawColor(if (index == 0) Color.RED else Color.BLUE)
                    document.finishPage(page)
                }
                file.outputStream().use(document::writeTo)
            } finally { document.close() }
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    assertEquals(2, renderer.pageCount)
                    renderer.openPage(1).use { page ->
                        val bitmap = Bitmap.createBitmap(300, 400, Bitmap.Config.ARGB_8888)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        assertEquals(Color.BLUE, bitmap.getPixel(150, 200))
                        bitmap.recycle()
                    }
                }
            }
        } finally { file.delete() }
    }
    @Test fun keyRoundTripsThroughKeystoreWithoutPlaintextPreference() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "drive-test-${UUID.randomUUID()}"
        val preferences = context.getSharedPreferences(name, 0)
        val settings = DriveSettings(context, name)
        try {
            val key = "not-a-real-api-key-for-local-keystore-test"
            settings.saveApiKey(key)
            assertEquals(key, settings.apiKey())
            assertFalse(preferences.getString("api_key", "")!!.contains(key))
            settings.saveApiKey("")
            assertEquals("", settings.apiKey())
        } finally { preferences.edit().clear().commit() }
    }
}
