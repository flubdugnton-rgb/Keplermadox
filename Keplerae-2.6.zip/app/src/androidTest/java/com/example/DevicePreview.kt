package com.example

import android.graphics.Bitmap
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File

/** Capturas reais do emulador, publicadas pelo Actions junto dos relatórios de interface. */
internal fun saveDevicePreview(name: String) {
    val instrumentation = InstrumentationRegistry.getInstrumentation()
    val root = File(instrumentation.targetContext.getExternalFilesDir(null), "design-preview").apply { mkdirs() }
    val screenshot = instrumentation.uiAutomation.takeScreenshot() ?: return
    File(root, "$name.png").outputStream().use { screenshot.compress(Bitmap.CompressFormat.PNG, 100, it) }
    screenshot.recycle()
}
