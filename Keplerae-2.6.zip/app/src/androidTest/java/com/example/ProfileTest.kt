package com.example

import androidx.activity.ComponentActivity
import androidx.compose.runtime.getValue
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.auth.GoogleUser
import com.example.data.repository.StudyViewModel
import com.example.ui.KepleraeApp
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ProfileTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun profileUsesChosenAccountAndThemeAndConfirmsSignOut() {
        lateinit var model: StudyViewModel
        var signOutCalls = 0
        compose.activityRule.scenario.onActivity { model = ViewModelProvider(it)[StudyViewModel::class.java] }
        compose.setContent {
            val state by model.state.collectAsStateWithLifecycle()
            KepleraeTheme(state.theme, state.dynamicColor) {
                KepleraeApp(state, model, GoogleUser("user@example.com", "Conta de teste", null), { signOutCalls++ })
            }
        }
        compose.waitUntil(20000) { compose.onAllNodesWithTag("profile_open").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("profile_open").performClick()
        compose.onNodeWithText("Conta de teste").assertIsDisplayed()
        compose.onNodeWithTag("profile_theme_DARK").performClick().assertIsSelected()
        compose.waitForIdle()
        saveDevicePreview("perfil-escuro")
        compose.onNodeWithTag("profile_theme_LIGHT").performClick().assertIsSelected()
        compose.waitForIdle()
        saveDevicePreview("perfil-claro")
        compose.onNodeWithTag("profile_theme_SYSTEM").performScrollTo().performClick().assertIsSelected()
        compose.onNodeWithTag("profile_theme_LIGHT").assertIsNotSelected()
        compose.onNodeWithTag("profile_theme_DARK").assertIsNotSelected()
        compose.onNodeWithTag("sign_out").performScrollTo().performClick()
        compose.runOnIdle { assertEquals(0, signOutCalls) }
        compose.onNodeWithTag("confirm_sign_out").performClick()
        compose.runOnIdle { assertEquals(1, signOutCalls) }
    }
}
