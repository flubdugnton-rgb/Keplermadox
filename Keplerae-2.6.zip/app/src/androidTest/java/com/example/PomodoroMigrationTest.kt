package com.example

import android.content.Context
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.productivity.PomodoroStore
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PomodoroMigrationTest {
    @Test fun version23HistoryAndDurationsSurviveNewSoundPreferences() {
        val context=InstrumentationRegistry.getInstrumentation().targetContext
        val prefs=context.getSharedPreferences("keplerae_pomodoro",Context.MODE_PRIVATE)
        val previous=prefs.getString("state",null)
        val constructor=PomodoroStore::class.java.getDeclaredConstructor(Context::class.java).apply {isAccessible=true}
        try {
            prefs.edit().putString("state","""{"settings":{"focus":50,"short":10,"long":20,"cycles":4,"sounds":false},"history":[{"id":"old","at":123,"duration":3000000}]}""").commit()
            val old=constructor.newInstance(context)
            assertEquals(50,old.state.value.settings.focusMinutes)
            assertFalse(old.state.value.settings.ambienceEnabled)
            assertFalse(old.state.value.settings.sounds)
            old.configure(old.state.value.settings.copy(ambienceEnabled=true,ambienceId="library",ambienceVolume=.4f))
            val reopened=constructor.newInstance(context).state.value
            assertEquals(50,reopened.settings.focusMinutes)
            assertEquals("library",reopened.settings.ambienceId)
            assertEquals(.4f,reopened.settings.ambienceVolume,0.001f)
            assertFalse(reopened.settings.sounds)
            assertEquals(3_000_000L,reopened.history.single().durationMs)
        } finally {
            val edit=prefs.edit();if(previous==null)edit.remove("state")else edit.putString("state",previous);edit.commit()
        }
    }
}
