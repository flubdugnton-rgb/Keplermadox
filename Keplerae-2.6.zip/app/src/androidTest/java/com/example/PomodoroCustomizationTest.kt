package com.example

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.productivity.*
import com.example.ui.productivity.PomodoroScreen
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PomodoroCustomizationTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    @Test fun savingCustomFieldsChangesFocusClockAndCycleCount() {
        val store=PomodoroStore.get(compose.activity)
        compose.runOnUiThread {store.pause();store.reset();store.configure(PomodoroSettings())}
        compose.setContent {KepleraeTheme {PomodoroScreen()}}
        compose.onNodeWithText("Ajustes").performClick()
        compose.onNodeWithTag("pomodoro_screen").performScrollToNode(hasTestTag("pomodoro_customize"))
        compose.onNodeWithTag("pomodoro_customize").performClick()
        listOf("focus" to "42","short" to "7","long" to "19","cycles" to "6").forEach { (field,value) ->
            compose.onNodeWithTag("custom_$field").performScrollTo().performTextReplacement(value)
        }
        compose.onNodeWithTag("custom_save").performClick()
        compose.runOnIdle {
            assertEquals(42,store.state.value.settings.focusMinutes)
            assertEquals(6,store.state.value.settings.cycles)
            assertEquals(42*60000L,store.state.value.remainingMs)
        }
        compose.onNodeWithTag("pomodoro_screen").performScrollToIndex(0)
        compose.onNodeWithText("Foco").performClick()
        compose.onNodeWithTag("pomodoro_time").assertTextEquals("42:00")
    }
}
