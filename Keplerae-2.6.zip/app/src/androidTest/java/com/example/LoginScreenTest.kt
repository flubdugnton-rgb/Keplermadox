package com.example

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.hasClickAction
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.repository.ThemeMode
import com.example.ui.login.LoginScreen
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LoginScreenTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    @Test fun offersOnlyGoogleAndInvokesTheEntryAction() {
        var calls = 0
        compose.setContent {
            KepleraeTheme(ThemeMode.LIGHT, dynamicColor = false) {
                LoginScreen(busy = false, error = null, onGoogleSignIn = { calls++ })
            }
        }
        compose.onNodeWithText("Kepleræ").assertIsDisplayed()
        compose.onNodeWithText("Desenvolvido por Madox Fênix").assertIsDisplayed()
        compose.onAllNodes(hasClickAction()).assertCountEquals(1)
        compose.onNodeWithTag("google_sign_in").performClick()
        compose.runOnIdle { assertEquals(1, calls) }
    }

    @Test fun preventsDuplicateRequestsWhileConnectingAndShowsErrorsInDarkTheme() {
        compose.setContent {
            KepleraeTheme(ThemeMode.DARK, dynamicColor = false) {
                LoginScreen(busy = true, error = "Sem conexão", onGoogleSignIn = {})
            }
        }
        compose.onNodeWithTag("google_sign_in").assertIsNotEnabled()
        compose.onNodeWithTag("login_error").assertIsDisplayed()
    }
}
