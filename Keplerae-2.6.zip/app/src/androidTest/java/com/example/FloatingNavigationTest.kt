package com.example

import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.ui.Destination
import com.example.ui.components.FloatingAppNavigation
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FloatingNavigationTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    @Test fun barExpandsCollapsesAndKeepsFiveDestinations() {
        val current=mutableStateOf(Destination.HOME)
        compose.setContent { KepleraeTheme {FloatingAppNavigation(current.value){current.value=it}} }
        compose.onNodeWithTag("nav_VIDEOS").assertDoesNotExist()
        compose.onNodeWithTag("nav_PDFS").assertDoesNotExist()
        compose.onNodeWithTag("nav_AUDIO").assertDoesNotExist()
        compose.onNodeWithTag("nav_POMODORO").performClick().assertIsSelected()
        compose.onNodeWithTag("navigation_expand").performClick()
        compose.onNodeWithTag("nav_POMODORO").assertExists()
        compose.onNodeWithTag("nav_HOME").assertDoesNotExist()
        compose.onNodeWithTag("navigation_expand").performClick()
        compose.onNodeWithTag("nav_NOTES").performClick().assertIsSelected()
        compose.onNodeWithTag("nav_QUESTIONS").assertExists()
        compose.onNodeWithTag("nav_SUBJECTS").assertExists()
    }
}
