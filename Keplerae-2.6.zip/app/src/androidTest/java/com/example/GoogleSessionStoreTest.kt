package com.example

import androidx.test.platform.app.InstrumentationRegistry
import com.example.data.auth.GoogleSessionStore
import com.example.data.auth.GoogleUser
import org.junit.Assert.*
import org.junit.Test

class GoogleSessionStoreTest {
    @Test fun profileSurvivesNewStoreInstanceAndSignOutClearsIt() {
        val context=InstrumentationRegistry.getInstrumentation().targetContext
        val store=GoogleSessionStore(context)
        val previous=store.read()
        try {
            val user=GoogleUser("user@example.com","Nome salvo",null)
            store.save(user)
            assertEquals(user,GoogleSessionStore(context).read())
            store.clear()
            assertNull(GoogleSessionStore(context).read())
        } finally { if(previous!=null) store.save(previous) else store.clear() }
    }
}
