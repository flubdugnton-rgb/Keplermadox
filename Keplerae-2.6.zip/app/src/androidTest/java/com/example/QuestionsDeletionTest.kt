package com.example

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.productivity.QuestionStore
import com.example.ui.productivity.QuestionsScreen
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class QuestionsDeletionTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    @Test fun blockDeletionAndGlobalResetRequireConfirmationAndPersist() {
        val store=QuestionStore.get(compose.activity)
        val first=store.createSubject("Bloco ${UUID.randomUUID()}")
        val second=store.createSubject("Outro ${UUID.randomUUID()}")
        store.add(first,8,2);store.add(second,3,1)
        compose.setContent {KepleraeTheme {QuestionsScreen()}}
        compose.onNodeWithTag("questions_screen").performScrollToNode(hasTestTag("delete_block_$first"))
        compose.onNodeWithTag("delete_block_$first").performClick()
        compose.onNodeWithText("Cancelar").performClick()
        compose.runOnIdle {assertTrue(store.state.value.subjects.any {it.id==first})}
        compose.onNodeWithTag("delete_block_$first").performClick()
        compose.onNodeWithTag("confirm_delete_block").performClick()
        compose.runOnIdle {
            assertFalse(store.state.value.subjects.any {it.id==first})
            assertFalse(store.state.value.records.any {it.subjectId==first})
            assertTrue(store.state.value.records.any {it.subjectId==second})
        }
        compose.onNodeWithTag("questions_screen").performScrollToIndex(0)
        compose.onNodeWithTag("questions_menu").performClick()
        compose.onNodeWithTag("questions_reset").performClick()
        compose.onNodeWithTag("confirm_reset_questions").performClick()
        compose.runOnIdle {
            assertTrue(store.state.value.subjects.isEmpty())
            assertTrue(store.state.value.records.isEmpty())
            val saved=org.json.JSONObject(compose.activity.getSharedPreferences("keplerae_questions",0).getString("state","{}")!!)
            assertEquals(0,saved.getJSONArray("subjects").length())
            assertEquals(0,saved.getJSONArray("records").length())
        }
    }
}
