package com.example

import com.example.data.pdf.*
import org.junit.Assert.*
import org.junit.Test

class PdfInkGeometryTest {
    @Test fun eraserHitsBetweenRecordedPoints() {
        val stroke = InkStroke("line", listOf(InkPoint(.1f,.1f),InkPoint(.9f,.9f)),false,0xFF000000,.005f)
        assertTrue(strokeHit(stroke,InkPoint(.5f,.5f)))
        assertFalse(strokeHit(stroke,InkPoint(.5f,.8f)))
    }
    @Test fun tapStrokeCanBeErasedAndCoordinatesStayInsidePage() {
        val point = InkPoint(-.1f,1.2f).clamped()
        assertEquals(InkPoint(0f,1f),point)
        assertTrue(strokeHit(InkStroke("dot",listOf(point),false,0xFF000000,.01f),point))
        assertFalse(strokeHit(InkStroke("empty",emptyList(),false,0xFF000000,.01f),point))
    }
    @Test fun cacheIdentityChangesWithAccountAndDriveId() {
        assertNotEquals(pdfStorageKey("one@example.com","id"),pdfStorageKey("two@example.com","id"))
        assertNotEquals(pdfStorageKey("one@example.com","id"),pdfStorageKey("one@example.com","other"))
        assertEquals(pdfStorageKey("one@example.com","id"),pdfStorageKey("one@example.com","id"))
        assertTrue(pdfStorageKey("account","../id").matches(Regex("[0-9a-f]{64}")))
    }
}
