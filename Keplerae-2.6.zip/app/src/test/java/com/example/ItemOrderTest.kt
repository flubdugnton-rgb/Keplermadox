package com.example

import com.example.data.repository.mergeVisibleOrder
import com.example.data.repository.moveId
import com.example.data.repository.reconcileOrder
import org.junit.Assert.assertEquals
import org.junit.Test

class ItemOrderTest {
    @Test fun savedOrderSurvivesCatalogAdditionsAndRemovals() {
        assertEquals(listOf("b", "a", "new"),
            reconcileOrder(listOf("a", "b", "new"), listOf("removed", "b", "b", "a")))
    }
    @Test fun reorderingFilteredRowsDoesNotMoveHiddenRows() {
        assertEquals(listOf("c", "hidden", "a", "b"),
            mergeVisibleOrder(listOf("a", "hidden", "b", "c"), listOf("c", "a", "b")))
    }
    @Test fun dragUsesItemKeysAndIgnoresHeadersOrRemovedItems() {
        val order = listOf("a", "b", "c")
        assertEquals(listOf("b", "c", "a"), moveId(order, "a", "c"))
        assertEquals(order, moveId(order, "header", "b"))
        assertEquals(order, moveId(order, "a", "removed"))
    }
}
