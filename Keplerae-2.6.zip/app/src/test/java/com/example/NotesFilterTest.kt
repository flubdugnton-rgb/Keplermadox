package com.example

import com.example.data.notes.Note
import com.example.data.notes.cleanTagName
import com.example.data.notes.noteIsBlank
import com.example.data.notes.visibleNotes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NotesFilterTest {
    private fun note(id: String, title: String, body: String = "", tag: String? = null, updated: Long = 0L) =
        Note(id, title, body, tag, 0, 0L, updated)

    @Test fun ordersByMostRecentlyEdited() {
        val result = visibleNotes(listOf(note("a", "A", updated = 1), note("b", "B", updated = 3), note("c", "C", updated = 2)), null, "")
        assertEquals(listOf("b", "c", "a"), result.map { it.id })
    }

    @Test fun filtersByTag() {
        val notes = listOf(note("a", "A", tag = "t1"), note("b", "B", tag = "t2"), note("c", "C"))
        assertEquals(listOf("a"), visibleNotes(notes, "t1", "").map { it.id })
        assertEquals(3, visibleNotes(notes, null, "").size)
    }

    @Test fun searchIgnoresAccentsAndCase() {
        val notes = listOf(note("a", "Fisioterapia respiratória", "Ventilação"), note("b", "Outro"))
        assertEquals(listOf("a"), visibleNotes(notes, null, "RESPIRATORIA").map { it.id })
        assertEquals(listOf("a"), visibleNotes(notes, null, "ventilacao").map { it.id })
    }

    @Test fun cleanTagNameRemovesHashAndExtraSpaces() {
        assertEquals("Plantão UTI", cleanTagName("  #Plantão   UTI "))
    }

    @Test fun blankDetection() {
        assertTrue(noteIsBlank("  ", ""))
        assertFalse(noteIsBlank("", "texto"))
    }
}
