package com.example

import com.example.data.auth.GoogleLoginConfiguration
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GoogleLoginConfigurationTest {
    @Test fun acceptsPublicWebClientId() {
        assertTrue(GoogleLoginConfiguration.isWebClientId("1234567890-abc_def-123.apps.googleusercontent.com"))
        // Não restringir IDs antigos a um único formato de prefixo.
        assertTrue(GoogleLoginConfiguration.isWebClientId("1234567890.apps.googleusercontent.com"))
    }

    @Test fun rejectsApiKeysSecretsAndCopiedConfigurationText() {
        listOf("", "AIzaExampleKey", "GOCSPX-example", "{\"client_id\":\"123-a.apps.googleusercontent.com\"}",
            "https://123-a.apps.googleusercontent.com", "123-a.apps.googleusercontent.com\nextra")
            .forEach { assertFalse(GoogleLoginConfiguration.isWebClientId(it)) }
    }
}
