package com.example

import com.example.data.productivity.*
import org.junit.Assert.*
import org.junit.Test

class StudyAdjustmentsTest {
    @Test fun deletingBlockRemovesOnlyItsRecordsAndRecalculatesTotals() {
        val state=QuestionState(listOf(QuestionSubject("a","A"),QuestionSubject("b","B")),
            listOf(QuestionRecord("1","a",8,2,1),QuestionRecord("2","b",3,1,2)))
        val result=withoutQuestionSubject(state,"a")
        assertEquals(listOf("b"),result.subjects.map { it.id })
        assertEquals(listOf("2"),result.records.map { it.id })
        assertEquals(4L,questionTotals(result.records).total)
        assertEquals(75.0,questionTotals(result.records).accuracy,.001)
        assertEquals(result,withoutQuestionSubject(result,"a"))
    }
    @Test fun editingInactiveCycleImmediatelySetsNewFocusAndKeepsHistory() {
        val record=FocusRecord("completed",1,25*60000L)
        val state=PomodoroState(phase=PomodoroPhase.LONG_BREAK,cycle=4,history=listOf(record))
        val result=applyPomodoroSettings(state,PomodoroSettings(40,7,18,6))
        assertEquals(PomodoroPhase.FOCUS,result.phase)
        assertEquals(40*60000L,result.remainingMs)
        assertEquals(result.remainingMs,result.phaseDurationMs)
        assertEquals(0,result.cycle)
        assertEquals(listOf(record),result.history)
        assertFalse(result.running)
    }
    @Test fun editingActiveOrPausedCyclePreservesCurrentDeadlineAndDuration() {
        listOf(PomodoroState(running=true,deadlineWall=2000,deadlineElapsed=1000),
            PomodoroState(paused=true,remainingMs=1400)).forEach { state ->
            val result=applyPomodoroSettings(state,PomodoroSettings(50,10,20,2))
            assertEquals(state.copy(settings=result.settings),result)
            assertEquals(2,result.settings.cycles)
        }
    }
    @Test fun changingSoundAloneDoesNotResetProgress() {
        val state=PomodoroState(cycle=2,phase=PomodoroPhase.SHORT_BREAK,remainingMs=300000)
        assertEquals(state.copy(settings=state.settings.copy(ambienceId="wind")),
            applyPomodoroSettings(state,state.settings.copy(ambienceId="wind")))
    }
}
