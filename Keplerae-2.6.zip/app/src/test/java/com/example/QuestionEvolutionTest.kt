package com.example

import com.example.data.productivity.*
import org.junit.Assert.*
import org.junit.Test
import java.util.TimeZone

class QuestionEvolutionTest {
    private val utc=TimeZone.getTimeZone("UTC")
    @Test fun dailyAccumulationSortsAndCombinesSessions() {
        val records=listOf(QuestionRecord("later","math",3,1,86_400_100L),
            QuestionRecord("first","math",10,2,100L),QuestionRecord("same","math",2,3,200L))
        val days=cumulativeQuestionDays(records,utc)
        assertEquals(2,days.size)
        assertEquals(12L,days[0].correct);assertEquals(5L,days[0].wrong)
        assertEquals(15L,days[1].correct);assertEquals(6L,days[1].wrong)
        assertEquals(questionTotals(records).total,days.last().total)
    }
    @Test fun filteringBeforeAccumulationKeepsSubjectsIndependent() {
        val records=listOf(QuestionRecord("a","math",9,1,100L),QuestionRecord("b","language",2,8,200L))
        val days=cumulativeQuestionDays(records.filter {it.subjectId=="math"},utc)
        assertEquals(10L,days.single().total);assertEquals(9L,days.single().correct)
    }
    @Test fun totalsDoNotOverflowIntAndDeletionRecalculates() {
        val records=(0..2999).map {QuestionRecord("$it","s",1_000_000,1_000_000,it.toLong())}
        assertEquals(6_000_000_000L,cumulativeQuestionDays(records,utc).single().total)
        assertEquals(5_998_000_000L,cumulativeQuestionDays(records.drop(1),utc).single().total)
        assertTrue(cumulativeQuestionDays(emptyList(),utc).isEmpty())
    }
    @Test fun groupingUsesRequestedLocalDay() {
        val records=listOf(QuestionRecord("a","s",1,0,0L),QuestionRecord("b","s",1,0,10_800_000L))
        assertEquals(1,cumulativeQuestionDays(records,utc).size)
        assertEquals(2,cumulativeQuestionDays(records,TimeZone.getTimeZone("GMT-03:00")).size)
    }
}
