package com.example

import com.example.data.drive.*
import org.junit.Assert.*
import org.junit.Test
import java.net.URLDecoder

class DriveRequestsTest {
    @Test fun mediaUsesApiAndCredentialsStayOutOfUrl() {
        val url = DriveRequests.file("real-ID_1", true)
        assertTrue(url.startsWith("https://www.googleapis.com/drive/v3/files/real-ID_1?"))
        assertTrue(url.contains("alt=media"))
        val headers = DriveCredentials("test-key").headers("app", "cert", "real-ID_1", "resource-key")
        assertEquals("test-key", headers["X-Goog-Api-Key"])
        assertEquals("real-ID_1/resource-key", headers["X-Goog-Drive-Resource-Keys"])
        assertFalse(url.contains("test-key"))
    }
    @Test fun googleAuthorizationReplacesAnonymousKey() {
        val headers = DriveCredentials("key", "token").headers("app", "cert", "id", "")
        assertEquals("Bearer token", headers["Authorization"])
        assertFalse(headers.containsKey("X-Goog-Api-Key"))
        assertFalse(headers.containsKey("X-Goog-Drive-Resource-Keys"))
    }
    @Test fun folderQueriesPreserveRealIdsAndPagination() {
        val url = URLDecoder.decode(DriveRequests.folder("folder_ID", "next+token"), "UTF-8")
        assertTrue(url.contains("'folder_ID' in parents and trashed = false"))
        assertTrue(url.contains("pageToken=next+token"))
        assertEquals("abc-def_1", DriveRequests.folderId("https://drive.google.com/drive/folders/abc-def_1?usp=sharing"))
        assertEquals("0-real_key", DriveRequests.resourceKey("https://drive.google.com/file/d/id/view?usp=sharing&resourcekey=0-real_key"))
    }
    @Test fun permissionsAndQuotaHaveDifferentRecoveryInstructions() {
        assertEquals("downloadQuotaExceeded", DriveRequests.errorReason("{\"error\":{\"errors\":[{\"reason\":\"downloadQuotaExceeded\"}]}}"))
        assertTrue(DriveRequests.errorMessage(404, "notFound").contains("autorize"))
        assertTrue(DriveRequests.errorMessage(403, "downloadQuotaExceeded").contains("limite"))
        assertTrue(DriveRequests.errorMessage(401, "authError").contains("expirou"))
        assertTrue(DriveRequests.errorMessage(403, "fileNotDownloadable").contains("proprietário"))
        assertTrue(DriveRequests.errorMessage(403, "accessNotConfigured").contains("Ative"))
    }
    @Test(expected = IllegalArgumentException::class) fun rejectInjectedFileIds() {
        DriveRequests.file("id?key=untrusted")
    }
}
