package com.example

import com.example.data.model.*
import org.junit.Assert.*
import org.junit.Test

class StudyItemTest {
    private fun item(kind: LinkKind = LinkKind.FILE) = StudyItem("id", "Fonética e acentuação", "01.mp4", "portugues",
        listOf("Aula 01"), ContentType.VIDEO, if (kind == LinkKind.FILE) "https://drive.google.com/file/d/realId/view?usp=drivesdk"
        else "https://drive.google.com/drive/folders/folderId", kind, if (kind == LinkKind.FILE) "realId" else "", "", "planilha.xlsx")
    @Test fun folderLinksAreNeverChangedToFilePreviews() {
        val folder = item(LinkKind.FOLDER)
        assertEquals(folder.url, folder.previewUrl)
        assertEquals("https://drive.google.com/file/d/realId/preview", item().previewUrl)
    }
    @Test fun onlyExpectedDriveLinksAreAllowed() {
        assertTrue(isAllowedDriveUrl(item().url))
        assertTrue(isAllowedDriveUrl(item(LinkKind.FOLDER).url))
        assertFalse(isAllowedDriveUrl("https://drive.google.com.evil.test/file/d/x"))
        assertFalse(isAllowedDriveUrl("http://drive.google.com/file/d/x"))
        assertFalse(isAllowedDriveUrl("javascript:alert(1)"))
        assertFalse(isAllowedDriveUrl("https://user@drive.google.com/file/d/x"))
    }
    @Test fun accentInsensitiveSearchAndExactFolderPrefixes() {
        assertTrue(item().matches("FONETICA"))
        assertTrue(item().matches("acentuacao"))
        assertFalse(item().matches("cardiologia"))
        assertEquals(1, itemsInPath(listOf(item()), listOf("Aula 01")).size)
        assertEquals(0, itemsInPath(listOf(item()), listOf("Aula 0")).size)
    }
}
