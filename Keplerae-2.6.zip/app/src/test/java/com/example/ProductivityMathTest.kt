package com.example

import com.example.data.productivity.*
import org.junit.Assert.*
import org.junit.Test

class ProductivityMathTest {
    @Test fun globalAccuracyWeightsEachQuestionRatherThanEachSession() {
        val records=listOf(QuestionRecord("a","s",1,0,0),QuestionRecord("b","s",0,9,0))
        val total=questionTotals(records)
        assertEquals(10L,total.total)
        assertEquals(10.0,total.accuracy,0.001)
        assertEquals(90.0,total.errorRate,0.001)
    }
    @Test fun rejectsEmptyNegativeAndOverflowInput() {
        assertFalse(validQuestionCounts(0,0));assertFalse(validQuestionCounts(-1,2))
        assertFalse(validQuestionCounts(null,3));assertFalse(validQuestionCounts(Int.MAX_VALUE,0))
        assertTrue(validQuestionCounts(0,8));assertTrue(validQuestionCounts(5,0))
    }
    @Test fun emptyStatsHaveNoNaNAndLargeTotalsUseLong() {
        assertEquals(0.0,questionTotals(emptyList()).accuracy,0.0)
        val records=(1..4000).map { QuestionRecord(it.toString(),"s",1_000_000,1_000_000,0) }
        assertEquals(8_000_000_000L,questionTotals(records).total)
    }
    @Test fun onlyFinishedFocusAddsTimeAndLongBreakFollowsFixedCycles() {
        val state=PomodoroState(running=true,phaseDurationMs=1_500_000,sessionId="focus1",cycle=3)
        val done=finishPhase(state,1234)
        assertEquals(PomodoroPhase.LONG_BREAK,done.phase)
        assertEquals(4,done.cycle);assertEquals(1,done.history.size)
        assertEquals(1_500_000L,done.history.single().durationMs)
        assertEquals(done,finishPhase(done,1500))
        val next=finishPhase(done.copy(running=true,sessionId="break1"),1800)
        assertEquals(PomodoroPhase.FOCUS,next.phase);assertEquals(0,next.cycle)
        assertEquals(1,next.history.size)
    }
    @Test fun pauseAndRestartRestoreDeadlineAndClampExpiredTimer() {
        val s=PomodoroState(running=true,deadlineWall=5000,deadlineElapsed=4000,bootEpoch=1000,phaseDurationMs=5000)
        assertEquals(3000L,remainingAt(s,2000,1000))
        assertEquals(0L,remainingAt(s,6000,5000))
        assertEquals(1700L,remainingAt(s.copy(running=false,remainingMs=1700),9000,8000))
    }
}
