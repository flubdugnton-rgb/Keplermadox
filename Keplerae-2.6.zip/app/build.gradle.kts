import java.security.KeyStore
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.example"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.aistudio.keplerae.stdy"
        minSdk = 24
        targetSdk = 36
        versionCode = 27
        versionName = "2.6.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    signingConfigs {
        getByName("debug") {
            val cachedKey = rootProject.file(".signing/debug.keystore")
            if (cachedKey.exists()) {
                storeFile = cachedKey
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures { compose = true }
}
kotlin { jvmToolchain(17) }
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.media3:media3-exoplayer:1.8.1")
    implementation("androidx.media3:media3-ui:1.8.1")
    implementation("androidx.media3:media3-session:1.8.1")
    implementation("com.google.android.gms:play-services-auth:22.0.0")
    // Haze 1.7.0 usa Compose 1.9.4. Mantenha todos os artefatos UI alinhados.
    val composeVersion = "1.9.4"
    implementation("androidx.credentials:credentials:1.6.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.6.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.10.2")
    implementation("dev.chrisbanes.haze:haze:1.7.0")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.compose.runtime:runtime:$composeVersion")
    implementation("androidx.compose.foundation:foundation:$composeVersion")
    implementation("androidx.compose.ui:ui:$composeVersion")
    implementation("androidx.compose.ui:ui-tooling-preview:$composeVersion")
    // Etapa 01 da versão 2.0: fontes Google, mesma versão do Compose UI.
    implementation("androidx.compose.ui:ui-text-google-fonts:$composeVersion")
    // Alpha autorizada: LoadingIndicator e indicadores ondulados Expressive.
    // Versão fixada para a base Compose 1.9 / SDK 36; não use '+' aqui.
    implementation("androidx.compose.material3:material3:1.5.0-alpha07")
    implementation("androidx.compose.animation:animation:$composeVersion")
    implementation("androidx.datastore:datastore-preferences:1.1.7")
    implementation("io.coil-kt.coil3:coil-compose:3.3.0")
    implementation("io.coil-kt.coil3:coil-network-okhttp:3.3.0")
    implementation("sh.calvin.reorderable:reorderable:2.5.1")
    implementation("androidx.compose.material:material-icons-extended:1.7.8")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4:$composeVersion")
    debugImplementation("androidx.compose.ui:ui-tooling:$composeVersion")
    debugImplementation("androidx.compose.ui:ui-test-manifest:$composeVersion")
}

// Nunca publica release com uma chave nova criada automaticamente pelo SDK.
val verifyReleaseSigning by tasks.registering {
    doLast {
        val file = rootProject.file(".signing/debug.keystore")
        check(file.isFile) { "Restaure KEPLERAE_KEYSTORE_B64 antes de gerar o APK release." }
        val keys = KeyStore.getInstance("JKS")
        file.inputStream().use { keys.load(it, "android".toCharArray()) }
        val certificate = keys.getCertificate("androiddebugkey")
        check(certificate != null) { "Alias androiddebugkey não encontrado." }
        val sha1 = MessageDigest.getInstance("SHA-1").digest(certificate.encoded)
            .joinToString("") { "%02X".format(it) }
        check(sha1 == "16007901DBBFAB9DE7B5539FFAC604FAF19DBC8A") { "Assinatura diferente da versão instalada." }
    }
}
tasks.matching { it.name == "validateSigningRelease" }.configureEach { dependsOn(verifyReleaseSigning) }
