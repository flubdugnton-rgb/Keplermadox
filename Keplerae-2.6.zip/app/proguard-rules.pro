# Conserva informações úteis para investigar falhas do APK otimizado.
-keepattributes SourceFile,LineNumberTable,Signature,*Annotation*
# Modelos JSON são codificados explicitamente; não usamos reflexão de nomes de campos.
# Media3, Credential Manager, Google Identity e Coil incluem consumer rules próprias.
# Cada execução publica mapping.txt junto dos relatórios para retrace de crashes.
