# Kepleræ 2.3.0 — código 24

- Inicial sem a barra superior duplicada de ícone/nome/paleta. Tema e perfil continuam disponíveis na página de perfil.
- Perfil Google persistido localmente; o app volta à inicial ao reabrir. Autorização Drive renovada em segundo plano ao voltar e a cada 45 minutos enquanto o processo estiver ativo. Tokens não são gravados.
- Desconectar limpa o perfil persistido e o estado do Credential Manager. Consentimento revogado ou conta removida pode exigir uma nova autorização do Drive.
- Menu Pomodoro após Matérias; menu Questões logo depois.
- Pomodoro: 25/5/15, 50/10/20 e 90/15/30; ciclos personalizados; iniciar, pausar, retomar, zerar e pular; avanço automático opcional; dois sons com opção de desligar.
- Cronômetro persistido com prazos, serviço em primeiro plano, notificação com contagem regressiva e ações, e recuperação ao reabrir. Permissão de notificações solicitada no início no Android 13+.
- Totais de focos completos/tempo, gráfico dos últimos 7 dias e histórico. Pausas e focos cancelados não contam. Conclusão idempotente não duplica sessões.
- Arte original: tomate astronauta na barquinha pescando estrelas/planetas com loop de oscilação e cintilação; cena estática de descanso em Saturno.
- Questões: criação de blocos por matéria, acertos/erros, calcular/salvar, datas locais automáticas, filtro por matéria, histórico com exclusão confirmada, dashboard de quantidades e percentuais, evolução diária.
- Estatística ponderada por quantidade de questões; totais em Long, validação de números negativos/zero/vazios/limites, sem divisão por zero.
- Novos testes para persistência de perfil, matemática das questões e transições/contagem do Pomodoro.

Preservados: os 1.022 materiais, links estáticos, transporte HTTP do Drive, reprodução nativa, PDF pager, favoritos, conclusões, reordenação, temas e assinatura de atualização.
