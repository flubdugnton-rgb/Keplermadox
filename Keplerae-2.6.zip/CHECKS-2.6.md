# Verificações — Kepleræ 2.6.0

## Executadas neste ambiente

| Verificação | Resultado |
|---|---|
| Catálogo de 1.022 itens, URLs e deduplicação | Passou; catálogo preservado |
| Permissões de rede | Passou |
| Delimitadores de 80 arquivos Kotlin/Gradle e 19 XMLs | Passou; análise estrutural, não compilação Kotlin |
| Referências de recursos e serviços | Passou |
| Nomes únicos dos recursos raw | Passou; não há WAV/OGG duplicando o mesmo ID |
| Versão 2.6.0 / código 27 | Conferida |
| Validação pública antes de restaurar assinatura | Conferida |
| Seis ambientes OGG | 120 s, mono 22.050 Hz, sem clipping digital ou salto atípico na volta |
| Relógio do Pomodoro | Bytes preservados da 2.5 |
| Scripts Python | Sintaxe validada |
| ZIP / YAML / shell do workflow | Conferidos na preparação final |

Os testes PCM comparam o salto entre última e primeira amostra com as variações da própria gravação. Não comprovam a reprodução sem pausa em todos os aparelhos, nem substituem ouvir os ambientes com fones.

## Preparadas para o GitHub, execução pendente

- `StudyAdjustmentsTest`: exclusão em cascata com totais derivados; ciclos customizados parados, em andamento e pausados; sons não reiniciam o progresso.
- `ReactiveThemeTest`: verifica a cor real de superfície ao trocar Claro/Escuro/Sistema, incluindo mudança da configuração Android.
- `ProfileTest`: seleção de Claro, Escuro e Sistema, preservando o fluxo de confirmação do logout.
- `FloatingNavigationTest`: cinco destinos, expansão, recolhimento e ausência dos três formatos como menus.
- `PomodoroCustomizationTest`: salva 42/7/19 minutos e seis focos; verifica store e contador de 42:00.
- `QuestionsDeletionTest`: cancelar, apagar bloco com registros, preservar outro bloco e reset global persistido.
- Testes existentes de PDF, anotações, Notas, dados e interface continuam incluídos. Os testes de fechamento das preferências e de busca de Notas foram corrigidos após as duas falhas na suíte da 2.5.
- Lint release, R8, geração do APK e abertura do release real no emulador API 35.

**Não existe APK 2.6 compilado nesta entrega.** A versão 2.5 anterior foi compilada e instalada pelo usuário. O novo código precisa passar no workflow da 2.6. A publicação automática do workflow retornou HTTP 403 (`Resource not accessible by integration`). Não foi tentado criar outra assinatura ou modificar o Secret existente.

## Conferência no aparelho após instalar

1. No perfil, toque no sol e na lua: toda a paleta muda imediatamente, com movimento dos raios/estrelas. Escolha Sistema, altere o tema Android e reabra; a preferência continua salva.
2. A barra fica embaixo em todas as larguras. Expanda/recolha e visite os cinco menus. Em Matérias, os filtros de formatos permanecem disponíveis.
3. Com o Pomodoro parado, personalize durações e focos; o contador deve atualizar. Durante uma etapa ativa/pausada, salvar mantém o tempo atual e usa os valores novos nas próximas etapas. Zerar aplica a nova duração da etapa atual.
4. Ouça os ambientes por mais de dois minutos, inclusive com tela bloqueada. Verifique loop, pausa, retomada, volume e interrupção por outro áudio. O relógio permanece igual.
5. Em Questões, cancele e confirme apagar um bloco. Apenas seus registros desaparecem. No menu, confirme Zerar tudo; outros módulos permanecem salvos. Feche/reabra para conferir persistência.
