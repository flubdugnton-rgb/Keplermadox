# Kepleræ 2.4.0 — Ambientes e evolução

- Barra geral com logo, nome e paleta removida de todos os destinos de estudo. Preferências continuam no perfil; pastas têm um botão de voltar no conteúdo.
- Pomodoro: cápsula de navegação com ícones, timer maior com algarismos tabulares, progresso ondulado visível desde 0%, superfícies suaves em claro e escuro.
- Estrelas com contraste específico em modo claro; mar cintilante, linha da vara e estrela pescada sobem e descem; estrela cadente ocasional.
- Saturno em repouso: estrelas móveis e reflexos orbitando os anéis; detalhes verde militar na arte.
- Ajustes inspirados na referência de meditação, com cartões lavanda, azul, menta e rosa e equivalentes escuros.
- Ambiente de foco contínuo opcional, volume próprio e 10 escolhas: relógio, vento, chuva, tempestade, lareira, quatro salões inspirados nas casas e biblioteca inspirada em Hogwarts.
- Alarme final e avanço automático continuam independentes. Ambiente para ao pausar, pular, zerar ou entrar em pausa; perda de foco sonoro e remoção de fones são tratadas pelo Android.
- Questões: dashboard elevado, filtros em cápsulas, blocos coloridos e três curvas acumuladas por dia (total/acertos/erros), com descrição acessível e datas reais.
- Taxas ponderadas, registros, filtros, exclusão com confirmação e totais em Long preservados.
- Leitura de dados 2.3 mantém ciclos e histórico; campos novos têm padrão ambiente desligado / chuva / 35%.
- Sem mudanças em login, autenticação Drive, catálogo de 1.022 itens ou players nativos.
- versionCode 25; versionName 2.4.0. Dependências mantidas, incluindo Material 3 1.5.0-alpha07.
