# Kepleræ 2.6.0

Projeto Android completo baseado na versão 2.5 instalada. Pacote `com.aistudio.keplerae.stdy`, versão 2.6.0, código 27. A atualização assinada com a chave existente preserva login, materiais, favoritos, conclusões, notas, anotações, questões e histórico do Pomodoro.

## Ajustes desta versão

- **Tema:** Claro e Escuro passam a atualizar as cores sem reiniciar a tela. A paleta de Pomodoro, Questões e Notas segue o tema aplicado ao app. No perfil, **Acompanhar o sistema** usa o tema do Android. Os raios do sol se movem e as estrelas da lua piscam ao tocar. A seleção continua salva pelo DataStore; cores dinâmicas e tipografia Google foram mantidas.
- **Navegação:** cápsula inferior flutuante Material 3 Expressive, com botão para expandir/recolher. Cinco menus: Início, Matérias, Pomodoro, Questões e Notas. Aulas/PDFs/Áudios permanecem disponíveis nos filtros de Matérias e nos atalhos da página inicial. Tablets também usam a barra inferior.
- **Ambientes do Pomodoro:** vento, chuva, tempestade, lareira, salão e biblioteca têm 120 segundos, com costuras de até três segundos e sobreposição equal-power. São colagens prolongadas das fontes existentes, com segmentos alternados; não são gravações novas de dois minutos. O relógio foi preservado. O player usa ExoPlayer em repetição e mantém o pipeline entre voltas. Sons e licença ficam incluídos no APK, sem depender da internet durante o foco.
- **Ciclos:** personalize durações e quantidade de focos mesmo quando há uma etapa em andamento ou pausada. Quando o timer está parado, salvar já prepara o novo foco e reinicia a contagem do ciclo, preservando o histórico. Uma etapa ativa mantém seu prazo; próximas etapas usam os valores novos. Para usar a duração nova na etapa atual, confirme **Zerar esta etapa**. Campos validam foco de 1–180 minutos, pausas de 1–90 minutos e 1–12 focos por ciclo.
- **Questões:** cada bloco tem botão de lixeira. A confirmação apaga o bloco e seus registros. O menu de três pontos oferece **Zerar tudo**, com confirmação, apagando os blocos e registros do módulo. Os totais e gráficos são recalculados. Materiais, Notas e Pomodoro ficam preservados.

PDF offline, página lembrada, caneta/marca-texto/borracha/pins, tela cheia, áudio em segundo plano, sessão Google, artes do Pomodoro e recursos da 2.5 continuam no projeto.

## Subir e compilar no GitHub

1. Envie `Keplerae-2.6.zip` **sem descompactar** à raiz de `flubdugnton-rgb/Keplermadox` e confirme o commit.
2. Substitua o conteúdo de `.github/workflows/compilar-apk.yml` pelo arquivo entregue separado. A cópia dentro do ZIP não muda o workflow externo. Confirme o commit; a compilação inicia automaticamente.
3. Preserve o Secret `KEPLERAE_KEYSTORE_B64` e a variável `GOOGLE_WEB_CLIENT_ID` já configurados. Pacote e certificado permanecem os mesmos; não é preciso refazer o login Google no Cloud.
4. Em **Actions → Compilar Keplerae 2.6 - Release**, acompanhe `apk` e `interface`. O artifact **Keplerae-2.6-APK** contém `Keplerae-2.6.0-release.apk`.
5. Instale por cima da 2.5, sem desinstalar. A assinatura do release deve continuar `16:00:79:01:DB:BF:AB:9D:E7:B5:53:9F:FA:C6:04:FA:F1:9D:BC:8A`.

Só o workflow externo compila o ZIP. Os ZIPs antigos podem permanecer no repositório; não são usados pela 2.6. Evite manter outro workflow de compilação disparando em paralelo. O workflow temporário de resgate não faz parte deste novo projeto; o Secret existente é a origem da assinatura.

## Dependências

Nenhuma biblioteca Android nova. Permanecem Gradle 8.13, AGP 8.11.1, Kotlin 2.2.21, Java 17, SDK 36 e Android mínimo 24. Este projeto usa Gradle instalado pelo CI, sem wrapper JAR.

| Recurso | Versão |
|---|---|
| Compose UI/Foundation/Animation | 1.9.4 |
| Material 3, incluindo HorizontalFloatingToolbar | **1.5.0-alpha07**, alpha já autorizada |
| Media3 ExoPlayer/UI/Session | 1.8.1 |
| Haze | 1.7.0 |
| Coil | 3.3.0 |
| Credential Manager | 1.6.0 |
| Google Identity googleid | 1.1.1 |
| DataStore Preferences | 1.1.7 |

As declarações completas estão em `app/build.gradle.kts` e no código completo entregue. Os sons públicos mantêm as atribuições em `app/src/main/assets/pomodoro_sound_credits.txt`.

## Validação

Estrutura, XMLs/recursos, catálogo de 1.022 itens, permissões de rede, duração/costura de seis ambientes e sintaxe Python foram verificados localmente. A compilação Kotlin, o lint e os novos testes Android **ainda não foram executados** nesta entrega: não há SDK/Gradle local e a integração GitHub recusou publicar o workflow com HTTP 403.

O workflow executa testes unitários release, lint, compilação otimizada, abertura do APK release real após R8 e testes de interface em emulador API 35. A abertura release acontece antes da suíte de interface, para não ficar bloqueada por falhas dessa suíte. A continuidade perceptiva dos sons deve ser conferida no aparelho; a verificação PCM não substitui escuta.

Veja `CHECKS-2.6.md`, `ARQUIVOS_ALTERADOS.md` e `CODIGO_COMPLETO.md`. Os changelogs e checks de versões anteriores são registros históricos da preparação dessas versões.

## Referências técnicas

- Material 3 Expressive: https://developer.android.com/jetpack/androidx/releases/compose-material3
- Floating toolbar: https://developer.android.com/reference/kotlin/androidx/compose/material3/package-summary
- Media3 Player: https://developer.android.com/reference/androidx/media3/common/Player
- Tema e cores dinâmicas: https://developer.android.com/develop/ui/compose/designsystems/material3
