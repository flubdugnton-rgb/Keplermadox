import os
import re
import subprocess
import sys
from pathlib import Path
from xml.etree import ElementTree

REQUIRED = {"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"}
ANDROID_NAME = "{http://schemas.android.com/apk/res/android}name"


def validate(permissions):
    missing = REQUIRED - set(permissions)
    if missing:
        raise ValueError("Permissões de rede ausentes: " + ", ".join(sorted(missing)))


if __name__ == "__main__":
    if len(sys.argv) == 2:
        sdk = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
        if not sdk:
            raise RuntimeError("SDK Android não encontrado")
        aapt = Path(sdk) / "build-tools" / "36.0.0" / "aapt"
        output = subprocess.check_output([str(aapt), "dump", "permissions", sys.argv[1]], text=True)
        validate(re.findall(r"uses-permission: name='([^']+)'", output))
        print("APK final: permissões de internet e estado da rede presentes.")
    else:
        manifest = ElementTree.parse("app/src/main/AndroidManifest.xml").getroot()
        validate(node.get(ANDROID_NAME) for node in manifest.findall("uses-permission"))
        print("Manifesto: permissões de rede corretas.")
