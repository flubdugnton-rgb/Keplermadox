#!/usr/bin/env python3
"""Confere duração e costuras dos ambientes incluídos, sem substituir escuta real."""
import array
import json
from pathlib import Path
import subprocess
ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT/'app/src/main/res/raw'
for name in ('wind', 'rain', 'storm', 'fire', 'room', 'library'):
    path = RAW/f'ambient_{name}.ogg'
    info = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_streams',
                                              '-show_format', '-of', 'json', str(path)]))
    assert abs(float(info['format']['duration']) - 120) < .02, path.name
    assert info['streams'][0]['channels'] == 1, path.name
    pcm = array.array('h')
    pcm.frombytes(subprocess.check_output(['ffmpeg', '-v', 'error', '-i', str(path),
                                         '-ac', '1', '-ar', '22050', '-f', 's16le', '-']))
    assert len(pcm) == 120*22050, path.name
    assert 100 < max(map(abs, pcm)) < 32767, path.name
    # Uma costura não deve exceder as variações presentes na própria gravação.
    differences = sorted(abs(pcm[i] - pcm[i-1]) for i in range(1, len(pcm), 10))
    typical_limit = differences[int(len(differences)*.99)]
    assert abs(pcm[-1] - pcm[0]) <= max(512, typical_limit), path.name
    assert not path.with_suffix('.wav').exists(), path.name
print('6 ambientes: 120s, mono, sem clipping digital nem salto atípico na costura.')
