#!/usr/bin/env python3
"""Importa as planilhas originais sem inventar URLs, títulos ou durações."""
import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse
from openpyxl import load_workbook

SOURCES = [
 ('Hu_Brasil_Fisioterapia_modulos_0_a_32(1).xlsx', 'fisioterapia', ['Fisioterapia']),
 ('Portugues_Adriana_Referencia-5-1(1).xlsx', 'portugues', ['Aulas']),
 ('Aulas_Raciocinio_Logico_e_Matematica(1).xlsx', 'matematica', ['Raciocínio Lógico e Matemática']),
 ('Aulas_Raciocinio_Logico_e_Matematica(2).xlsx', 'matematica', ['Raciocínio Lógico e Matemática']),
 ('Aulas_Legislacao_EBSERH(1).xlsx', 'hu_legislacao', ['Legislação EBSERH']),
 ('Aulas_SUS-1(1).xlsx', 'sus', ['Aulas SUS']),
 ('Aulas_Profisio(1).xlsx', 'profisio', ['Vídeos', 'Artigos', 'Áudios']),
]

def build(source_dir):
    items, seen, duplicates, skipped = [], set(), 0, []
    for name, subject, sheets in SOURCES:
        book = load_workbook(source_dir / name, data_only=True)
        for sheet_name in sheets:
            sheet = book[sheet_name]
            for row_no, row in enumerate(sheet.iter_rows(min_row=2), start=2):
                values = [c.value for c in row]
                if not any(values): continue
                module = str(values[0] or 'Geral').strip()
                portuguese = subject == 'portugues'
                filename = str(values[2 if portuguese else 1] or '').strip()
                link_cell = row[3]
                url = str(link_cell.hyperlink.target if link_cell.hyperlink else values[3] or '').strip()
                parsed = urlparse(url)
                if parsed.scheme != 'https' or parsed.hostname != 'drive.google.com':
                    skipped.append({'source':name,'sheet':sheet_name,'row':row_no,'reason':'Sem URL válida do Drive'})
                    continue
                folder = '/folders/' in parsed.path
                title_ref = str(values[5] or '').strip() if portuguese else ''
                title = title_ref if title_ref and title_ref != 'Nome individual a identificar' else re.sub(r'\.(mp4|pdf|mp3|m4a|wav)$','',filename,flags=re.I)
                ext = filename.lower().rsplit('.',1)[-1]
                kind = 'PDF' if ext == 'pdf' else 'AUDIO' if ext in ['mp3','m4a','wav'] else 'VIDEO'
                key = (subject,url,filename,module) if folder else (subject,parsed.path)
                if key in seen:
                    duplicates += 1
                    continue
                seen.add(key)
                notes = [str(values[6])] if portuguese and len(values)>6 and values[6] else []
                if folder: notes.append('A planilha fornece o link da pasta. Localize '+filename+' no Google Drive.')
                path = module.split(' / ') if subject == 'profisio' else [module]
                file_id = re.search(r'/file/d/([^/]+)',parsed.path)
                uid = hashlib.sha256(repr(key).encode()).hexdigest()[:20]
                items.append(dict(id=uid,title=title or filename,filename=filename,subjectId=subject,
                    folderPath=path,type=kind,url=url,linkKind='FOLDER' if folder else 'FILE',
                    driveFileId=file_id.group(1) if file_id else '',note=' '.join(notes),
                    source=name,sheet=sheet_name,row=row_no))
    report = dict(total=len(items),bySubject=dict(Counter(x['subjectId'] for x in items)),
                  byType=dict(Counter(x['type'] for x in items)),
                  fileLinks=sum(x['linkKind']=='FILE' for x in items),
                  folderLinks=sum(x['linkKind']=='FOLDER' for x in items),
                  duplicateRowsRemoved=duplicates,skippedRows=skipped)
    return items,report

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('source_dir',type=Path)
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'app/src/main/assets/catalog.json')
    args=parser.parse_args()
    items,report=build(args.source_dir)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n')
    (args.output.parent/'catalog_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False))
