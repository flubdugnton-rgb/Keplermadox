#!/usr/bin/env python3
import json
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse
root=Path(__file__).resolve().parents[1]
rows=json.loads((root/'app/src/main/assets/catalog.json').read_text())
report=json.loads((root/'app/src/main/assets/catalog_report.json').read_text())
assert len(rows)==report['total']==1022
assert len({r['id'] for r in rows})==len(rows)
assert set(r['subjectId'] for r in rows)=={'fisioterapia','portugues','matematica','hu_legislacao','sus','profisio'}
assert dict(Counter(r['type'] for r in rows))==report['byType']
for r in rows:
    u=urlparse(r['url'])
    assert u.scheme=='https' and u.hostname=='drive.google.com' and u.username is None
    assert r['title'] and r['filename'] and r['folderPath'] and r['source']
    assert all(p.strip() for p in r['folderPath'])
    if r['linkKind']=='FILE':
        assert '/file/d/' in u.path and r['driveFileId'] == u.path.split('/file/d/')[1].split('/')[0]
    else:
        assert '/drive/folders/' in u.path and not r['driveFileId']
        assert 'link da pasta' in r['note']
assert sum(r['linkKind']=='FOLDER' for r in rows)==342
assert not any('Keplerae_DriveFolderId' in r['url'] for r in rows)
assert sum(r['subjectId']=='matematica' for r in rows)==17
assert sum(r['type']=='AUDIO' for r in rows)==13
assert sum(r['subjectId']=='profisio' and r['type']=='PDF' for r in rows)==284
print('Catálogo validado: 1.022 itens; URLs, formatos, pastas e deduplicação consistentes.')
