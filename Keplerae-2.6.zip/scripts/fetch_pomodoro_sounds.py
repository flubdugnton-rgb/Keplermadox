#!/usr/bin/env python3
"""Instala sons de domínio público fixados em um commit, sem dependências extras.
Os WAVs originais incluídos no ZIP continuam utilizáveis se a origem estiver fora do ar.
"""
import hashlib
import io
import json
from pathlib import Path
import struct
import urllib.request
import wave

ROOT = Path(__file__).resolve().parents[1]
COMMIT = "0bdbbe370c42897e12b7c5b0b26d96228e0d2931"
FILES = [("bell1.wav", "3b7bf89fdf2a516aa27680f1c34c42af4a5025bb", "pomo_bell.wav"),
         ("metal1.wav", "9eba344bc130b5171d8393d46ad3c6f7ed67b8f5", "pomo_soft.wav")]

def normalized_wav(data):
    with wave.open(io.BytesIO(data)) as source:
        if source.getcomptype() != "NONE" or source.getsampwidth() not in (2, 3, 4):
            raise ValueError("Formato PCM não suportado")
        rate, channels, width = source.getframerate(), source.getnchannels(), source.getsampwidth()
        raw = source.readframes(min(source.getnframes(), int(rate * 2.4)))
    values = []
    step = width * channels
    for offset in range(0, len(raw) - step + 1, step):
        values.append(sum(int.from_bytes(raw[offset+c*width:offset+(c+1)*width], "little", signed=True)
                          for c in range(channels)) / channels)
    peak = max(map(abs, values), default=1) or 1
    pcm = bytearray()
    for index, value in enumerate(values):
        fade = min(1.0, index / max(1, int(rate*.008)), (len(values)-index) / max(1, int(rate*.15)))
        pcm.extend(struct.pack("<h", int(value/peak*12000*fade)))
    result=io.BytesIO()
    with wave.open(result,"wb") as output:
        output.setnchannels(1);output.setsampwidth(2);output.setframerate(rate);output.writeframes(pcm)
    return result.getvalue()

def main():
    provenance=[]
    for name, expected, destination in FILES:
        url=f"https://raw.githubusercontent.com/code4fukui/sound-cc0/{COMMIT}/{name}"
        path=ROOT/"app/src/main/res/raw"/destination
        try:
            request=urllib.request.Request(url,headers={"User-Agent":"Keplerae-build/2.3"})
            with urllib.request.urlopen(request,timeout=30) as response: data=response.read(5_000_000)
            actual=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
            if actual!=expected: raise ValueError("Hash da fonte difere do commit fixado")
            path.write_bytes(normalized_wav(data))
            provenance.append({"file":destination,"source":url,"license":"public domain / Unlicense", "git_blob":expected})
            print(f"Som público validado: {name}")
        except Exception as error:
            if not path.exists(): raise
            provenance.append({"file":destination,"source":"original tone bundled with Keplerae", "license":"CC0", "fallback":True})
            print(f"Origem indisponível; usando som original incluído ({type(error).__name__}).")
    (ROOT/"design/pomodoro-sound-provenance.json").write_text(json.dumps(provenance,indent=2)+"\n")

if __name__=="__main__":main()
