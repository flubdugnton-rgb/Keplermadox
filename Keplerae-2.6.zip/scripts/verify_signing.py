#!/usr/bin/env python3
import hashlib
import subprocess
import tempfile
from pathlib import Path
EXPECTED = '16007901DBBFAB9DE7B5539FFAC604FAF19DBC8A'
file = Path('.signing/debug.keystore')
if not file.is_file(): raise SystemExit('Assinatura anterior ausente. Não será criada uma chave nova.')
with tempfile.TemporaryDirectory() as temporary:
    cert = Path(temporary) / 'cert.der'
    subprocess.run(['keytool','-exportcert','-keystore',str(file),'-storepass','android',
                    '-alias','androiddebugkey','-file',str(cert)],check=True,capture_output=True)
    actual = hashlib.sha1(cert.read_bytes()).hexdigest().upper()
if actual != EXPECTED: raise SystemExit('A assinatura difere do APK instalado. Recupere a chave anterior.')
print('SHA-1 da versão instalada confirmado.')
