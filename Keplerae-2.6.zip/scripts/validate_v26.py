#!/usr/bin/env python3
"""Estrutura pública da versão 2.6; compilação e testes Android rodam no CI."""
from pathlib import Path
import runpy
ROOT = Path(__file__).resolve().parents[1]
runpy.run_path(str(ROOT/'scripts/validate_v25.py'), run_name='__main__')
gradle = (ROOT/'app/build.gradle.kts').read_text()
assert 'versionCode = 27' in gradle and 'versionName = "2.6.0"' in gradle
raw = ROOT/'app/src/main/res/raw'
names = [file.stem for file in raw.iterdir() if file.is_file()]
assert len(names) == len(set(names)), 'Recursos raw com o mesmo nome-base'
workflow = (ROOT/'.github/workflows/compilar-apk.yml').read_text()
assert 'Keplerae-2.6.zip' in workflow and 'assembleRelease' in workflow
assert workflow.index('validate_v26.py') < workflow.index('Restaurar assinatura')
assert 'KEPLERAE_KEYSTORE_B64' in workflow
assert 'actions/cache' not in workflow
print('Versão, recursos únicos, workflow release e restauração protegida: OK.')
