#!/usr/bin/env python3
"""Restaura o Secret sem imprimir sua representação base64 nem bytes privados."""
import base64
import os
from pathlib import Path
value = ''.join(os.environ.get('KEYSTORE_B64', '').split())
if not value:
    raise SystemExit('O Secret KEPLERAE_KEYSTORE_B64 não está configurado. Execute primeiro o resgate cifrado da assinatura anterior.')
try:
    contents = base64.b64decode(value, validate=True)
except ValueError:
    raise SystemExit('Secret de assinatura inválido: base64 incorreto.')
if not contents:
    raise SystemExit('Secret de assinatura vazio.')
folder = Path('.signing'); folder.mkdir(mode=0o700, exist_ok=True)
file = folder / 'debug.keystore'; file.write_bytes(contents); file.chmod(0o600)
print('Assinatura restaurada do Secret.')
