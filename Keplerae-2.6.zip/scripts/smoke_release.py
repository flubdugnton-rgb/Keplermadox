#!/usr/bin/env python3
"""Instala o release real e detecta encerramento/crash na abertura após R8."""
import subprocess
import sys
import time
PACKAGE = 'com.aistudio.keplerae.stdy'
def adb(*args): return subprocess.run(['adb', *args], check=True, capture_output=True, text=True).stdout
adb('install', '-r', sys.argv[1])
adb('logcat', '-c')
adb('shell','am','force-stop',PACKAGE)
adb('shell','am','start','-W','-n',f'{PACKAGE}/com.example.MainActivity')
time.sleep(6)
logs = adb('logcat','-d','-b','crash')
if PACKAGE in logs and ('FATAL EXCEPTION' in logs or 'Fatal signal' in logs):
    print(logs)
    raise SystemExit('O APK release falhou ao abrir.')
if not adb('shell','pidof',PACKAGE).strip(): raise SystemExit('O processo release não permaneceu aberto.')
print('APK release instalado e aberto no emulador.')
