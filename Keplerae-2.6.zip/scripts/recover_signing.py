#!/usr/bin/env python3
"""Descriptografa o artifact e configura o Secret via gh, sem mostrar a chave."""
import argparse
import base64
import hashlib
import subprocess
import tempfile
import zipfile
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--artifact',required=True)
p.add_argument('--private-key',required=True)
p.add_argument('--destination',required=True,help='Pasta privada fora do repositório')
p.add_argument('--repository',help='owner/repo: também configura KEPLERAE_KEYSTORE_B64 com gh já autenticado')
a=p.parse_args()
def run(args,**kwargs): return subprocess.run(args,check=True,capture_output=True,**kwargs)
with tempfile.TemporaryDirectory() as temporary:
    work=Path(temporary)
    with zipfile.ZipFile(a.artifact) as z:
        for name in ['debug.keystore.enc','key-password.enc']:
            matches=[n for n in z.namelist() if Path(n).name==name]
            if len(matches)!=1: raise SystemExit('Artifact cifrado inválido.')
            (work/name).write_bytes(z.read(matches[0]))
    password=work/'password'
    run(['openssl','pkeyutl','-decrypt','-inkey',a.private_key,'-in',str(work/'key-password.enc'),
         '-out',str(password),'-pkeyopt','rsa_padding_mode:oaep','-pkeyopt','rsa_oaep_md:sha256'])
    key=work/'debug.keystore'
    run(['openssl','enc','-d','-aes-256-cbc','-pbkdf2','-iter','200000','-in',str(work/'debug.keystore.enc'),
         '-out',str(key),'-pass',f'file:{password}'])
    cert=work/'cert.der'
    run(['keytool','-exportcert','-keystore',str(key),'-storepass','android','-alias','androiddebugkey','-file',str(cert)])
    if hashlib.sha1(cert.read_bytes()).hexdigest().upper()!='16007901DBBFAB9DE7B5539FFAC604FAF19DBC8A':
        raise SystemExit('SHA-1 incorreto. A chave não será usada.')
    dest=Path(a.destination).resolve();dest.mkdir(parents=True,exist_ok=True,mode=0o700)
    target=dest/'debug.keystore'
    if target.exists(): raise SystemExit('Já existe um backup neste destino; ele não será sobrescrito.')
    target.write_bytes(key.read_bytes());target.chmod(0o600)
    if a.repository:
        run(['gh','secret','set','KEPLERAE_KEYSTORE_B64','--repo',a.repository],input=base64.b64encode(key.read_bytes()))
        print('Secret de assinatura configurado.')
print('SHA-1 confirmado e backup privado salvo. Nenhuma chave foi exibida.')
