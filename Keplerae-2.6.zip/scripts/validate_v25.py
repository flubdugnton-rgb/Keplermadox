#!/usr/bin/env python3
"""Verificações estruturais; não substituem compilação Kotlin nem testes Android."""
import re
import xml.etree.ElementTree as ET
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
NS = '{http://schemas.android.com/apk/res/android}'
xml_files = list((ROOT/'app/src').rglob('*.xml'))
for file in xml_files: ET.parse(file)
manifest = ET.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot()
services = {s.attrib[NS+'name']:s for s in manifest.find('application').findall('service')}
assert '.data.playback.PlaybackService' in services
assert 'mediaPlayback' in services['.data.playback.PlaybackService'].attrib[NS+'foregroundServiceType']
assert any(a.attrib.get(NS+'name')=='androidx.media3.session.MediaSessionService'
           for a in services['.data.playback.PlaybackService'].iter('action'))
permissions = {p.attrib[NS+'name'] for p in manifest.findall('uses-permission')}
assert {'android.permission.INTERNET','android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK','android.permission.WAKE_LOCK'} <= permissions
# Recursos referenciados por Kotlin precisam existir antes de AAPT/AGP.
res = ROOT/'app/src/main/res'
resources = {}
for folder in res.iterdir():
    if not folder.is_dir(): continue
    kind = folder.name.split('-')[0]
    if kind == 'values':
        for file in folder.glob('*.xml'):
            for node in ET.parse(file).getroot():
                if 'name' in node.attrib: resources.setdefault(node.tag.replace('string-array','array'),set()).add(node.attrib['name'])
    else:
        resources.setdefault(kind,set()).update(p.stem for p in folder.iterdir() if p.is_file())
for file in (ROOT/'app/src/main/java').rglob('*.kt'):
    for kind,name in re.findall(r'(?<![\w.])R\.(\w+)\.(\w+)',file.read_text()):
        assert name in resources.get(kind,set()),f'Recurso ausente: {file.name}: R.{kind}.{name}'
# Nunca inclui material privado no pacote de código público.
for file in ROOT.rglob('*'):
    if file.is_file() and 'build' not in file.parts:
        assert file.suffix not in {'.keystore','.jks','.pem'},f'Material de assinatura no projeto: {file}'
assert not (ROOT/'.github/workflows/android-apk.yml').exists()
# Detecta delimitadores quebrados em edições, respeitando strings e comentários Kotlin.
def balanced(text):
    length=len(text)
    def comment(i):
        depth=1;i+=2
        while depth and i<length:
            if text.startswith('/*',i): depth+=1;i+=2
            elif text.startswith('*/',i): depth-=1;i+=2
            else:i+=1
        assert depth==0,'Comentário não fechado'
        return i
    def quoted(i):
        quote='"""' if text.startswith('"""',i) else text[i]
        i+=len(quote)
        while i<length:
            if text.startswith(quote,i):return i+len(quote)
            if quote!='"""' and text[i]=='\\':i+=2;continue
            if quote!='\'' and text.startswith('${',i):
                depth=1;i+=2
                while depth and i<length:
                    if text[i] in ['"',"'"]:i=quoted(i)
                    elif text.startswith('/*',i):i=comment(i)
                    elif text.startswith('//',i):i=text.find('\n',i) if '\n' in text[i:] else length
                    elif text[i]=='{':depth+=1;i+=1
                    elif text[i]=='}':depth-=1;i+=1
                    else:i+=1
                assert depth==0,'Interpolação não fechada'
            else:i+=1
        raise AssertionError('String não fechada')
    i=0;stack=[];pairs={')':'(',']':'[','}':'{'}
    while i<length:
        if text.startswith('//',i):i=text.find('\n',i) if '\n' in text[i:] else length
        elif text.startswith('/*',i):i=comment(i)
        elif text[i] in ['"',"'"]:i=quoted(i)
        elif text[i]=='`':
            i=text.find('`',i+1)+1;assert i>0,'Identificador não fechado'
        elif text[i] in '([{':stack.append(text[i]);i+=1
        elif text[i] in ')]}':
            assert stack and stack.pop()==pairs[text[i]],f'Delimitador incorreto na posição {i}'
            i+=1
        else:i+=1
    assert not stack,'Delimitador não fechado'
files=list((ROOT/'app/src').rglob('*.kt'))+list(ROOT.rglob('*.kts'))
for file in files:
    try:balanced(file.read_text())
    except AssertionError as error:raise AssertionError(f'{file.relative_to(ROOT)}: {error}') from error
print(f'Estrutura validada: {len(files)} arquivos Kotlin/Gradle, {len(xml_files)} XMLs, recursos e serviço de áudio.')
