"""Preenche o ID público Web pelo Actions ou confere o valor já salvo no XML."""
import os
import re
from pathlib import Path
from xml.etree import ElementTree

PATH = Path("app/src/main/res/values/google_login.xml")


def configure():
    document = ElementTree.parse(PATH)
    node = document.find(".//string[@name='google_web_client_id']")
    if node is None:
        raise ValueError("Recurso google_web_client_id ausente")
    value = (os.environ.get("GOOGLE_WEB_CLIENT_ID") or node.text or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]+\.apps\.googleusercontent\.com", value):
        raise ValueError(
            "Configure a variável GOOGLE_WEB_CLIENT_ID no GitHub ou preencha "
            "google_web_client_id em google_login.xml. Use o ID público OAuth do tipo Web "
            "no mesmo projeto do cliente Android. Chave de API e client secret não servem."
        )
    node.text = value
    document.write(PATH, encoding="utf-8", xml_declaration=True)
    # Não registrar valores de credenciais em logs, mesmo quando são IDs públicos.
    print("ID OAuth Web configurado; tipo de cliente deve ser Web no Google Cloud.")


if __name__ == "__main__":
    configure()
