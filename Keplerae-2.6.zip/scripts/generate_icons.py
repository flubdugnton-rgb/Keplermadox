#!/usr/bin/env python3
"""Integra os assets aprovados da 2.5, sem redesenhar o logo por código."""
from pathlib import Path
from PIL import Image, ImageDraw
root = Path(__file__).resolve().parents[1]
full = Image.open(root/'design/icon-512.png').convert('RGBA')
foreground = Image.open(root/'design/keplerae-2.5-emblem.png').convert('RGBA')
res = root/'app/src/main/res'
full.resize((512,512),Image.Resampling.LANCZOS).save(res/'drawable-nodpi/keplerae_logo.png')
# A figura ocupa a zona segura; cada launcher aplica sua própria máscara.
canvas = Image.new('RGBA',(432,432),(0,0,0,0))
canvas.alpha_composite(foreground.resize((288,288),Image.Resampling.LANCZOS),(72,72))
canvas.save(res/'drawable-nodpi/keplerae_launcher_foreground.png')
for density,size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    icon = full.resize((size,size),Image.Resampling.LANCZOS)
    icon.save(res/f'mipmap-{density}/ic_launcher.png')
    mask = Image.new('L',(size,size),0)
    ImageDraw.Draw(mask).ellipse((0,0,size-1,size-1),fill=255)
    icon.putalpha(mask);icon.save(res/f'mipmap-{density}/ic_launcher_round.png')
print('Ícones 2.5 gerados para todas as densidades.')
