# Kepleræ 2.6.0 — código 27

- Tema aplicado imediatamente no app. Perfil com Claro, Escuro e Acompanhar o sistema; sol e lua animam quando tocados. Preferência continua no DataStore.
- Navegação inferior flutuante Expressive, expansível e recolhível, em celulares e tablets: Início, Matérias, Pomodoro, Questões e Notas. Os formatos continuam nos filtros de Matérias.
- Ambientes, exceto relógio, preparados em OGG de 120 segundos com segmentos alternados e costuras equal-power de até três segundos. Relógio preservado. Reprodução em ExoPlayer com repetição, sem recriar o player a cada volta.
- Personalização e presets do Pomodoro sempre acessíveis. Quando parado, o foco e o contador usam o novo ciclo imediatamente. Durante foco/pausa ativa ou pausada, a etapa atual mantém o tempo; próximas etapas usam as novas configurações.
- Questões permite apagar bloco e registros associados com confirmação, além de zerar todo o módulo. Totais e gráficos usam os registros restantes.
- Testes de interface cobrem tema real, navegação, ciclo personalizado e exclusão persistida. Correções nos testes antigos do fechamento das preferências e da busca em Notas.
- Assinatura e configuração Google existentes preservadas. Nenhuma dependência Android nova.
