# Arquivos alterados — Kepleræ 1.0.1

Comparação com o projeto 2.6. O ZIP é o projeto inteiro; estes caminhos identificam as mudanças desta entrega.

As bibliotecas foram mantidas. No Gradle do app, somente versionName/versionCode foram alterados.

## Alterados

- `.github/workflows/compilar-apk.yml`
- `README.md`
- `app/build.gradle.kts`
- `app/src/androidTest/java/com/example/InterfaceTest.kt`
- `app/src/androidTest/java/com/example/ProfileTest.kt`
- `app/src/main/assets/pomodoro_sound_credits.txt`
- `app/src/main/java/com/example/data/notes/NoteStore.kt`
- `app/src/main/java/com/example/data/pdf/PdfAnnotations.kt`
- `app/src/main/java/com/example/data/productivity/PomodoroStore.kt`
- `app/src/main/java/com/example/data/productivity/QuestionStore.kt`
- `app/src/main/java/com/example/data/repository/AppearancePreferences.kt`
- `app/src/main/java/com/example/data/repository/StudyViewModel.kt`
- `app/src/main/java/com/example/ui/CatalogScreen.kt`
- `app/src/main/java/com/example/ui/DriveViewer.kt`
- `app/src/main/java/com/example/ui/KepleraeApp.kt`
- `app/src/main/java/com/example/ui/profile/ProfileScreen.kt`
- `scripts/fetch_ambient_sounds.py`
- `ARQUIVOS_ALTERADOS.md`

## Adicionados

- `BACKUP_FORMAT.md`
- `CHECKS-1.0.1.md`
- `app/src/androidTest/java/com/example/BackupImportTest.kt`
- `app/src/androidTest/java/com/example/BackupJsonTest.kt`
- `app/src/androidTest/java/com/example/SidebarNavigationTest.kt`
- `app/src/main/java/com/example/data/backup/BackupJson.kt`
- `app/src/main/java/com/example/data/backup/BackupModel.kt`
- `app/src/main/java/com/example/data/backup/BackupRepository.kt`
- `app/src/main/java/com/example/ui/backup/BackupControls.kt`
- `app/src/main/java/com/example/ui/components/SidebarNavigation.kt`
- `app/src/test/java/com/example/BackupMergeTest.kt`
- `docs/history/VERIFICACAO.json`
- `docs/history/verification.json`
- `scripts/validate_release.py`
- `verification.json`

## Removidos ou movidos

- `VERIFICACAO.json`
- `app/src/androidTest/java/com/example/FloatingNavigationTest.kt`
- `app/src/main/java/com/example/ui/components/FloatingAppNavigation.kt`
- `scripts/validate_v26.py`
- `verification.json`

Os relatórios JSON antigos foram movidos para docs/history. O validador atual é scripts/validate_release.py.
O arquivo externo .github/workflows/compilar-apk.yml precisa ser substituído no GitHub; a cópia dentro do ZIP serve como fonte.
