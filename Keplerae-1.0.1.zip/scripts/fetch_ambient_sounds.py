#!/usr/bin/env python3
"""Ambientes locais de 120s, costuras equal-power e atribuição preservada.
O relógio fica intacto. Sem rede, conserva os OGGs prontos incluídos.
"""
import argparse
import array
import hashlib
import json
import math
from pathlib import Path
import subprocess
import tempfile
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'app/src/main/res/raw'
ASSETS=ROOT/'app/src/main/assets'
RATE=22050
SECONDS=120
BLANKET='775f2a767230a9681850d1b1e085be58656f1382'
SOURCES=[
 ('fire',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/fireplace.ogg','10890350b03b3644bc11299637a915a8738faceb','ezwa','Public Domain','https://soundbible.com/1543-Fireplace.html'),
 ('wind',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/wind.ogg','349b7d398194e60e60629b8952fadf2b54b64fd9','felix.blume; edição Porrumentzio','CC0 1.0','https://freesound.org/people/felix.blume/sounds/217506/'),
 ('room',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/coffee-shop.ogg','a93acfbde2c3cddf4ac31bc27d14f19b44121aa5','stephan','Public Domain','https://soundbible.com/1664-Restaurant-Ambiance.html'),
 ('storm',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/storm.ogg','cf6f788da00f9c3fc7ab014f538afc51eaf26b12','digifishmusic; edição Porrumentzio','CC BY 4.0','https://freesound.org/people/digifishmusic/sounds/41739/'),
 ('rain','https://raw.githubusercontent.com/mateusfg7/Noisekun/main/.github/assets/sounds/rain.ogg','7945216b9e95dcf5493848d752e3d639f91e8f01','SFXProducer','CC0 1.0','https://www.youtube.com/watch?v=3oMcTXhXOpc'),
]

def download(url):
 req=urllib.request.Request(url,headers={'User-Agent':'Keplerae-build/1.0.1'})
 with urllib.request.urlopen(req,timeout=25) as response:data=response.read(16_000_001)
 if len(data)>16_000_000:raise ValueError('Arquivo maior que o limite')
 return data

def cross(a,b):
 """Equal power conserva energia entre segmentos não correlacionados."""
 n=len(a)
 return array.array('f',(a[i]*math.cos(math.pi/2*i/(n-1))+b[i]*math.sin(math.pi/2*i/(n-1)) for i in range(n)))

def seal(values,overlap):
 # Termina antes da cauda que abre a volta seguinte: sem fade até silêncio.
 return cross(values[-overlap:],values[:overlap])+values[overlap:-overlap]

def seamless_pcm(data,seconds=SECONDS):
 with tempfile.TemporaryDirectory() as folder:
  source=Path(folder)/'source';source.write_bytes(data)
  raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(source),'-t','300','-ac','1','-ar',str(RATE),'-f','s16le','-'],timeout=40)
 values=array.array('h');values.frombytes(raw)
 if len(values)<100:raise ValueError('Som vazio')
 overlap=min(3*RATE,len(values)//4)
 base=seal(array.array('f',values),overlap);result=base[:]
 target=seconds*RATE+overlap;offsets=(.17,.43,.71,.29,.83,.57);step=0
 while len(result)<target:
  offset=int(len(base)*offsets[step%len(offsets)])
  segment=base[offset:]+base[:offset]
  result=result[:-overlap]+cross(result[-overlap:],segment[:overlap])+segment[overlap:];step+=1
 result=seal(result[:target],overlap)
 peak=max(map(abs,result)) or 1
 return array.array('h',(round(value/peak*15000) for value in result))

def prepare(data,destination):
 pcm=seamless_pcm(data)
 subprocess.run(['ffmpeg','-y','-v','error','-f','s16le','-ar',str(RATE),'-ac','1','-i','-','-c:a','libvorbis','-q:a','4',str(destination)],input=pcm.tobytes(),check=True,timeout=40)
 destination.with_suffix('.wav').unlink(missing_ok=True)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--local-sources',type=Path);parser.add_argument('--offline',action='store_true');args=parser.parse_args()
 provenance_path=ROOT/'design/ambient-sound-provenance.json'
 existing=json.loads(provenance_path.read_text()) if provenance_path.exists() else []
 provenance={Path(item['file']).stem:item for item in existing}
 for name,url,expected,author,license_name,original in SOURCES:
  destination=RAW/f'ambient_{name}.ogg';local=args.local_sources/f'{name}.ogg' if args.local_sources else None
  try:
   if local and local.exists():data=local.read_bytes()
   elif args.offline:raise ConnectionError('Modo offline')
   else:data=download(url)
   actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   if actual!=expected:raise ValueError('Fonte alterada')
   prepare(data,destination)
   provenance[f'ambient_{name}']={'file':destination.name,'author':author,'license':license_name,'source':original,'git_blob':expected,'download':url}
   print(f'Ambiente preparado: {destination.name}, {SECONDS}s')
  except (OSError,ValueError,subprocess.SubprocessError) as error:
   if not destination.exists():
    fallback=destination.with_suffix('.wav')
    if not fallback.exists():raise
    prepare(fallback.read_bytes(),destination)
   print(f'Ambiente incluído preservado: {destination.name} ({type(error).__name__})')
 library=RAW/'ambient_library.ogg'
 if not library.exists():prepare(library.with_suffix('.wav').read_bytes(),library)
 # Android usa o nome-base como ID: não pode haver WAV e OGG do mesmo som.
 for destination in RAW.glob('ambient_*.ogg'):
  destination.with_suffix('.wav').unlink(missing_ok=True)
 for stem,item in provenance.items():
  if stem=='ambient_clock':continue
  item['file']=stem+'.ogg'
  item['changes']='120s, mono 22050Hz, normalização, segmentos alternados e costuras equal-power de até 3s'
 provenance_path.write_text(json.dumps(list(provenance.values()),ensure_ascii=False,indent=2)+'\n')
 credits=['SONS DE AMBIENTE — KEPLERÆ 1.0.1','']
 for item in provenance.values():credits.extend([item['file']+' — '+item['author'],item['license'],item['source'],item.get('changes',''),''])
 credits.extend(['CC0: https://creativecommons.org/publicdomain/zero/1.0/','CC BY 4.0: https://creativecommons.org/licenses/by/4.0/',
  'Casas e biblioteca: combinações inspiradas; sem trilhas ou gravações dos filmes.',
  'Relógio preservado. Outros ambientes: colagem de segmentos com transições; não são gravações novas de dois minutos.'])
 (ASSETS/'pomodoro_sound_credits.txt').write_text('\n'.join(credits)+'\n')

if __name__=='__main__':main()
