#!/usr/bin/env python3
"""Validação estrutural pública da release 1.0.1; testes Kotlin/Android rodam no CI."""
from pathlib import Path
import runpy
ROOT=Path(__file__).resolve().parents[1]
runpy.run_path(str(ROOT/'scripts/validate_v25.py'),run_name='__main__')
gradle=(ROOT/'app/build.gradle.kts').read_text()
assert 'versionCode = 28' in gradle and 'versionName = "1.0.1"' in gradle
assert 'isMinifyEnabled = true' in gradle and 'isShrinkResources = true' in gradle
workflow=(ROOT/'.github/workflows/compilar-apk.yml').read_text()
assert 'Keplerae-1.0.1.zip' in workflow and 'assembleRelease' in workflow
assert workflow.index('validate_release.py')<workflow.index('Restaurar assinatura')
assert 'KEPLERAE_KEYSTORE_B64' in workflow and 'actions/cache' not in workflow
raw=ROOT/'app/src/main/res/raw'
names=[f.stem for f in raw.iterdir() if f.is_file()]
assert len(names)==len(set(names)), 'Recursos raw duplicados'
ui=ROOT/'app/src/main/java/com/example/ui'
app=(ui/'KepleraeApp.kt').read_text()
assert 'SidebarNavigation(' in app and 'FloatingAppNavigation' not in app and 'bottomBar =' not in app
sidebar=(ui/'components/SidebarNavigation.kt').read_text()
assert 'profile_rail' in sidebar and 'GoogleAvatar' in sidebar
profile=(ui/'profile/ProfileScreen.kt').read_text()
assert 'backupContent()' in profile and 'Kepleræ 1.0.1' in profile
codec=(ROOT/'app/src/main/java/com/example/data/backup/BackupJson.kt').read_text()
assert 'schemaVersion' in codec and 'MAX_BACKUP_BYTES' in codec
for private in ('accessToken','idToken','apiKey','keystore','password','photoUrl','email'):
    assert f'.put("{private}"' not in codec, f'Credencial/conta no backup: {private}'
assert 'backup_confirm_import' in (ui/'backup/BackupControls.kt').read_text()
print('Release 1.0.1/código 28, navegação lateral, backup portátil e workflow: estrutura OK.')
