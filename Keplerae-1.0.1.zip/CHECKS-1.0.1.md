# Verificações — Kepleræ 1.0.1

## Executadas localmente nesta entrega

| Check | Resultado |
|---|---|
| Análise estrutural Kotlin/Gradle | Passou: 87 arquivos; verifica delimitadores, não tipos nem compilação |
| XMLs e referências de recursos | Passou: 19 XMLs, recursos e serviço de áudio |
| Catálogo | Passou: 1.022 itens, URLs, formatos, pastas e deduplicação |
| Catálogo e arquivos de áudio comparados com 2.6 | Iguais byte a byte |
| Permissões de rede | Passou |
| Duração/costura dos seis ambientes | Passou: 120 s, mono, sem clipping digital ou salto PCM atípico |
| Versão | 1.0.1 / código 28; mesmo pacote |
| Workflow e assinatura | Release otimizado; Secret e SHA-1 existente; código público validado antes da chave |
| Código de backup | Formato/schema, limite de tamanho, validação prévia, IDs, mesclagem e seleção de arquivos conferidos |
| Pacote final | ZIP testado e fontes comparados após empacotar; sem keystore/JKS/PEM |

A análise estrutural é uma verificação local limitada. Este ambiente não tem Android SDK/Gradle; **não foram executados compilação Kotlin, lint ou os novos testes Android da 1.0.1**. O relatório da 2.6 abaixo não comprova as alterações novas.

## Testes novos/ajustados no projeto, para execução no CI

- BackupMergeTest: nota mais recente, remapeamento de blocos/matérias, preservação de totais, histórico de foco e anotações sem duplicatas.
- BackupJsonTest: round-trip de todas as seções e rejeição de schema/referência/contagem/ID inválidos.
- BackupImportTest: gravação nos stores, importação repetida, preservação de registros e exportação de PDF importado ainda não baixado.
- SidebarNavigationTest: cinco menus, seleção de seção, avatar e acesso ao perfil.
- ProfileTest: perfil aberto pela barra lateral a partir de Matérias, botões de backup, temas e confirmação de logout.
- InterfaceTest: rolagem da lista antes de localizar o resultado de busca.

O workflow roda testReleaseUnitTest, lintRelease, assembleRelease e assembleDebugAndroidTest. No emulador API 35, abre primeiro o APK release real (já com R8) e depois roda connectedDebugAndroidTest.

## Evidência da base 2.6, anterior a esta alteração

GitHub Actions run **37922410646**, commit **d4025218afb7e605d1c5a33b878cb9a391a7f78a**:
- Job apk: sucesso, 34 testes unitários passaram, lint passou e APK release compilado.
- Smoke release: abriu e manteve o processo no emulador.
- Interface: 17/18 testes passaram. A falha foi InterfaceTest na busca de um item fora da área renderizada da lista, corrigida no teste nesta entrega.
- Tema reativo, navegação inferior da base, ciclos personalizados e exclusões de Questões passaram. A navegação foi substituída por barra lateral e será testada novamente.

## Conferência no aparelho após compilar

1. Instalar por cima; conferir versão 1.0.1 e manutenção da sessão/dados.
2. Em Matérias/Pomodoro/Questões/Notas e num material aberto, tocar a foto lateral. Voltar do perfil deve retornar ao material.
3. Exportar pelo perfil, de preferência para o Drive; importar e confirmar; repetir a importação e conferir que totais não dobram.
4. Conferir uma nota com bloco, um registro de Questões, foco contabilizado, tema, página de PDF e traço/pin.
5. Invalidar schemaVersion de uma cópia do JSON: o app deve recusar antes de importar.

Guardar os relatórios do CI e conferir o SHA-1 existente antes da instalação. Nenhum APK da 1.0.1 é incluído neste pacote de fontes.
