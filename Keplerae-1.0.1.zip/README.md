# Kepleræ 1.0.1 — Release

Projeto Android completo baseado na 2.6 já compilada e instalada. O nome público volta para **1.0.1**, como solicitado. O código interno sobe para **28**; pacote `com.aistudio.keplerae.stdy` e certificado permanecem os mesmos, permitindo instalar por cima da 2.6 (código 27), sem desinstalar nem apagar dados.

## Mudanças

- Navegação lateral estreita, inspirada no print do Instagram: cinco ícones monocromáticos (Início, Matérias, Pomodoro, Questões, Notas) e foto Google. O perfil pode ser aberto nas seções e no visualizador de materiais. Em tela cheia, a faixa se recolhe para liberar a tela. Ao abrir o perfil a partir de um material, Voltar retorna ao material.
- No perfil, junto do seletor de tema, **Exportar dados e configurações** e **Importar dados e configurações**. Usa JSON versionado e o seletor de arquivos do Android; o destino pode ser armazenamento local ou Google Drive, quando o provedor do Drive está disponível.
- Exporta preferências de tema/cores, favoritos/conclusões/últimos acessos/ordem dos materiais, blocos e notas, matérias e registros de Questões, configurações e histórico de foco do Pomodoro, páginas de leitura e desenhos/pins de PDFs da conta atual.
- Importação confirma os totais antes de salvar. Combina registros por IDs, reaproveita blocos com o mesmo nome e mantém a edição mais recente das notas. Importar o mesmo arquivo novamente não duplica registros. As preferências do arquivo são aplicadas; o timer em andamento mantém seu prazo.
- O contrato usa IDs do Drive e coordenadas normalizadas, com documentação e exemplo em `BACKUP_FORMAT.md`. Uma futura versão iOS/macOS poderá implementar o mesmo contrato. Essas versões ainda não existem; o formato não cria sincronização automática.

## Os dados já estão na conta Google?

O login Google identifica a conta e autoriza leitura do Drive. O app mantém os registros no aparelho e **não tem um serviço próprio de sincronização**. O Android pode incluí-los no backup do dispositivo quando esse recurso está ativado e suas condições são atendidas; isso é diferente de sincronização entre as versões do Kepleræ. A exportação permite guardar uma cópia no Drive e depois importá-la explicitamente.

O JSON não inclui login, tokens, chave de API, assinatura, foto/email da conta, mídia nem os PDFs baixados. Após transferir para outro dispositivo, faça login normalmente para abrir os materiais privados. As anotações serão associadas ao mesmo ID do PDF; o arquivo poderá ser baixado novamente pelo Drive.

## Subir e compilar

1. Envie `Keplerae-1.0.1.zip` **sem descompactar** à raiz de `flubdugnton-rgb/Keplermadox` e confirme o commit.
2. Substitua `.github/workflows/compilar-apk.yml` pelo arquivo separado entregue, mantendo esse caminho. A cópia dentro do ZIP não altera o workflow externo. Confirme o commit.
3. Preserve o Secret `KEPLERAE_KEYSTORE_B64` e a variável `GOOGLE_WEB_CLIENT_ID` existentes. Não precisa refazer o cadastro no Google Cloud.
4. Em **Actions → Compilar Keplerae 1.0.1 - Release**, acompanhe `apk` e `interface`. O artifact **Keplerae-1.0.1-APK** contém `Keplerae-1.0.1-release.apk`.
5. Instale por cima da atual, sem desinstalar. O SHA-1 da assinatura deve continuar `16:00:79:01:DB:BF:AB:9D:E7:B5:53:9F:FA:C6:04:FA:F1:9D:BC:8A`.

Os ZIPs antigos podem permanecer: este workflow utiliza apenas `Keplerae-1.0.1.zip`. A compilação pública valida o código antes de restaurar a assinatura do Secret e recusa uma chave diferente. Não publique o keystore junto do projeto.

## Código e dependências

Nenhuma biblioteca nova. Permanecem Java 17, Gradle 8.13, AGP 8.11.1, Kotlin 2.2.21, SDK 36 e Android mínimo 24. O CI instala Gradle; não há wrapper JAR.

| Biblioteca | Versão |
|---|---|
| Compose UI / Foundation / Animation | 1.9.4 |
| Material 3 Expressive | **1.5.0-alpha07**, já autorizada |
| Media3 ExoPlayer / UI / Session | 1.8.1 |
| Haze | 1.7.0 |
| Coil | 3.3.0 |
| Credential Manager | 1.6.0 |
| Google Identity googleid | 1.1.1 |
| DataStore Preferences | 1.1.7 |

Tema reativo claro/escuro/sistema, animações do sol/lua, sons ambientes de 120 segundos, ciclos personalizados, exclusão em Questões, Notas, áudio em segundo plano, PDF offline/anotações e sessão persistente da 2.6 continuam. As dependências completas estão em `app/build.gradle.kts`; todos os fontes e testes estão no ZIP e no `CODIGO_COMPLETO.md`.

## Validação

Consulte `CHECKS-1.0.1.md`. As verificações estruturais locais passaram. **A versão 1.0.1 ainda precisa da compilação Kotlin, lint, testes unitários e de dispositivo no GitHub**, pois este ambiente não tem SDK/Gradle. O workflow executa esses checks e abre o APK release após R8 antes dos testes de interface.

A base 2.6 foi compilada no run 37922410646: 34 testes unitários e lint passaram; o APK release abriu no emulador; 17 de 18 testes de interface passaram. O teste de busca que falhou por item fora da área da lista recebeu a rolagem necessária nesta versão. Isso não substitui os novos testes de 1.0.1.

A tentativa de envio direto desta entrega também foi recusada pela integração GitHub com HTTP 403 (Resource not accessible by integration). Os dois arquivos para upload e o passo a passo acima estão prontos; nenhum novo commit ou APK 1.0.1 foi publicado por esta sessão.

Documentos antigos (`CHANGELOG-2.*`, `CHECKS-2.*` e `docs/history`) são históricos. `ARQUIVOS_ALTERADOS.md`, `BACKUP_FORMAT.md` e `CHECKS-1.0.1.md` descrevem esta entrega.

## Referências

- Backup Android: https://developer.android.com/identity/data/autobackup
- Seletor de arquivos: https://developer.android.com/training/data-storage/shared/documents-files
- Versionamento Android: https://developer.android.com/studio/publish/versioning
- Material 3: https://developer.android.com/jetpack/androidx/releases/compose-material3
