package com.example

import com.example.data.backup.*
import com.example.data.notes.*
import com.example.data.pdf.*
import com.example.data.productivity.*
import org.junit.Assert.*
import org.junit.Test

class BackupMergeTest {
    @Test fun newerNoteWinsAndSameNamedTagIsRemappedWithoutDuplicates() {
        val local=NoteState(listOf(NoteTag("local","Estudo")),
            listOf(Note("n","Antiga","", "local",0,1,10)))
        val incoming=NoteState(listOf(NoteTag("other","ESTUDO")),
            listOf(Note("n","Atualizada","texto","other",2,1,20),
                Note("new","Nova","texto",null,0,2,30)))
        val merged=mergeNotes(local,incoming)
        assertEquals(1,merged.tags.size)
        assertEquals("local",merged.notes.first {it.id=="n"}.tagId)
        assertEquals("Atualizada",merged.notes.first {it.id=="n"}.title)
        assertEquals(merged,mergeNotes(merged,incoming))
        assertEquals(merged,mergeNotes(merged,local))
    }
    @Test fun questionRecordsKeepTotalsAndUseExistingSubjectByName() {
        val local=QuestionState(listOf(QuestionSubject("a","SUS")),
            listOf(QuestionRecord("old","a",8,2,1)))
        val incoming=QuestionState(listOf(QuestionSubject("b","sus")),
            listOf(QuestionRecord("new","b",9,1,2)))
        val merged=mergeQuestions(local,incoming)
        assertEquals(1,merged.subjects.size)
        assertTrue(merged.records.all {it.subjectId=="a"})
        assertEquals(QuestionTotals(17,3),questionTotals(merged.records))
        assertEquals(merged,mergeQuestions(merged,incoming))
    }
    @Test fun focusHistoryDoesNotDoubleCountWhenImportedTwice() {
        val local=listOf(FocusRecord("first",100,60_000))
        val incoming=listOf(FocusRecord("second",200,120_000),local.first())
        val merged=mergeHistory(local,incoming)
        assertEquals(2,merged.size)
        assertEquals(180_000L,merged.sumOf {it.durationMs})
        assertEquals(merged,mergeHistory(merged,incoming))
    }
    @Test fun annotationsKeepExistingInkAndAddImportedPinsAndPages() {
        val stroke=InkStroke("s",listOf(InkPoint(.2f,.3f)),false,0xFF123456L,.01f)
        val note=PdfNote("pin",InkPoint(.4f,.5f),"Revisar")
        val local=AnnotationDocument(mapOf(0 to PageAnnotations(listOf(stroke))))
        val incoming=AnnotationDocument(mapOf(0 to PageAnnotations(listOf(stroke),listOf(note)),
            2 to PageAnnotations(notes=listOf(note.copy(id="pin2")))))
        val merged=mergeAnnotations(local,incoming)
        assertEquals(listOf(stroke),merged.pages[0]!!.strokes)
        assertEquals(listOf(note),merged.pages[0]!!.notes)
        assertEquals(2,merged.pages.size)
        assertEquals(merged,mergeAnnotations(merged,incoming))
    }
}
