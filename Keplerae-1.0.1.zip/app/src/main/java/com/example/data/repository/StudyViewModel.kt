package com.example.data.repository

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

enum class ThemeMode(val label: String) { SYSTEM("Sistema"), LIGHT("Claro"), DARK("Escuro") }
data class StudyState(
    val items: List<StudyItem> = emptyList(),
    val favorites: Set<String> = emptySet(),
    val completed: Set<String> = emptySet(),
    val accessed: Map<String, Long> = emptyMap(),
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val itemOrder: List<String> = emptyList(),
    val loading: Boolean = true,
    val error: String? = null
)
class StudyViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application
    private val preferences = application.getSharedPreferences("keplerae", 0)
    private val appearancePreferences = AppearancePreferences(application)
    private val mutableState = MutableStateFlow(StudyState(
        favorites = preferences.getStringSet("favorites", emptySet())!!.toSet(),
        completed = preferences.getStringSet("completed", emptySet())!!.toSet(),
        accessed = readAccessed(),
        theme = runCatching { ThemeMode.valueOf(preferences.getString("theme", "SYSTEM")!!) }.getOrDefault(ThemeMode.SYSTEM),
        dynamicColor = preferences.getBoolean("dynamic_color", true),
        itemOrder = runCatching {
            val array = JSONArray(preferences.getString("item_order", "[]")!!)
            List(array.length()) { array.getString(it) }
        }.getOrDefault(emptyList()),
    ))
    val state = mutableState.asStateFlow()
    init {
        reload()
        viewModelScope.launch {
            appearancePreferences.appearance.collect { appearance ->
                mutableState.update { it.copy(theme = appearance.theme, dynamicColor = appearance.dynamicColor) }
            }
        }
    }
    fun reload() {
        mutableState.value = mutableState.value.copy(loading = true, error = null)
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching {
                val json = JSONArray(app.assets.open("catalog.json").bufferedReader().use { it.readText() })
                List(json.length()) { index ->
                    val row = json.getJSONObject(index)
                    val path = row.getJSONArray("folderPath")
                    StudyItem(row.getString("id"), row.getString("title"), row.getString("filename"),
                        row.getString("subjectId"), List(path.length()) { path.getString(it) },
                        ContentType.valueOf(row.getString("type")), row.getString("url"),
                        LinkKind.valueOf(row.getString("linkKind")), row.getString("driveFileId"),
                        row.getString("note"), row.getString("source"))
                }.also { rows -> require(rows.all { isAllowedDriveUrl(it.url) }) }
            } }
            mutableState.value = result.fold(
                onSuccess = { mutableState.value.copy(items = it, loading = false) },
                onFailure = { mutableState.value.copy(loading = false, error = "Não foi possível carregar a biblioteca.") }
            )
        }
    }
    private fun readAccessed(): Map<String,Long> = runCatching {
        val json = JSONObject(preferences.getString("accessed", "{}")!!)
        json.keys().asSequence().associateWith { json.getLong(it) }
    }.getOrDefault(emptyMap())
    fun toggleFavorite(id: String) {
        val next = mutableState.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        preferences.edit().putStringSet("favorites", next).apply()
        mutableState.value = mutableState.value.copy(favorites = next)
    }
    fun toggleCompleted(id: String) {
        val next = mutableState.value.completed.toMutableSet().apply { if (!add(id)) remove(id) }
        preferences.edit().putStringSet("completed", next).apply()
        mutableState.value = mutableState.value.copy(completed = next)
    }
    fun recordAccess(id: String) {
        val next = mutableState.value.accessed + (id to System.currentTimeMillis())
        preferences.edit().putString("accessed", JSONObject(next).toString()).apply()
        mutableState.value = mutableState.value.copy(accessed = next)
    }
    fun setTheme(theme: ThemeMode) {
        mutableState.update { it.copy(theme = theme) }
        viewModelScope.launch { appearancePreferences.setTheme(theme) }
    }
    fun setDynamicColor(enabled: Boolean) {
        mutableState.update { it.copy(dynamicColor = enabled) }
        viewModelScope.launch { appearancePreferences.setDynamicColor(enabled) }
    }
    fun saveVisibleOrder(visibleIds: List<String>) {
        val current = mutableState.value
        val fullOrder = reconcileOrder(current.items.map { it.id }, current.itemOrder)
        val next = mergeVisibleOrder(fullOrder, visibleIds)
        preferences.edit().putString("item_order", JSONArray(next).toString()).apply()
        mutableState.update { it.copy(itemOrder = next) }
    }
    /** Mescla registros de estudo e aplica a preferência importada em uma gravação DataStore. */
    suspend fun importData(incoming: com.example.data.backup.StudyBackup) {
        val current=mutableState.value
        val favorites=current.favorites+incoming.favorites
        val completed=current.completed+incoming.completed
        val accessed=(current.accessed.keys+incoming.accessed.keys).associateWith {
            maxOf(current.accessed[it] ?: 0L,incoming.accessed[it] ?: 0L)
        }
        val order=(incoming.itemOrder+current.itemOrder).distinct()
        withContext(Dispatchers.IO) {
            check(preferences.edit().putStringSet("favorites",favorites).putStringSet("completed",completed)
                .putString("accessed",JSONObject(accessed).toString()).putString("item_order",JSONArray(order).toString()).commit())
        }
        appearancePreferences.setAppearance(incoming.theme,incoming.dynamicColor)
        mutableState.update { it.copy(favorites=favorites,completed=completed,accessed=accessed,
            itemOrder=order,theme=incoming.theme,dynamicColor=incoming.dynamicColor) }
    }
}
