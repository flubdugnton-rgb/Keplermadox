package com.example.data.productivity

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Um único proprietário no processo, compartilhado pela tela e pelo serviço. */
class PomodoroStore private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("keplerae_pomodoro", Context.MODE_PRIVATE)
    private val mutable = MutableStateFlow(read())
    val state = mutable.asStateFlow()
    private fun read(): PomodoroState = runCatching {
        val j = JSONObject(prefs.getString("state", "{}") ?: "{}")
        val s = j.optJSONObject("settings") ?: JSONObject()
        val settings = PomodoroSettings(s.optInt("focus",25), s.optInt("short",5), s.optInt("long",15),
            s.optInt("cycles",4), s.optBoolean("sounds",true), s.optString("sound","bell"), s.optBoolean("auto",false),
            s.optBoolean("ambienceEnabled",false),s.optString("ambienceId","rain"),s.optDouble("ambienceVolume",.35).toFloat())
            .takeIf { it.valid() } ?: PomodoroSettings()
        val h = j.optJSONArray("history") ?: JSONArray()
        val history = (0 until h.length()).map { h.getJSONObject(it) }.map {
            FocusRecord(it.getString("id"), it.getLong("at"), it.getLong("duration")) }
        val phase = runCatching { PomodoroPhase.valueOf(j.optString("phase","FOCUS")) }.getOrDefault(PomodoroPhase.FOCUS)
        PomodoroState(settings,phase,j.optBoolean("running"),j.optBoolean("paused"),
            j.optLong("remaining",settings.duration(phase)),j.optLong("duration",settings.duration(phase)),
            j.optLong("wall"),j.optLong("elapsed"),j.optLong("boot"),j.optInt("cycle"),j.optString("session"),history)
    }.getOrDefault(PomodoroState())
    private fun save(s: PomodoroState, durable: Boolean = false) {
        val c=s.settings
        val j=JSONObject().put("settings",JSONObject().put("focus",c.focusMinutes).put("short",c.shortMinutes)
            .put("long",c.longMinutes).put("cycles",c.cycles).put("sounds",c.sounds).put("sound",c.sound).put("auto",c.autoAdvance)
            .put("ambienceEnabled",c.ambienceEnabled).put("ambienceId",c.ambienceId).put("ambienceVolume",c.ambienceVolume.toDouble()))
            .put("phase",s.phase.name).put("running",s.running).put("paused",s.paused).put("remaining",s.remainingMs)
            .put("duration",s.phaseDurationMs).put("wall",s.deadlineWall).put("elapsed",s.deadlineElapsed)
            .put("boot",s.bootEpoch).put("cycle",s.cycle).put("session",s.sessionId)
            .put("history",JSONArray().apply { s.history.forEach { put(JSONObject().put("id",it.id).put("at",it.finishedAt).put("duration",it.durationMs)) } })
        // Uma transação para estado + histórico: reabrir não duplica conclusões.
        val saved=prefs.edit().putString("state",j.toString()).commit()
        if(durable)check(saved) {"Não foi possível salvar o Pomodoro."}
        mutable.value=s
    }
    @Synchronized fun start() {
        val s=mutable.value
        if (s.running) return
        val wall=System.currentTimeMillis(); val elapsed=SystemClock.elapsedRealtime()
        val remain=if (s.paused) s.remainingMs else s.settings.duration(s.phase)
        save(s.copy(running=true,paused=false,remainingMs=remain,deadlineWall=wall+remain,deadlineElapsed=elapsed+remain,
            phaseDurationMs=if(s.paused)s.phaseDurationMs else remain,
            bootEpoch=wall-elapsed,sessionId=s.sessionId.ifBlank { UUID.randomUUID().toString() }))
    }
    @Synchronized fun pause() {
        val s=mutable.value
        if (s.running) save(s.copy(running=false,paused=true,
            remainingMs=remainingAt(s,System.currentTimeMillis(),SystemClock.elapsedRealtime())))
    }
    @Synchronized fun reset() {
        val s=mutable.value
        save(s.copy(running=false,paused=false,remainingMs=s.settings.duration(s.phase),
            phaseDurationMs=s.settings.duration(s.phase),sessionId="",deadlineWall=0,deadlineElapsed=0))
    }
    @Synchronized fun skip() {
        val s=mutable.value
        val next=if(s.phase==PomodoroPhase.FOCUS) PomodoroPhase.SHORT_BREAK else PomodoroPhase.FOCUS
        save(s.copy(phase=next,running=false,paused=false,remainingMs=s.settings.duration(next),
            phaseDurationMs=s.settings.duration(next),sessionId="",deadlineWall=0,deadlineElapsed=0))
    }
    @Synchronized fun finishIfDue(): Boolean {
        val s=mutable.value
        if(!s.running || remainingAt(s,System.currentTimeMillis(),SystemClock.elapsedRealtime())>0) return false
        save(finishPhase(s,System.currentTimeMillis()))
        return true
    }
    @Synchronized fun configure(settings: PomodoroSettings) {
        require(settings.valid())
        save(applyPomodoroSettings(mutable.value, settings))
    }
    @Synchronized fun importData(settings: PomodoroSettings, history: List<FocusRecord>) {
        val current=mutable.value
        save(applyPomodoroSettings(current,settings).copy(
            history=com.example.data.backup.mergeHistory(current.history,history)),true)
    }
    companion object {
        @Volatile private var instance: PomodoroStore?=null
        fun get(context: Context): PomodoroStore = instance ?: synchronized(this) {
            instance ?: PomodoroStore(context).also { instance=it } }
    }
}
