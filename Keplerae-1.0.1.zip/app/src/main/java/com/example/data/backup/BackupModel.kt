package com.example.data.backup

import com.example.data.notes.*
import com.example.data.pdf.AnnotationDocument
import com.example.data.productivity.*
import com.example.data.repository.ThemeMode

const val BACKUP_FORMAT = "keplerae-backup"
const val BACKUP_SCHEMA = 1
const val MAX_BACKUP_BYTES = 25 * 1024 * 1024

data class StudyBackup(val favorites: Set<String>, val completed: Set<String>,
    val accessed: Map<String,Long>, val itemOrder: List<String>,
    val theme: ThemeMode, val dynamicColor: Boolean)
data class PdfBackup(val driveFileId: String, val lastPage: Int, val annotations: AnnotationDocument)
data class PortableBackup(val exportedAt: Long, val study: StudyBackup,
    val notes: NoteState, val questions: QuestionState,
    val pomodoroSettings: PomodoroSettings, val focusHistory: List<FocusRecord>,
    val documents: List<PdfBackup>, val stylusOnly: Boolean, val straightHighlight: Boolean) {
    fun summary() = "${notes.notes.size} notas • ${questions.records.size} registros de questões • " +
        "${focusHistory.size} pomodoros • ${documents.size} PDFs com leitura/anotações"
}

/** Importações sucessivas são idempotentes; registros existentes não são apagados. */
fun mergeNotes(local: NoteState, incoming: NoteState): NoteState {
    val tags=local.tags.toMutableList();val ids=mutableMapOf<String,String>()
    incoming.tags.forEach { tag ->
        val match=tags.firstOrNull {it.id==tag.id} ?: tags.firstOrNull {it.name.equals(tag.name,true)}
        ids[tag.id]=match?.id ?: tag.id
        if(match==null)tags.add(tag)
    }
    val notes=local.notes.associateBy {it.id}.toMutableMap()
    incoming.notes.forEach { note ->
        val adjusted=note.copy(tagId=note.tagId?.let {ids[it] ?: it})
        val old=notes[note.id]
        if(old==null || adjusted.updatedAt>old.updatedAt)notes[note.id]=adjusted
    }
    return NoteState(tags,notes.values.toList())
}
fun mergeQuestions(local: QuestionState, incoming: QuestionState): QuestionState {
    val subjects=local.subjects.toMutableList();val ids=mutableMapOf<String,String>()
    incoming.subjects.forEach { subject ->
        val match=subjects.firstOrNull {it.id==subject.id} ?: subjects.firstOrNull {it.name.equals(subject.name,true)}
        ids[subject.id]=match?.id ?: subject.id
        if(match==null)subjects.add(subject)
    }
    val records=local.records.associateBy {it.id}.toMutableMap()
    incoming.records.forEach {record ->
        if(record.id !in records)records[record.id]=record.copy(subjectId=ids[record.subjectId] ?: record.subjectId)
    }
    return QuestionState(subjects,records.values.toList())
}
fun mergeHistory(local: List<FocusRecord>, incoming: List<FocusRecord>): List<FocusRecord> =
    (local+incoming).distinctBy {it.id}.sortedBy {it.finishedAt}
fun mergeAnnotations(local: AnnotationDocument, incoming: AnnotationDocument): AnnotationDocument =
    AnnotationDocument((local.pages.keys+incoming.pages.keys).associateWith { page ->
        val before=local.pages[page] ?: com.example.data.pdf.PageAnnotations()
        val added=incoming.pages[page] ?: com.example.data.pdf.PageAnnotations()
        com.example.data.pdf.PageAnnotations((before.strokes+added.strokes).distinctBy {it.id},
            (before.notes+added.notes).distinctBy {it.id})
    })
