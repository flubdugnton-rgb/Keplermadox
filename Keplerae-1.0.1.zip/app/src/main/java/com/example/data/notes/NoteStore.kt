package com.example.data.notes

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Guarda blocos e anotações neste aparelho (entram no backup automático do Android). */
class NoteStore private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("keplerae_notes", Context.MODE_PRIVATE)
    private val mutable = MutableStateFlow(read())
    val state: StateFlow<NoteState> = mutable.asStateFlow()

    private fun read(): NoteState = runCatching {
        val root = JSONObject(prefs.getString("state", "{}") ?: "{}")
        val tags = root.optJSONArray("tags") ?: JSONArray()
        val notes = root.optJSONArray("notes") ?: JSONArray()
        NoteState(
            tags = (0 until tags.length()).map { tags.getJSONObject(it) }
                .map { NoteTag(it.getString("id"), it.getString("name")) },
            notes = (0 until notes.length()).map { notes.getJSONObject(it) }.map {
                Note(
                    id = it.getString("id"),
                    title = it.optString("title"),
                    body = it.optString("body"),
                    tagId = it.optString("tag").takeIf { tag -> tag.isNotBlank() },
                    tone = it.optInt("tone", 0).coerceIn(0, NOTE_TONE_COUNT - 1),
                    createdAt = it.optLong("created"),
                    updatedAt = it.optLong("updated"),
                )
            },
        )
    }.getOrDefault(NoteState())

    private fun write(next: NoteState, durable: Boolean = false) {
        val json = JSONObject()
            .put("tags", JSONArray().apply {
                next.tags.forEach { put(JSONObject().put("id", it.id).put("name", it.name)) }
            })
            .put("notes", JSONArray().apply {
                next.notes.forEach {
                    put(
                        JSONObject().put("id", it.id).put("title", it.title).put("body", it.body)
                            .put("tag", it.tagId ?: "").put("tone", it.tone)
                            .put("created", it.createdAt).put("updated", it.updatedAt)
                    )
                }
            })
        val edit=prefs.edit().putString("state",json.toString())
        if(durable)check(edit.commit()) {"Não foi possível salvar as notas."} else edit.apply()
        mutable.value = next
    }

    @Synchronized fun upsert(note: Note) {
        val current = mutable.value
        val notes = if (current.notes.any { it.id == note.id })
            current.notes.map { if (it.id == note.id) note else it }
        else current.notes + note
        write(current.copy(notes = notes))
    }

    @Synchronized fun delete(id: String) {
        val current = mutable.value
        write(current.copy(notes = current.notes.filterNot { it.id == id }))
    }

    @Synchronized fun importData(incoming: NoteState) {
        write(com.example.data.backup.mergeNotes(mutable.value, incoming),true)
    }

    /** Reaproveita um bloco existente com o mesmo nome (sem diferenciar maiúsculas). */
    @Synchronized fun createTag(name: String): String {
        val clean = cleanTagName(name)
        require(clean.isNotBlank() && clean.length <= 30) { "Use um nome de 1 a 30 caracteres." }
        val current = mutable.value
        current.tags.firstOrNull { it.name.equals(clean, true) }?.let { return it.id }
        val tag = NoteTag(UUID.randomUUID().toString(), clean)
        write(current.copy(tags = current.tags + tag))
        return tag.id
    }

    @Synchronized fun renameTag(id: String, name: String) {
        val clean = cleanTagName(name)
        require(clean.isNotBlank() && clean.length <= 30) { "Use um nome de 1 a 30 caracteres." }
        val current = mutable.value
        require(current.tags.none { it.id != id && it.name.equals(clean, true) }) { "Esse bloco já existe." }
        write(current.copy(tags = current.tags.map { if (it.id == id) it.copy(name = clean) else it }))
    }

    /** As anotações do bloco excluído continuam salvas, apenas sem bloco. */
    @Synchronized fun deleteTag(id: String) {
        val current = mutable.value
        write(
            current.copy(
                tags = current.tags.filterNot { it.id == id },
                notes = current.notes.map { if (it.tagId == id) it.copy(tagId = null) else it },
            )
        )
    }

    companion object {
        @Volatile private var instance: NoteStore? = null
        fun get(context: Context): NoteStore = instance ?: synchronized(this) {
            instance ?: NoteStore(context).also { instance = it }
        }
    }
}
