package com.example.data.backup

import android.content.Context
import android.net.Uri
import android.util.AtomicFile
import com.example.data.notes.NoteStore
import com.example.data.pdf.*
import com.example.data.productivity.*
import com.example.data.repository.StudyViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

/** Usa o seletor Android: o usuário pode escolher arquivo local ou Google Drive. */
class BackupRepository(context: Context) {
    private val app=context.applicationContext
    private val reading=app.getSharedPreferences("keplerae_pdf_reading",Context.MODE_PRIVATE)
    private fun key(id: String)=pdfStorageKey(pdfAccountKey(app),id)
    private fun indexKey()="backup_documents_${key("index")}"
    private fun annotationFile(id: String)=File(File(app.filesDir,"annotations"),"${key(id)}.json")

    suspend fun snapshot(model: StudyViewModel): PortableBackup = withContext(Dispatchers.IO) {
        PdfAnnotationStore.flushAll()
        val state=model.state.value
        val notes=NoteStore.get(app).state.value;val questions=QuestionStore.get(app).state.value
        val pomodoro=PomodoroStore.get(app).state.value
        // IDs do catálogo e metadados de PDFs baixados também cobrem pastas do Drive.
        val ids=linkedSetOf<String>()
        ids.addAll(reading.getStringSet(indexKey(),emptySet()) ?: emptySet())
        val catalog=JSONArray(app.assets.open("catalog.json").bufferedReader().use {it.readText()})
        for(i in 0 until catalog.length())catalog.getJSONObject(i).optString("driveFileId").takeIf {it.isNotBlank()}?.let(ids::add)
        File(app.filesDir,"pdfs").listFiles()?.filter {it.extension=="json"}?.forEach {file->
            val id=runCatching {JSONObject(file.readText()).getString("id")}.getOrNull()
            if(id!=null && file.nameWithoutExtension==key(id))ids.add(id)
        }
        val documents=ids.mapNotNull {id->
            val file=annotationFile(id);val stored=reading.contains(key(id))
            if(!file.exists()&&!stored)null else PdfBackup(id,reading.getInt(key(id),0),
                if(file.exists())BackupJson.decodeAnnotations(JSONObject(AtomicFile(file).openRead().bufferedReader().use {it.readText()})) else AnnotationDocument())
        }
        PortableBackup(System.currentTimeMillis(),StudyBackup(state.favorites,state.completed,state.accessed,
            state.itemOrder,state.theme,state.dynamicColor),notes,questions,pomodoro.settings,pomodoro.history,
            documents,reading.getBoolean("stylus_only",false),reading.getBoolean("straight_highlight",true))
    }
    suspend fun export(uri: Uri, model: StudyViewModel) = withContext(Dispatchers.IO) {
        val json=BackupJson.encode(snapshot(model))
        // Valida o próprio arquivo antes de entregar o backup ao provedor externo.
        BackupJson.decode(json)
        val bytes=json.toByteArray(Charsets.UTF_8)
        check(bytes.size<=MAX_BACKUP_BYTES) {"Os dados excedem o limite de 25 MB."}
        val stream=app.contentResolver.openOutputStream(uri,"wt") ?: error("Não foi possível criar o arquivo.")
        stream.use {it.write(bytes);it.flush()}
    }
    suspend fun read(uri: Uri): PortableBackup = withContext(Dispatchers.IO) {
        val input=app.contentResolver.openInputStream(uri) ?: error("Não foi possível abrir o arquivo.")
        val output=ByteArrayOutputStream()
        input.use {stream->
            val buffer=ByteArray(8192)
            while(true) {
                val count=stream.read(buffer);if(count<0)break
                require(output.size()+count<=MAX_BACKUP_BYTES) {"Backup maior que 25 MB."}
                output.write(buffer,0,count)
            }
        }
        BackupJson.decode(output.toString("UTF-8"))
    }
    /** Mescla por IDs; não importa conta/token, timer em andamento ou cache dos PDFs. */
    suspend fun importBackup(backup: PortableBackup, model: StudyViewModel) {
        // Protege também quem chama o repositório diretamente, sem a tela de confirmação.
        BackupJson.decode(BackupJson.encode(backup))
        withContext(Dispatchers.IO) {
            PdfAnnotationStore.flushAll()
            backup.documents.forEach {document->
                val file=annotationFile(document.driveFileId)
                val old=if(file.exists())BackupJson.decodeAnnotations(JSONObject(AtomicFile(file).openRead().bufferedReader().use {it.readText()})) else AnnotationDocument()
                val merged=mergeAnnotations(old,document.annotations)
                file.parentFile?.mkdirs()
                val atomic=AtomicFile(file);val output=atomic.startWrite()
                try {output.write(BackupJson.encodeAnnotations(merged).toString().toByteArray());atomic.finishWrite(output)}
                catch(error:Exception) {atomic.failWrite(output);throw error}
            }
            check(reading.edit().apply {
                backup.documents.forEach {putInt(key(it.driveFileId),it.lastPage)}
                putStringSet(indexKey(),(reading.getStringSet(indexKey(),emptySet()) ?: emptySet())+
                    backup.documents.map {it.driveFileId})
                putBoolean("stylus_only",backup.stylusOnly);putBoolean("straight_highlight",backup.straightHighlight)
            }.commit()) {"Não foi possível salvar a leitura dos PDFs."}
            NoteStore.get(app).importData(backup.notes)
            QuestionStore.get(app).importData(backup.questions)
            PomodoroStore.get(app).importData(backup.pomodoroSettings,backup.focusHistory)
        }
        model.importData(backup.study)
    }
}
