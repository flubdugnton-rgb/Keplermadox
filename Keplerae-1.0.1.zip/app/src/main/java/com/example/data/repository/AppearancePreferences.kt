package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.SharedPreferencesMigration
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

// Uma única instância por arquivo, inclusive após recriações da Activity.
private val Context.appearanceDataStore by preferencesDataStore(
    name = "keplerae_appearance",
    produceMigrations = { context ->
        // Migra apenas aparência. Favoritos, conclusões e histórico continuam intactos.
        listOf(SharedPreferencesMigration(context, "keplerae", setOf("theme", "dynamic_color")))
    },
)

data class Appearance(val theme: ThemeMode = ThemeMode.SYSTEM, val dynamicColor: Boolean = true)

class AppearancePreferences(context: Context) {
    private val store = context.applicationContext.appearanceDataStore
    private val themeKey = stringPreferencesKey("theme")
    private val dynamicKey = booleanPreferencesKey("dynamic_color")
    val appearance = store.data.catch { error ->
        if (error is IOException) emit(emptyPreferences()) else throw error
    }.map { prefs ->
        Appearance(
            runCatching { ThemeMode.valueOf(prefs[themeKey] ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM),
            prefs[dynamicKey] ?: true,
        )
    }
    suspend fun setTheme(theme: ThemeMode) { store.edit { it[themeKey] = theme.name } }
    suspend fun setDynamicColor(enabled: Boolean) { store.edit { it[dynamicKey] = enabled } }
    suspend fun setAppearance(theme: ThemeMode, dynamic: Boolean) {
        store.edit { it[themeKey] = theme.name; it[dynamicKey] = dynamic }
    }
}
