package com.example.data.backup

import com.example.data.notes.*
import com.example.data.pdf.*
import com.example.data.productivity.*
import com.example.data.repository.ThemeMode
import org.json.JSONArray
import org.json.JSONObject

/** Contrato JSON versionado, sem caminhos Android, credenciais ou arquivos de mídia. */
object BackupJson {
    private fun <T> array(values: Iterable<T>, map: (T)->Any): JSONArray =
        JSONArray().apply {values.forEach {put(map(it))}}
    private fun JSONArray.objects(): List<JSONObject> {
        require(length()<=50_000) {"Backup com registros demais."}
        return List(length()) {getJSONObject(it)}
    }
    private fun strings(a: JSONArray): List<String> {
        require(a.length()<=50_000)
        return List(a.length()) {a.getString(it).also(::id)}.also {require(it.distinct().size==it.size)}
    }
    private fun id(value: String) {require(value.length in 1..256 && value.none {it.isISOControl()}) {"Identificador inválido."}}
    private fun text(value: String, limit: Int) {require(value.length<=limit) {"Texto excede o limite."}}
    private fun timestamp(value: Long) {require(value>=0) {"Data inválida."}}
    private fun unique(ids: List<String>) {ids.forEach(::id);require(ids.distinct().size==ids.size) {"Registros duplicados no arquivo."}}

    fun encode(backup: PortableBackup): String {
        val s=backup.study;val c=backup.pomodoroSettings
        return JSONObject().put("format",BACKUP_FORMAT).put("schemaVersion",BACKUP_SCHEMA)
            .put("appVersion","1.0.1").put("exportedAt",backup.exportedAt)
            .put("study",JSONObject().put("favorites",array(s.favorites){it}).put("completed",array(s.completed){it})
                .put("itemOrder",array(s.itemOrder){it}).put("accessed",array(s.accessed.entries){JSONObject().put("id",it.key).put("at",it.value)})
                .put("theme",s.theme.name).put("dynamicColor",s.dynamicColor))
            .put("notes",JSONObject().put("tags",array(backup.notes.tags){JSONObject().put("id",it.id).put("name",it.name)})
                .put("items",array(backup.notes.notes){JSONObject().put("id",it.id).put("title",it.title).put("body",it.body)
                    .put("tagId",it.tagId ?: JSONObject.NULL).put("tone",it.tone).put("createdAt",it.createdAt).put("updatedAt",it.updatedAt)}))
            .put("questions",JSONObject().put("subjects",array(backup.questions.subjects){JSONObject().put("id",it.id).put("name",it.name)})
                .put("records",array(backup.questions.records){JSONObject().put("id",it.id).put("subjectId",it.subjectId)
                    .put("correct",it.correct).put("wrong",it.wrong).put("recordedAt",it.recordedAt)}))
            .put("pomodoro",JSONObject().put("settings",JSONObject().put("focusMinutes",c.focusMinutes).put("shortMinutes",c.shortMinutes)
                .put("longMinutes",c.longMinutes).put("cycles",c.cycles).put("sounds",c.sounds).put("sound",c.sound)
                .put("autoAdvance",c.autoAdvance).put("ambienceEnabled",c.ambienceEnabled).put("ambienceId",c.ambienceId).put("ambienceVolume",c.ambienceVolume.toDouble()))
                .put("history",array(backup.focusHistory){JSONObject().put("id",it.id).put("finishedAt",it.finishedAt).put("durationMs",it.durationMs)}))
            .put("pdf",JSONObject().put("stylusOnly",backup.stylusOnly).put("straightHighlight",backup.straightHighlight)
                .put("documents",array(backup.documents){JSONObject().put("driveFileId",it.driveFileId).put("lastPage",it.lastPage)
                    .put("annotations",encodeAnnotations(it.annotations))})).toString(2)
    }

    /** Toda a entrada é validada antes de qualquer gravação nos stores. */
    fun decode(value: String): PortableBackup {
        require(value.toByteArray(Charsets.UTF_8).size<=MAX_BACKUP_BYTES) {"Backup maior que 25 MB."}
        val root=JSONObject(value)
        require(root.getString("format")==BACKUP_FORMAT) {"Este arquivo não é um backup Kepleræ."}
        require(root.getInt("schemaVersion")==BACKUP_SCHEMA) {"Formato de backup incompatível. Atualize o app."}
        val exportedAt=root.getLong("exportedAt").also(::timestamp)
        val s=root.getJSONObject("study")
        val accessed=s.getJSONArray("accessed").objects().map {
            it.getString("id").also(::id) to it.getLong("at").also(::timestamp)
        };unique(accessed.map {it.first})
        val study=StudyBackup(strings(s.getJSONArray("favorites")).toSet(),strings(s.getJSONArray("completed")).toSet(),
            accessed.toMap(),strings(s.getJSONArray("itemOrder")),ThemeMode.valueOf(s.getString("theme")),s.getBoolean("dynamicColor"))
        val n=root.getJSONObject("notes")
        val tags=n.getJSONArray("tags").objects().map {NoteTag(it.getString("id"),it.getString("name").also {name->require(name.isNotBlank());text(name,30)})}
        unique(tags.map {it.id})
        val notes=n.getJSONArray("items").objects().map {
            Note(it.getString("id"),it.getString("title").also {t->text(t,2000)},it.getString("body").also {t->text(t,200_000)},
                if(it.isNull("tagId"))null else it.getString("tagId").also {tag->require(tags.any {t->t.id==tag})},
                it.getInt("tone").also {tone->require(tone in 0 until NOTE_TONE_COUNT)},
                it.getLong("createdAt").also(::timestamp),it.getLong("updatedAt").also(::timestamp))
        };unique(notes.map {it.id})
        val q=root.getJSONObject("questions")
        val subjects=q.getJSONArray("subjects").objects().map {QuestionSubject(it.getString("id"),it.getString("name").also {name->require(name.isNotBlank());text(name,80)})}
        unique(subjects.map {it.id})
        val records=q.getJSONArray("records").objects().map {
            val subject=it.getString("subjectId");require(subjects.any {s->s.id==subject}) {"Registro sem matéria."}
            val correct=it.getInt("correct");val wrong=it.getInt("wrong");require(validQuestionCounts(correct,wrong)) {"Contagem inválida."}
            QuestionRecord(it.getString("id"),subject,correct,wrong,it.getLong("recordedAt").also(::timestamp))
        };unique(records.map {it.id})
        val p=root.getJSONObject("pomodoro");val c=p.getJSONObject("settings")
        val settings=PomodoroSettings(c.getInt("focusMinutes"),c.getInt("shortMinutes"),c.getInt("longMinutes"),c.getInt("cycles"),
            c.getBoolean("sounds"),c.getString("sound"),c.getBoolean("autoAdvance"),c.getBoolean("ambienceEnabled"),
            c.getString("ambienceId"),c.getDouble("ambienceVolume").toFloat())
        require(settings.valid());require(settings.sound in setOf("bell","soft"));id(settings.ambienceId)
        val history=p.getJSONArray("history").objects().map {FocusRecord(it.getString("id"),it.getLong("finishedAt").also(::timestamp),
            it.getLong("durationMs").also {ms->require(ms in 1..(180*60_000L))})};unique(history.map {it.id})
        val pdf=root.getJSONObject("pdf")
        val documents=pdf.getJSONArray("documents").objects().map {PdfBackup(it.getString("driveFileId").also {
            driveId->require(Regex("[A-Za-z0-9_-]{1,256}").matches(driveId))},it.getInt("lastPage").also {page->require(page in 0..100_000)},
            decodeAnnotations(it.getJSONObject("annotations")))};unique(documents.map {it.driveFileId})
        return PortableBackup(exportedAt,study,NoteState(tags,notes),QuestionState(subjects,records),settings,history,
            documents,pdf.getBoolean("stylusOnly"),pdf.getBoolean("straightHighlight"))
    }
    fun encodeAnnotations(document: AnnotationDocument): JSONObject = JSONObject().put("version",1)
        .put("pages",array(document.pages.toSortedMap().entries) { (index,a)->
            JSONObject().put("page",index).put("strokes",array(a.strokes){s->JSONObject().put("id",s.id).put("highlight",s.highlight)
                .put("color",s.color).put("width",s.width.toDouble()).put("points",array(s.points){JSONArray().put(it.x.toDouble()).put(it.y.toDouble())})})
                .put("notes",array(a.notes){JSONObject().put("id",it.id).put("x",it.point.x.toDouble()).put("y",it.point.y.toDouble()).put("text",it.text)})
        })
    fun decodeAnnotations(root: JSONObject): AnnotationDocument {
        require(root.getInt("version")==1)
        val pages=root.getJSONArray("pages").objects().map {p->
            val page=p.getInt("page");require(page in 0..100_000)
            val strokes=p.getJSONArray("strokes").objects().map {s->
                val points=s.getJSONArray("points");require(points.length() in 1..100_000)
                InkStroke(s.getString("id"),List(points.length()){i->val point=points.getJSONArray(i)
                    InkPoint(coordinate(point.getDouble(0)),coordinate(point.getDouble(1)))},s.getBoolean("highlight"),
                    s.getLong("color").also {require(it in 0..0xFFFFFFFFL)},s.getDouble("width").toFloat().also {require(it.isFinite()&&it>0&&it<=1)})
            };unique(strokes.map {it.id})
            val notes=p.getJSONArray("notes").objects().map {n->PdfNote(n.getString("id"),InkPoint(coordinate(n.getDouble("x")),coordinate(n.getDouble("y"))),
                n.getString("text").also {text(it,20_000)})};unique(notes.map {it.id})
            page to PageAnnotations(strokes,notes)
        }
        require(pages.map {it.first}.distinct().size==pages.size)
        return AnnotationDocument(pages.toMap())
    }
    private fun coordinate(value: Double): Float {require(value.isFinite()&&value in 0.0..1.0);return value.toFloat()}
}
