package com.example.ui.backup

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.backup.*
import com.example.data.repository.StudyViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** O provedor de arquivos cuida do destino; não pede novas permissões OAuth. */
@Composable fun BackupControls(model: StudyViewModel) {
    val context=LocalContext.current
    val repository=remember(context) {BackupRepository(context)}
    val scope=rememberCoroutineScope()
    var busy by remember {mutableStateOf(false)}
    var pending by remember {mutableStateOf<PortableBackup?>(null)}
    var message by remember {mutableStateOf<String?>(null)}
    fun operation(action:suspend ()->Unit) {
        scope.launch {
            busy=true
            try {action()}
            catch(cancel:CancellationException) {throw cancel}
            catch(error:Exception) {message="Não foi possível concluir: ${error.message ?: "confira o arquivo e tente novamente"}"}
            finally {busy=false}
        }
    }
    val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) {uri->
        if(uri!=null)operation {repository.export(uri,model);message="Dados exportados. Guarde o arquivo para importar em outro dispositivo."}
    }
    val importLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {uri->
        if(uri!=null)operation {pending=repository.read(uri)}
    }
    Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("Seus dados",style=MaterialTheme.typography.titleMedium)
        Text("Transfira configurações, notas, estudo, Questões, Pomodoro e anotações de PDFs. Você pode salvar o arquivo no Google Drive.",
            style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(enabled=!busy,onClick={
            val stamp=SimpleDateFormat("yyyy-MM-dd-HHmm",Locale.ROOT).format(Date())
            export.launch("Keplerae-backup-$stamp.json")
        },modifier=Modifier.fillMaxWidth().testTag("backup_export")) {
            Icon(Icons.Outlined.FileUpload,null);Spacer(Modifier.width(8.dp));Text("Exportar dados e configurações")
        }
        OutlinedButton(enabled=!busy,onClick={importLauncher.launch(arrayOf("application/json","text/plain","application/octet-stream"))},
            modifier=Modifier.fillMaxWidth().testTag("backup_import")) {
            Icon(Icons.Outlined.FileDownload,null);Spacer(Modifier.width(8.dp));Text("Importar dados e configurações")
        }
    }
    pending?.let {backup->
        AlertDialog(onDismissRequest={pending=null},icon={Icon(Icons.Outlined.FileDownload,null)},
            title={Text("Importar seus dados?")},text={Text(backup.summary()+
                "\n\nOs registros serão mesclados com os atuais, sem duplicar IDs. Nas notas, a edição mais recente prevalece. As configurações de tema e Pomodoro serão aplicadas. A conta conectada permanece a mesma.")},
            confirmButton={TextButton(onClick={pending=null;operation {repository.importBackup(backup,model);message="Dados importados e configurações aplicadas."}},
                modifier=Modifier.testTag("backup_confirm_import")) {Text("Importar")}},
            dismissButton={TextButton(onClick={pending=null}) {Text("Cancelar")}})
    }
    if(busy)AlertDialog(onDismissRequest={},icon={Icon(Icons.Outlined.Sync,null)},
        title={Text("Preparando seus dados…")},text={LinearProgressIndicator(Modifier.fillMaxWidth())},confirmButton={})
    message?.let {text->AlertDialog(onDismissRequest={message=null},icon={Icon(Icons.Outlined.Info,null)},
        title={Text("Transferência de dados")},text={Text(text)},confirmButton={TextButton(onClick={message=null}) {Text("Fechar")}})}
}
