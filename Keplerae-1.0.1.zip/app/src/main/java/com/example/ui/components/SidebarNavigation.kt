package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import com.example.data.auth.GoogleUser
import com.example.ui.Destination
import com.example.ui.profile.GoogleAvatar

val MainDestinations = listOf(Destination.HOME, Destination.SUBJECTS,
    Destination.POMODORO, Destination.QUESTIONS, Destination.NOTES)

/** Faixa lateral estreita, ícones monocromáticos e perfil acessível em qualquer seção. */
@Composable fun SidebarNavigation(current: Destination, profile: Boolean, user: GoogleUser?,
    onNavigate: (Destination) -> Unit, onProfile: () -> Unit) {
    val active = current.takeIf { it in MainDestinations } ?: Destination.SUBJECTS
    Surface(color=MaterialTheme.colorScheme.surface, modifier=Modifier.width(64.dp).fillMaxHeight()
        .testTag("sidebar_navigation")) {
        Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical=16.dp),
                horizontalAlignment=Alignment.CenterHorizontally,
                verticalArrangement=Arrangement.spacedBy(12.dp)) {
                MainDestinations.forEach { destination ->
                    val chosen = !profile && active==destination
                    val filled = when(destination) {
                        Destination.HOME -> Icons.Filled.Home
                        Destination.SUBJECTS -> Icons.Filled.GridView
                        Destination.POMODORO -> Icons.Filled.Timer
                        Destination.QUESTIONS -> Icons.Filled.Quiz
                        else -> Icons.Filled.EditNote
                    }
                    IconButton(onClick={onNavigate(destination)},modifier=Modifier.size(48.dp)
                        .testTag("nav_${destination.name}").semantics { role=Role.Tab;selected=chosen }) {
                        Icon(if(chosen)filled else destination.icon,destination.title,Modifier.size(27.dp),
                            tint=if(chosen)MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Surface(onClick=onProfile,shape=CircleShape,
                    color=MaterialTheme.colorScheme.surface,
                    border=BorderStroke(if(profile)2.dp else 1.dp,
                        if(profile)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                    modifier=Modifier.size(48.dp).testTag("profile_rail")
                        .semantics { contentDescription="Abrir meu perfil";selected=profile }) {
                    GoogleAvatar(user,Modifier.fillMaxSize().padding(6.dp))
                }
            }
        }
    }
}
