@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.components.*
import com.example.ui.home.SubjectTile
import com.example.ui.theme.isDarkMode
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState

private fun folderKey(subjectId: String, path: List<String>) = "folder/$subjectId/${path.joinToString("\u001f")}"

@Composable fun CatalogScreen(state: StudyState, destination: Destination, subject: Subject?, path: List<String>,
    motion: SharedMotion, onSelectSubject: (Subject) -> Unit, onFolder: (String) -> Unit,
    onOpen: (StudyItem) -> Unit, onFavorite: (String) -> Unit, onCompleted: (String) -> Unit,
    onRefresh: () -> Unit, onSaveOrder: (List<String>) -> Unit, onBack: () -> Unit = {}) {
    var query by rememberSaveable(destination, subject?.id) { mutableStateOf("") }
    var filter by rememberSaveable(destination, subject?.id) { mutableStateOf("all") }
    var typeName by rememberSaveable(destination, subject?.id) { mutableStateOf("") }
    val type = destination.type ?: typeName.takeIf { it.isNotBlank() }?.let(ContentType::valueOf)
    val base = remember(state.items, destination, subject, type) { state.items.filter {
        (subject == null || it.subjectId == subject.id) && (type == null || it.type == type)
    } }
    val filtered = remember(base, state.favorites, state.completed, filter, query) { base.filter {
        it.matches(query) && when (filter) {
            "favorites" -> it.id in state.favorites
            "completed" -> it.id in state.completed
            "pending" -> it.id !in state.completed
            else -> true
        }
    } }
    val browsing = query.isBlank() && filter == "all"
    val showSubjects = browsing && subject == null
    val scoped = if (subject != null && browsing) itemsInPath(filtered, path) else filtered
    val folders = if (subject != null && browsing)
        scoped.mapNotNull { it.folderPath.getOrNull(path.size) }.distinct() else emptyList()
    val leaves = if (subject != null && browsing) scoped.filter { it.folderPath.size == path.size } else scoped
    val availableIds = leaves.map { it.id }
    var orderedIds by remember(destination, subject?.id, path, query, filter, typeName) {
        mutableStateOf(reconcileOrder(availableIds, state.itemOrder))
    }
    LaunchedEffect(availableIds, state.itemOrder) { orderedIds = reconcileOrder(availableIds, state.itemOrder) }
    val byId = remember(leaves) { leaves.associateBy { it.id } }
    val orderedRows = orderedIds.mapNotNull(byId::get)
    val listState = rememberLazyListState()
    LaunchedEffect(path, query, filter, subject?.id, destination, typeName) { listState.scrollToItem(0) }
    val reorderState = rememberReorderableLazyListState(listState) { from, to ->
        orderedIds = moveId(orderedIds, from.key as? String ?: "", to.key as? String ?: "")
    }
    fun moveAccessible(id: String, direction: Int): Boolean {
        val index = orderedIds.indexOf(id)
        val target = orderedIds.getOrNull(index + direction) ?: return false
        orderedIds = moveId(orderedIds, id, target)
        onSaveOrder(orderedIds)
        return true
    }
    ExpressiveRefreshBox(state.loading, onRefresh, Modifier.fillMaxSize()) {
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize().testTag("catalog_list"), contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (subject != null) item(key = "back_to_folder") {
                TextButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (path.isEmpty()) "Matérias" else "Pasta anterior")
                }
            }
            item(key = "header") {
                CatalogHeader(state, subject, path, destination, scoped.size, motion)
            }
            item(key = "search") {
                OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("catalog_search"),
                    placeholder = { Text("Buscar aulas, arquivos e pastas") }, leadingIcon = { Icon(Icons.Outlined.Search, null) },
                    trailingIcon = { if (query.isNotBlank()) IconButton(onClick = { query = "" }) {
                        Icon(Icons.Filled.Close, "Limpar busca")
                    } }, shape = RoundedCornerShape(28.dp))
            }
            item(key = "filters") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("all" to "Todos", "favorites" to "Favoritos", "pending" to "Pendentes", "completed" to "Concluídos")) { (id, label) ->
                        FilterChip(selected = filter == id, onClick = { filter = id }, label = { Text(label) },
                            leadingIcon = { if (filter == id) Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) })
                    }
                }
            }
            if (subject != null && destination.type == null) item(key = "formats") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = typeName.isBlank(), onClick = { typeName = "" }, label = { Text("Todos os formatos") }) }
                    items(ContentType.entries) { t -> FilterChip(selected = typeName == t.name,
                        onClick = { typeName = t.name }, label = { Text(t.label) }) }
                }
            }
            if (showSubjects) {
                items(Subjects.all.filter { s -> base.any { it.subjectId == s.id } }.chunked(2),
                    key = { "subjects/${it.first().id}" }) { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { s -> SubjectTile(s, state.copy(items = base), motion, Modifier.weight(1f)) { onSelectSubject(s) } }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            } else {
                items(folders, key = { "folder_row/$it" }) { name ->
                    val count = scoped.count { it.folderPath.getOrNull(path.size) == name }
                    val sharedKey = folderKey(subject!!.id, path + name)
                    val tone = folderTone(subject.id, isDarkMode(state.theme))
                    val completed = scoped.count { it.folderPath.getOrNull(path.size) == name && it.id in state.completed }
                    FolderSurface(tone, Modifier.fillMaxWidth().then(motion.bounds("$sharedKey/container")), { onFolder(name) }) {
                        Column(Modifier.padding(18.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                Surface(shape = MaterialTheme.shapes.medium, color = tone.ink.copy(alpha = .08f)) {
                                    Icon(Icons.Outlined.Folder, null, motion.element("$sharedKey/art").padding(14.dp).size(28.dp), tint = tone.accent)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(name, style = MaterialTheme.typography.titleMedium, modifier = motion.bounds("$sharedKey/name"))
                                    Text("$count materiais", style = MaterialTheme.typography.bodySmall)
                                }
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                            }
                            Spacer(Modifier.height(12.dp))
                            LinearProgressIndicator(progress = { if(count==0) 0f else completed.toFloat()/count },
                                modifier = Modifier.fillMaxWidth(), color = tone.accent, trackColor = tone.ink.copy(alpha = .12f))
                        }
                    }
                }
                if (orderedRows.isNotEmpty()) item(key = "reorder_help") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Seus materiais", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        HelpTooltip("Organizar materiais", "Arraste a alça à direita para reordenar. " +
                            "Toque na seta para expandir os detalhes. A ordem fica salva neste aparelho.")
                    }
                }
                items(orderedRows, key = { it.id }) { item ->
                    ReorderableItem(reorderState, key = item.id) { dragging ->
                        val elevation by animateDpAsState(if (dragging) 8.dp else 0.dp, label = "drag_elevation")
                        MaterialRow(item, state, onOpen, onFavorite, onCompleted, elevation,
                            modifier = Modifier.semantics {
                                customActions = listOf(
                                    CustomAccessibilityAction("Mover para cima") { moveAccessible(item.id, -1) },
                                    CustomAccessibilityAction("Mover para baixo") { moveAccessible(item.id, 1) })
                            }, dragHandle = {
                                IconButton(onClick = {}, modifier = Modifier.draggableHandle(
                                    onDragStopped = { onSaveOrder(orderedIds) })) {
                                    Icon(Icons.Outlined.DragHandle, "Arrastar para reordenar")
                                }
                            })
                    }
                }
            }
            if (scoped.isEmpty()) item(key = "empty") {
                Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.SearchOff, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
                    Text("Nenhum material encontrado", style = MaterialTheme.typography.titleMedium)
                    Text("Tente outro termo ou ajuste os filtros.")
                }
            }
        }
    }
}

@Composable private fun CatalogHeader(state: StudyState, subject: Subject?, path: List<String>,
    destination: Destination, count: Int, motion: SharedMotion) {
    val sharedKey = when {
        subject == null -> null
        path.isEmpty() -> "subject/${subject.id}"
        else -> folderKey(subject.id, path)
    }
    val tone = folderTone(subject?.id ?: destination.name, isDarkMode(state.theme))
    FolderSurface(tone, Modifier.fillMaxWidth().then(if (sharedKey != null) motion.bounds("$sharedKey/container") else Modifier)) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (subject != null) {
                if (path.isEmpty()) SubjectArtwork(subject.id, tone.accent,
                    motion.element("$sharedKey/art").size(96.dp))
                else Icon(Icons.Outlined.Folder, null, motion.element("$sharedKey/art").size(44.dp))
            }
            Text(path.lastOrNull() ?: subject?.name ?: destination.title,
                style = MaterialTheme.typography.headlineLarge,
                modifier = if (sharedKey != null) motion.bounds("$sharedKey/name") else Modifier)
            Text(if (path.isNotEmpty()) path.joinToString(" › ") else subject?.subtitle ?: when (destination) {
                Destination.PDFS -> "Artigos e materiais para sua leitura"
                Destination.AUDIO -> "Sua biblioteca de áudios"
                Destination.VIDEOS -> "Suas aulas, organizadas por matéria"
                else -> "Escolha uma matéria para começar"
            }, style = MaterialTheme.typography.bodyMedium)
            Text("$count materiais", style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable private fun MaterialRow(item: StudyItem, state: StudyState, onOpen: (StudyItem) -> Unit,
    onFavorite: (String) -> Unit, onCompleted: (String) -> Unit, elevation: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier, dragHandle: @Composable () -> Unit) {
    var expanded by rememberSaveable(item.id) { mutableStateOf(false) }
    val complete = item.id in state.completed
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow,
        shadowElevation = elevation, modifier = modifier.fillMaxWidth().animateContentSize()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(contentIcon(item.type), null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, style = MaterialTheme.typography.titleMedium)
                    Text(if (complete) "Concluído" else "${Subjects.get(item.subjectId).name} · ${item.type.label}",
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
                dragHandle()
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(onClick = { onOpen(item) }) {
                    Icon(if (item.linkKind == LinkKind.FOLDER) Icons.Outlined.FolderOpen else contentIcon(item.type), null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (item.linkKind == LinkKind.FOLDER) "Abrir pasta" else when (item.type) {
                        ContentType.VIDEO -> "Assistir"; ContentType.PDF -> "Ler PDF"; ContentType.AUDIO -> "Ouvir"
                    })
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { onFavorite(item.id) }) {
                    Icon(if (item.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        if (item.id in state.favorites) "Remover dos favoritos" else "Favoritar")
                }
                IconButton(onClick = { expanded = !expanded }, modifier = Modifier.testTag("expand_${item.id}")) {
                    Icon(if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                        if (expanded) "Recolher detalhes" else "Expandir detalhes")
                }
            }
            AnimatedVisibility(expanded, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 8.dp)) {
                    HorizontalDivider()
                    Text(item.filename, style = MaterialTheme.typography.bodySmall)
                    if (item.note.isNotBlank()) Text(item.note, style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(if (complete) "Material concluído" else "Marcar como concluído", style = MaterialTheme.typography.bodyMedium)
                        IconToggleButton(checked = complete, onCheckedChange = { onCompleted(item.id) }) {
                            Icon(if (complete) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircle,
                                if (complete) "Marcar como pendente" else "Marcar como concluído")
                        }
                    }
                }
            }
        }
    }
}

internal fun contentIcon(type: ContentType): ImageVector = when (type) {
    ContentType.VIDEO -> Icons.Outlined.PlayCircleOutline
    ContentType.PDF -> Icons.Outlined.Description
    ContentType.AUDIO -> Icons.Outlined.Headphones
}
