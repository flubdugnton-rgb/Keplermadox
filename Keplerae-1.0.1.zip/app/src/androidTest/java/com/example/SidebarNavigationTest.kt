package com.example

import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.auth.GoogleUser
import com.example.ui.Destination
import com.example.ui.components.SidebarNavigation
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SidebarNavigationTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    @Test fun fiveMenusAndProfileRemainAccessibleAfterNavigation() {
        val current=mutableStateOf(Destination.HOME)
        val profile=mutableStateOf(false)
        var profileCalls=0
        compose.setContent { KepleraeTheme {
            SidebarNavigation(current.value,profile.value,GoogleUser("test@example.com","Teste",null),
                onNavigate={current.value=it;profile.value=false},
                onProfile={profile.value=true;profileCalls++})
        } }
        compose.onNodeWithTag("sidebar_navigation").assertIsDisplayed()
        listOf("VIDEOS","PDFS","AUDIO").forEach {compose.onNodeWithTag("nav_$it").assertDoesNotExist()}
        compose.onNodeWithTag("nav_POMODORO").performClick().assertIsSelected()
        compose.onNodeWithTag("nav_NOTES").performClick().assertIsSelected()
        compose.onNodeWithTag("profile_rail").performClick().assertIsSelected()
        compose.runOnIdle {assertEquals(1,profileCalls)}
        compose.onNodeWithTag("nav_NOTES").assertIsNotSelected()
        compose.onNodeWithTag("nav_SUBJECTS").performClick().assertIsSelected()
        listOf("HOME","POMODORO","QUESTIONS","NOTES").forEach {compose.onNodeWithTag("nav_$it").assertIsDisplayed()}
        compose.onNodeWithTag("profile_rail").assertIsDisplayed().assertIsNotSelected()
    }
}
