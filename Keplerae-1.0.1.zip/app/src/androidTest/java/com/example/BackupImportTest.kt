package com.example

import android.app.Application
import android.net.Uri
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelProvider
import com.example.data.backup.*
import com.example.data.notes.*
import com.example.data.pdf.*
import com.example.data.productivity.*
import com.example.data.repository.StudyViewModel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class BackupImportTest {
    @Test fun importThenExportKeepsExternalPdfAndRepeatedImportDoesNotDuplicate() = runBlocking {
        val instrumentation=InstrumentationRegistry.getInstrumentation()
        val context=instrumentation.targetContext
        lateinit var model:StudyViewModel
        val owner=ViewModelStore()
        instrumentation.runOnMainSync {
            model=ViewModelProvider(owner,ViewModelProvider.AndroidViewModelFactory.getInstance(
                context.applicationContext as Application))[StudyViewModel::class.java]
        }
        val unique=UUID.randomUUID().toString()
        val base=backupFixture()
        val data=base.copy(notes=NoteState(listOf(NoteTag("t-$unique","Bloco ${unique.take(8)}")),
            listOf(base.notes.notes.single().copy(id="n-$unique",tagId="t-$unique"))),
            questions=QuestionState(listOf(QuestionSubject("s-$unique","Matéria $unique")),
                listOf(base.questions.records.single().copy(id="q-$unique",subjectId="s-$unique"))),
            focusHistory=listOf(base.focusHistory.single().copy(id="f-$unique")),
            documents=listOf(base.documents.single().copy(driveFileId="pdf-$unique")))
        val repository=BackupRepository(context)
        val notes=NoteStore.get(context);val questions=QuestionStore.get(context);val pomodoro=PomodoroStore.get(context)
        val beforeNotes=notes.state.value.notes.map {it.id}.toSet()
        val beforeQuestions=questions.state.value.records.map {it.id}.toSet()
        val beforeHistory=pomodoro.state.value.history.map {it.id}.toSet()
        val beforeSettings=pomodoro.state.value.settings
        val beforeStudy=model.state.value
        val file=File(context.cacheDir,"backup-$unique.json")
        try {
            repository.importBackup(data,model)
            repository.importBackup(data,model)
            assertEquals(1,notes.state.value.notes.count {it.id=="n-$unique"})
            assertEquals(1,questions.state.value.records.count {it.id=="q-$unique"})
            assertEquals(1,pomodoro.state.value.history.count {it.id=="f-$unique"})
            assertTrue(notes.state.value.notes.map {it.id}.containsAll(beforeNotes))
            assertTrue(questions.state.value.records.map {it.id}.containsAll(beforeQuestions))
            assertTrue(pomodoro.state.value.history.map {it.id}.containsAll(beforeHistory))
            assertTrue(model.state.value.favorites.containsAll(data.study.favorites))
            assertEquals(data.study.theme,model.state.value.theme)
            assertEquals(data.pomodoroSettings,pomodoro.state.value.settings)
            repository.export(Uri.fromFile(file),model)
            val restored=repository.read(Uri.fromFile(file))
            assertEquals(data.documents.single(),restored.documents.first {it.driveFileId=="pdf-$unique"})
            assertEquals(data.notes.notes.single(),restored.notes.notes.first {it.id=="n-$unique"})
        } finally {
            file.delete()
            notes.delete("n-$unique");notes.deleteTag("t-$unique")
            questions.deleteSubject("s-$unique")
            val key=pdfStorageKey(pdfAccountKey(context),"pdf-$unique")
            File(context.filesDir,"annotations/$key.json").delete()
            pomodoro.configure(beforeSettings)
            model.importData(data.study.copy(theme=beforeStudy.theme,dynamicColor=beforeStudy.dynamicColor))
            instrumentation.runOnMainSync {owner.clear()}
        }
    }
}
