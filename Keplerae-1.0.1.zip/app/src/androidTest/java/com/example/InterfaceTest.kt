package com.example

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.activity.ComponentActivity
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.repository.StudyViewModel
import com.example.ui.KepleraeApp
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class InterfaceTest {
    // Testa catálogo/tema diretamente, sem simular credenciais nem burlar o login em produção.
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun catalogAndThemeControlsWork() {
        lateinit var viewModel: StudyViewModel
        compose.activityRule.scenario.onActivity { activity ->
            viewModel = ViewModelProvider(activity)[StudyViewModel::class.java]
        }
        compose.setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            KepleraeTheme(state.theme, state.dynamicColor) { KepleraeApp(state, viewModel) }
        }
        compose.waitUntil(timeoutMillis = 20000) {
            compose.onAllNodesWithText("Seu percurso").fetchSemanticsNodes().isNotEmpty()
        }
        saveDevicePreview("inicio")
        // A barra de aparência foi removida da inicial por solicitação do usuário.
        compose.onNodeWithTag("settings").assertDoesNotExist()
        compose.onNodeWithTag("profile_open").performClick()
        compose.onNodeWithTag("settings").performClick()
        compose.onNodeWithTag("theme_DARK").performClick()
        compose.onNodeWithTag("theme_DARK").assertIsSelected()
        compose.onNodeWithTag("theme_LIGHT").performClick()
        compose.onNodeWithTag("theme_LIGHT").assertIsSelected()
        compose.onNodeWithTag("theme_SYSTEM").performClick()
        compose.onNodeWithTag("theme_SYSTEM").assertIsSelected()
        compose.onNodeWithTag("appearance_close").performClick()
        compose.waitUntil(timeoutMillis = 10000) {
            compose.onAllNodesWithTag("appearance_sheet").fetchSemanticsNodes().isEmpty()
        }
        compose.onNodeWithTag("profile_back").performClick()
        compose.waitUntil(timeoutMillis = 10000) {
            compose.onAllNodesWithTag("profile_open").fetchSemanticsNodes().isNotEmpty()
        }
        compose.onNodeWithTag("nav_SUBJECTS").performClick()
        compose.onNodeWithTag("settings").assertDoesNotExist()
        compose.onNodeWithTag("catalog_search").performTextInput("AVALIAÇÃO FISIOTERAPÊUTICA")
        compose.onNodeWithTag("catalog_list").performScrollToNode(
            hasText("AVALIAÇÃO FISIOTERAPÊUTICA EM TERAPIA INTENSIVA", substring = true))
        compose.onAllNodesWithText("AVALIAÇÃO FISIOTERAPÊUTICA EM TERAPIA INTENSIVA", substring = true)
            .onFirst().assertExists()
    }
}
