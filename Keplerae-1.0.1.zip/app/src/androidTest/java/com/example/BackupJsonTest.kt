package com.example

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.backup.*
import com.example.data.notes.*
import com.example.data.pdf.*
import com.example.data.productivity.*
import com.example.data.repository.ThemeMode
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

fun backupFixture() = PortableBackup(1_700_000_000_000L,
    StudyBackup(setOf("material-1"),setOf("material-2"),mapOf("material-1" to 100L),
        listOf("material-2","material-1"),ThemeMode.DARK,false),
    NoteState(listOf(NoteTag("tag","Estudo")),listOf(Note("note","Revisão","Conceitos de SUS","tag",2,1,2))),
    QuestionState(listOf(QuestionSubject("subject","SUS")),listOf(QuestionRecord("record","subject",8,2,3))),
    PomodoroSettings(focusMinutes=40,shortMinutes=8,longMinutes=20,cycles=3,ambienceEnabled=true),
    listOf(FocusRecord("focus",4,40*60_000L)),
    listOf(PdfBackup("external-drive-id",5,AnnotationDocument(mapOf(5 to PageAnnotations(
        listOf(InkStroke("ink",listOf(InkPoint(.1f,.3f),InkPoint(.8f,.3f)),true,0xFFFFD54FL,.027f)),
        listOf(PdfNote("pin",InkPoint(.4f,.6f),"Revisar"))))))),true,true)

@RunWith(AndroidJUnit4::class)
class BackupJsonTest {
    @Test fun allModulesAndNormalizedCoordinatesRoundTrip() {
        val fixture=backupFixture()
        val json=BackupJson.encode(fixture)
        assertEquals(fixture,BackupJson.decode(json))
        val root=JSONObject(json)
        assertEquals("keplerae-backup",root.getString("format"))
        assertEquals(1,root.getInt("schemaVersion"))
        assertFalse(json.contains("accessToken"))
        assertFalse(json.contains("apiKey"))
        assertFalse(json.contains("/data/"))
    }
    @Test fun invalidSchemaRelationsAndCountsAreRejectedBeforeImport() {
        fun rejected(change:(JSONObject)->Unit) {
            val root=JSONObject(BackupJson.encode(backupFixture()));change(root)
            assertThrows(Exception::class.java) {BackupJson.decode(root.toString())}
        }
        rejected {it.put("schemaVersion",999)}
        rejected {it.put("format","outro-app")}
        rejected {it.getJSONObject("questions").getJSONArray("records").getJSONObject(0).put("subjectId","missing")}
        rejected {it.getJSONObject("questions").getJSONArray("records").getJSONObject(0).put("wrong",-1)}
        rejected {it.getJSONObject("pdf").getJSONArray("documents").getJSONObject(0).put("driveFileId","../arquivo")}
        rejected {it.getJSONObject("pomodoro").getJSONObject("settings").put("cycles",0)}
    }
}
