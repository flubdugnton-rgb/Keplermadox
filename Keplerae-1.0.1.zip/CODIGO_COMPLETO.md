# Kepleræ 1.0.1 — Código completo

Este arquivo reúne os fontes, testes, Gradle, recursos XML, scripts e workflow completos. Imagens, fontes, sons e catálogo estão no ZIP do projeto. Veja README.md para compilar e BACKUP_FORMAT.md para o contrato de dados.

## .github/workflows/compilar-apk.yml

```yaml
name: Compilar Keplerae 1.0.1 - Release
on:
  push:
    branches: [main, master]
    paths: ['Keplerae-1.0.1.zip', '.github/workflows/compilar-apk.yml']
  workflow_dispatch:
    inputs:
      testar_interface:
        description: Testar interface e abertura do APK release no emulador
        type: boolean
        default: true
permissions:
  contents: read
concurrency:
  group: apk-zip-${{ github.ref }}
  cancel-in-progress: true
jobs:
  apk:
    runs-on: ubuntu-latest
    timeout-minutes: 40
    defaults:
      run:
        working-directory: android-project
    steps:
      - uses: actions/checkout@v4
      - name: Extrair projeto 1.0.1
        working-directory: .
        run: |
          test -f Keplerae-1.0.1.zip
          unzip -q Keplerae-1.0.1.zip -d android-project
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: android-actions/setup-android@v3
        with:
          packages: platform-tools
          log-accepted-android-sdk-licenses: false
      - name: Instalar SDK
        run: sdkmanager 'platforms;android-36' 'build-tools;36.0.0'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.13'
      - name: Configurar entrada Google
        env:
          GOOGLE_WEB_CLIENT_ID: ${{ vars.GOOGLE_WEB_CLIENT_ID }}
        run: python3 scripts/configure_google_login.py
      - name: Preparar sons públicos do Pomodoro
        run: |
          command -v ffmpeg >/dev/null || { sudo apt-get update; sudo apt-get install -y ffmpeg; }
          python3 scripts/fetch_pomodoro_sounds.py
          python3 scripts/fetch_ambient_sounds.py
      - name: Validar projeto
        run: |
          python3 scripts/validate_catalog.py
          python3 scripts/validate_network_permissions.py
          python3 scripts/validate_release.py
          python3 scripts/validate_ambient_sounds.py
      # Valida o código público antes de restaurar a chave privada no runner.
      - name: Restaurar assinatura
        env:
          KEYSTORE_B64: ${{ secrets.KEPLERAE_KEYSTORE_B64 }}
        run: python3 scripts/restore_signing.py
      - name: Conferir a assinatura existente
        run: python3 scripts/verify_signing.py
      - name: Compilar release otimizado, testar e verificar
        run: gradle --no-daemon :app:testReleaseUnitTest :app:lintRelease :app:assembleRelease :app:assembleDebugAndroidTest
      - name: Validar APK e nomear
        run: |
          python3 scripts/validate_network_permissions.py app/build/outputs/apk/release/app-release.apk
          cp app/build/outputs/apk/release/app-release.apk Keplerae-1.0.1-release.apk
      - uses: actions/upload-artifact@v4
        with:
          name: Keplerae-1.0.1-APK
          path: android-project/Keplerae-1.0.1-release.apk
          if-no-files-found: error
          retention-days: 30
      - name: Resultados e mapa R8
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: Keplerae-1.0.1-verificacoes
          path: |
            android-project/app/build/reports/tests/
            android-project/app/build/reports/lint-results-release.html
            android-project/app/build/outputs/mapping/release/
          if-no-files-found: ignore
  interface:
    if: ${{ github.event_name != 'workflow_dispatch' || inputs.testar_interface }}
    needs: apk
    runs-on: ubuntu-latest
    timeout-minutes: 40
    steps:
      - uses: actions/checkout@v4
      - name: Extrair projeto
        run: unzip -q Keplerae-1.0.1.zip -d android-project
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.13'
      - uses: android-actions/setup-android@v3
        with:
          packages: platform-tools
          log-accepted-android-sdk-licenses: false
      - name: Instalar SDK
        run: sdkmanager 'platforms;android-36' 'build-tools;36.0.0'
      - name: Restaurar assinatura
        working-directory: android-project
        env:
          KEYSTORE_B64: ${{ secrets.KEPLERAE_KEYSTORE_B64 }}
        run: python3 scripts/restore_signing.py
      - name: Conferir a assinatura existente
        working-directory: android-project
        run: python3 scripts/verify_signing.py
      - name: Configurar Google
        working-directory: android-project
        env:
          GOOGLE_WEB_CLIENT_ID: ${{ vars.GOOGLE_WEB_CLIENT_ID }}
        run: python3 scripts/configure_google_login.py
      - uses: actions/download-artifact@v4
        with:
          name: Keplerae-1.0.1-APK
          path: release-apk
      - name: Ativar KVM
        run: |
          echo 'KERNEL=="kvm", GROUP="kvm", MODE="0666", OPTIONS+="static_node=kvm"' | sudo tee /etc/udev/rules.d/99-kvm4all.rules
          sudo udevadm control --reload-rules
          sudo udevadm trigger --name-match=kvm
      - uses: reactivecircus/android-emulator-runner@v2
        with:
          api-level: 35
          arch: x86_64
          script: |
            python3 android-project/scripts/smoke_release.py release-apk/Keplerae-1.0.1-release.apk
            gradle --no-daemon -p android-project :app:connectedDebugAndroidTest
            mkdir -p android-project/app/build/design-preview
            adb pull /sdcard/Android/data/com.aistudio.keplerae.stdy/files/design-preview/. android-project/app/build/design-preview/ || true
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: Keplerae-1.0.1-testes-dispositivo
          path: |
            android-project/app/build/reports/androidTests/
            android-project/app/build/design-preview/
          if-no-files-found: ignore
```

## app/build.gradle.kts

```kotlin
import java.security.KeyStore
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.example"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.aistudio.keplerae.stdy"
        minSdk = 24
        targetSdk = 36
        versionCode = 28
        versionName = "1.0.1"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    signingConfigs {
        getByName("debug") {
            val cachedKey = rootProject.file(".signing/debug.keystore")
            if (cachedKey.exists()) {
                storeFile = cachedKey
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures { compose = true }
}
kotlin { jvmToolchain(17) }
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.media3:media3-exoplayer:1.8.1")
    implementation("androidx.media3:media3-ui:1.8.1")
    implementation("androidx.media3:media3-session:1.8.1")
    implementation("com.google.android.gms:play-services-auth:22.0.0")
    // Haze 1.7.0 usa Compose 1.9.4. Mantenha todos os artefatos UI alinhados.
    val composeVersion = "1.9.4"
    implementation("androidx.credentials:credentials:1.6.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.6.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.10.2")
    implementation("dev.chrisbanes.haze:haze:1.7.0")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.compose.runtime:runtime:$composeVersion")
    implementation("androidx.compose.foundation:foundation:$composeVersion")
    implementation("androidx.compose.ui:ui:$composeVersion")
    implementation("androidx.compose.ui:ui-tooling-preview:$composeVersion")
    // Etapa 01 da versão 2.0: fontes Google, mesma versão do Compose UI.
    implementation("androidx.compose.ui:ui-text-google-fonts:$composeVersion")
    // Alpha autorizada: LoadingIndicator e indicadores ondulados Expressive.
    // Versão fixada para a base Compose 1.9 / SDK 36; não use '+' aqui.
    implementation("androidx.compose.material3:material3:1.5.0-alpha07")
    implementation("androidx.compose.animation:animation:$composeVersion")
    implementation("androidx.datastore:datastore-preferences:1.1.7")
    implementation("io.coil-kt.coil3:coil-compose:3.3.0")
    implementation("io.coil-kt.coil3:coil-network-okhttp:3.3.0")
    implementation("sh.calvin.reorderable:reorderable:2.5.1")
    implementation("androidx.compose.material:material-icons-extended:1.7.8")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4:$composeVersion")
    debugImplementation("androidx.compose.ui:ui-tooling:$composeVersion")
    debugImplementation("androidx.compose.ui:ui-test-manifest:$composeVersion")
}

// Nunca publica release com uma chave nova criada automaticamente pelo SDK.
val verifyReleaseSigning by tasks.registering {
    doLast {
        val file = rootProject.file(".signing/debug.keystore")
        check(file.isFile) { "Restaure KEPLERAE_KEYSTORE_B64 antes de gerar o APK release." }
        val keys = KeyStore.getInstance("JKS")
        file.inputStream().use { keys.load(it, "android".toCharArray()) }
        val certificate = keys.getCertificate("androiddebugkey")
        check(certificate != null) { "Alias androiddebugkey não encontrado." }
        val sha1 = MessageDigest.getInstance("SHA-1").digest(certificate.encoded)
            .joinToString("") { "%02X".format(it) }
        check(sha1 == "16007901DBBFAB9DE7B5539FFAC604FAF19DBC8A") { "Assinatura diferente da versão instalada." }
    }
}
tasks.matching { it.name == "validateSigningRelease" }.configureEach { dependsOn(verifyReleaseSigning) }
```

## app/proguard-rules.pro

```text
# Conserva informações úteis para investigar falhas do APK otimizado.
-keepattributes SourceFile,LineNumberTable,Signature,*Annotation*
# Modelos JSON são codificados explicitamente; não usamos reflexão de nomes de campos.
# Media3, Credential Manager, Google Identity e Coil incluem consumer rules próprias.
# Cada execução publica mapping.txt junto dos relatórios para retrace de crashes.
```

## app/src/androidTest/java/com/example/BackupImportTest.kt

```kotlin
package com.example

import android.app.Application
import android.net.Uri
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelProvider
import com.example.data.backup.*
import com.example.data.notes.*
import com.example.data.pdf.*
import com.example.data.productivity.*
import com.example.data.repository.StudyViewModel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class BackupImportTest {
    @Test fun importThenExportKeepsExternalPdfAndRepeatedImportDoesNotDuplicate() = runBlocking {
        val instrumentation=InstrumentationRegistry.getInstrumentation()
        val context=instrumentation.targetContext
        lateinit var model:StudyViewModel
        val owner=ViewModelStore()
        instrumentation.runOnMainSync {
            model=ViewModelProvider(owner,ViewModelProvider.AndroidViewModelFactory.getInstance(
                context.applicationContext as Application))[StudyViewModel::class.java]
        }
        val unique=UUID.randomUUID().toString()
        val base=backupFixture()
        val data=base.copy(notes=NoteState(listOf(NoteTag("t-$unique","Bloco ${unique.take(8)}")),
            listOf(base.notes.notes.single().copy(id="n-$unique",tagId="t-$unique"))),
            questions=QuestionState(listOf(QuestionSubject("s-$unique","Matéria $unique")),
                listOf(base.questions.records.single().copy(id="q-$unique",subjectId="s-$unique"))),
            focusHistory=listOf(base.focusHistory.single().copy(id="f-$unique")),
            documents=listOf(base.documents.single().copy(driveFileId="pdf-$unique")))
        val repository=BackupRepository(context)
        val notes=NoteStore.get(context);val questions=QuestionStore.get(context);val pomodoro=PomodoroStore.get(context)
        val beforeNotes=notes.state.value.notes.map {it.id}.toSet()
        val beforeQuestions=questions.state.value.records.map {it.id}.toSet()
        val beforeHistory=pomodoro.state.value.history.map {it.id}.toSet()
        val beforeSettings=pomodoro.state.value.settings
        val beforeStudy=model.state.value
        val file=File(context.cacheDir,"backup-$unique.json")
        try {
            repository.importBackup(data,model)
            repository.importBackup(data,model)
            assertEquals(1,notes.state.value.notes.count {it.id=="n-$unique"})
            assertEquals(1,questions.state.value.records.count {it.id=="q-$unique"})
            assertEquals(1,pomodoro.state.value.history.count {it.id=="f-$unique"})
            assertTrue(notes.state.value.notes.map {it.id}.containsAll(beforeNotes))
            assertTrue(questions.state.value.records.map {it.id}.containsAll(beforeQuestions))
            assertTrue(pomodoro.state.value.history.map {it.id}.containsAll(beforeHistory))
            assertTrue(model.state.value.favorites.containsAll(data.study.favorites))
            assertEquals(data.study.theme,model.state.value.theme)
            assertEquals(data.pomodoroSettings,pomodoro.state.value.settings)
            repository.export(Uri.fromFile(file),model)
            val restored=repository.read(Uri.fromFile(file))
            assertEquals(data.documents.single(),restored.documents.first {it.driveFileId=="pdf-$unique"})
            assertEquals(data.notes.notes.single(),restored.notes.notes.first {it.id=="n-$unique"})
        } finally {
            file.delete()
            notes.delete("n-$unique");notes.deleteTag("t-$unique")
            questions.deleteSubject("s-$unique")
            val key=pdfStorageKey(pdfAccountKey(context),"pdf-$unique")
            File(context.filesDir,"annotations/$key.json").delete()
            pomodoro.configure(beforeSettings)
            model.importData(data.study.copy(theme=beforeStudy.theme,dynamicColor=beforeStudy.dynamicColor))
            instrumentation.runOnMainSync {owner.clear()}
        }
    }
}
```

## app/src/androidTest/java/com/example/BackupJsonTest.kt

```kotlin
package com.example

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.backup.*
import com.example.data.notes.*
import com.example.data.pdf.*
import com.example.data.productivity.*
import com.example.data.repository.ThemeMode
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

fun backupFixture() = PortableBackup(1_700_000_000_000L,
    StudyBackup(setOf("material-1"),setOf("material-2"),mapOf("material-1" to 100L),
        listOf("material-2","material-1"),ThemeMode.DARK,false),
    NoteState(listOf(NoteTag("tag","Estudo")),listOf(Note("note","Revisão","Conceitos de SUS","tag",2,1,2))),
    QuestionState(listOf(QuestionSubject("subject","SUS")),listOf(QuestionRecord("record","subject",8,2,3))),
    PomodoroSettings(focusMinutes=40,shortMinutes=8,longMinutes=20,cycles=3,ambienceEnabled=true),
    listOf(FocusRecord("focus",4,40*60_000L)),
    listOf(PdfBackup("external-drive-id",5,AnnotationDocument(mapOf(5 to PageAnnotations(
        listOf(InkStroke("ink",listOf(InkPoint(.1f,.3f),InkPoint(.8f,.3f)),true,0xFFFFD54FL,.027f)),
        listOf(PdfNote("pin",InkPoint(.4f,.6f),"Revisar"))))))),true,true)

@RunWith(AndroidJUnit4::class)
class BackupJsonTest {
    @Test fun allModulesAndNormalizedCoordinatesRoundTrip() {
        val fixture=backupFixture()
        val json=BackupJson.encode(fixture)
        assertEquals(fixture,BackupJson.decode(json))
        val root=JSONObject(json)
        assertEquals("keplerae-backup",root.getString("format"))
        assertEquals(1,root.getInt("schemaVersion"))
        assertFalse(json.contains("accessToken"))
        assertFalse(json.contains("apiKey"))
        assertFalse(json.contains("/data/"))
    }
    @Test fun invalidSchemaRelationsAndCountsAreRejectedBeforeImport() {
        fun rejected(change:(JSONObject)->Unit) {
            val root=JSONObject(BackupJson.encode(backupFixture()));change(root)
            assertThrows(Exception::class.java) {BackupJson.decode(root.toString())}
        }
        rejected {it.put("schemaVersion",999)}
        rejected {it.put("format","outro-app")}
        rejected {it.getJSONObject("questions").getJSONArray("records").getJSONObject(0).put("subjectId","missing")}
        rejected {it.getJSONObject("questions").getJSONArray("records").getJSONObject(0).put("wrong",-1)}
        rejected {it.getJSONObject("pdf").getJSONArray("documents").getJSONObject(0).put("driveFileId","../arquivo")}
        rejected {it.getJSONObject("pomodoro").getJSONObject("settings").put("cycles",0)}
    }
}
```

## app/src/androidTest/java/com/example/DevicePreview.kt

```kotlin
package com.example

import android.graphics.Bitmap
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File

/** Capturas reais do emulador, publicadas pelo Actions junto dos relatórios de interface. */
internal fun saveDevicePreview(name: String) {
    val instrumentation = InstrumentationRegistry.getInstrumentation()
    val root = File(instrumentation.targetContext.getExternalFilesDir(null), "design-preview").apply { mkdirs() }
    val screenshot = instrumentation.uiAutomation.takeScreenshot() ?: return
    File(root, "$name.png").outputStream().use { screenshot.compress(Bitmap.CompressFormat.PNG, 100, it) }
    screenshot.recycle()
}
```

## app/src/androidTest/java/com/example/DriveNativeTest.kt

```kotlin
package com.example

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.example.data.drive.DriveSettings
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class DriveNativeTest {
    @Test fun installedAppHasNetworkPermissionAndCanCreateSocket() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals(android.content.pm.PackageManager.PERMISSION_GRANTED,
            context.checkPermission(android.Manifest.permission.INTERNET, android.os.Process.myPid(), android.os.Process.myUid()))
        java.net.ServerSocket(0, 1, java.net.InetAddress.getLoopbackAddress()).use { server ->
            java.net.Socket().use { client ->
                client.connect(java.net.InetSocketAddress(java.net.InetAddress.getLoopbackAddress(), server.localPort), 2000)
                server.accept().use { peer -> assertTrue(peer.isConnected) }
            }
        }
    }
    @Test fun pdfCanBeRenderedOnDeviceWithoutBrowser() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val file = File.createTempFile("native-pdf-test-", ".pdf", context.cacheDir)
        try {
            val document = PdfDocument()
            try {
                repeat(2) { index ->
                    val page = document.startPage(PdfDocument.PageInfo.Builder(300, 400, index + 1).create())
                    page.canvas.drawColor(if (index == 0) Color.RED else Color.BLUE)
                    document.finishPage(page)
                }
                file.outputStream().use(document::writeTo)
            } finally { document.close() }
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    assertEquals(2, renderer.pageCount)
                    renderer.openPage(1).use { page ->
                        val bitmap = Bitmap.createBitmap(300, 400, Bitmap.Config.ARGB_8888)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        assertEquals(Color.BLUE, bitmap.getPixel(150, 200))
                        bitmap.recycle()
                    }
                }
            }
        } finally { file.delete() }
    }
    @Test fun keyRoundTripsThroughKeystoreWithoutPlaintextPreference() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val name = "drive-test-${UUID.randomUUID()}"
        val preferences = context.getSharedPreferences(name, 0)
        val settings = DriveSettings(context, name)
        try {
            val key = "not-a-real-api-key-for-local-keystore-test"
            settings.saveApiKey(key)
            assertEquals(key, settings.apiKey())
            assertFalse(preferences.getString("api_key", "")!!.contains(key))
            settings.saveApiKey("")
            assertEquals("", settings.apiKey())
        } finally { preferences.edit().clear().commit() }
    }
}
```

## app/src/androidTest/java/com/example/GoogleSessionStoreTest.kt

```kotlin
package com.example

import androidx.test.platform.app.InstrumentationRegistry
import com.example.data.auth.GoogleSessionStore
import com.example.data.auth.GoogleUser
import org.junit.Assert.*
import org.junit.Test

class GoogleSessionStoreTest {
    @Test fun profileSurvivesNewStoreInstanceAndSignOutClearsIt() {
        val context=InstrumentationRegistry.getInstrumentation().targetContext
        val store=GoogleSessionStore(context)
        val previous=store.read()
        try {
            val user=GoogleUser("user@example.com","Nome salvo",null)
            store.save(user)
            assertEquals(user,GoogleSessionStore(context).read())
            store.clear()
            assertNull(GoogleSessionStore(context).read())
        } finally { if(previous!=null) store.save(previous) else store.clear() }
    }
}
```

## app/src/androidTest/java/com/example/InterfaceTest.kt

```kotlin
package com.example

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.activity.ComponentActivity
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.repository.StudyViewModel
import com.example.ui.KepleraeApp
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class InterfaceTest {
    // Testa catálogo/tema diretamente, sem simular credenciais nem burlar o login em produção.
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun catalogAndThemeControlsWork() {
        lateinit var viewModel: StudyViewModel
        compose.activityRule.scenario.onActivity { activity ->
            viewModel = ViewModelProvider(activity)[StudyViewModel::class.java]
        }
        compose.setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            KepleraeTheme(state.theme, state.dynamicColor) { KepleraeApp(state, viewModel) }
        }
        compose.waitUntil(timeoutMillis = 20000) {
            compose.onAllNodesWithText("Seu percurso").fetchSemanticsNodes().isNotEmpty()
        }
        saveDevicePreview("inicio")
        // A barra de aparência foi removida da inicial por solicitação do usuário.
        compose.onNodeWithTag("settings").assertDoesNotExist()
        compose.onNodeWithTag("profile_open").performClick()
        compose.onNodeWithTag("settings").performClick()
        compose.onNodeWithTag("theme_DARK").performClick()
        compose.onNodeWithTag("theme_DARK").assertIsSelected()
        compose.onNodeWithTag("theme_LIGHT").performClick()
        compose.onNodeWithTag("theme_LIGHT").assertIsSelected()
        compose.onNodeWithTag("theme_SYSTEM").performClick()
        compose.onNodeWithTag("theme_SYSTEM").assertIsSelected()
        compose.onNodeWithTag("appearance_close").performClick()
        compose.waitUntil(timeoutMillis = 10000) {
            compose.onAllNodesWithTag("appearance_sheet").fetchSemanticsNodes().isEmpty()
        }
        compose.onNodeWithTag("profile_back").performClick()
        compose.waitUntil(timeoutMillis = 10000) {
            compose.onAllNodesWithTag("profile_open").fetchSemanticsNodes().isNotEmpty()
        }
        compose.onNodeWithTag("nav_SUBJECTS").performClick()
        compose.onNodeWithTag("settings").assertDoesNotExist()
        compose.onNodeWithTag("catalog_search").performTextInput("AVALIAÇÃO FISIOTERAPÊUTICA")
        compose.onNodeWithTag("catalog_list").performScrollToNode(
            hasText("AVALIAÇÃO FISIOTERAPÊUTICA EM TERAPIA INTENSIVA", substring = true))
        compose.onAllNodesWithText("AVALIAÇÃO FISIOTERAPÊUTICA EM TERAPIA INTENSIVA", substring = true)
            .onFirst().assertExists()
    }
}
```

## app/src/androidTest/java/com/example/LoginScreenTest.kt

```kotlin
package com.example

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.hasClickAction
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.repository.ThemeMode
import com.example.ui.login.LoginScreen
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LoginScreenTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    @Test fun offersOnlyGoogleAndInvokesTheEntryAction() {
        var calls = 0
        compose.setContent {
            KepleraeTheme(ThemeMode.LIGHT, dynamicColor = false) {
                LoginScreen(busy = false, error = null, onGoogleSignIn = { calls++ })
            }
        }
        compose.onNodeWithText("Kepleræ").assertIsDisplayed()
        compose.onNodeWithText("Desenvolvido por Madox Fênix").assertIsDisplayed()
        compose.onAllNodes(hasClickAction()).assertCountEquals(1)
        compose.onNodeWithTag("google_sign_in").performClick()
        compose.runOnIdle { assertEquals(1, calls) }
    }

    @Test fun preventsDuplicateRequestsWhileConnectingAndShowsErrorsInDarkTheme() {
        compose.setContent {
            KepleraeTheme(ThemeMode.DARK, dynamicColor = false) {
                LoginScreen(busy = true, error = "Sem conexão", onGoogleSignIn = {})
            }
        }
        compose.onNodeWithTag("google_sign_in").assertIsNotEnabled()
        compose.onNodeWithTag("login_error").assertIsDisplayed()
    }
}
```

## app/src/androidTest/java/com/example/NativePdfPagerTest.kt

```kotlin
package com.example

import android.graphics.pdf.PdfDocument
import androidx.activity.ComponentActivity
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.ui.NativePdf
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class NativePdfPagerTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun reopeningSameDocumentRestoresSettledPage() {
        val key = "page-test-${java.util.UUID.randomUUID()}"
        val file = File.createTempFile("remember-page", ".pdf", compose.activity.cacheDir)
        val pdf = PdfDocument()
        repeat(3) { index ->
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(300,450,index+1).create())
            pdf.finishPage(page)
        }
        file.outputStream().use(pdf::writeTo);pdf.close()
        var opened by mutableStateOf(true)
        compose.setContent { KepleraeTheme { if (opened) NativePdf(file,Modifier.fillMaxSize(),documentKey=key) } }
        compose.waitUntil(20000) { compose.onAllNodesWithText("1 / 3").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Próxima página").performClick()
        compose.waitUntil(10000) { compose.onAllNodesWithText("2 / 3").fetchSemanticsNodes().isNotEmpty() }
        compose.waitForIdle()
        compose.runOnIdle { opened = false };compose.waitForIdle()
        compose.runOnIdle { opened = true }
        compose.waitUntil(20000) { compose.onAllNodesWithText("2 / 3").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("2 / 3").assertIsDisplayed()
        compose.runOnIdle { opened = false };compose.waitForIdle()
        compose.activity.getSharedPreferences("keplerae_pdf_reading",0).edit().remove(key).commit()
        file.delete()
    }
    @Test fun oneFingerSwipeAdvancesRealRenderedPdfPages() {
        val file = File.createTempFile("pager-test", ".pdf", compose.activity.cacheDir)
        val document = PdfDocument()
        try {
            repeat(3) { index ->
                val page = document.startPage(PdfDocument.PageInfo.Builder(300, 450, index + 1).create())
                page.canvas.drawText("Página ${index + 1}", 40f, 60f, android.graphics.Paint().apply { textSize = 24f })
                document.finishPage(page)
            }
            file.outputStream().use(document::writeTo)
        } finally {
            document.close()
        }
        compose.setContent { KepleraeTheme { NativePdf(file, Modifier.fillMaxSize()) } }
        compose.waitUntil(20000) { compose.onAllNodesWithContentDescription("Página 1").fetchSemanticsNodes().isNotEmpty() }
        // Arrasto controlado, sem fling que possa saltar mais de uma página.
        compose.onNodeWithTag("pdf_pager").performTouchInput {
            swipe(start = androidx.compose.ui.geometry.Offset(width * .8f, height * .5f),
                end = androidx.compose.ui.geometry.Offset(width * .2f, height * .5f), durationMillis = 450)
        }
        compose.waitUntil(10000) { compose.onAllNodesWithText("2 / 3").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("2 / 3").assertIsDisplayed()
        saveDevicePreview("pdf-pagina-2")
        compose.onNodeWithContentDescription("Página anterior").performClick()
        compose.waitUntil(10000) { compose.onAllNodesWithText("1 / 3").fetchSemanticsNodes().isNotEmpty() }
        file.delete()
    }
}
```

## app/src/androidTest/java/com/example/NotesScreenTest.kt

```kotlin
package com.example

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.ui.notes.NotesScreen
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class NotesScreenTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun floatingActionCreatesSearchableNoteAndDeleteRemovesIt() {
        val title = "Nota ${UUID.randomUUID()}"
        compose.setContent { KepleraeTheme { NotesScreen() } }
        compose.onNodeWithTag("note_new").performClick()
        compose.onNodeWithTag("note_title").performTextInput(title)
        compose.onNodeWithTag("note_body").performTextInput("Revisar matéria amanhã")
        compose.onNodeWithTag("note_confirm").performClick()
        compose.onNodeWithTag("notes_search").performTextInput(title)
        compose.onNode(hasText(title) and !hasTestTag("notes_search")).performClick()
        compose.onNodeWithContentDescription("Excluir anotação").performClick()
        compose.onNodeWithText("Excluir",useUnmergedTree=true).performClick()
        compose.onNode(hasText(title) and !hasTestTag("notes_search")).assertDoesNotExist()
    }
}
```

## app/src/androidTest/java/com/example/PdfPersistenceTest.kt

```kotlin
package com.example

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.example.data.pdf.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class PdfPersistenceTest {
    @Test fun inkAndPinsSurviveReopeningAndSnapshotReplacement() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val key = "test-${UUID.randomUUID()}"
        val data = PageAnnotations(listOf(InkStroke("stroke",listOf(InkPoint(.1f,.3f),InkPoint(.8f,.3f)),
            true,0xFFFFD54FL,.027f)),listOf(PdfNote("note",InkPoint(.4f,.6f),"Revisar este conceito")))
        val first = PdfAnnotationStore(context,key)
        first.load();first.replace(4,data);first.flush();first.close()
        val reopened = PdfAnnotationStore(context,key)
        try {
            reopened.load();assertEquals(data,reopened.state.value.pages[4])
            reopened.replace(4,PageAnnotations());reopened.flush()
            val third = PdfAnnotationStore(context,key)
            third.load();assertEquals(PageAnnotations(),third.state.value.pages[4]);third.close()
        } finally {
            reopened.close();File(context.filesDir,"annotations/$key.json").delete()
        }
    }
}
```

## app/src/androidTest/java/com/example/PomodoroCustomizationTest.kt

```kotlin
package com.example

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.productivity.*
import com.example.ui.productivity.PomodoroScreen
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PomodoroCustomizationTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    @Test fun savingCustomFieldsChangesFocusClockAndCycleCount() {
        val store=PomodoroStore.get(compose.activity)
        compose.runOnUiThread {store.pause();store.reset();store.configure(PomodoroSettings())}
        compose.setContent {KepleraeTheme {PomodoroScreen()}}
        compose.onNodeWithText("Ajustes").performClick()
        compose.onNodeWithTag("pomodoro_screen").performScrollToNode(hasTestTag("pomodoro_customize"))
        compose.onNodeWithTag("pomodoro_customize").performClick()
        listOf("focus" to "42","short" to "7","long" to "19","cycles" to "6").forEach { (field,value) ->
            compose.onNodeWithTag("custom_$field").performScrollTo().performTextReplacement(value)
        }
        compose.onNodeWithTag("custom_save").performClick()
        compose.runOnIdle {
            assertEquals(42,store.state.value.settings.focusMinutes)
            assertEquals(6,store.state.value.settings.cycles)
            assertEquals(42*60000L,store.state.value.remainingMs)
        }
        compose.onNodeWithTag("pomodoro_screen").performScrollToIndex(0)
        compose.onNodeWithText("Foco").performClick()
        compose.onNodeWithTag("pomodoro_time").assertTextEquals("42:00")
    }
}
```

## app/src/androidTest/java/com/example/PomodoroMigrationTest.kt

```kotlin
package com.example

import android.content.Context
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.productivity.PomodoroStore
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PomodoroMigrationTest {
    @Test fun version23HistoryAndDurationsSurviveNewSoundPreferences() {
        val context=InstrumentationRegistry.getInstrumentation().targetContext
        val prefs=context.getSharedPreferences("keplerae_pomodoro",Context.MODE_PRIVATE)
        val previous=prefs.getString("state",null)
        val constructor=PomodoroStore::class.java.getDeclaredConstructor(Context::class.java).apply {isAccessible=true}
        try {
            prefs.edit().putString("state","""{"settings":{"focus":50,"short":10,"long":20,"cycles":4,"sounds":false},"history":[{"id":"old","at":123,"duration":3000000}]}""").commit()
            val old=constructor.newInstance(context)
            assertEquals(50,old.state.value.settings.focusMinutes)
            assertFalse(old.state.value.settings.ambienceEnabled)
            assertFalse(old.state.value.settings.sounds)
            old.configure(old.state.value.settings.copy(ambienceEnabled=true,ambienceId="library",ambienceVolume=.4f))
            val reopened=constructor.newInstance(context).state.value
            assertEquals(50,reopened.settings.focusMinutes)
            assertEquals("library",reopened.settings.ambienceId)
            assertEquals(.4f,reopened.settings.ambienceVolume,0.001f)
            assertFalse(reopened.settings.sounds)
            assertEquals(3_000_000L,reopened.history.single().durationMs)
        } finally {
            val edit=prefs.edit();if(previous==null)edit.remove("state")else edit.putString("state",previous);edit.commit()
        }
    }
}
```

## app/src/androidTest/java/com/example/ProductivityDesignTest.kt

```kotlin
package com.example

import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.repository.ThemeMode
import com.example.ui.productivity.*
import com.example.ui.theme.KepleraeTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ProductivityDesignTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    @Test fun focusSettingsAndDashboardRenderInBothThemes() {
        val dark=mutableStateOf(false);val questions=mutableStateOf(false)
        compose.setContent {
            KepleraeTheme(if(dark.value)ThemeMode.DARK else ThemeMode.LIGHT,false) {
                if(questions.value)QuestionsScreen()else PomodoroScreen()
            }
        }
        compose.onNodeWithTag("pomodoro_time").assertExists()
        saveDevicePreview("pomodoro-claro-2.4")
        compose.runOnIdle {dark.value=true}
        compose.onNodeWithTag("pomodoro_time").assertExists()
        saveDevicePreview("pomodoro-escuro-2.4")
        compose.onNodeWithText("Ajustes").performClick()
        compose.onNodeWithText("Som durante o foco").assertExists()
        saveDevicePreview("ajustes-escuro-2.4")
        compose.runOnIdle {dark.value=false}
        compose.onNodeWithText("Som durante o foco").assertExists()
        saveDevicePreview("ajustes-claro-2.4")
        compose.runOnIdle {questions.value=true}
        compose.onNodeWithTag("questions_screen").assertExists()
        compose.onNodeWithText("Seu desempenho").assertExists()
        saveDevicePreview("questoes-claro-2.4")
        compose.runOnIdle {dark.value=true}
        compose.onNodeWithText("Seu desempenho").assertExists()
        saveDevicePreview("questoes-escuro-2.4")
    }
}
```

## app/src/androidTest/java/com/example/ProfileTest.kt

```kotlin
package com.example

import androidx.activity.ComponentActivity
import androidx.compose.runtime.getValue
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.auth.GoogleUser
import com.example.data.repository.StudyViewModel
import com.example.ui.KepleraeApp
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ProfileTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Test fun profileUsesChosenAccountAndThemeAndConfirmsSignOut() {
        lateinit var model: StudyViewModel
        var signOutCalls = 0
        compose.activityRule.scenario.onActivity { model = ViewModelProvider(it)[StudyViewModel::class.java] }
        compose.setContent {
            val state by model.state.collectAsStateWithLifecycle()
            KepleraeTheme(state.theme, state.dynamicColor) {
                KepleraeApp(state, model, GoogleUser("user@example.com", "Conta de teste", null), { signOutCalls++ })
            }
        }
        compose.waitUntil(20000) { compose.onAllNodesWithTag("profile_open").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("nav_SUBJECTS").performClick()
        compose.onNodeWithTag("profile_rail").performClick()
        compose.onNodeWithText("Conta de teste").assertIsDisplayed()
        compose.onNodeWithTag("profile_theme_DARK").performClick().assertIsSelected()
        compose.waitForIdle()
        saveDevicePreview("perfil-escuro")
        compose.onNodeWithTag("profile_theme_LIGHT").performClick().assertIsSelected()
        compose.waitForIdle()
        saveDevicePreview("perfil-claro")
        compose.onNodeWithTag("profile_theme_SYSTEM").performScrollTo().performClick().assertIsSelected()
        compose.onNodeWithTag("profile_theme_LIGHT").assertIsNotSelected()
        compose.onNodeWithTag("profile_theme_DARK").assertIsNotSelected()
        compose.onNodeWithTag("backup_export").performScrollTo().assertIsDisplayed()
        compose.onNodeWithTag("backup_import").performScrollTo().assertIsDisplayed()
        compose.onNodeWithTag("profile_rail").assertIsDisplayed()
        compose.onNodeWithTag("sign_out").performScrollTo().performClick()
        compose.runOnIdle { assertEquals(0, signOutCalls) }
        compose.onNodeWithTag("confirm_sign_out").performClick()
        compose.runOnIdle { assertEquals(1, signOutCalls) }
    }
}
```

## app/src/androidTest/java/com/example/QuestionsDeletionTest.kt

```kotlin
package com.example

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.productivity.QuestionStore
import com.example.ui.productivity.QuestionsScreen
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class QuestionsDeletionTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    @Test fun blockDeletionAndGlobalResetRequireConfirmationAndPersist() {
        val store=QuestionStore.get(compose.activity)
        val first=store.createSubject("Bloco ${UUID.randomUUID()}")
        val second=store.createSubject("Outro ${UUID.randomUUID()}")
        store.add(first,8,2);store.add(second,3,1)
        compose.setContent {KepleraeTheme {QuestionsScreen()}}
        compose.onNodeWithTag("questions_screen").performScrollToNode(hasTestTag("delete_block_$first"))
        compose.onNodeWithTag("delete_block_$first").performClick()
        compose.onNodeWithText("Cancelar").performClick()
        compose.runOnIdle {assertTrue(store.state.value.subjects.any {it.id==first})}
        compose.onNodeWithTag("delete_block_$first").performClick()
        compose.onNodeWithTag("confirm_delete_block").performClick()
        compose.runOnIdle {
            assertFalse(store.state.value.subjects.any {it.id==first})
            assertFalse(store.state.value.records.any {it.subjectId==first})
            assertTrue(store.state.value.records.any {it.subjectId==second})
        }
        compose.onNodeWithTag("questions_screen").performScrollToIndex(0)
        compose.onNodeWithTag("questions_menu").performClick()
        compose.onNodeWithTag("questions_reset").performClick()
        compose.onNodeWithTag("confirm_reset_questions").performClick()
        compose.runOnIdle {
            assertTrue(store.state.value.subjects.isEmpty())
            assertTrue(store.state.value.records.isEmpty())
            val saved=org.json.JSONObject(compose.activity.getSharedPreferences("keplerae_questions",0).getString("state","{}")!!)
            assertEquals(0,saved.getJSONArray("subjects").length())
            assertEquals(0,saved.getJSONArray("records").length())
        }
    }
}
```

## app/src/androidTest/java/com/example/ReactiveThemeTest.kt

```kotlin
package com.example

import android.content.res.Configuration
import androidx.activity.ComponentActivity
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.repository.ThemeMode
import com.example.ui.theme.KepleraeTheme
import com.example.ui.theme.LocalKepleraeDarkTheme
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ReactiveThemeTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    @Test fun themeColorsChangeImmediatelyAndSystemModeFollowsConfiguration() {
        val mode=mutableStateOf(ThemeMode.LIGHT)
        val systemDark=mutableStateOf(true)
        var luminance=0f; var appliedDark=false
        compose.setContent {
            val configuration=Configuration(LocalConfiguration.current).apply {
                uiMode=(uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or
                    (if(systemDark.value)Configuration.UI_MODE_NIGHT_YES else Configuration.UI_MODE_NIGHT_NO)
            }
            CompositionLocalProvider(LocalConfiguration provides configuration) {
                KepleraeTheme(mode.value,false) {
                    val surface=MaterialTheme.colorScheme.surface
                    val dark=LocalKepleraeDarkTheme.current
                    SideEffect { luminance=surface.luminance();appliedDark=dark }
                }
            }
        }
        compose.runOnIdle {assertTrue(luminance>.35f);assertFalse(appliedDark);mode.value=ThemeMode.DARK}
        compose.runOnIdle {assertTrue(luminance<.35f);assertTrue(appliedDark);mode.value=ThemeMode.LIGHT}
        compose.runOnIdle {assertTrue(luminance>.35f);mode.value=ThemeMode.SYSTEM}
        compose.runOnIdle {assertTrue(luminance<.35f);systemDark.value=false}
        compose.runOnIdle {assertTrue(luminance>.35f);assertFalse(appliedDark)}
    }
}
```

## app/src/androidTest/java/com/example/SidebarNavigationTest.kt

```kotlin
package com.example

import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.auth.GoogleUser
import com.example.ui.Destination
import com.example.ui.components.SidebarNavigation
import com.example.ui.theme.KepleraeTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SidebarNavigationTest {
    @get:Rule val compose=createAndroidComposeRule<ComponentActivity>()
    @Test fun fiveMenusAndProfileRemainAccessibleAfterNavigation() {
        val current=mutableStateOf(Destination.HOME)
        val profile=mutableStateOf(false)
        var profileCalls=0
        compose.setContent { KepleraeTheme {
            SidebarNavigation(current.value,profile.value,GoogleUser("test@example.com","Teste",null),
                onNavigate={current.value=it;profile.value=false},
                onProfile={profile.value=true;profileCalls++})
        } }
        compose.onNodeWithTag("sidebar_navigation").assertIsDisplayed()
        listOf("VIDEOS","PDFS","AUDIO").forEach {compose.onNodeWithTag("nav_$it").assertDoesNotExist()}
        compose.onNodeWithTag("nav_POMODORO").performClick().assertIsSelected()
        compose.onNodeWithTag("nav_NOTES").performClick().assertIsSelected()
        compose.onNodeWithTag("profile_rail").performClick().assertIsSelected()
        compose.runOnIdle {assertEquals(1,profileCalls)}
        compose.onNodeWithTag("nav_NOTES").assertIsNotSelected()
        compose.onNodeWithTag("nav_SUBJECTS").performClick().assertIsSelected()
        listOf("HOME","POMODORO","QUESTIONS","NOTES").forEach {compose.onNodeWithTag("nav_$it").assertIsDisplayed()}
        compose.onNodeWithTag("profile_rail").assertIsDisplayed().assertIsNotSelected()
    }
}
```

## app/src/debug/java/com/example/ui/DesignPreview.kt

```kotlin
@file:OptIn(androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import com.example.data.auth.GoogleUser
import com.example.data.model.*
import com.example.data.repository.StudyState
import com.example.data.repository.ThemeMode
import com.example.ui.components.SharedMotion
import com.example.ui.home.HomeScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.theme.KepleraeTheme
import org.json.JSONArray

/** Previews reais de Compose. Leem o catálogo empacotado e não acessam o Drive. */
@Composable private fun PreviewContent(profile: Boolean, dark: Boolean) {
    val context = LocalContext.current
    val state = remember(context, dark) {
        val rows = runCatching {
            val array = JSONArray(context.assets.open("catalog.json").bufferedReader().use { it.readText() })
            List(array.length()) { i ->
                val row = array.getJSONObject(i); val path = row.getJSONArray("folderPath")
                StudyItem(row.getString("id"), row.getString("title"), row.getString("filename"),
                    row.getString("subjectId"), List(path.length()) { path.getString(it) },
                    ContentType.valueOf(row.getString("type")), row.getString("url"),
                    LinkKind.valueOf(row.getString("linkKind")), row.getString("driveFileId"),
                    row.getString("note"), row.getString("source"))
            }
        }.getOrDefault(emptyList())
        StudyState(items = rows, theme = if (dark) ThemeMode.DARK else ThemeMode.LIGHT,
            dynamicColor = false, loading = false)
    }
    KepleraeTheme(state.theme, dynamicColor = false) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            SharedTransitionLayout {
                val shared = this
                AnimatedContent(profile, label = "preview_route") { showProfile ->
                    val motion = SharedMotion(shared, this)
                    val user = GoogleUser("exemplo@example.com", "Conta de exemplo", null)
                    if (showProfile) ProfileScreen(user, state, motion, {}, {}, {}, {})
                    else HomeScreen(state, user, motion, {}, {}, {}, {}, {})
                }
            }
        }
    }
}

@Preview(name = "Início claro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun HomeLightPreview() = PreviewContent(profile = false, dark = false)
@Preview(name = "Início escuro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun HomeDarkPreview() = PreviewContent(profile = false, dark = true)
@Preview(name = "Início tablet", widthDp = 1000, heightDp = 700, showBackground = true)
@Composable private fun TabletHomePreview() = PreviewContent(profile = false, dark = false)
@Preview(name = "Perfil claro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun ProfileLightPreview() = PreviewContent(profile = true, dark = false)
@Preview(name = "Perfil escuro", widthDp = 412, heightDp = 915, showBackground = true)
@Composable private fun ProfileDarkPreview() = PreviewContent(profile = true, dark = true)
@Preview(name = "Perfil fonte ampliada", widthDp = 360, heightDp = 800, fontScale = 1.5f)
@Composable private fun ProfileLargeFontPreview() = PreviewContent(profile = true, dark = false)
```

## app/src/debug/java/com/example/ui/login/LoginPreview.kt

```kotlin
package com.example.ui.login

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.data.repository.ThemeMode
import com.example.ui.theme.KepleraeTheme

@Preview(name = "Login claro", showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun LoginLightPreview() {
    KepleraeTheme(mode = ThemeMode.LIGHT, dynamicColor = false) {
        LoginScreen(busy = false, error = null, onGoogleSignIn = {})
    }
}

@Preview(name = "Login escuro", showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun LoginDarkPreview() {
    KepleraeTheme(mode = ThemeMode.DARK, dynamicColor = false) {
        LoginScreen(busy = false, error = null, onGoogleSignIn = {})
    }
}

@Preview(name = "Tablet", showBackground = true, widthDp = 960, heightDp = 600)
@Preview(name = "Texto ampliado", showBackground = true, widthDp = 360, heightDp = 740, fontScale = 1.5f)
@Composable
private fun LoginTabletPreview() {
    KepleraeTheme(mode = ThemeMode.LIGHT, dynamicColor = false) {
        LoginScreen(busy = true, error = null, onGoogleSignIn = {})
    }
}
```

## app/src/debug/java/com/example/ui/theme/ThemePreview.kt

```kotlin
package com.example.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.data.repository.ThemeMode

/** Amostra do tema; não é uma nova tela do app. */
@Composable
private fun ThemeSample(dark: Boolean) {
    KepleraeTheme(mode = if (dark) ThemeMode.DARK else ThemeMode.LIGHT, dynamicColor = false) {
        Surface {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Kepleræ", style = MaterialTheme.typography.displayLarge)
                Text("Seu espaço de estudo", style = MaterialTheme.typography.headlineSmall)
                Text("Aulas, PDFs e áudios no seu ritmo.", style = MaterialTheme.typography.bodyLarge)
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Continuar aprendendo", style = MaterialTheme.typography.titleLarge)
                        Text("Cores, formas e tipografia compartilhadas.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = {}) { Text("Começar") }
                    FilledTonalButton(onClick = {}) { Text("Biblioteca") }
                }
            }
        }
    }
}

@Preview(name = "Kepleræ · claro", widthDp = 420, showBackground = true)
@Composable private fun LightThemePreview() = ThemeSample(dark = false)

@Preview(name = "Kepleræ · escuro", widthDp = 420, showBackground = true)
@Composable private fun DarkThemePreview() = ThemeSample(dark = true)
```

## app/src/main/AndroidManifest.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />


    <!-- Visibilidade do provedor de fontes a partir do Android 11. -->
    <queries>
        <provider android:authorities="com.google.android.gms.fonts" />
    </queries>

    <application
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.MyApplication">
        <service android:name=".data.playback.PlaybackService" android:exported="true"
            android:foregroundServiceType="mediaPlayback">
            <intent-filter><action android:name="androidx.media3.session.MediaSessionService" /></intent-filter>
        </service>
        <service android:name=".data.productivity.PomodoroService" android:exported="false"
            android:foregroundServiceType="specialUse|mediaPlayback">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="User-started Pomodoro study timer with countdown notification and completion sound until the user pauses or stops it." />
        </service>
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:theme="@style/Theme.MyApplication">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
```

## app/src/main/java/com/example/MainActivity.kt

```kotlin
package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.StudyViewModel
import com.example.data.auth.GoogleLoginViewModel
import com.example.ui.KepleraeApp
import com.example.ui.login.LoginRoute
import com.example.ui.theme.KepleraeTheme
import com.example.ui.theme.isDarkMode
import com.example.data.productivity.PomodoroStore
import com.example.data.productivity.PomodoroService

class MainActivity : ComponentActivity() {
    private val viewModel: StudyViewModel by viewModels()
    private val loginViewModel: GoogleLoginViewModel by viewModels()
    override fun onResume() {
        super.onResume()
        loginViewModel.refreshSavedAuthorization()
        if(PomodoroStore.get(this).state.value.running) {
            runCatching { PomodoroService.command(this,PomodoroService.RESTORE) }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            val login by loginViewModel.state.collectAsStateWithLifecycle()
            val dark = isDarkMode(state.theme)
            SideEffect {
                val style = if (dark) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                    else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            KepleraeTheme(state.theme, state.dynamicColor) {
                if (login.user == null) LoginRoute(loginViewModel)
                else KepleraeApp(state, viewModel, login.user, loginViewModel::signOut,
                    openPomodoro = intent?.getBooleanExtra("open_pomodoro",false)==true)
            }
        }
    }
}
```

## app/src/main/java/com/example/data/auth/GoogleLoginConfiguration.kt

```kotlin
package com.example.data.auth

/** Valida o formato do ID público. O tipo Web deve ser conferido no Google Cloud. */
internal object GoogleLoginConfiguration {
    fun isWebClientId(value: String): Boolean =
        value.matches(Regex("[A-Za-z0-9_-]+\\.apps\\.googleusercontent\\.com"))
}
```

## app/src/main/java/com/example/data/auth/GoogleLoginViewModel.kt

```kotlin
package com.example.data.auth

import android.accounts.Account
import android.app.Application
import android.app.PendingIntent
import android.content.Intent
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialProviderConfigurationException
import androidx.credentials.exceptions.GetCredentialUnsupportedException
import androidx.credentials.exceptions.NoCredentialException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.drive.DriveSession
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.tasks.await

data class GoogleLoginState(
    val user: GoogleUser? = null,
    val busy: Boolean = false,
    val error: String? = null,
    val driveResolution: PendingIntent? = null,
)

/**
 * Credential Manager identifica a conta; AuthorizationClient autoriza o Drive.
 * Um ID token do Google nunca é usado como access token da API do Drive.
 * Não há Activity, ID token ou refresh token guardado neste ViewModel.
 */
class GoogleLoginViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext = application.applicationContext
    private val authorizationClient = Identity.getAuthorizationClient(appContext)
    private val sessionStore = GoogleSessionStore(appContext)
    private val _state = MutableStateFlow(GoogleLoginState(user = sessionStore.read()))
    val state = _state.asStateFlow()
    private var pendingUser: GoogleUser? = null
    private var operation = 0L

    init {
        refreshSavedAuthorization()
        viewModelScope.launch {
            while (true) { delay(45 * 60_000L); refreshSavedAuthorization() }
        }
    }

    /** Restaura o perfil imediatamente e renova o token sem abrir folhas de login. */
    fun refreshSavedAuthorization() {
        val user = _state.value.user ?: return
        val requestId = operation
        viewModelScope.launch {
            try {
                val result = authorizationClient.authorize(AuthorizationRequest.builder()
                    .setAccount(Account(user.email, "com.google"))
                    .setRequestedScopes(listOf(Scope(DRIVE_READONLY))).build()).await()
                if (requestId != operation || _state.value.user?.email != user.email) return@launch
                if (!result.hasResolution() && !result.accessToken.isNullOrBlank()) {
                    DriveSession.accessToken = result.accessToken.orEmpty()
                    DriveSession.revision++
                }
                // Se o consentimento foi revogado, o visualizador oferece Configurar Drive.
                // Falta de internet não apaga a conta nem obriga login ao abrir o app.
            } catch (error: CancellationException) { throw error }
            catch (_: Exception) { /* Perfil local permanece disponível offline. */ }
        }
    }

    fun beginSignIn(): Boolean {
        if (_state.value.busy) return false // Impede duas folhas de conta simultâneas.
        operation++
        pendingUser = null
        _state.value = GoogleLoginState(busy = true)
        return true
    }

    fun cancelCredentialRequest() {
        // Se o Credential Manager for cancelado pela recriação da tela, pode tentar de novo.
        if (pendingUser == null && _state.value.busy) {
            _state.value = GoogleLoginState()
        }
    }

    fun credentialFailure(error: Throwable) {
        pendingUser = null
        _state.value = GoogleLoginState(error = loginErrorMessage(error))
    }

    fun configurationMissing() {
        _state.value = GoogleLoginState(
            error = "A entrada Google ainda não foi configurada nesta versão do app. Preencha o ID OAuth do tipo Web antes de gerar o APK.",
        )
    }

    fun authorizeDrive(user: GoogleUser) {
        pendingUser = user
        val requestId = operation
        viewModelScope.launch {
            try {
                val request = AuthorizationRequest.builder()
                    // A mesma conta escolhida em Entrar com Google, inclusive com várias contas.
                    .setAccount(Account(user.email, "com.google"))
                    .setRequestedScopes(listOf(Scope(DRIVE_READONLY)))
                    .build()
                val result = authorizationClient.authorize(request).await()
                if (requestId != operation) return@launch
                if (result.hasResolution()) {
                    val pending = result.pendingIntent
                        ?: error("Não foi possível iniciar a autorização de leitura do Drive.")
                    _state.value = GoogleLoginState(busy = true, driveResolution = pending)
                } else {
                    completeDriveAuthorization(result)
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                if (requestId == operation) credentialFailure(error)
            }
        }
    }

    /** Consome a solicitação antes de abrir a folha, evitando repetições em recomposição. */
    fun consumeDriveResolution() {
        _state.value = _state.value.copy(driveResolution = null)
    }

    fun receiveDriveResult(data: Intent?, wasSuccessful: Boolean) {
        if (pendingUser == null) return // Ignora resultados de uma sessão já encerrada.
        if (!wasSuccessful || data == null) {
            pendingUser = null
            _state.value = GoogleLoginState(
                error = "A leitura do Drive não foi autorizada. Toque em Entrar com Google para tentar novamente.",
            )
            return
        }
        try {
            completeDriveAuthorization(authorizationClient.getAuthorizationResultFromIntent(data))
        } catch (error: Exception) {
            credentialFailure(error)
        }
    }

    private fun completeDriveAuthorization(result: AuthorizationResult) {
        val user = pendingUser ?: error("A conta escolhida não está mais disponível.")
        val token = result.accessToken.orEmpty()
        check(token.isNotBlank()) { "O Google não retornou a autorização de leitura do Drive." }
        // Mantém a integração nativa 1.2.2: o restante do app lê DriveSession.
        DriveSession.accessToken = token
        DriveSession.revision++
        pendingUser = null
        sessionStore.save(user)
        _state.value = GoogleLoginState(user = user)
    }

    /** Saída pelo perfil: encerra a sessão local e limpa a escolha de conta no provedor Google. */
    fun signOut() {
        operation++ // Respostas atrasadas não podem restaurar a sessão encerrada.
        pendingUser = null
        DriveSession.clear()
        appContext.stopService(android.content.Intent(appContext, com.example.data.playback.PlaybackService::class.java))
        sessionStore.clear()
        _state.value = GoogleLoginState(busy = true)
        viewModelScope.launch {
            try {
                CredentialManager.create(appContext)
                    .clearCredentialState(ClearCredentialStateRequest())
                _state.value = GoogleLoginState()
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                // A sessão local sempre termina, mesmo se o provedor estiver indisponível.
                _state.value = GoogleLoginState(
                    error = "Você saiu do app. O Google não conseguiu limpar a seleção de conta; escolha a conta novamente na próxima entrada.",
                )
            }
        }
    }

    private companion object {
        const val DRIVE_READONLY = "https://www.googleapis.com/auth/drive.readonly"
    }
}

internal fun loginErrorMessage(error: Throwable): String = when (error) {
    is GetCredentialCancellationException -> "Entrada cancelada. Você pode tentar novamente."
    is NoCredentialException -> "Nenhuma conta foi disponibilizada. Confira os Serviços do Google Play e tente novamente."
    is GetCredentialProviderConfigurationException -> "O provedor Google não está disponível. Atualize os Serviços do Google Play neste aparelho."
    is GetCredentialUnsupportedException -> "Este aparelho não oferece o provedor de entrada Google necessário."
    is ApiException -> when (error.statusCode) {
        7 -> "Não foi possível conectar ao Google. Confira sua conexão e tente novamente."
        10 -> "O Google recusou o cadastro do app (10). Confira o cliente OAuth Android, o pacote e o SHA-1 deste APK."
        16 -> "Autorização cancelada. Toque em Entrar com Google para tentar novamente."
        8 -> "O Google retornou um erro interno (8). Tente novamente; esse código sozinho não identifica erro no OAuth."
        else -> "Não foi possível autorizar o Drive. Código Google: ${error.statusCode}. Confira os usuários de teste e os clientes OAuth no mesmo projeto."
    }
    else -> "Não foi possível concluir a entrada. Confira sua conexão, o ID OAuth Web e os clientes OAuth no Google Cloud."
}
```

## app/src/main/java/com/example/data/auth/GoogleSessionStore.kt

```kotlin
package com.example.data.auth

import android.content.Context

/** Guarda apenas o perfil local. Tokens do Google continuam somente em memória. */
class GoogleSessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("keplerae_google_session", Context.MODE_PRIVATE)
    fun read(): GoogleUser? {
        val email = prefs.getString("email", null)?.takeIf { it.isNotBlank() } ?: return null
        return GoogleUser(email, prefs.getString("name", email) ?: email, prefs.getString("photo", null))
    }
    fun save(user: GoogleUser) {
        prefs.edit().putString("email", user.email).putString("name", user.displayName)
            .putString("photo", user.photoUrl).commit()
    }
    fun clear() { prefs.edit().clear().commit() }
}
```

## app/src/main/java/com/example/data/auth/GoogleUser.kt

```kotlin
package com.example.data.auth

/** Somente dados de apresentação. Tokens não são persistidos neste modelo. */
data class GoogleUser(
    val email: String,
    val displayName: String,
    val photoUrl: String?,
)
```

## app/src/main/java/com/example/data/backup/BackupJson.kt

```kotlin
package com.example.data.backup

import com.example.data.notes.*
import com.example.data.pdf.*
import com.example.data.productivity.*
import com.example.data.repository.ThemeMode
import org.json.JSONArray
import org.json.JSONObject

/** Contrato JSON versionado, sem caminhos Android, credenciais ou arquivos de mídia. */
object BackupJson {
    private fun <T> array(values: Iterable<T>, map: (T)->Any): JSONArray =
        JSONArray().apply {values.forEach {put(map(it))}}
    private fun JSONArray.objects(): List<JSONObject> {
        require(length()<=50_000) {"Backup com registros demais."}
        return List(length()) {getJSONObject(it)}
    }
    private fun strings(a: JSONArray): List<String> {
        require(a.length()<=50_000)
        return List(a.length()) {a.getString(it).also(::id)}.also {require(it.distinct().size==it.size)}
    }
    private fun id(value: String) {require(value.length in 1..256 && value.none {it.isISOControl()}) {"Identificador inválido."}}
    private fun text(value: String, limit: Int) {require(value.length<=limit) {"Texto excede o limite."}}
    private fun timestamp(value: Long) {require(value>=0) {"Data inválida."}}
    private fun unique(ids: List<String>) {ids.forEach(::id);require(ids.distinct().size==ids.size) {"Registros duplicados no arquivo."}}

    fun encode(backup: PortableBackup): String {
        val s=backup.study;val c=backup.pomodoroSettings
        return JSONObject().put("format",BACKUP_FORMAT).put("schemaVersion",BACKUP_SCHEMA)
            .put("appVersion","1.0.1").put("exportedAt",backup.exportedAt)
            .put("study",JSONObject().put("favorites",array(s.favorites){it}).put("completed",array(s.completed){it})
                .put("itemOrder",array(s.itemOrder){it}).put("accessed",array(s.accessed.entries){JSONObject().put("id",it.key).put("at",it.value)})
                .put("theme",s.theme.name).put("dynamicColor",s.dynamicColor))
            .put("notes",JSONObject().put("tags",array(backup.notes.tags){JSONObject().put("id",it.id).put("name",it.name)})
                .put("items",array(backup.notes.notes){JSONObject().put("id",it.id).put("title",it.title).put("body",it.body)
                    .put("tagId",it.tagId ?: JSONObject.NULL).put("tone",it.tone).put("createdAt",it.createdAt).put("updatedAt",it.updatedAt)}))
            .put("questions",JSONObject().put("subjects",array(backup.questions.subjects){JSONObject().put("id",it.id).put("name",it.name)})
                .put("records",array(backup.questions.records){JSONObject().put("id",it.id).put("subjectId",it.subjectId)
                    .put("correct",it.correct).put("wrong",it.wrong).put("recordedAt",it.recordedAt)}))
            .put("pomodoro",JSONObject().put("settings",JSONObject().put("focusMinutes",c.focusMinutes).put("shortMinutes",c.shortMinutes)
                .put("longMinutes",c.longMinutes).put("cycles",c.cycles).put("sounds",c.sounds).put("sound",c.sound)
                .put("autoAdvance",c.autoAdvance).put("ambienceEnabled",c.ambienceEnabled).put("ambienceId",c.ambienceId).put("ambienceVolume",c.ambienceVolume.toDouble()))
                .put("history",array(backup.focusHistory){JSONObject().put("id",it.id).put("finishedAt",it.finishedAt).put("durationMs",it.durationMs)}))
            .put("pdf",JSONObject().put("stylusOnly",backup.stylusOnly).put("straightHighlight",backup.straightHighlight)
                .put("documents",array(backup.documents){JSONObject().put("driveFileId",it.driveFileId).put("lastPage",it.lastPage)
                    .put("annotations",encodeAnnotations(it.annotations))})).toString(2)
    }

    /** Toda a entrada é validada antes de qualquer gravação nos stores. */
    fun decode(value: String): PortableBackup {
        require(value.toByteArray(Charsets.UTF_8).size<=MAX_BACKUP_BYTES) {"Backup maior que 25 MB."}
        val root=JSONObject(value)
        require(root.getString("format")==BACKUP_FORMAT) {"Este arquivo não é um backup Kepleræ."}
        require(root.getInt("schemaVersion")==BACKUP_SCHEMA) {"Formato de backup incompatível. Atualize o app."}
        val exportedAt=root.getLong("exportedAt").also(::timestamp)
        val s=root.getJSONObject("study")
        val accessed=s.getJSONArray("accessed").objects().map {
            it.getString("id").also(::id) to it.getLong("at").also(::timestamp)
        };unique(accessed.map {it.first})
        val study=StudyBackup(strings(s.getJSONArray("favorites")).toSet(),strings(s.getJSONArray("completed")).toSet(),
            accessed.toMap(),strings(s.getJSONArray("itemOrder")),ThemeMode.valueOf(s.getString("theme")),s.getBoolean("dynamicColor"))
        val n=root.getJSONObject("notes")
        val tags=n.getJSONArray("tags").objects().map {NoteTag(it.getString("id"),it.getString("name").also {name->require(name.isNotBlank());text(name,30)})}
        unique(tags.map {it.id})
        val notes=n.getJSONArray("items").objects().map {
            Note(it.getString("id"),it.getString("title").also {t->text(t,2000)},it.getString("body").also {t->text(t,200_000)},
                if(it.isNull("tagId"))null else it.getString("tagId").also {tag->require(tags.any {t->t.id==tag})},
                it.getInt("tone").also {tone->require(tone in 0 until NOTE_TONE_COUNT)},
                it.getLong("createdAt").also(::timestamp),it.getLong("updatedAt").also(::timestamp))
        };unique(notes.map {it.id})
        val q=root.getJSONObject("questions")
        val subjects=q.getJSONArray("subjects").objects().map {QuestionSubject(it.getString("id"),it.getString("name").also {name->require(name.isNotBlank());text(name,80)})}
        unique(subjects.map {it.id})
        val records=q.getJSONArray("records").objects().map {
            val subject=it.getString("subjectId");require(subjects.any {s->s.id==subject}) {"Registro sem matéria."}
            val correct=it.getInt("correct");val wrong=it.getInt("wrong");require(validQuestionCounts(correct,wrong)) {"Contagem inválida."}
            QuestionRecord(it.getString("id"),subject,correct,wrong,it.getLong("recordedAt").also(::timestamp))
        };unique(records.map {it.id})
        val p=root.getJSONObject("pomodoro");val c=p.getJSONObject("settings")
        val settings=PomodoroSettings(c.getInt("focusMinutes"),c.getInt("shortMinutes"),c.getInt("longMinutes"),c.getInt("cycles"),
            c.getBoolean("sounds"),c.getString("sound"),c.getBoolean("autoAdvance"),c.getBoolean("ambienceEnabled"),
            c.getString("ambienceId"),c.getDouble("ambienceVolume").toFloat())
        require(settings.valid());require(settings.sound in setOf("bell","soft"));id(settings.ambienceId)
        val history=p.getJSONArray("history").objects().map {FocusRecord(it.getString("id"),it.getLong("finishedAt").also(::timestamp),
            it.getLong("durationMs").also {ms->require(ms in 1..(180*60_000L))})};unique(history.map {it.id})
        val pdf=root.getJSONObject("pdf")
        val documents=pdf.getJSONArray("documents").objects().map {PdfBackup(it.getString("driveFileId").also {
            driveId->require(Regex("[A-Za-z0-9_-]{1,256}").matches(driveId))},it.getInt("lastPage").also {page->require(page in 0..100_000)},
            decodeAnnotations(it.getJSONObject("annotations")))};unique(documents.map {it.driveFileId})
        return PortableBackup(exportedAt,study,NoteState(tags,notes),QuestionState(subjects,records),settings,history,
            documents,pdf.getBoolean("stylusOnly"),pdf.getBoolean("straightHighlight"))
    }
    fun encodeAnnotations(document: AnnotationDocument): JSONObject = JSONObject().put("version",1)
        .put("pages",array(document.pages.toSortedMap().entries) { (index,a)->
            JSONObject().put("page",index).put("strokes",array(a.strokes){s->JSONObject().put("id",s.id).put("highlight",s.highlight)
                .put("color",s.color).put("width",s.width.toDouble()).put("points",array(s.points){JSONArray().put(it.x.toDouble()).put(it.y.toDouble())})})
                .put("notes",array(a.notes){JSONObject().put("id",it.id).put("x",it.point.x.toDouble()).put("y",it.point.y.toDouble()).put("text",it.text)})
        })
    fun decodeAnnotations(root: JSONObject): AnnotationDocument {
        require(root.getInt("version")==1)
        val pages=root.getJSONArray("pages").objects().map {p->
            val page=p.getInt("page");require(page in 0..100_000)
            val strokes=p.getJSONArray("strokes").objects().map {s->
                val points=s.getJSONArray("points");require(points.length() in 1..100_000)
                InkStroke(s.getString("id"),List(points.length()){i->val point=points.getJSONArray(i)
                    InkPoint(coordinate(point.getDouble(0)),coordinate(point.getDouble(1)))},s.getBoolean("highlight"),
                    s.getLong("color").also {require(it in 0..0xFFFFFFFFL)},s.getDouble("width").toFloat().also {require(it.isFinite()&&it>0&&it<=1)})
            };unique(strokes.map {it.id})
            val notes=p.getJSONArray("notes").objects().map {n->PdfNote(n.getString("id"),InkPoint(coordinate(n.getDouble("x")),coordinate(n.getDouble("y"))),
                n.getString("text").also {text(it,20_000)})};unique(notes.map {it.id})
            page to PageAnnotations(strokes,notes)
        }
        require(pages.map {it.first}.distinct().size==pages.size)
        return AnnotationDocument(pages.toMap())
    }
    private fun coordinate(value: Double): Float {require(value.isFinite()&&value in 0.0..1.0);return value.toFloat()}
}
```

## app/src/main/java/com/example/data/backup/BackupModel.kt

```kotlin
package com.example.data.backup

import com.example.data.notes.*
import com.example.data.pdf.AnnotationDocument
import com.example.data.productivity.*
import com.example.data.repository.ThemeMode

const val BACKUP_FORMAT = "keplerae-backup"
const val BACKUP_SCHEMA = 1
const val MAX_BACKUP_BYTES = 25 * 1024 * 1024

data class StudyBackup(val favorites: Set<String>, val completed: Set<String>,
    val accessed: Map<String,Long>, val itemOrder: List<String>,
    val theme: ThemeMode, val dynamicColor: Boolean)
data class PdfBackup(val driveFileId: String, val lastPage: Int, val annotations: AnnotationDocument)
data class PortableBackup(val exportedAt: Long, val study: StudyBackup,
    val notes: NoteState, val questions: QuestionState,
    val pomodoroSettings: PomodoroSettings, val focusHistory: List<FocusRecord>,
    val documents: List<PdfBackup>, val stylusOnly: Boolean, val straightHighlight: Boolean) {
    fun summary() = "${notes.notes.size} notas • ${questions.records.size} registros de questões • " +
        "${focusHistory.size} pomodoros • ${documents.size} PDFs com leitura/anotações"
}

/** Importações sucessivas são idempotentes; registros existentes não são apagados. */
fun mergeNotes(local: NoteState, incoming: NoteState): NoteState {
    val tags=local.tags.toMutableList();val ids=mutableMapOf<String,String>()
    incoming.tags.forEach { tag ->
        val match=tags.firstOrNull {it.id==tag.id} ?: tags.firstOrNull {it.name.equals(tag.name,true)}
        ids[tag.id]=match?.id ?: tag.id
        if(match==null)tags.add(tag)
    }
    val notes=local.notes.associateBy {it.id}.toMutableMap()
    incoming.notes.forEach { note ->
        val adjusted=note.copy(tagId=note.tagId?.let {ids[it] ?: it})
        val old=notes[note.id]
        if(old==null || adjusted.updatedAt>old.updatedAt)notes[note.id]=adjusted
    }
    return NoteState(tags,notes.values.toList())
}
fun mergeQuestions(local: QuestionState, incoming: QuestionState): QuestionState {
    val subjects=local.subjects.toMutableList();val ids=mutableMapOf<String,String>()
    incoming.subjects.forEach { subject ->
        val match=subjects.firstOrNull {it.id==subject.id} ?: subjects.firstOrNull {it.name.equals(subject.name,true)}
        ids[subject.id]=match?.id ?: subject.id
        if(match==null)subjects.add(subject)
    }
    val records=local.records.associateBy {it.id}.toMutableMap()
    incoming.records.forEach {record ->
        if(record.id !in records)records[record.id]=record.copy(subjectId=ids[record.subjectId] ?: record.subjectId)
    }
    return QuestionState(subjects,records.values.toList())
}
fun mergeHistory(local: List<FocusRecord>, incoming: List<FocusRecord>): List<FocusRecord> =
    (local+incoming).distinctBy {it.id}.sortedBy {it.finishedAt}
fun mergeAnnotations(local: AnnotationDocument, incoming: AnnotationDocument): AnnotationDocument =
    AnnotationDocument((local.pages.keys+incoming.pages.keys).associateWith { page ->
        val before=local.pages[page] ?: com.example.data.pdf.PageAnnotations()
        val added=incoming.pages[page] ?: com.example.data.pdf.PageAnnotations()
        com.example.data.pdf.PageAnnotations((before.strokes+added.strokes).distinctBy {it.id},
            (before.notes+added.notes).distinctBy {it.id})
    })
```

## app/src/main/java/com/example/data/backup/BackupRepository.kt

```kotlin
package com.example.data.backup

import android.content.Context
import android.net.Uri
import android.util.AtomicFile
import com.example.data.notes.NoteStore
import com.example.data.pdf.*
import com.example.data.productivity.*
import com.example.data.repository.StudyViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

/** Usa o seletor Android: o usuário pode escolher arquivo local ou Google Drive. */
class BackupRepository(context: Context) {
    private val app=context.applicationContext
    private val reading=app.getSharedPreferences("keplerae_pdf_reading",Context.MODE_PRIVATE)
    private fun key(id: String)=pdfStorageKey(pdfAccountKey(app),id)
    private fun indexKey()="backup_documents_${key("index")}"
    private fun annotationFile(id: String)=File(File(app.filesDir,"annotations"),"${key(id)}.json")

    suspend fun snapshot(model: StudyViewModel): PortableBackup = withContext(Dispatchers.IO) {
        PdfAnnotationStore.flushAll()
        val state=model.state.value
        val notes=NoteStore.get(app).state.value;val questions=QuestionStore.get(app).state.value
        val pomodoro=PomodoroStore.get(app).state.value
        // IDs do catálogo e metadados de PDFs baixados também cobrem pastas do Drive.
        val ids=linkedSetOf<String>()
        ids.addAll(reading.getStringSet(indexKey(),emptySet()) ?: emptySet())
        val catalog=JSONArray(app.assets.open("catalog.json").bufferedReader().use {it.readText()})
        for(i in 0 until catalog.length())catalog.getJSONObject(i).optString("driveFileId").takeIf {it.isNotBlank()}?.let(ids::add)
        File(app.filesDir,"pdfs").listFiles()?.filter {it.extension=="json"}?.forEach {file->
            val id=runCatching {JSONObject(file.readText()).getString("id")}.getOrNull()
            if(id!=null && file.nameWithoutExtension==key(id))ids.add(id)
        }
        val documents=ids.mapNotNull {id->
            val file=annotationFile(id);val stored=reading.contains(key(id))
            if(!file.exists()&&!stored)null else PdfBackup(id,reading.getInt(key(id),0),
                if(file.exists())BackupJson.decodeAnnotations(JSONObject(AtomicFile(file).openRead().bufferedReader().use {it.readText()})) else AnnotationDocument())
        }
        PortableBackup(System.currentTimeMillis(),StudyBackup(state.favorites,state.completed,state.accessed,
            state.itemOrder,state.theme,state.dynamicColor),notes,questions,pomodoro.settings,pomodoro.history,
            documents,reading.getBoolean("stylus_only",false),reading.getBoolean("straight_highlight",true))
    }
    suspend fun export(uri: Uri, model: StudyViewModel) = withContext(Dispatchers.IO) {
        val json=BackupJson.encode(snapshot(model))
        // Valida o próprio arquivo antes de entregar o backup ao provedor externo.
        BackupJson.decode(json)
        val bytes=json.toByteArray(Charsets.UTF_8)
        check(bytes.size<=MAX_BACKUP_BYTES) {"Os dados excedem o limite de 25 MB."}
        val stream=app.contentResolver.openOutputStream(uri,"wt") ?: error("Não foi possível criar o arquivo.")
        stream.use {it.write(bytes);it.flush()}
    }
    suspend fun read(uri: Uri): PortableBackup = withContext(Dispatchers.IO) {
        val input=app.contentResolver.openInputStream(uri) ?: error("Não foi possível abrir o arquivo.")
        val output=ByteArrayOutputStream()
        input.use {stream->
            val buffer=ByteArray(8192)
            while(true) {
                val count=stream.read(buffer);if(count<0)break
                require(output.size()+count<=MAX_BACKUP_BYTES) {"Backup maior que 25 MB."}
                output.write(buffer,0,count)
            }
        }
        BackupJson.decode(output.toString("UTF-8"))
    }
    /** Mescla por IDs; não importa conta/token, timer em andamento ou cache dos PDFs. */
    suspend fun importBackup(backup: PortableBackup, model: StudyViewModel) {
        // Protege também quem chama o repositório diretamente, sem a tela de confirmação.
        BackupJson.decode(BackupJson.encode(backup))
        withContext(Dispatchers.IO) {
            PdfAnnotationStore.flushAll()
            backup.documents.forEach {document->
                val file=annotationFile(document.driveFileId)
                val old=if(file.exists())BackupJson.decodeAnnotations(JSONObject(AtomicFile(file).openRead().bufferedReader().use {it.readText()})) else AnnotationDocument()
                val merged=mergeAnnotations(old,document.annotations)
                file.parentFile?.mkdirs()
                val atomic=AtomicFile(file);val output=atomic.startWrite()
                try {output.write(BackupJson.encodeAnnotations(merged).toString().toByteArray());atomic.finishWrite(output)}
                catch(error:Exception) {atomic.failWrite(output);throw error}
            }
            check(reading.edit().apply {
                backup.documents.forEach {putInt(key(it.driveFileId),it.lastPage)}
                putStringSet(indexKey(),(reading.getStringSet(indexKey(),emptySet()) ?: emptySet())+
                    backup.documents.map {it.driveFileId})
                putBoolean("stylus_only",backup.stylusOnly);putBoolean("straight_highlight",backup.straightHighlight)
            }.commit()) {"Não foi possível salvar a leitura dos PDFs."}
            NoteStore.get(app).importData(backup.notes)
            QuestionStore.get(app).importData(backup.questions)
            PomodoroStore.get(app).importData(backup.pomodoroSettings,backup.focusHistory)
        }
        model.importData(backup.study)
    }
}
```

## app/src/main/java/com/example/data/drive/DriveRepository.kt

```kotlin
package com.example.data.drive

import android.content.Context
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class DriveFile(val id: String, val name: String, val mimeType: String, val resourceKey: String = "",
    val canDownload: Boolean = true, val size: Long = 0) {
    val folder: Boolean get() = mimeType == "application/vnd.google-apps.folder"
    val contentType: ContentType? get() = when {
        mimeType == "application/pdf" || name.endsWith(".pdf", true) -> ContentType.PDF
        mimeType.startsWith("video/") -> ContentType.VIDEO
        mimeType.startsWith("audio/") -> ContentType.AUDIO
        else -> null
    }
    fun studyItem(parent: StudyItem): StudyItem = parent.copy(
        id = if (name.equals(parent.filename, true)) parent.id else "drive-$id",
        title = name.substringBeforeLast('.'), filename = name,
        type = contentType ?: parent.type, linkKind = LinkKind.FILE, driveFileId = id,
        url = "https://drive.google.com/file/d/$id/view" + if (resourceKey.isBlank()) "" else "?resourcekey=$resourceKey",
        note = "")
}

class DriveRepository(private val context: Context, val credentials: DriveCredentials) {
    private val certificate = installedCertificate(context)
    fun headers(id: String, resourceKey: String) = credentials.headers(context.packageName, certificate, id, resourceKey)
    private fun connection(url: String, id: String, resourceKey: String): HttpURLConnection {
        check(credentials.configured) { "Configure sua chave de API ou autorize uma conta Google." }
        return (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 30000
            headers(id, resourceKey).forEach { (key, value) -> setRequestProperty(key, value) }
        }
    }
    private fun checkResponse(connection: HttpURLConnection) {
        if (connection.responseCode in 200..299) return
        val body = connection.errorStream?.bufferedReader()?.use { it.readText().take(65536) }.orEmpty()
        val reason = runCatching {
            val error = JSONObject(body).getJSONObject("error")
            error.optJSONArray("errors")?.optJSONObject(0)?.optString("reason").orEmpty().ifBlank {
                error.optJSONArray("details")?.optJSONObject(0)?.optString("reason").orEmpty()
            }
        }.getOrDefault("")
        throw IOException(DriveRequests.errorMessage(connection.responseCode, reason))
    }
    private suspend fun json(url: String, id: String, resourceKey: String): JSONObject = withContext(Dispatchers.IO) {
        val request = connection(url, id, resourceKey)
        try { checkResponse(request); currentCoroutineContext().ensureActive()
            JSONObject(request.inputStream.bufferedReader().use { it.readText() })
        } finally { request.disconnect() }
    }
    private fun parse(row: JSONObject): DriveFile {
        val shortcut = row.optJSONObject("shortcutDetails")
        return DriveFile(shortcut?.optString("targetId")?.takeIf { it.isNotBlank() } ?: row.getString("id"),
            row.getString("name"), shortcut?.optString("targetMimeType")?.takeIf { it.isNotBlank() } ?: row.getString("mimeType"),
            shortcut?.optString("targetResourceKey")?.takeIf { it.isNotBlank() } ?: row.optString("resourceKey"),
            row.optJSONObject("capabilities")?.optBoolean("canDownload", true) ?: true, row.optString("size").toLongOrNull() ?: 0)
    }
    suspend fun metadata(id: String, resourceKey: String): DriveFile {
        var file = parse(json(DriveRequests.file(id), id, resourceKey))
        if (file.id != id) return parse(json(DriveRequests.file(file.id), file.id, file.resourceKey))
        return file.copy(resourceKey = file.resourceKey.ifBlank { resourceKey })
    }
    suspend fun folder(id: String, resourceKey: String): List<DriveFile> {
        val files = mutableListOf<DriveFile>(); var token = ""
        do {
            currentCoroutineContext().ensureActive()
            val page = json(DriveRequests.folder(id, token), id, resourceKey)
            val rows = page.optJSONArray("files")
            if (rows != null) for (i in 0 until rows.length()) files += parse(rows.getJSONObject(i))
            token = page.optString("nextPageToken")
        } while (token.isNotBlank())
        return files.distinctBy { it.id }.sortedWith(compareBy<DriveFile> { !it.folder }.thenBy { searchable(it.name) })
    }
    suspend fun pdf(file: DriveFile, destination: File, onProgress: (Long, Long) -> Unit): File = withContext(Dispatchers.IO) {
        require(file.canDownload) { "O proprietário bloqueou o acesso ao conteúdo pela API." }
        val request = connection(DriveRequests.file(file.id, true), file.id, file.resourceKey)
        try {
            checkResponse(request)
            val size = request.contentLengthLong; var received = 0L; var lastUpdate = 0L
            request.inputStream.use { input -> destination.outputStream().use { output ->
                val buffer = ByteArray(32768)
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val count = input.read(buffer); if (count < 0) break
                    output.write(buffer, 0, count); received += count
                    if (received - lastUpdate >= 262144) { onProgress(received, size); lastUpdate = received }
                }
            } }
            currentCoroutineContext().ensureActive()
            require(destination.inputStream().use { String(it.readNBytesCompat(5), Charsets.US_ASCII) } == "%PDF-") {
                "O Drive não retornou um PDF válido." }
            onProgress(received, size); destination
        } catch (e: Exception) { destination.delete(); throw e }
        finally { request.disconnect() }
    }
}
private fun java.io.InputStream.readNBytesCompat(length: Int): ByteArray {
    val result = ByteArray(length); var offset = 0
    while (offset < length) { val n = read(result, offset, length - offset); if (n < 0) break; offset += n }
    return result.copyOf(offset)
}
```

## app/src/main/java/com/example/data/drive/DriveRequests.kt

```kotlin
package com.example.data.drive

import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder

data class DriveCredentials(val apiKey: String = "", val accessToken: String = "") {
    val configured: Boolean get() = apiKey.isNotBlank() || accessToken.isNotBlank()
    fun headers(packageName: String, certificate: String, id: String, resourceKey: String): Map<String, String> = buildMap {
        if (accessToken.isNotBlank()) put("Authorization", "Bearer $accessToken")
        else if (apiKey.isNotBlank()) put("X-Goog-Api-Key", apiKey)
        put("X-Android-Package", packageName)
        if (certificate.isNotBlank()) put("X-Android-Cert", certificate)
        if (resourceKey.isNotBlank()) put("X-Goog-Drive-Resource-Keys", "$id/$resourceKey")
    }
}

object DriveRequests {
    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8")
    fun file(id: String, media: Boolean = false): String {
        require(id.matches(Regex("[A-Za-z0-9_-]+"))) { "Identificador do arquivo inválido." }
        val fields = "id,name,mimeType,size,resourceKey,capabilities(canDownload),shortcutDetails(targetId,targetMimeType,targetResourceKey)"
        return "https://www.googleapis.com/drive/v3/files/$id?" +
            if (media) "alt=media&supportsAllDrives=true" else "supportsAllDrives=true&fields=${encode(fields)}"
    }
    fun folder(id: String, pageToken: String = ""): String {
        require(id.matches(Regex("[A-Za-z0-9_-]+")))
        val query = "'$id' in parents and trashed = false"
        val fields = "nextPageToken,files(id,name,mimeType,size,resourceKey,capabilities(canDownload),shortcutDetails(targetId,targetMimeType,targetResourceKey))"
        return "https://www.googleapis.com/drive/v3/files?q=${encode(query)}&pageSize=100" +
            "&supportsAllDrives=true&includeItemsFromAllDrives=true&fields=${encode(fields)}" +
            if (pageToken.isBlank()) "" else "&pageToken=${encode(pageToken)}"
    }
    fun resourceKey(url: String): String = runCatching {
        URI(url).rawQuery.orEmpty().split('&').firstNotNullOfOrNull { part ->
            val pair = part.split('=', limit = 2)
            if (pair.size == 2 && pair[0].equals("resourcekey", true)) URLDecoder.decode(pair[1], "UTF-8") else null
        }.orEmpty()
    }.getOrDefault("")
    fun folderId(url: String): String = runCatching {
        URI(url).path.substringAfter("/drive/folders/").substringBefore('/')
            .takeIf { it.matches(Regex("[A-Za-z0-9_-]+")) }.orEmpty()
    }.getOrDefault("")
    fun errorMessage(status: Int, reason: String): String = when {
        status == 401 -> "A autorização Google expirou. Autorize sua conta novamente."
        reason in setOf("keyInvalid", "API_KEY_INVALID", "badRequest") -> "Confira a chave de API nas configurações do Drive."
        reason in setOf("accessNotConfigured", "SERVICE_DISABLED") -> "Ative a Google Drive API no projeto da sua chave."
        reason in setOf("downloadQuotaExceeded", "rateLimitExceeded", "userRateLimitExceeded", "quotaExceeded") || status == 429 ->
            "O Drive atingiu um limite de acesso. Aguarde e tente novamente."
        reason in setOf("cannotDownloadFile", "fileNotDownloadable", "downloadRestrictedForRevision") ->
            "O proprietário bloqueou o acesso ao conteúdo pela API."
        status == 404 -> "Arquivo não encontrado ou sem acesso. Para arquivos privados, autorize a conta Google correta."
        status == 403 -> "Acesso negado. Confira as restrições da chave ou autorize a conta Google que pode acessar o arquivo."
        status >= 500 -> "O Drive está temporariamente indisponível. Tente novamente."
        else -> "Não foi possível carregar este material. Confira a conexão e tente novamente."
    }
    fun errorReason(body: String): String = Regex("\"reason\"\\s*:\\s*\"([^\"]+)\"")
        .find(body)?.groupValues?.get(1).orEmpty()
}
```

## app/src/main/java/com/example/data/drive/DriveSettings.kt

```kotlin
package com.example.data.drive

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object DriveSession {
    // Short-lived Google access tokens stay in memory; no refresh token or client secret is stored.
    var accessToken by mutableStateOf("")
    var revision by mutableStateOf(0)
    fun clear() { accessToken = ""; revision++ }
}

class DriveSettings(private val context: Context, preferenceName: String = "keplerae_drive") {
    private val prefs = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE)
    private fun secret(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey("keplerae_drive_key", null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder("keplerae_drive_key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    fun apiKey(): String = runCatching {
        val encrypted = prefs.getString("api_key", null) ?: return@runCatching ""
        val parts = encrypted.split(':', limit = 2)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secret(), GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)))
        String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), Charsets.UTF_8)
    }.getOrDefault("")
    fun saveApiKey(value: String) {
        if (value.isBlank()) prefs.edit().remove("api_key").apply()
        else {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, secret())
            val encrypted = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" +
                Base64.encodeToString(cipher.doFinal(value.trim().toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
            prefs.edit().putString("api_key", encrypted).apply()
        }
        DriveSession.revision++
    }
    fun credentials() = DriveCredentials(apiKey(), DriveSession.accessToken)
}

@Suppress("DEPRECATION")
fun installedCertificate(context: Context): String = runCatching {
    val signatures = if (Build.VERSION.SDK_INT >= 28) {
        val info = context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        info.signingInfo?.apkContentsSigners
    } else context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures
    val certificate = signatures?.firstOrNull()?.toByteArray() ?: return@runCatching ""
    MessageDigest.getInstance("SHA-1").digest(certificate).joinToString("") { "%02X".format(it) }
}.getOrDefault("")
```

## app/src/main/java/com/example/data/model/StudyItem.kt

```kotlin
package com.example.data.model

import java.net.URI
import java.text.Normalizer

enum class ContentType(val label: String) { VIDEO("Aulas"), PDF("PDFs"), AUDIO("Áudios") }
enum class LinkKind { FILE, FOLDER }

data class StudyItem(
    val id: String, val title: String, val filename: String,
    val subjectId: String, val folderPath: List<String>, val type: ContentType,
    val url: String, val linkKind: LinkKind, val driveFileId: String,
    val note: String, val source: String
) {
    val previewUrl: String get() = if (linkKind == LinkKind.FILE && driveFileId.isNotBlank())
        "https://drive.google.com/file/d/$driveFileId/preview" else url
    fun matches(query: String): Boolean = searchable("$title $filename ${folderPath.joinToString(" ")} $subjectId")
        .contains(searchable(query.trim()))
}
fun searchable(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
    .replace(Regex("\\p{M}+"), "").lowercase(java.util.Locale.ROOT)
fun isAllowedDriveUrl(url: String): Boolean = runCatching {
    val uri = URI(url)
    uri.scheme == "https" && uri.host == "drive.google.com" && uri.userInfo == null &&
        (uri.path.startsWith("/file/d/") || uri.path.startsWith("/drive/folders/"))
}.getOrDefault(false)
fun itemsInPath(items: List<StudyItem>, path: List<String>): List<StudyItem> =
    items.filter { it.folderPath.take(path.size) == path }

data class Subject(val id: String, val name: String, val subtitle: String, val monogram: String)
object Subjects {
    val all = listOf(
        Subject("fisioterapia", "Fisioterapia", "HU Brasil · módulos e simulados", "F"),
        Subject("portugues", "Português", "Gramática e interpretação", "P"),
        Subject("matematica", "Matemática e Raciocínio Lógico", "Lógica, teoria e questões", "M"),
        Subject("hu_legislacao", "HU Legislação", "Normas e legislação EBSERH", "H"),
        Subject("sus", "SUS", "Saúde pública e políticas", "S"),
        Subject("profisio", "Profisio", "Artigos, aulas e áudios por ciclo", "Pr")
    )
    fun get(id: String) = all.first { it.id == id }
}
```

## app/src/main/java/com/example/data/notes/NoteModel.kt

```kotlin
package com.example.data.notes

import com.example.data.model.searchable

/** Quantidade de cores disponíveis para os cartões; a paleta fica em ui/notes. */
const val NOTE_TONE_COUNT = 5

/** Bloco (categoria) de anotações, exibido como #nome. */
data class NoteTag(val id: String, val name: String)

data class Note(
    val id: String,
    val title: String,
    val body: String,
    val tagId: String?,
    val tone: Int,
    val createdAt: Long,
    val updatedAt: Long,
)

data class NoteState(val tags: List<NoteTag> = emptyList(), val notes: List<Note> = emptyList())

/** Remove # inicial e espaços repetidos: "  #Plantão   UTI " vira "Plantão UTI". */
fun cleanTagName(raw: String): String =
    raw.trim().removePrefix("#").trim().replace(Regex("\\s+"), " ")

fun noteIsBlank(title: String, body: String): Boolean = title.isBlank() && body.isBlank()

/** Filtra por bloco e busca (sem acento, sem maiúsculas); mais recentes primeiro. */
fun visibleNotes(notes: List<Note>, tagId: String?, query: String): List<Note> {
    val needle = searchable(query.trim())
    return notes.filter { note ->
        (tagId == null || note.tagId == tagId) &&
            (needle.isEmpty() || searchable("${note.title} ${note.body}").contains(needle))
    }.sortedByDescending { it.updatedAt }
}
```

## app/src/main/java/com/example/data/notes/NoteStore.kt

```kotlin
package com.example.data.notes

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Guarda blocos e anotações neste aparelho (entram no backup automático do Android). */
class NoteStore private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("keplerae_notes", Context.MODE_PRIVATE)
    private val mutable = MutableStateFlow(read())
    val state: StateFlow<NoteState> = mutable.asStateFlow()

    private fun read(): NoteState = runCatching {
        val root = JSONObject(prefs.getString("state", "{}") ?: "{}")
        val tags = root.optJSONArray("tags") ?: JSONArray()
        val notes = root.optJSONArray("notes") ?: JSONArray()
        NoteState(
            tags = (0 until tags.length()).map { tags.getJSONObject(it) }
                .map { NoteTag(it.getString("id"), it.getString("name")) },
            notes = (0 until notes.length()).map { notes.getJSONObject(it) }.map {
                Note(
                    id = it.getString("id"),
                    title = it.optString("title"),
                    body = it.optString("body"),
                    tagId = it.optString("tag").takeIf { tag -> tag.isNotBlank() },
                    tone = it.optInt("tone", 0).coerceIn(0, NOTE_TONE_COUNT - 1),
                    createdAt = it.optLong("created"),
                    updatedAt = it.optLong("updated"),
                )
            },
        )
    }.getOrDefault(NoteState())

    private fun write(next: NoteState, durable: Boolean = false) {
        val json = JSONObject()
            .put("tags", JSONArray().apply {
                next.tags.forEach { put(JSONObject().put("id", it.id).put("name", it.name)) }
            })
            .put("notes", JSONArray().apply {
                next.notes.forEach {
                    put(
                        JSONObject().put("id", it.id).put("title", it.title).put("body", it.body)
                            .put("tag", it.tagId ?: "").put("tone", it.tone)
                            .put("created", it.createdAt).put("updated", it.updatedAt)
                    )
                }
            })
        val edit=prefs.edit().putString("state",json.toString())
        if(durable)check(edit.commit()) {"Não foi possível salvar as notas."} else edit.apply()
        mutable.value = next
    }

    @Synchronized fun upsert(note: Note) {
        val current = mutable.value
        val notes = if (current.notes.any { it.id == note.id })
            current.notes.map { if (it.id == note.id) note else it }
        else current.notes + note
        write(current.copy(notes = notes))
    }

    @Synchronized fun delete(id: String) {
        val current = mutable.value
        write(current.copy(notes = current.notes.filterNot { it.id == id }))
    }

    @Synchronized fun importData(incoming: NoteState) {
        write(com.example.data.backup.mergeNotes(mutable.value, incoming),true)
    }

    /** Reaproveita um bloco existente com o mesmo nome (sem diferenciar maiúsculas). */
    @Synchronized fun createTag(name: String): String {
        val clean = cleanTagName(name)
        require(clean.isNotBlank() && clean.length <= 30) { "Use um nome de 1 a 30 caracteres." }
        val current = mutable.value
        current.tags.firstOrNull { it.name.equals(clean, true) }?.let { return it.id }
        val tag = NoteTag(UUID.randomUUID().toString(), clean)
        write(current.copy(tags = current.tags + tag))
        return tag.id
    }

    @Synchronized fun renameTag(id: String, name: String) {
        val clean = cleanTagName(name)
        require(clean.isNotBlank() && clean.length <= 30) { "Use um nome de 1 a 30 caracteres." }
        val current = mutable.value
        require(current.tags.none { it.id != id && it.name.equals(clean, true) }) { "Esse bloco já existe." }
        write(current.copy(tags = current.tags.map { if (it.id == id) it.copy(name = clean) else it }))
    }

    /** As anotações do bloco excluído continuam salvas, apenas sem bloco. */
    @Synchronized fun deleteTag(id: String) {
        val current = mutable.value
        write(
            current.copy(
                tags = current.tags.filterNot { it.id == id },
                notes = current.notes.map { if (it.tagId == id) it.copy(tagId = null) else it },
            )
        )
    }

    companion object {
        @Volatile private var instance: NoteStore? = null
        fun get(context: Context): NoteStore = instance ?: synchronized(this) {
            instance ?: NoteStore(context).also { instance = it }
        }
    }
}
```

## app/src/main/java/com/example/data/pdf/PdfAnnotations.kt

```kotlin
package com.example.data.pdf

import android.content.Context
import android.util.AtomicFile
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Coordenadas normalizadas sobre a página real, independentes do zoom e da tela. */
data class InkPoint(val x: Float, val y: Float) {
    fun clamped() = InkPoint(x.coerceIn(0f, 1f), y.coerceIn(0f, 1f))
}
data class InkStroke(val id: String, val points: List<InkPoint>, val highlight: Boolean,
    val color: Long, val width: Float)
data class PdfNote(val id: String, val point: InkPoint, val text: String)
data class PageAnnotations(val strokes: List<InkStroke> = emptyList(), val notes: List<PdfNote> = emptyList())
data class AnnotationDocument(val pages: Map<Int, PageAnnotations> = emptyMap())

/** JSON próprio. AtomicFile preserva a versão anterior caso a gravação seja interrompida. */
class PdfAnnotationStore(context: Context, key: String) {
    private val file = AtomicFile(File(File(context.filesDir, "annotations").apply { mkdirs() }, "$key.json"))
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val gate = Mutex()
    private val mutable = MutableStateFlow(AnnotationDocument())
    val state = mutable.asStateFlow()
    private val failure = MutableStateFlow<String?>(null)
    val error = failure.asStateFlow()
    private var lastWrite: Job? = null
    init { active.add(this) }
    suspend fun load() = withContext(Dispatchers.IO) {
        gate.withLock {
            mutable.value = runCatching {
                val root = JSONObject(file.openRead().bufferedReader().use { it.readText() })
                val pages = root.optJSONArray("pages") ?: JSONArray()
                AnnotationDocument((0 until pages.length()).associate { i ->
                    val p = pages.getJSONObject(i)
                    val strokes = p.optJSONArray("strokes") ?: JSONArray()
                    val notes = p.optJSONArray("notes") ?: JSONArray()
                    p.getInt("page") to PageAnnotations(
                        (0 until strokes.length()).map { j ->
                            val s = strokes.getJSONObject(j); val points = s.getJSONArray("points")
                            InkStroke(s.getString("id"), (0 until points.length()).map { k ->
                                val a = points.getJSONArray(k); InkPoint(a.getDouble(0).toFloat(), a.getDouble(1).toFloat()).clamped()
                            }, s.optBoolean("highlight"), s.getLong("color"), s.getDouble("width").toFloat())
                        }, (0 until notes.length()).map { j ->
                            val n = notes.getJSONObject(j)
                            PdfNote(n.getString("id"), InkPoint(n.getDouble("x").toFloat(), n.getDouble("y").toFloat()).clamped(), n.getString("text"))
                        })
                })
            }.getOrDefault(AnnotationDocument())
        }
    }
    fun replace(page: Int, annotations: PageAnnotations) {
        val next = mutable.value.copy(pages = mutable.value.pages + (page to annotations))
        mutable.value = next
        val previous = lastWrite
        lastWrite = scope.launch {
            previous?.join()
            gate.withLock {
                val root = JSONObject().put("version", 1).put("pages", JSONArray().apply {
                    next.pages.toSortedMap().forEach { (index, a) ->
                        put(JSONObject().put("page", index).put("strokes", JSONArray().apply {
                            a.strokes.forEach { s -> put(JSONObject().put("id", s.id).put("highlight", s.highlight)
                                .put("color", s.color).put("width", s.width).put("points", JSONArray().apply {
                                    s.points.forEach { put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble())) }
                                })) }
                        }).put("notes", JSONArray().apply {
                            a.notes.forEach { n -> put(JSONObject().put("id", n.id).put("x", n.point.x.toDouble())
                                .put("y", n.point.y.toDouble()).put("text", n.text)) }
                        }))
                    }
                })
                var output: java.io.FileOutputStream? = null
                try {
                    output = file.startWrite(); output.write(root.toString().toByteArray()); file.finishWrite(output)
                    failure.value = null
                } catch (_: Exception) {
                    output?.let { file.failWrite(it) }
                    failure.value = "Não foi possível salvar as anotações. Confira o espaço livre no aparelho."
                }
            }
        }
    }
    suspend fun flush() { lastWrite?.join() }
    fun close() { scope.launch { lastWrite?.join(); active.remove(this@PdfAnnotationStore); scope.cancel() } }
    companion object {
        private val active=java.util.concurrent.ConcurrentHashMap.newKeySet<PdfAnnotationStore>()
        suspend fun flushAll() { active.toList().forEach {
            it.flush()
            check(it.error.value==null) {it.error.value ?: "Não foi possível salvar as anotações."}
        } }
    }
}

/** Distância ao segmento: a borracha encontra também os intervalos entre pontos. */
fun strokeHit(stroke: InkStroke, point: InkPoint, radius: Float = .025f): Boolean {
    fun squareDistance(a: InkPoint, b: InkPoint): Float = (a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)
    val distance = radius + stroke.width / 2
    if (stroke.points.size == 1) return squareDistance(stroke.points[0], point) <= distance*distance
    return stroke.points.zipWithNext().any { (a,b) ->
        val dx=b.x-a.x; val dy=b.y-a.y; val length=dx*dx+dy*dy
        val t=if(length==0f) 0f else (((point.x-a.x)*dx+(point.y-a.y)*dy)/length).coerceIn(0f,1f)
        squareDistance(InkPoint(a.x+t*dx,a.y+t*dy),point) <= distance*distance
    }
}
```

## app/src/main/java/com/example/data/pdf/PdfCache.kt

```kotlin
package com.example.data.pdf

import android.content.Context
import com.example.data.auth.GoogleSessionStore
import com.example.data.drive.DriveFile
import com.example.data.drive.DriveRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/** Arquivos privados são separados por conta; a chave do Drive nunca vira caminho de disco. */
fun pdfAccountKey(context: Context): String = GoogleSessionStore(context).read()?.email ?: "public"
fun pdfStorageKey(account: String, id: String): String = MessageDigest.getInstance("SHA-256")
    .digest("$account\u0000$id".toByteArray()).joinToString("") { "%02x".format(it) }

data class CachedPdf(val metadata: DriveFile, val file: File, val key: String)

class PdfCache(context: Context) {
    private val directory = File(context.filesDir, "pdfs").apply { mkdirs() }
    private val account = pdfAccountKey(context)
    fun key(id: String) = pdfStorageKey(account, id)
    suspend fun find(id: String): CachedPdf? = withContext(Dispatchers.IO) {
        val key = key(id)
        val file = File(directory, "$key.pdf")
        runCatching {
            if (!validPdf(file)) return@runCatching null
            val json = JSONObject(File(directory, "$key.json").readText())
            CachedPdf(DriveFile(json.getString("id"), json.getString("name"), "application/pdf",
                json.optString("resourceKey")), file, key)
        }.getOrNull()
    }
    /** Download atômico: nunca expõe um PDF incompleto como cache válido. */
    suspend fun download(id: String, metadata: DriveFile, repository: DriveRepository,
        onProgress: (Long, Long) -> Unit): CachedPdf = gate.withLock {
        find(id)?.let { return@withLock it }
        withContext(Dispatchers.IO) {
            val key = key(id)
            val target = File(directory, "$key.pdf")
            val part = File(directory, "$key.part")
            try {
                repository.pdf(metadata, part, onProgress)
                check(part.renameTo(target)) { "Não foi possível salvar este PDF no aparelho." }
                File(directory, "$key.json").writeText(JSONObject().put("id", metadata.id)
                    .put("name", metadata.name).put("resourceKey", metadata.resourceKey).toString())
                CachedPdf(metadata, target, key)
            } finally { part.delete() }
        }
    }
    companion object { private val gate = Mutex() }
}
private fun validPdf(file: File): Boolean = file.isFile && file.length() > 5 &&
    file.inputStream().use { input ->
        val magic = ByteArray(5)
        input.read(magic) == 5 && String(magic, Charsets.US_ASCII) == "%PDF-"
    }
```

## app/src/main/java/com/example/data/playback/DrivePlaybackSource.kt

```kotlin
package com.example.data.playback

import android.accounts.Account
import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.*
import com.example.data.auth.GoogleSessionStore
import com.example.data.drive.*
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.ClearTokenRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Executado na thread de carregamento do Media3, nunca na thread de UI. */
@androidx.annotation.OptIn(UnstableApi::class)
internal class DrivePlaybackSource(private val context: Context) : DataSource.Factory {
    private val authorization = Identity.getAuthorizationClient(context.applicationContext)
    @Volatile private var lastToken = ""
    @Synchronized private fun credentials(): DriveCredentials {
        val account = GoogleSessionStore(context).read()
        val key = DriveSettings(context).apiKey()
        if (account != null) {
            try {
                val result = Tasks.await(authorization.authorize(AuthorizationRequest.builder()
                    .setAccount(Account(account.email, "com.google"))
                    .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.readonly"))).build()), 20, TimeUnit.SECONDS)
                if (!result.hasResolution() && !result.accessToken.isNullOrBlank()) {
                    // Não guarda tokens na fila, no disco ou nos metadados da notificação.
                    lastToken = result.accessToken.orEmpty()
                    return DriveCredentials(key, lastToken)
                }
            } catch (e: Exception) {
                if (e is InterruptedException) Thread.currentThread().interrupt()
                if (key.isBlank()) throw IOException("Não foi possível renovar o acesso ao Drive. Confira a conexão ou autorize a conta.", e)
            }
        }
        if (key.isBlank()) throw IOException("Autorize sua conta Google nas configurações do Drive.")
        return DriveCredentials(apiKey = key)
    }
    private fun invalidate() {
        val invalid = lastToken
        lastToken = ""
        if (invalid.isNotBlank()) runCatching {
            Tasks.await(authorization.clearToken(ClearTokenRequest.builder().setToken(invalid).build()), 10, TimeUnit.SECONDS)
        }
    }
    override fun createDataSource(): DataSource {
        val resolved = ResolvingDataSource.Factory(DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(15000).setReadTimeoutMs(30000), ResolvingDataSource.Resolver { spec ->
            val uri = spec.uri
            val id = uri.lastPathSegment.orEmpty()
            require(uri.scheme == "https" && uri.host == "www.googleapis.com" &&
                uri.path == "/drive/v3/files/$id" && id.matches(Regex("[A-Za-z0-9_-]+"))) { "Endereço de reprodução inválido." }
            val resourceKey = spec.key.orEmpty().substringAfter('|', "")
            spec.withRequestHeaders(credentials().headers(context.packageName, installedCertificate(context), id, resourceKey))
        }).createDataSource()
        return object : DataSource by resolved {
            override fun open(dataSpec: DataSpec): Long {
                try { return resolved.open(dataSpec) }
                catch (e: HttpDataSource.InvalidResponseCodeException) {
                    if (e.responseCode != 401 || lastToken.isBlank()) throw e
                    resolved.close(); invalidate()
                    return resolved.open(dataSpec) // Apenas uma nova tentativa, com token renovado.
                }
            }
        }
    }
}
```

## app/src/main/java/com/example/data/playback/PlaybackService.kt

```kotlin
package com.example.data.playback

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.example.MainActivity

/** O serviço é dono do player. Fechar o visualizador não destrói o áudio. */
@androidx.annotation.OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private val preferences by lazy { getSharedPreferences("keplerae_playback", 0) }
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val saveTick = object : Runnable {
        override fun run() { savePosition(); handler.postDelayed(this, 5000L) }
    }
    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DrivePlaybackSource(this)))
            .setSeekBackIncrementMs(10000).setSeekForwardIncrementMs(10000).build().apply {
                setAudioAttributes(AudioAttributes.DEFAULT, true)
                setHandleAudioBecomingNoisy(true)
                setWakeMode(C.WAKE_MODE_LOCAL)
            }
        player.addListener(object : Player.Listener {
            override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo, reason: Int) {
                oldPosition.mediaItem?.mediaId?.takeIf { it.isNotBlank() }?.let { id ->
                    preferences.edit().putLong(id, if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION)
                        0L else oldPosition.positionMs.coerceAtLeast(0)).apply()
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { savePosition() }
            override fun onPlaybackStateChanged(playbackState: Int) { savePosition() }
        })
        val open = PendingIntent.getActivity(this, 2500, Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        session = MediaSession.Builder(this, player).setSessionActivity(open)
            .setCallback(object : MediaSession.Callback {
                override fun onConnect(session: MediaSession, controller: MediaSession.ControllerInfo): MediaSession.ConnectionResult {
                    return if (controller.packageName == packageName || controller.isTrusted)
                        super.onConnect(session, controller) else MediaSession.ConnectionResult.reject()
                }
            }).build()
        handler.post(saveTick)
    }
    private fun savePosition() {
        val player = session?.player ?: return
        val id = player.currentMediaItem?.mediaId?.takeIf { it.isNotBlank() } ?: return
        val position = if (player.playbackState == Player.STATE_ENDED) 0L else player.currentPosition.coerceAtLeast(0)
        preferences.edit().putLong(id, position).apply()
    }
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session
    override fun onTaskRemoved(rootIntent: Intent?) {
        // Uma sessão tocando continua; uma sessão parada libera o serviço.
        val player = session?.player
        if (player == null || !player.playWhenReady || player.playbackState == Player.STATE_ENDED || player.mediaItemCount == 0) stopSelf()
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null); savePosition()
        session?.run { player.release(); release() }; session = null
        super.onDestroy()
    }
}
```

## app/src/main/java/com/example/data/productivity/PomodoroAmbience.kt

```kotlin
package com.example.data.productivity

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import android.os.Build
import com.example.R

data class AmbientLayer(val resource: Int, val gain: Float = 1f)
data class AmbientPreset(val id: String, val title: String, val detail: String,
    val palette: Int, val layers: List<AmbientLayer>)

/** Camadas locais: nenhuma página externa ou streaming é necessário durante o foco. */
object AmbientPresets {
    val all = listOf(
        AmbientPreset("clock","Relógio","Tique-taque ritmado",0,listOf(AmbientLayer(R.raw.ambient_clock))),
        AmbientPreset("wind","Ar e vento","Uma brisa constante",1,listOf(AmbientLayer(R.raw.ambient_wind))),
        AmbientPreset("rain","Chuva","Gotas para concentrar",2,listOf(AmbientLayer(R.raw.ambient_rain))),
        AmbientPreset("storm","Tempestade","Chuva e trovões",3,listOf(AmbientLayer(R.raw.ambient_storm,.65f),AmbientLayer(R.raw.ambient_rain,.35f))),
        AmbientPreset("fire","Lareira","Madeira crepitando",0,listOf(AmbientLayer(R.raw.ambient_fire))),
        AmbientPreset("gryffindor","Grifinória","Salão comunal • lareira e conversa",0,listOf(AmbientLayer(R.raw.ambient_fire,.65f),AmbientLayer(R.raw.ambient_room,.30f))),
        AmbientPreset("slytherin","Sonserina","Salão comunal • brisa e chuva",3,listOf(AmbientLayer(R.raw.ambient_wind,.55f),AmbientLayer(R.raw.ambient_rain,.35f))),
        AmbientPreset("ravenclaw","Corvinal","Salão comunal • vento e relógio",1,listOf(AmbientLayer(R.raw.ambient_wind,.45f),AmbientLayer(R.raw.ambient_clock,.30f))),
        AmbientPreset("hufflepuff","Lufa-Lufa","Salão comunal • calor e tranquilidade",2,listOf(AmbientLayer(R.raw.ambient_fire,.55f),AmbientLayer(R.raw.ambient_wind,.20f))),
        AmbientPreset("library","Biblioteca de Hogwarts","Leitura • páginas e relógio",1,listOf(AmbientLayer(R.raw.ambient_library,.65f),AmbientLayer(R.raw.ambient_clock,.20f)))
    )
    fun get(id: String): AmbientPreset = all.firstOrNull { it.id == id } ?: all.first { it.id == "rain" }
}

/** Propriedade exclusiva do serviço: pausa/descarte liberam todos os players e o foco. */
@androidx.annotation.OptIn(UnstableApi::class)
class PomodoroAmbience(context: Context) {
    private val app = context.applicationContext
    private val manager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val players = mutableListOf<Pair<ExoPlayer,Float>>()
    private var id: String? = null
    private var volume = .35f
    private var resumeAfterInterruption = false
    private var focusHeld = false
    private var duckFactor=1f
    private var blocked=false
    private val attributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
    private val listener = AudioManager.OnAudioFocusChangeListener { change ->
        when(change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                if(resumeAfterInterruption) players.forEach { runCatching { it.first.play() } }
                resumeAfterInterruption=false
                duckFactor=1f;applyVolume(duckFactor)
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeAfterInterruption=players.any { runCatching { it.first.isPlaying }.getOrDefault(false) }
                players.forEach { runCatching { it.first.pause() } }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {duckFactor=.15f;applyVolume(duckFactor)}
            AudioManager.AUDIOFOCUS_LOSS -> {blocked=true;stop()}
        }
    }
    private val request: AudioFocusRequest? = if(Build.VERSION.SDK_INT>=26)
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attributes)
            .setOnAudioFocusChangeListener(listener).build() else null

    @Suppress("DEPRECATION")
    fun update(settings: PomodoroSettings, activeFocus: Boolean) {
        if(!activeFocus||!settings.ambienceEnabled) {stop();if(!settings.ambienceEnabled)blocked=false;return}
        if(blocked)return
        volume=settings.ambienceVolume
        val preset=AmbientPresets.get(settings.ambienceId)
        if(id==preset.id && players.isNotEmpty()) {applyVolume(duckFactor);return}
        stop()
        val granted=if(Build.VERSION.SDK_INT>=26) manager.requestAudioFocus(request!!)
            else manager.requestAudioFocus(listener,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN)
        if(granted!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED) return
        focusHeld=true;id=preset.id;duckFactor=1f
        for(layer in preset.layers) {
            try {
                // Repeat ONE conserva o pipeline entre voltas. OGGs têm costura
                // de três segundos; não recriamos o player em cada conclusão.
                val player=ExoPlayer.Builder(app)
                    .setAudioAttributes(androidx.media3.common.AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), false)
                    .setHandleAudioBecomingNoisy(false).setWakeMode(C.WAKE_MODE_LOCAL).build()
                players.add(player to layer.gain)
                player.repeatMode=Player.REPEAT_MODE_ONE
                player.volume=(volume*layer.gain).coerceIn(0f,1f)
                player.addListener(object:Player.Listener {
                    override fun onPlayerError(error:PlaybackException) { stop() }
                })
                player.setMediaItem(MediaItem.fromUri(Uri.parse("android.resource://${app.packageName}/${layer.resource}")))
                player.prepare()
                player.play()
            } catch(_:Exception) {stop();return}
        }
    }
    fun muteForNoisyOutput() {blocked=true;stop()}
    fun allowUserStart() {blocked=false}
    private fun applyVolume(factor: Float) = players.forEach { (p,gain) ->
        runCatching { p.volume=(volume*gain*factor).coerceIn(0f,1f) }
    }
    @Suppress("DEPRECATION")
    fun stop() {
        val old=players.toList();players.clear()
        old.forEach { runCatching { it.first.release() } }
        id=null;resumeAfterInterruption=false
        if(focusHeld) {
            focusHeld=false
            if(Build.VERSION.SDK_INT>=26) manager.abandonAudioFocusRequest(request!!)
            else manager.abandonAudioFocus(listener)
        }
    }
}
```

## app/src/main/java/com/example/data/productivity/PomodoroModel.kt

```kotlin
package com.example.data.productivity

enum class PomodoroPhase(val label: String) { FOCUS("Foco"), SHORT_BREAK("Pausa curta"), LONG_BREAK("Pausa longa") }
data class PomodoroSettings(val focusMinutes: Int = 25, val shortMinutes: Int = 5,
    val longMinutes: Int = 15, val cycles: Int = 4, val sounds: Boolean = true,
    val sound: String = "bell", val autoAdvance: Boolean = false,
    val ambienceEnabled: Boolean = false, val ambienceId: String = "rain",
    val ambienceVolume: Float = .35f) {
    fun valid() = focusMinutes in 1..180 && shortMinutes in 1..90 && longMinutes in 1..90 && cycles in 1..12 &&
        ambienceVolume.isFinite() && ambienceVolume in 0f..1f
    fun duration(phase: PomodoroPhase): Long = when (phase) {
        PomodoroPhase.FOCUS -> focusMinutes
        PomodoroPhase.SHORT_BREAK -> shortMinutes
        PomodoroPhase.LONG_BREAK -> longMinutes
    } * 60_000L
}
data class FocusRecord(val id: String, val finishedAt: Long, val durationMs: Long)
data class PomodoroState(val settings: PomodoroSettings = PomodoroSettings(),
    val phase: PomodoroPhase = PomodoroPhase.FOCUS, val running: Boolean = false,
    val paused: Boolean = false, val remainingMs: Long = 25 * 60_000L,
    val phaseDurationMs: Long = 25 * 60_000L, val deadlineWall: Long = 0,
    val deadlineElapsed: Long = 0, val bootEpoch: Long = 0,
    val cycle: Int = 0, val sessionId: String = "", val history: List<FocusRecord> = emptyList())

/** Durações/ciclos podem ser escolhidos sempre. A etapa ativa mantém seu prazo. */
fun applyPomodoroSettings(state: PomodoroState, settings: PomodoroSettings): PomodoroState {
    require(settings.valid())
    val durationsChanged = state.settings.focusMinutes != settings.focusMinutes ||
        state.settings.shortMinutes != settings.shortMinutes ||
        state.settings.longMinutes != settings.longMinutes || state.settings.cycles != settings.cycles
    return if (durationsChanged && !state.running && !state.paused) state.copy(
        settings=settings, phase=PomodoroPhase.FOCUS, cycle=0,
        remainingMs=settings.duration(PomodoroPhase.FOCUS), phaseDurationMs=settings.duration(PomodoroPhase.FOCUS),
        sessionId="", deadlineWall=0, deadlineElapsed=0,
    ) else state.copy(settings=settings)
}

/** Relógio monotônico enquanto o aparelho não reinicia; parede como recuperação após reboot. */
fun remainingAt(state: PomodoroState, wall: Long, elapsed: Long): Long {
    if (!state.running) return state.remainingMs
    val sameBoot = kotlin.math.abs((wall - elapsed) - state.bootEpoch) < 60_000
    return ((if (sameBoot) state.deadlineElapsed - elapsed else state.deadlineWall - wall)
        .coerceIn(0, state.phaseDurationMs))
}

/** Conclusão idempotente: apenas fases inteiras de foco contam como pomodoros. */
fun finishPhase(state: PomodoroState, now: Long): PomodoroState {
    if (!state.running) return state
    val focus = state.phase == PomodoroPhase.FOCUS
    val cycle = if (focus) state.cycle + 1 else state.cycle
    val next = when (state.phase) {
        PomodoroPhase.FOCUS -> if (cycle >= state.settings.cycles) PomodoroPhase.LONG_BREAK else PomodoroPhase.SHORT_BREAK
        else -> PomodoroPhase.FOCUS
    }
    val history = if (focus && state.history.none { it.id == state.sessionId })
        state.history + FocusRecord(state.sessionId, now, state.phaseDurationMs) else state.history
    return state.copy(phase = next, running = false, paused = false, remainingMs = state.settings.duration(next),
        phaseDurationMs = state.settings.duration(next), cycle = if (state.phase == PomodoroPhase.LONG_BREAK) 0 else cycle,
        deadlineWall = 0, deadlineElapsed = 0, sessionId = "", history = history)
}
```

## app/src/main/java/com/example/data/productivity/PomodoroService.kt

```kotlin
package com.example.data.productivity

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.media.AudioManager
import android.content.pm.ServiceInfo
import android.content.pm.PackageManager
import android.Manifest
import android.annotation.SuppressLint
import android.media.MediaPlayer
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect

object PomodoroAudio {
    private var player: MediaPlayer?=null
    fun play(context: Context, sound: String) {
        player?.release()
        player=MediaPlayer.create(context.applicationContext, if(sound=="soft") R.raw.pomo_soft else R.raw.pomo_bell)
        player?.setOnCompletionListener { it.release(); if(player===it) player=null }
        player?.start()
    }
}

/** Serviço iniciado pelo usuário, com notificação visível e parada explícita. */
@SuppressLint("MissingPermission") // FGS permitido sem POST_NOTIFICATIONS; posts normais verificados abaixo.
class PomodoroService : Service() {
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    private var timer: Job?=null
    private var lock: PowerManager.WakeLock?=null
    private var audioObserver: Job?=null
    private var noisyRegistered=false
    private val ambience by lazy { PomodoroAmbience(this) }
    private val noisyReceiver=object:BroadcastReceiver() {
        override fun onReceive(context:Context?,intent:Intent?) { ambience.muteForNoisyOutput() }
    }
    private val store by lazy { PomodoroStore.get(this) }
    override fun onBind(intent: Intent?): IBinder?=null
    override fun onCreate() {
        super.onCreate()
        ContextCompat.registerReceiver(this,noisyReceiver,IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
            ContextCompat.RECEIVER_NOT_EXPORTED)
        noisyRegistered=true
        if(Build.VERSION.SDK_INT>=26) {
            val manager=getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL,"Pomodoro em andamento",NotificationManager.IMPORTANCE_LOW).apply { setSound(null,null) })
            manager.createNotificationChannel(NotificationChannel(DONE_CHANNEL,"Conclusões do Pomodoro",NotificationManager.IMPORTANCE_DEFAULT).apply { setSound(null,null) })
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when(intent?.action) {
            PAUSE -> { store.pause(); stopTimer(); return START_NOT_STICKY }
            RESET -> { store.reset(); stopTimer(); return START_NOT_STICKY }
            SKIP -> { store.skip(); stopTimer(); return START_NOT_STICKY }
            RESTORE -> Unit
            else -> { ambience.allowUserStart();store.start() }
        }
        if(!store.state.value.running) { stopSelf(); return START_NOT_STICKY }
        val initialNotification=notification(store.state.value)
        startVisible(initialNotification,store.state.value)
        audioObserver?.cancel()
        audioObserver=scope.launch {
            store.state.collect { current ->
                if(current.running) {
                    startVisible(notification(current),current)
                    ambience.update(current.settings,current.phase==PomodoroPhase.FOCUS)
                } else ambience.stop()
            }
        }
        lock?.let { if(it.isHeld) it.release() }
        lock=(getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"keplerae:pomodoro")
            .apply { acquire(store.state.value.phaseDurationMs+30_000L) }
        timer?.cancel()
        timer=scope.launch {
            while(isActive && store.state.value.running) {
                val endedPhase=store.state.value.phase
                if(store.finishIfDue()) {
                    val state=store.state.value
                    ambience.stop()
                    if(state.settings.sounds) PomodoroAudio.play(this@PomodoroService,state.settings.sound)
                    if(canNotify() && NotificationManagerCompat.from(this@PomodoroService).areNotificationsEnabled()) {
                        val done=NotificationCompat.Builder(this@PomodoroService,DONE_CHANNEL)
                            .setSmallIcon(R.drawable.ic_pomodoro_notification)
                            .setContentTitle("${endedPhase.label} concluído")
                            .setContentText("Próxima etapa: ${state.phase.label.lowercase()}.")
                            .setContentIntent(openApp()).setAutoCancel(true).setSilent(true).build()
                        getSystemService(NotificationManager::class.java).notify(ID+1,done)
                    }
                    if(state.settings.autoAdvance) {
                        store.start()
                        lock?.let { if(it.isHeld) it.release(); it.acquire(store.state.value.phaseDurationMs+30_000L) }
                    } else { stopTimer(); break }
                }
                val left=remainingAt(store.state.value,System.currentTimeMillis(),SystemClock.elapsedRealtime())
                delay(left.coerceIn(200L,30_000L))
            }
        }
        return START_STICKY
    }
    private fun startVisible(n:Notification,s:PomodoroState) {
        if(Build.VERSION.SDK_INT>=34) {
            val type=ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                if(s.settings.ambienceEnabled&&s.phase==PomodoroPhase.FOCUS)
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            startForeground(ID,n,type)
        } else startForeground(ID,n)
    }
    private fun openApp(): PendingIntent=PendingIntent.getActivity(this,0,
        Intent(this,MainActivity::class.java).putExtra("open_pomodoro",true)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun canNotify(): Boolean = Build.VERSION.SDK_INT<33 ||
        ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED
    private fun action(name: String): PendingIntent=PendingIntent.getService(this,name.hashCode(),
        Intent(this,PomodoroService::class.java).setAction(name),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun notification(s: PomodoroState): Notification {
        val remaining=remainingAt(s,System.currentTimeMillis(),SystemClock.elapsedRealtime())
        return NotificationCompat.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_pomodoro_notification)
            .setContentTitle("Pomodoro • ${s.phase.label}")
            .setContentText("Ciclo ${s.cycle.coerceAtMost(s.settings.cycles-1)+1} de ${s.settings.cycles}")
            .setWhen(System.currentTimeMillis()+remaining).setUsesChronometer(true).setChronometerCountDown(true)
            .setContentIntent(openApp()).setOngoing(true).setOnlyAlertOnce(true).setSilent(true)
            .addAction(0,"Pausar",action(PAUSE)).addAction(0,"Parar",action(RESET)).build()
    }
    private fun stopTimer() {
        timer?.cancel(); timer=null
        audioObserver?.cancel();audioObserver=null;ambience.stop()
        lock?.let { if(it.isHeld) it.release() }; lock=null
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    override fun onDestroy() {
        timer?.cancel();audioObserver?.cancel();ambience.stop(); scope.cancel()
        if(noisyRegistered) { unregisterReceiver(noisyReceiver);noisyRegistered=false }
        lock?.let { if(it.isHeld) it.release() }; lock=null
        super.onDestroy()
    }
    companion object {
        const val START="pomodoro.start"; const val RESTORE="pomodoro.restore"
        const val PAUSE="pomodoro.pause"; const val RESET="pomodoro.reset"; const val SKIP="pomodoro.skip"
        private const val CHANNEL="keplerae_pomodoro_timer"
        private const val DONE_CHANNEL="keplerae_pomodoro_done"
        private const val ID=2300
        fun command(context: Context, action: String) {
            val intent=Intent(context,PomodoroService::class.java).setAction(action)
            if(action==START||action==RESTORE) ContextCompat.startForegroundService(context,intent)
            else context.startService(intent)
        }
    }
}
fun formatTimer(ms: Long): String {
    val seconds=((ms+999)/1000).coerceAtLeast(0)
    return "%02d:%02d".format(seconds/60,seconds%60)
}
```

## app/src/main/java/com/example/data/productivity/PomodoroStore.kt

```kotlin
package com.example.data.productivity

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Um único proprietário no processo, compartilhado pela tela e pelo serviço. */
class PomodoroStore private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("keplerae_pomodoro", Context.MODE_PRIVATE)
    private val mutable = MutableStateFlow(read())
    val state = mutable.asStateFlow()
    private fun read(): PomodoroState = runCatching {
        val j = JSONObject(prefs.getString("state", "{}") ?: "{}")
        val s = j.optJSONObject("settings") ?: JSONObject()
        val settings = PomodoroSettings(s.optInt("focus",25), s.optInt("short",5), s.optInt("long",15),
            s.optInt("cycles",4), s.optBoolean("sounds",true), s.optString("sound","bell"), s.optBoolean("auto",false),
            s.optBoolean("ambienceEnabled",false),s.optString("ambienceId","rain"),s.optDouble("ambienceVolume",.35).toFloat())
            .takeIf { it.valid() } ?: PomodoroSettings()
        val h = j.optJSONArray("history") ?: JSONArray()
        val history = (0 until h.length()).map { h.getJSONObject(it) }.map {
            FocusRecord(it.getString("id"), it.getLong("at"), it.getLong("duration")) }
        val phase = runCatching { PomodoroPhase.valueOf(j.optString("phase","FOCUS")) }.getOrDefault(PomodoroPhase.FOCUS)
        PomodoroState(settings,phase,j.optBoolean("running"),j.optBoolean("paused"),
            j.optLong("remaining",settings.duration(phase)),j.optLong("duration",settings.duration(phase)),
            j.optLong("wall"),j.optLong("elapsed"),j.optLong("boot"),j.optInt("cycle"),j.optString("session"),history)
    }.getOrDefault(PomodoroState())
    private fun save(s: PomodoroState, durable: Boolean = false) {
        val c=s.settings
        val j=JSONObject().put("settings",JSONObject().put("focus",c.focusMinutes).put("short",c.shortMinutes)
            .put("long",c.longMinutes).put("cycles",c.cycles).put("sounds",c.sounds).put("sound",c.sound).put("auto",c.autoAdvance)
            .put("ambienceEnabled",c.ambienceEnabled).put("ambienceId",c.ambienceId).put("ambienceVolume",c.ambienceVolume.toDouble()))
            .put("phase",s.phase.name).put("running",s.running).put("paused",s.paused).put("remaining",s.remainingMs)
            .put("duration",s.phaseDurationMs).put("wall",s.deadlineWall).put("elapsed",s.deadlineElapsed)
            .put("boot",s.bootEpoch).put("cycle",s.cycle).put("session",s.sessionId)
            .put("history",JSONArray().apply { s.history.forEach { put(JSONObject().put("id",it.id).put("at",it.finishedAt).put("duration",it.durationMs)) } })
        // Uma transação para estado + histórico: reabrir não duplica conclusões.
        val saved=prefs.edit().putString("state",j.toString()).commit()
        if(durable)check(saved) {"Não foi possível salvar o Pomodoro."}
        mutable.value=s
    }
    @Synchronized fun start() {
        val s=mutable.value
        if (s.running) return
        val wall=System.currentTimeMillis(); val elapsed=SystemClock.elapsedRealtime()
        val remain=if (s.paused) s.remainingMs else s.settings.duration(s.phase)
        save(s.copy(running=true,paused=false,remainingMs=remain,deadlineWall=wall+remain,deadlineElapsed=elapsed+remain,
            phaseDurationMs=if(s.paused)s.phaseDurationMs else remain,
            bootEpoch=wall-elapsed,sessionId=s.sessionId.ifBlank { UUID.randomUUID().toString() }))
    }
    @Synchronized fun pause() {
        val s=mutable.value
        if (s.running) save(s.copy(running=false,paused=true,
            remainingMs=remainingAt(s,System.currentTimeMillis(),SystemClock.elapsedRealtime())))
    }
    @Synchronized fun reset() {
        val s=mutable.value
        save(s.copy(running=false,paused=false,remainingMs=s.settings.duration(s.phase),
            phaseDurationMs=s.settings.duration(s.phase),sessionId="",deadlineWall=0,deadlineElapsed=0))
    }
    @Synchronized fun skip() {
        val s=mutable.value
        val next=if(s.phase==PomodoroPhase.FOCUS) PomodoroPhase.SHORT_BREAK else PomodoroPhase.FOCUS
        save(s.copy(phase=next,running=false,paused=false,remainingMs=s.settings.duration(next),
            phaseDurationMs=s.settings.duration(next),sessionId="",deadlineWall=0,deadlineElapsed=0))
    }
    @Synchronized fun finishIfDue(): Boolean {
        val s=mutable.value
        if(!s.running || remainingAt(s,System.currentTimeMillis(),SystemClock.elapsedRealtime())>0) return false
        save(finishPhase(s,System.currentTimeMillis()))
        return true
    }
    @Synchronized fun configure(settings: PomodoroSettings) {
        require(settings.valid())
        save(applyPomodoroSettings(mutable.value, settings))
    }
    @Synchronized fun importData(settings: PomodoroSettings, history: List<FocusRecord>) {
        val current=mutable.value
        save(applyPomodoroSettings(current,settings).copy(
            history=com.example.data.backup.mergeHistory(current.history,history)),true)
    }
    companion object {
        @Volatile private var instance: PomodoroStore?=null
        fun get(context: Context): PomodoroStore = instance ?: synchronized(this) {
            instance ?: PomodoroStore(context).also { instance=it } }
    }
}
```

## app/src/main/java/com/example/data/productivity/QuestionModel.kt

```kotlin
package com.example.data.productivity

data class QuestionSubject(val id: String, val name: String)
data class QuestionRecord(val id: String, val subjectId: String, val correct: Int, val wrong: Int, val recordedAt: Long)
data class QuestionState(val subjects: List<QuestionSubject> = emptyList(), val records: List<QuestionRecord> = emptyList())

/** Exclusão em cascata: estatísticas são derivadas dos registros restantes. */
fun withoutQuestionSubject(state: QuestionState, id: String): QuestionState = state.copy(
    subjects = state.subjects.filterNot { it.id == id },
    records = state.records.filterNot { it.subjectId == id },
)
data class QuestionTotals(val correct: Long, val wrong: Long) {
    val total: Long get() = correct + wrong
    val accuracy: Double get() = if(total==0L) 0.0 else 100.0*correct/total
    val errorRate: Double get() = if(total==0L) 0.0 else 100.0*wrong/total
}
fun questionTotals(records: List<QuestionRecord>): QuestionTotals = QuestionTotals(
    records.sumOf { it.correct.toLong() },records.sumOf { it.wrong.toLong() })
fun validQuestionCounts(correct: Int?, wrong: Int?): Boolean = correct!=null && wrong!=null &&
    correct in 0..1_000_000 && wrong in 0..1_000_000 && correct.toLong()+wrong>0

/** Cada ponto contém o acumulado até aquele dia local, incluindo dias fora da janela do gráfico. */
data class CumulativeQuestionDay(val recordedAt:Long,val correct:Long,val wrong:Long) {
    val total:Long get()=correct+wrong
}
fun cumulativeQuestionDays(records:List<QuestionRecord>,
    timeZone:java.util.TimeZone=java.util.TimeZone.getDefault()):List<CumulativeQuestionDay> {
    val formatter=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.ROOT).apply {this.timeZone=timeZone}
    val groups=records.sortedBy {it.recordedAt}.groupBy {formatter.format(java.util.Date(it.recordedAt))}
    var correct=0L;var wrong=0L
    return groups.values.map { day ->
        correct+=day.sumOf {it.correct.toLong()};wrong+=day.sumOf {it.wrong.toLong()}
        CumulativeQuestionDay(day.first().recordedAt,correct,wrong)
    }
}
```

## app/src/main/java/com/example/data/productivity/QuestionStore.kt

```kotlin
package com.example.data.productivity

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class QuestionStore private constructor(context: Context) {
    private val prefs=context.applicationContext.getSharedPreferences("keplerae_questions",Context.MODE_PRIVATE)
    private val mutable=MutableStateFlow(read())
    val state=mutable.asStateFlow()
    private fun read(): QuestionState = runCatching {
        val j=JSONObject(prefs.getString("state","{}")?:"{}")
        val subjects=j.optJSONArray("subjects")?:JSONArray(); val records=j.optJSONArray("records")?:JSONArray()
        QuestionState((0 until subjects.length()).map { subjects.getJSONObject(it) }.map {
            QuestionSubject(it.getString("id"),it.getString("name")) },
            (0 until records.length()).map { records.getJSONObject(it) }.map {
                QuestionRecord(it.getString("id"),it.getString("subject"),it.getInt("correct"),it.getInt("wrong"),it.getLong("at")) })
    }.getOrDefault(QuestionState())
    private fun save(state: QuestionState, durable: Boolean = false) {
        val j=JSONObject().put("subjects",JSONArray().apply { state.subjects.forEach {
            put(JSONObject().put("id",it.id).put("name",it.name)) } })
            .put("records",JSONArray().apply { state.records.forEach {
                put(JSONObject().put("id",it.id).put("subject",it.subjectId).put("correct",it.correct).put("wrong",it.wrong).put("at",it.recordedAt)) } })
        val saved=prefs.edit().putString("state",j.toString()).commit()
        if(durable)check(saved) {"Não foi possível salvar as questões."}
        mutable.value=state
    }
    @Synchronized fun createSubject(name: String): String {
        val clean=name.trim().replace(Regex("\\s+")," ")
        require(clean.isNotBlank()&&clean.length<=80) { "Use um nome de 1 a 80 caracteres." }
        require(mutable.value.subjects.none { it.name.equals(clean,true) }) { "Essa matéria já existe." }
        val subject=QuestionSubject(UUID.randomUUID().toString(),clean)
        save(mutable.value.copy(subjects=mutable.value.subjects+subject));return subject.id
    }
    @Synchronized fun add(subjectId: String, correct: Int, wrong: Int) {
        require(mutable.value.subjects.any { it.id==subjectId })
        require(validQuestionCounts(correct,wrong)) { "Informe números inteiros positivos ou zero; o total deve ser maior que zero." }
        save(mutable.value.copy(records=mutable.value.records+
            QuestionRecord(UUID.randomUUID().toString(),subjectId,correct,wrong,System.currentTimeMillis())))
    }
    @Synchronized fun deleteRecord(id: String) { save(mutable.value.copy(records=mutable.value.records.filterNot { it.id==id })) }
    @Synchronized fun deleteSubject(id: String) { save(withoutQuestionSubject(mutable.value, id)) }
    /** Um único save apaga blocos e histórico; outros módulos não são acessados. */
    @Synchronized fun resetAll() { save(QuestionState()) }
    @Synchronized fun importData(incoming: QuestionState) {
        save(com.example.data.backup.mergeQuestions(mutable.value, incoming),true)
    }
    companion object {
        @Volatile private var instance: QuestionStore?=null
        fun get(context: Context): QuestionStore = instance?:synchronized(this) {
            instance?:QuestionStore(context).also { instance=it } }
    }
}
```

## app/src/main/java/com/example/data/repository/AppearancePreferences.kt

```kotlin
package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.SharedPreferencesMigration
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

// Uma única instância por arquivo, inclusive após recriações da Activity.
private val Context.appearanceDataStore by preferencesDataStore(
    name = "keplerae_appearance",
    produceMigrations = { context ->
        // Migra apenas aparência. Favoritos, conclusões e histórico continuam intactos.
        listOf(SharedPreferencesMigration(context, "keplerae", setOf("theme", "dynamic_color")))
    },
)

data class Appearance(val theme: ThemeMode = ThemeMode.SYSTEM, val dynamicColor: Boolean = true)

class AppearancePreferences(context: Context) {
    private val store = context.applicationContext.appearanceDataStore
    private val themeKey = stringPreferencesKey("theme")
    private val dynamicKey = booleanPreferencesKey("dynamic_color")
    val appearance = store.data.catch { error ->
        if (error is IOException) emit(emptyPreferences()) else throw error
    }.map { prefs ->
        Appearance(
            runCatching { ThemeMode.valueOf(prefs[themeKey] ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM),
            prefs[dynamicKey] ?: true,
        )
    }
    suspend fun setTheme(theme: ThemeMode) { store.edit { it[themeKey] = theme.name } }
    suspend fun setDynamicColor(enabled: Boolean) { store.edit { it[dynamicKey] = enabled } }
    suspend fun setAppearance(theme: ThemeMode, dynamic: Boolean) {
        store.edit { it[themeKey] = theme.name; it[dynamicKey] = dynamic }
    }
}
```

## app/src/main/java/com/example/data/repository/ItemOrder.kt

```kotlin
package com.example.data.repository

/** Ignora IDs removidos, evita duplicatas e acrescenta novos materiais no fim. */
fun reconcileOrder(currentIds: List<String>, savedIds: List<String>): List<String> {
    val available = currentIds.toSet()
    return (savedIds.filter { it in available } + currentIds).distinct()
}

/** Reordena somente o conjunto visível; materiais ocultos mantêm sua posição. */
fun mergeVisibleOrder(fullOrder: List<String>, visibleOrder: List<String>): List<String> {
    val visible = visibleOrder.distinct().filter { it in fullOrder }.toSet()
    val iterator = visibleOrder.distinct().filter { it in visible }.iterator()
    return fullOrder.map { if (it in visible && iterator.hasNext()) iterator.next() else it }
}

/** Índices são resolvidos pelas chaves; cabeçalhos de LazyColumn não interferem. */
fun moveId(order: List<String>, from: String, to: String): List<String> {
    val source = order.indexOf(from)
    val target = order.indexOf(to)
    if (source < 0 || target < 0 || source == target) return order
    return order.toMutableList().apply { add(target, removeAt(source)) }
}
```

## app/src/main/java/com/example/data/repository/StudyViewModel.kt

```kotlin
package com.example.data.repository

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

enum class ThemeMode(val label: String) { SYSTEM("Sistema"), LIGHT("Claro"), DARK("Escuro") }
data class StudyState(
    val items: List<StudyItem> = emptyList(),
    val favorites: Set<String> = emptySet(),
    val completed: Set<String> = emptySet(),
    val accessed: Map<String, Long> = emptyMap(),
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val itemOrder: List<String> = emptyList(),
    val loading: Boolean = true,
    val error: String? = null
)
class StudyViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application
    private val preferences = application.getSharedPreferences("keplerae", 0)
    private val appearancePreferences = AppearancePreferences(application)
    private val mutableState = MutableStateFlow(StudyState(
        favorites = preferences.getStringSet("favorites", emptySet())!!.toSet(),
        completed = preferences.getStringSet("completed", emptySet())!!.toSet(),
        accessed = readAccessed(),
        theme = runCatching { ThemeMode.valueOf(preferences.getString("theme", "SYSTEM")!!) }.getOrDefault(ThemeMode.SYSTEM),
        dynamicColor = preferences.getBoolean("dynamic_color", true),
        itemOrder = runCatching {
            val array = JSONArray(preferences.getString("item_order", "[]")!!)
            List(array.length()) { array.getString(it) }
        }.getOrDefault(emptyList()),
    ))
    val state = mutableState.asStateFlow()
    init {
        reload()
        viewModelScope.launch {
            appearancePreferences.appearance.collect { appearance ->
                mutableState.update { it.copy(theme = appearance.theme, dynamicColor = appearance.dynamicColor) }
            }
        }
    }
    fun reload() {
        mutableState.value = mutableState.value.copy(loading = true, error = null)
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching {
                val json = JSONArray(app.assets.open("catalog.json").bufferedReader().use { it.readText() })
                List(json.length()) { index ->
                    val row = json.getJSONObject(index)
                    val path = row.getJSONArray("folderPath")
                    StudyItem(row.getString("id"), row.getString("title"), row.getString("filename"),
                        row.getString("subjectId"), List(path.length()) { path.getString(it) },
                        ContentType.valueOf(row.getString("type")), row.getString("url"),
                        LinkKind.valueOf(row.getString("linkKind")), row.getString("driveFileId"),
                        row.getString("note"), row.getString("source"))
                }.also { rows -> require(rows.all { isAllowedDriveUrl(it.url) }) }
            } }
            mutableState.value = result.fold(
                onSuccess = { mutableState.value.copy(items = it, loading = false) },
                onFailure = { mutableState.value.copy(loading = false, error = "Não foi possível carregar a biblioteca.") }
            )
        }
    }
    private fun readAccessed(): Map<String,Long> = runCatching {
        val json = JSONObject(preferences.getString("accessed", "{}")!!)
        json.keys().asSequence().associateWith { json.getLong(it) }
    }.getOrDefault(emptyMap())
    fun toggleFavorite(id: String) {
        val next = mutableState.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        preferences.edit().putStringSet("favorites", next).apply()
        mutableState.value = mutableState.value.copy(favorites = next)
    }
    fun toggleCompleted(id: String) {
        val next = mutableState.value.completed.toMutableSet().apply { if (!add(id)) remove(id) }
        preferences.edit().putStringSet("completed", next).apply()
        mutableState.value = mutableState.value.copy(completed = next)
    }
    fun recordAccess(id: String) {
        val next = mutableState.value.accessed + (id to System.currentTimeMillis())
        preferences.edit().putString("accessed", JSONObject(next).toString()).apply()
        mutableState.value = mutableState.value.copy(accessed = next)
    }
    fun setTheme(theme: ThemeMode) {
        mutableState.update { it.copy(theme = theme) }
        viewModelScope.launch { appearancePreferences.setTheme(theme) }
    }
    fun setDynamicColor(enabled: Boolean) {
        mutableState.update { it.copy(dynamicColor = enabled) }
        viewModelScope.launch { appearancePreferences.setDynamicColor(enabled) }
    }
    fun saveVisibleOrder(visibleIds: List<String>) {
        val current = mutableState.value
        val fullOrder = reconcileOrder(current.items.map { it.id }, current.itemOrder)
        val next = mergeVisibleOrder(fullOrder, visibleIds)
        preferences.edit().putString("item_order", JSONArray(next).toString()).apply()
        mutableState.update { it.copy(itemOrder = next) }
    }
    /** Mescla registros de estudo e aplica a preferência importada em uma gravação DataStore. */
    suspend fun importData(incoming: com.example.data.backup.StudyBackup) {
        val current=mutableState.value
        val favorites=current.favorites+incoming.favorites
        val completed=current.completed+incoming.completed
        val accessed=(current.accessed.keys+incoming.accessed.keys).associateWith {
            maxOf(current.accessed[it] ?: 0L,incoming.accessed[it] ?: 0L)
        }
        val order=(incoming.itemOrder+current.itemOrder).distinct()
        withContext(Dispatchers.IO) {
            check(preferences.edit().putStringSet("favorites",favorites).putStringSet("completed",completed)
                .putString("accessed",JSONObject(accessed).toString()).putString("item_order",JSONArray(order).toString()).commit())
        }
        appearancePreferences.setAppearance(incoming.theme,incoming.dynamicColor)
        mutableState.update { it.copy(favorites=favorites,completed=completed,accessed=accessed,
            itemOrder=order,theme=incoming.theme,dynamicColor=incoming.dynamicColor) }
    }
}
```

## app/src/main/java/com/example/ui/CatalogScreen.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.components.*
import com.example.ui.home.SubjectTile
import com.example.ui.theme.isDarkMode
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState

private fun folderKey(subjectId: String, path: List<String>) = "folder/$subjectId/${path.joinToString("\u001f")}"

@Composable fun CatalogScreen(state: StudyState, destination: Destination, subject: Subject?, path: List<String>,
    motion: SharedMotion, onSelectSubject: (Subject) -> Unit, onFolder: (String) -> Unit,
    onOpen: (StudyItem) -> Unit, onFavorite: (String) -> Unit, onCompleted: (String) -> Unit,
    onRefresh: () -> Unit, onSaveOrder: (List<String>) -> Unit, onBack: () -> Unit = {}) {
    var query by rememberSaveable(destination, subject?.id) { mutableStateOf("") }
    var filter by rememberSaveable(destination, subject?.id) { mutableStateOf("all") }
    var typeName by rememberSaveable(destination, subject?.id) { mutableStateOf("") }
    val type = destination.type ?: typeName.takeIf { it.isNotBlank() }?.let(ContentType::valueOf)
    val base = remember(state.items, destination, subject, type) { state.items.filter {
        (subject == null || it.subjectId == subject.id) && (type == null || it.type == type)
    } }
    val filtered = remember(base, state.favorites, state.completed, filter, query) { base.filter {
        it.matches(query) && when (filter) {
            "favorites" -> it.id in state.favorites
            "completed" -> it.id in state.completed
            "pending" -> it.id !in state.completed
            else -> true
        }
    } }
    val browsing = query.isBlank() && filter == "all"
    val showSubjects = browsing && subject == null
    val scoped = if (subject != null && browsing) itemsInPath(filtered, path) else filtered
    val folders = if (subject != null && browsing)
        scoped.mapNotNull { it.folderPath.getOrNull(path.size) }.distinct() else emptyList()
    val leaves = if (subject != null && browsing) scoped.filter { it.folderPath.size == path.size } else scoped
    val availableIds = leaves.map { it.id }
    var orderedIds by remember(destination, subject?.id, path, query, filter, typeName) {
        mutableStateOf(reconcileOrder(availableIds, state.itemOrder))
    }
    LaunchedEffect(availableIds, state.itemOrder) { orderedIds = reconcileOrder(availableIds, state.itemOrder) }
    val byId = remember(leaves) { leaves.associateBy { it.id } }
    val orderedRows = orderedIds.mapNotNull(byId::get)
    val listState = rememberLazyListState()
    LaunchedEffect(path, query, filter, subject?.id, destination, typeName) { listState.scrollToItem(0) }
    val reorderState = rememberReorderableLazyListState(listState) { from, to ->
        orderedIds = moveId(orderedIds, from.key as? String ?: "", to.key as? String ?: "")
    }
    fun moveAccessible(id: String, direction: Int): Boolean {
        val index = orderedIds.indexOf(id)
        val target = orderedIds.getOrNull(index + direction) ?: return false
        orderedIds = moveId(orderedIds, id, target)
        onSaveOrder(orderedIds)
        return true
    }
    ExpressiveRefreshBox(state.loading, onRefresh, Modifier.fillMaxSize()) {
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize().testTag("catalog_list"), contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (subject != null) item(key = "back_to_folder") {
                TextButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (path.isEmpty()) "Matérias" else "Pasta anterior")
                }
            }
            item(key = "header") {
                CatalogHeader(state, subject, path, destination, scoped.size, motion)
            }
            item(key = "search") {
                OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("catalog_search"),
                    placeholder = { Text("Buscar aulas, arquivos e pastas") }, leadingIcon = { Icon(Icons.Outlined.Search, null) },
                    trailingIcon = { if (query.isNotBlank()) IconButton(onClick = { query = "" }) {
                        Icon(Icons.Filled.Close, "Limpar busca")
                    } }, shape = RoundedCornerShape(28.dp))
            }
            item(key = "filters") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("all" to "Todos", "favorites" to "Favoritos", "pending" to "Pendentes", "completed" to "Concluídos")) { (id, label) ->
                        FilterChip(selected = filter == id, onClick = { filter = id }, label = { Text(label) },
                            leadingIcon = { if (filter == id) Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) })
                    }
                }
            }
            if (subject != null && destination.type == null) item(key = "formats") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = typeName.isBlank(), onClick = { typeName = "" }, label = { Text("Todos os formatos") }) }
                    items(ContentType.entries) { t -> FilterChip(selected = typeName == t.name,
                        onClick = { typeName = t.name }, label = { Text(t.label) }) }
                }
            }
            if (showSubjects) {
                items(Subjects.all.filter { s -> base.any { it.subjectId == s.id } }.chunked(2),
                    key = { "subjects/${it.first().id}" }) { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { s -> SubjectTile(s, state.copy(items = base), motion, Modifier.weight(1f)) { onSelectSubject(s) } }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            } else {
                items(folders, key = { "folder_row/$it" }) { name ->
                    val count = scoped.count { it.folderPath.getOrNull(path.size) == name }
                    val sharedKey = folderKey(subject!!.id, path + name)
                    val tone = folderTone(subject.id, isDarkMode(state.theme))
                    val completed = scoped.count { it.folderPath.getOrNull(path.size) == name && it.id in state.completed }
                    FolderSurface(tone, Modifier.fillMaxWidth().then(motion.bounds("$sharedKey/container")), { onFolder(name) }) {
                        Column(Modifier.padding(18.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                Surface(shape = MaterialTheme.shapes.medium, color = tone.ink.copy(alpha = .08f)) {
                                    Icon(Icons.Outlined.Folder, null, motion.element("$sharedKey/art").padding(14.dp).size(28.dp), tint = tone.accent)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(name, style = MaterialTheme.typography.titleMedium, modifier = motion.bounds("$sharedKey/name"))
                                    Text("$count materiais", style = MaterialTheme.typography.bodySmall)
                                }
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                            }
                            Spacer(Modifier.height(12.dp))
                            LinearProgressIndicator(progress = { if(count==0) 0f else completed.toFloat()/count },
                                modifier = Modifier.fillMaxWidth(), color = tone.accent, trackColor = tone.ink.copy(alpha = .12f))
                        }
                    }
                }
                if (orderedRows.isNotEmpty()) item(key = "reorder_help") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Seus materiais", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        HelpTooltip("Organizar materiais", "Arraste a alça à direita para reordenar. " +
                            "Toque na seta para expandir os detalhes. A ordem fica salva neste aparelho.")
                    }
                }
                items(orderedRows, key = { it.id }) { item ->
                    ReorderableItem(reorderState, key = item.id) { dragging ->
                        val elevation by animateDpAsState(if (dragging) 8.dp else 0.dp, label = "drag_elevation")
                        MaterialRow(item, state, onOpen, onFavorite, onCompleted, elevation,
                            modifier = Modifier.semantics {
                                customActions = listOf(
                                    CustomAccessibilityAction("Mover para cima") { moveAccessible(item.id, -1) },
                                    CustomAccessibilityAction("Mover para baixo") { moveAccessible(item.id, 1) })
                            }, dragHandle = {
                                IconButton(onClick = {}, modifier = Modifier.draggableHandle(
                                    onDragStopped = { onSaveOrder(orderedIds) })) {
                                    Icon(Icons.Outlined.DragHandle, "Arrastar para reordenar")
                                }
                            })
                    }
                }
            }
            if (scoped.isEmpty()) item(key = "empty") {
                Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.SearchOff, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
                    Text("Nenhum material encontrado", style = MaterialTheme.typography.titleMedium)
                    Text("Tente outro termo ou ajuste os filtros.")
                }
            }
        }
    }
}

@Composable private fun CatalogHeader(state: StudyState, subject: Subject?, path: List<String>,
    destination: Destination, count: Int, motion: SharedMotion) {
    val sharedKey = when {
        subject == null -> null
        path.isEmpty() -> "subject/${subject.id}"
        else -> folderKey(subject.id, path)
    }
    val tone = folderTone(subject?.id ?: destination.name, isDarkMode(state.theme))
    FolderSurface(tone, Modifier.fillMaxWidth().then(if (sharedKey != null) motion.bounds("$sharedKey/container") else Modifier)) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (subject != null) {
                if (path.isEmpty()) SubjectArtwork(subject.id, tone.accent,
                    motion.element("$sharedKey/art").size(96.dp))
                else Icon(Icons.Outlined.Folder, null, motion.element("$sharedKey/art").size(44.dp))
            }
            Text(path.lastOrNull() ?: subject?.name ?: destination.title,
                style = MaterialTheme.typography.headlineLarge,
                modifier = if (sharedKey != null) motion.bounds("$sharedKey/name") else Modifier)
            Text(if (path.isNotEmpty()) path.joinToString(" › ") else subject?.subtitle ?: when (destination) {
                Destination.PDFS -> "Artigos e materiais para sua leitura"
                Destination.AUDIO -> "Sua biblioteca de áudios"
                Destination.VIDEOS -> "Suas aulas, organizadas por matéria"
                else -> "Escolha uma matéria para começar"
            }, style = MaterialTheme.typography.bodyMedium)
            Text("$count materiais", style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable private fun MaterialRow(item: StudyItem, state: StudyState, onOpen: (StudyItem) -> Unit,
    onFavorite: (String) -> Unit, onCompleted: (String) -> Unit, elevation: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier, dragHandle: @Composable () -> Unit) {
    var expanded by rememberSaveable(item.id) { mutableStateOf(false) }
    val complete = item.id in state.completed
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow,
        shadowElevation = elevation, modifier = modifier.fillMaxWidth().animateContentSize()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(contentIcon(item.type), null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, style = MaterialTheme.typography.titleMedium)
                    Text(if (complete) "Concluído" else "${Subjects.get(item.subjectId).name} · ${item.type.label}",
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
                dragHandle()
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(onClick = { onOpen(item) }) {
                    Icon(if (item.linkKind == LinkKind.FOLDER) Icons.Outlined.FolderOpen else contentIcon(item.type), null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (item.linkKind == LinkKind.FOLDER) "Abrir pasta" else when (item.type) {
                        ContentType.VIDEO -> "Assistir"; ContentType.PDF -> "Ler PDF"; ContentType.AUDIO -> "Ouvir"
                    })
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { onFavorite(item.id) }) {
                    Icon(if (item.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        if (item.id in state.favorites) "Remover dos favoritos" else "Favoritar")
                }
                IconButton(onClick = { expanded = !expanded }, modifier = Modifier.testTag("expand_${item.id}")) {
                    Icon(if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                        if (expanded) "Recolher detalhes" else "Expandir detalhes")
                }
            }
            AnimatedVisibility(expanded, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 8.dp)) {
                    HorizontalDivider()
                    Text(item.filename, style = MaterialTheme.typography.bodySmall)
                    if (item.note.isNotBlank()) Text(item.note, style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(if (complete) "Material concluído" else "Marcar como concluído", style = MaterialTheme.typography.bodyMedium)
                        IconToggleButton(checked = complete, onCheckedChange = { onCompleted(item.id) }) {
                            Icon(if (complete) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircle,
                                if (complete) "Marcar como pendente" else "Marcar como concluído")
                        }
                    }
                }
            }
        }
    }
}

internal fun contentIcon(type: ContentType): ImageVector = when (type) {
    ContentType.VIDEO -> Icons.Outlined.PlayCircleOutline
    ContentType.PDF -> Icons.Outlined.Description
    ContentType.AUDIO -> Icons.Outlined.Headphones
}
```

## app/src/main/java/com/example/ui/DriveConfigDialog.kt

```kotlin
package com.example.ui

import android.accounts.Account
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Cloud
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.google.android.gms.common.api.ApiException
import androidx.compose.ui.unit.dp
import com.example.data.drive.*
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope

private fun authorizationFailure(error: Throwable): String {
    val code = (error as? ApiException)?.statusCode
    return when (code) {
        8 -> "O Google retornou erro interno (código 8). Tente novamente com conexão ativa. Esse código sozinho não identifica falha de cadastro OAuth."
        10 -> "Google recusou o cadastro do app (código 10). No Google Cloud, cadastre um cliente OAuth Android com o pacote e SHA-1 exibidos abaixo. Uma chave de API sozinha não permite conectar a conta."
        7 -> "Sem conexão com o Google (código 7). Confira a internet e tente novamente."
        16 -> "O Google devolveu cancelamento (código 16). Se você confirmou a conta, confira o cliente OAuth Android e os usuários de teste da tela de consentimento."
        else -> "Não foi possível autorizar a conta. Código Google: ${code ?: "indisponível"}. Confira o cliente OAuth Android, o SHA-1 e a tela de consentimento no Google Cloud."
    }
}

@Composable fun DriveConfigDialog(accountEmail: String? = null, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val settings = remember { DriveSettings(context) }
    var key by remember { mutableStateOf(settings.apiKey()) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    fun authorized(result: AuthorizationResult) {
        busy = false
        val token = result.accessToken.orEmpty()
        if (token.isBlank()) message = "A leitura dos arquivos não foi autorizada."
        else { DriveSession.accessToken = token; DriveSession.revision++; onDismiss() }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        runCatching { Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(result.data) }
            .onSuccess(::authorized).onFailure { busy = false; message = authorizationFailure(it) }
    }
    val fingerprint = remember { installedCertificate(context).chunked(2).joinToString(":") }
    AlertDialog(onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Cloud, null) },
        title = { Text("Conectar ao Google Drive") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Cole sua chave para abrir arquivos públicos diretamente no Kepleræ.")
                OutlinedTextField(value = key, onValueChange = { key = it; message = null },
                    label = { Text("Chave de API do Drive") }, singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Ocultar" else "Mostrar") } },
                    modifier = Modifier.fillMaxWidth())
                Text("A chave fica protegida neste dispositivo e não é incluída no projeto do GitHub.",
                    style = MaterialTheme.typography.bodySmall)
                HorizontalDivider()
                Text("Arquivos privados", style = MaterialTheme.typography.titleSmall)
                Text("Autorize a leitura pela conta Google que tem acesso aos materiais. Isso não permite alterar nem excluir seus arquivos.")
                OutlinedButton(enabled = !busy, onClick = {
                    busy = true; message = null
                    val request = AuthorizationRequest.builder()
                        .apply { accountEmail?.let { setAccount(Account(it, "com.google")) } }
                        .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.readonly"))).build()
                    Identity.getAuthorizationClient(context).authorize(request)
                        .addOnSuccessListener { result ->
                            if (result.hasResolution()) {
                                val pending = result.pendingIntent
                                if (pending == null) { busy = false; message = "Não foi possível iniciar a autorização." }
                                else runCatching { launcher.launch(IntentSenderRequest.Builder(pending.intentSender).build()) }
                                    .onFailure { busy = false; message = authorizationFailure(it) }
                            } else authorized(result)
                        }
                        .addOnFailureListener {
                            busy = false
                            message = authorizationFailure(it)
                        }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Aguardando Google…" else "Autorizar conta Google") }
                if (DriveSession.accessToken.isNotBlank()) TextButton(onClick = { DriveSession.clear(); message = "Acesso ao Drive desconectado. A conta do perfil não foi alterada." }) {
                    Text("Desconectar Drive")
                }
                if (message != null) Text(message!!, color = MaterialTheme.colorScheme.error)
                Text("Cadastro da chave / OAuth", style = MaterialTheme.typography.titleSmall)
                SelectionContainer { Column {
                    Text("Pacote: ${context.packageName}", style = MaterialTheme.typography.bodySmall)
                    Text("SHA-1: $fingerprint", style = MaterialTheme.typography.bodySmall)
                } }
                Text("Se sua chave tem restrição Android, use esses dados. A autorização de arquivos privados também exige um cliente OAuth Android com esse pacote e SHA-1.",
                    style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = {
            val cleaned = key.filterNot { it.isWhitespace() || Character.getType(it) == Character.FORMAT.toInt() }
                .trim('"', '\'')
            if (cleaned.isNotEmpty() && (cleaned.length < 20 || cleaned.any { !it.isLetterOrDigit() && it != '_' && it != '-' })) {
                message = "Cole apenas o valor da chave, sem endereço, JSON ou texto adicional. Use Mostrar para conferir."
            } else runCatching { settings.saveApiKey(cleaned) }
                .onSuccess { onDismiss() }.onFailure { message = "Não foi possível salvar a chave neste aparelho." }
        }) { Text("Salvar chave") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } })
}
```

## app/src/main/java/com/example/ui/DriveViewer.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.data.pdf.PdfCache
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.drive.*
import com.example.data.model.*
import com.example.data.repository.StudyState
import com.example.data.repository.reconcileOrder
import com.example.ui.components.ExpressiveRefreshBox
import com.example.ui.components.LoadingPane
import com.example.ui.components.FolderSurface
import com.example.ui.components.folderTone
import androidx.compose.ui.graphics.luminance
import kotlinx.coroutines.CancellationException
import java.io.File

private data class MaterialLoad(val loading: Boolean = true, val file: DriveFile? = null,
    val pdf: File? = null, val pdfKey: String = "", val progress: Float? = null, val error: String? = null)
private data class FolderLoad(val loading: Boolean = true, val files: List<DriveFile> = emptyList(),
    val error: String? = null)

@Composable fun DriveViewer(item: StudyItem, state: StudyState, onDismiss: () -> Unit,
    onFavorite: (String) -> Unit, onCompleted: (String) -> Unit, onAccess: (String) -> Unit,
    accountEmail: String? = null, onFullscreenChanged: (Boolean) -> Unit = {}) {
    val context = LocalContext.current
    val view = LocalView.current
    val revision = DriveSession.revision
    val token = DriveSession.accessToken
    val credentials = remember(revision, token) { DriveSettings(context).credentials() }
    val repository = remember(credentials) { DriveRepository(context, credentials) }
    var configure by remember { mutableStateOf(false) }
    var fullscreen by remember(item.id) { mutableStateOf(false) }
    LaunchedEffect(fullscreen) { onFullscreenChanged(fullscreen) }
    DisposableEffect(Unit) { onDispose { onFullscreenChanged(false) } }
    DisposableEffect(fullscreen, view) {
        val activity = view.context.findActivity()
        val controller = activity?.let { WindowCompat.getInsetsController(it.window, view) }
        if (fullscreen) {
            controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        } else controller?.show(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    var selected by remember(item.id) { mutableStateOf(if (item.linkKind == LinkKind.FILE) item else null) }
    val initialFolder = remember(item.id) {
        DriveFile(DriveRequests.folderId(item.url), item.title, "application/vnd.google-apps.folder", DriveRequests.resourceKey(item.url))
    }
    var folders by remember(item.id) { mutableStateOf(listOf(initialFolder)) }
    var folderTracks by remember(item.id) { mutableStateOf<List<StudyItem>>(emptyList()) }
    var autoPlay by remember(item.id) { mutableStateOf(false) }
    val order = reconcileOrder(state.items.map { it.id }, state.itemOrder)
    val catalogAudio = remember(state.items, order) {
        val byId = state.items.associateBy { it.id }
        order.mapNotNull(byId::get).filter { it.type == ContentType.AUDIO && it.linkKind == LinkKind.FILE }
    }
    val active = selected ?: item
    fun back() {
        when {
            fullscreen -> fullscreen = false
            selected != null && item.linkKind == LinkKind.FOLDER -> selected = null
            selected == null && folders.size > 1 -> folders = folders.dropLast(1)
            else -> onDismiss()
        }
    }
    BackHandler { back() }
    key(item.id) {
        Surface(Modifier.fillMaxSize()) {
            Scaffold(
                contentWindowInsets = if (fullscreen) WindowInsets(0) else ScaffoldDefaults.contentWindowInsets,
                topBar = {
                    if (!fullscreen) TopAppBar(
                        title = { Text(if (selected != null) active.title else folders.last().name,
                            maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        navigationIcon = { IconButton(onClick = ::back) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar")
                        } },
                        actions = {
                            IconButton(onClick = { configure = true }) { Icon(Icons.Outlined.Settings, "Configurar Drive") }
                            if (selected != null) {
                                IconButton(onClick = { onFavorite(active.id) }) {
                                    Icon(if (active.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favoritar")
                                }
                                IconButton(onClick = { fullscreen = true }) { Icon(Icons.Outlined.Fullscreen, "Tela cheia") }
                            }
                        })
                },
                bottomBar = {
                    if (!fullscreen && selected != null) Surface(color = MaterialTheme.colorScheme.surfaceContainer) {
                        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (active.note.isNotBlank()) Text(active.note, style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(active.type.label, style = MaterialTheme.typography.labelLarge)
                                    Text("Seu progresso fica salvo no Kepleræ.", style = MaterialTheme.typography.bodySmall)
                                }
                                Button(onClick = { onCompleted(active.id) }) {
                                    Text(if (active.id in state.completed) "Concluído ✓" else "Concluir")
                                }
                            }
                        }
                    }
                }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when {
                        selected != null -> MaterialContent(active, repository, Modifier.fillMaxSize(),
                            onConfigure = { configure = true },
                            playlist = if (folderTracks.isNotEmpty()) folderTracks else catalogAudio, autoPlay = autoPlay,
                            onSelectTrack = { track -> selected = track; autoPlay = true; onAccess(track.id) })
                        !credentials.configured -> ViewerMessage("Conecte seu Google Drive",
                            "Adicione sua chave de API para materiais públicos ou autorize a conta Google para arquivos privados.",
                            onConfigure = { configure = true })
                        else -> FolderContent(folders.last(), item, repository,
                            onFolder = { folders = folders + it },
                            onFile = { file, files ->
                                folderTracks = files.filter { it.contentType == ContentType.AUDIO && !it.folder }.map { it.studyItem(item) }
                                selected = file.studyItem(item); autoPlay = false; onAccess(selected!!.id)
                            },
                            onConfigure = { configure = true })
                    }
                    if (fullscreen) FilledIconButton(onClick = { fullscreen = false },
                        modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(12.dp)) {
                        Icon(Icons.Outlined.FullscreenExit, "Sair da tela cheia")
                    }
                }
            }
        }
    }
    if (configure) DriveConfigDialog(accountEmail = accountEmail, onDismiss = { configure = false })
}

@Composable private fun MaterialContent(item: StudyItem, repository: DriveRepository,
    modifier: Modifier, onConfigure: () -> Unit, playlist: List<StudyItem>, autoPlay: Boolean,
    onSelectTrack: (StudyItem) -> Unit) {
    val context = LocalContext.current
    val cache = remember(item.id) { PdfCache(context) }
    var retry by remember(item.id) { mutableIntStateOf(0) }
    val loaded by produceState(MaterialLoad(), item.id, repository, retry) {
        value = MaterialLoad()
        try {
            val cached = cache.find(item.driveFileId)
            if (cached != null) value = MaterialLoad(loading = false, file = cached.metadata,
                pdf = cached.file, pdfKey = cached.key)
            else {
                val file = repository.metadata(item.driveFileId, DriveRequests.resourceKey(item.url))
                require(file.canDownload) { "O proprietário bloqueou a leitura do conteúdo pela API." }
                require(file.contentType != null) { "Este formato não é suportado pelo visualizador interno." }
                if (file.contentType == ContentType.PDF) {
                    val pdf = cache.download(item.driveFileId, file, repository) { received, size ->
                        value = MaterialLoad(file = file, progress = if (size > 0) (received.toFloat() / size).coerceIn(0f, 1f) else null)
                    }
                    value = MaterialLoad(loading = false, file = file, pdf = pdf.file, pdfKey = pdf.key)
                } else value = MaterialLoad(loading = false, file = file)
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { value = MaterialLoad(loading = false, error = e.message ?: "Não foi possível carregar o material.") }
    }
    when {
        loaded.loading -> LoadingPane(
            if (loaded.file?.contentType == ContentType.PDF) "Preparando PDF…" else "Carregando material…",
            modifier, loaded.progress)
        loaded.error != null -> ViewerMessage("Não foi possível carregar", loaded.error!!,
            onRetry = { retry++ }, onConfigure = onConfigure)
        loaded.pdf != null -> NativePdf(loaded.pdf!!, modifier, documentKey = loaded.pdfKey)
        loaded.file != null -> NativeMedia(item.copy(type = loaded.file!!.contentType!!), loaded.file!!, repository, modifier, onConfigure,
            playlist = playlist, autoPlay = autoPlay, onSelectTrack = onSelectTrack)
    }
}

@Composable private fun FolderContent(folder: DriveFile, item: StudyItem, repository: DriveRepository,
    onFolder: (DriveFile) -> Unit, onFile: (DriveFile, List<DriveFile>) -> Unit, onConfigure: () -> Unit) {
    var query by remember(folder.id) { mutableStateOf("") }
    var retry by remember(folder.id) { mutableIntStateOf(0) }
    val loaded by produceState(FolderLoad(), folder.id, repository, retry) {
        value = FolderLoad(files = value.files)
        try { value = FolderLoad(false, repository.folder(folder.id, folder.resourceKey)) }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { value = FolderLoad(false, error = e.message ?: "Não foi possível ler a pasta.") }
    }
    if (loaded.loading && loaded.files.isEmpty()) LoadingPane("Carregando pasta…")
    else if (loaded.error != null) ViewerMessage("Não foi possível abrir a pasta", loaded.error!!,
        onRetry = { retry++ }, onConfigure = onConfigure)
    else ExpressiveRefreshBox(loaded.loading, { retry++ }, Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Localize: ${item.filename}", style = MaterialTheme.typography.bodyMedium)
        OutlinedTextField(query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, label = { Text("Buscar nesta pasta") })
        val files = loaded.files.filter { searchable(it.name).contains(searchable(query)) }
        if (files.isEmpty()) Text("Nenhum arquivo encontrado nesta pasta.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(files, key = { it.id }) { file ->
                val supported = file.folder || file.contentType != null
                val body: @Composable () -> Unit = {
                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(when {
                            file.folder -> Icons.Outlined.Folder
                            file.contentType == ContentType.AUDIO -> Icons.Outlined.Headphones
                            file.contentType == ContentType.PDF -> Icons.Outlined.Description
                            else -> Icons.Outlined.PlayCircleOutline
                        }, null, tint = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f)) {
                            Text(file.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(if (file.folder) "Pasta" else file.contentType?.label ?: "Formato não suportado",
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                if (file.folder) FolderSurface(folderTone(item.subjectId, MaterialTheme.colorScheme.surface.luminance() < .35f),
                    Modifier.fillMaxWidth(), { onFolder(file) }) { body() }
                else Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.fillMaxWidth().clickable(enabled = supported) { onFile(file, loaded.files) }, content = body)
            }
        }
    }
    }
}

@Composable private fun ViewerMessage(title: String, detail: String, onRetry: (() -> Unit)? = null,
    onConfigure: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Outlined.CloudOff, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp)); Text(detail)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (onRetry != null) Button(onClick = onRetry) { Text("Tentar novamente") }
            OutlinedButton(onClick = onConfigure) { Text("Configurar Drive") }
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
```

## app/src/main/java/com/example/ui/KepleraeApp.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui

import android.os.Build

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.LibraryBooks
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.example.data.auth.GoogleUser
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.components.SidebarNavigation
import com.example.ui.backup.BackupControls
import com.example.ui.components.LoadingPane
import com.example.ui.components.SharedMotion
import com.example.ui.home.HomeScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.productivity.PomodoroScreen
import com.example.ui.productivity.QuestionsScreen
import com.example.ui.notes.NotesScreen

enum class Destination(val title: String, val icon: ImageVector, val type: ContentType?) {
    HOME("Início", Icons.Outlined.Home, null),
    VIDEOS("Aulas", Icons.Outlined.PlayCircleOutline, ContentType.VIDEO),
    PDFS("PDFs", Icons.AutoMirrored.Filled.LibraryBooks, ContentType.PDF),
    AUDIO("Áudios", Icons.Outlined.Headphones, ContentType.AUDIO),
    SUBJECTS("Matérias", Icons.Outlined.GridView, null),
    POMODORO("Pomodoro", Icons.Outlined.Timer, null),
    QUESTIONS("Questões", Icons.Outlined.Quiz, null),
    NOTES("Notas", Icons.Outlined.EditNote, null),
}

private data class AppRoute(val destination: Destination, val subjectId: String?,
    val path: List<String>, val profile: Boolean, val viewerId: String?)

@Composable fun KepleraeApp(state: StudyState, model: StudyViewModel,
    user: GoogleUser? = null, onSignOut: () -> Unit = {}, openPomodoro: Boolean = false) {
    var destinationName by rememberSaveable { mutableStateOf(if(openPomodoro) Destination.POMODORO.name else Destination.HOME.name) }
    var subjectId by rememberSaveable { mutableStateOf<String?>(null) }
    var pathKey by rememberSaveable { mutableStateOf("") }
    var settings by rememberSaveable { mutableStateOf(false) }
    var configureDrive by remember { mutableStateOf(false) }
    var profile by rememberSaveable { mutableStateOf(false) }
    var activeId by rememberSaveable { mutableStateOf<String?>(null) }
    var viewerFullscreen by remember { mutableStateOf(false) }
    val destination = Destination.valueOf(destinationName)
    val subject = subjectId?.let(Subjects::get)
    val path = if (pathKey.isBlank()) emptyList() else pathKey.split('\u001f')
    val activeItem = state.items.firstOrNull { it.id == activeId }
    fun navigate(next: Destination) {
        destinationName = next.name; subjectId = null; pathKey = ""; profile = false
        activeId = null; viewerFullscreen = false
    }
    fun select(next: Subject) { subjectId = next.id; pathKey = "" }
    fun open(item: StudyItem) { model.recordAccess(item.id); activeId = item.id }
    fun back() {
        when {
            profile -> profile = false
            path.isNotEmpty() -> pathKey = path.dropLast(1).joinToString("\u001f")
            subjectId != null -> subjectId = null
            destination != Destination.HOME -> navigate(Destination.HOME)
        }
    }
    BackHandler(enabled = (profile || subject != null || destination != Destination.HOME)
        && (activeItem == null || profile) && !settings && !configureDrive) { back() }

    BackHandler(enabled = settings) { settings = false }

    SharedTransitionLayout {
        val shared = this
        BoxWithConstraints(Modifier.fillMaxSize()) {
            // A faixa lateral acompanha todas as seções, inclusive o visualizador.
            // Tela cheia suspende a navegação e os espaços das barras do sistema.
            Scaffold(contentWindowInsets = if (viewerFullscreen && !profile) WindowInsets(0)
                else ScaffoldDefaults.contentWindowInsets) { padding ->
                Row(Modifier.fillMaxSize().padding(padding).consumeWindowInsets(padding)) {
                    if (!viewerFullscreen || profile) SidebarNavigation(destination, profile, user,
                        onNavigate = ::navigate, onProfile = { profile = true })
                    Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
                        AnimatedContent(targetState = AppRoute(destination, subjectId, path, profile, activeId),
                            modifier = Modifier.widthIn(max = 1120.dp).fillMaxSize(),
                            transitionSpec = {
                                if (initialState.destination != targetState.destination)
                                    fadeIn(tween(120)) togetherWith fadeOut(tween(80))
                                else fadeIn(tween(220)) togetherWith fadeOut(tween(180))
                            },
                            label = "shared_destinations") { route ->
                            val motion = SharedMotion(shared, this, route.destination.name)
                            val viewer = state.items.firstOrNull { it.id == route.viewerId }
                            when {
                                route.profile -> ProfileScreen(user, state, motion,
                                    onTheme = model::setTheme, onDynamicColor = model::setDynamicColor,
                                    onConfigureDrive = { configureDrive = true }, onSignOut = onSignOut,
                                    onBack = ::back, onAppearance = { settings = true },
                                    backupContent = { BackupControls(model) })
                                viewer != null -> DriveViewer(viewer, state,
                                    onDismiss = { activeId = null; viewerFullscreen = false },
                                    onFavorite = model::toggleFavorite, onCompleted = model::toggleCompleted,
                                    onAccess = model::recordAccess, accountEmail = user?.email,
                                    onFullscreenChanged = { viewerFullscreen = it })
                                route.destination == Destination.POMODORO -> PomodoroScreen()
                                route.destination == Destination.QUESTIONS -> QuestionsScreen()
                                route.destination == Destination.NOTES -> NotesScreen()
                                state.loading && state.items.isEmpty() -> LoadingPane("Preparando sua biblioteca…")
                                state.error != null -> Column(Modifier.fillMaxSize().padding(24.dp),
                                    verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Outlined.CloudOff, null, Modifier.size(48.dp))
                                    Text(state.error)
                                    Button(onClick = model::reload) { Text("Tentar novamente") }
                                }
                                route.subjectId == null && route.destination == Destination.HOME ->
                                    HomeScreen(state, user, motion, ::navigate, ::select, ::open,
                                        onProfile = { profile = true }, onRefresh = model::reload)
                                else -> CatalogScreen(state, route.destination, route.subjectId?.let(Subjects::get),
                                    route.path, motion, ::select,
                                    onFolder = { pathKey = (route.path + it).joinToString("\u001f") },
                                    onOpen = ::open, onFavorite = model::toggleFavorite,
                                    onCompleted = model::toggleCompleted, onRefresh = model::reload,
                                    onSaveOrder = model::saveVisibleOrder, onBack = ::back)
                            }
                        }
                    }
                }
            }
        }
    }
    if (settings) AppearanceSheet(state, model, onDismiss = { settings = false },
        onConfigure = { settings = false; configureDrive = true })
    if (configureDrive) DriveConfigDialog(accountEmail = user?.email, onDismiss = { configureDrive = false })
}

/** Preserva o modo automático e o acesso às configurações anteriores. */
@Composable private fun AppearanceSheet(state: StudyState, model: StudyViewModel,
    onDismiss: () -> Unit, onConfigure: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, modifier = Modifier.testTag("appearance_sheet")) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Do seu jeito", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss, modifier = Modifier.testTag("appearance_close")) {
                    Icon(Icons.Outlined.Close, "Fechar preferências")
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(selected = mode == state.theme, onClick = { model.setTheme(mode) },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("theme_${mode.name}"),
                        label = { Text(mode.label) })
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Cores do seu Android", style = MaterialTheme.typography.titleMedium)
                    Text(if (Build.VERSION.SDK_INT >= 31) "Use as cores do seu papel de parede."
                        else "Disponível no Android 12 ou superior.", style = MaterialTheme.typography.bodySmall)
                }
                Switch(state.dynamicColor, model::setDynamicColor, enabled = Build.VERSION.SDK_INT >= 31)
            }
            OutlinedButton(onClick = onConfigure, modifier = Modifier.fillMaxWidth()) { Text("Configurar Google Drive") }
            Text("Kepleræ 1.0.1", style = MaterialTheme.typography.titleMedium)
            Text("${state.items.size} materiais. Seu progresso é salvo neste aparelho.")
        }
    }
}
```

## app/src/main/java/com/example/ui/NativeMedia.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui

import android.view.ViewGroup
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.data.playback.PlaybackService
import com.example.ui.components.LoadingPane
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.*
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.example.data.drive.*
import com.example.data.model.ContentType
import com.example.data.model.StudyItem
import com.example.ui.components.HelpTooltip
import kotlinx.coroutines.delay

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable fun NativeMedia(item: StudyItem, file: DriveFile, repository: DriveRepository,
    modifier: Modifier = Modifier, onConfigure: () -> Unit,
    playlist: List<StudyItem> = emptyList(), autoPlay: Boolean = false,
    onSelectTrack: (StudyItem) -> Unit = {}) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val preferences = remember { context.getSharedPreferences("keplerae_playback", 0) }
    var failure by remember(file.id, repository) { mutableStateOf<String?>(null) }
    var buffering by remember(file.id, repository) { mutableStateOf(true) }
    var playing by remember(file.id, repository) { mutableStateOf(false) }
    var position by remember(file.id) { mutableLongStateOf(0L) }
    var duration by remember(file.id) { mutableLongStateOf(0L) }
    var speed by remember(file.id) { mutableFloatStateOf(1f) }
    val audio = item.type == ContentType.AUDIO
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var connectionError by remember { mutableStateOf<String?>(null) }
    DisposableEffect(audio) {
        if (audio) {
            val future = MediaController.Builder(context,
                SessionToken(context, ComponentName(context, PlaybackService::class.java))).buildAsync()
            var disposed = false
            future.addListener({
                if (!disposed) runCatching { future.get() }.onSuccess { controller = it }
                    .onFailure { connectionError = "Não foi possível conectar ao serviço de áudio. Abra novamente o material." }
            }, ContextCompat.getMainExecutor(context))
            onDispose { disposed = true; controller = null; MediaController.releaseFuture(future) }
        } else onDispose { }
    }
    val videoPlayer = remember(file.id, repository, audio) {
        if (audio) null else {
            val dataSource = DefaultHttpDataSource.Factory().setConnectTimeoutMs(15000).setReadTimeoutMs(30000)
                .setDefaultRequestProperties(repository.headers(file.id, file.resourceKey))
            ExoPlayer.Builder(context).setMediaSourceFactory(DefaultMediaSourceFactory(dataSource))
                .setSeekBackIncrementMs(10000).setSeekForwardIncrementMs(10000).build().apply {
                    setAudioAttributes(AudioAttributes.DEFAULT, true); setHandleAudioBecomingNoisy(true)
                    setMediaItem(MediaItem.Builder().setMediaId(file.id).setUri(DriveRequests.file(file.id, true))
                        .setMimeType(file.mimeType).setMediaMetadata(MediaMetadata.Builder().setTitle(item.title).build()).build())
                    seekTo(preferences.getLong(file.id, 0).coerceAtLeast(0)); playWhenReady = autoPlay
                }
        }
    }
    val player: Player? = if (audio) controller else videoPlayer
    val tracks = remember(playlist, item, file) {
        val current = item.copy(driveFileId = file.id)
        (playlist.map { if (it.id == item.id) current else it } + current)
            .filter { it.driveFileId.isNotBlank() }.distinctBy { it.driveFileId }
    }
    val trackCallback by rememberUpdatedState(onSelectTrack)
    val activeMediaId by rememberUpdatedState(file.id)
    LaunchedEffect(controller, audio, file.id, tracks) {
        val c = controller ?: return@LaunchedEffect
        if (!audio) return@LaunchedEffect
        val existing = c.currentMediaItem?.mediaId == file.id
        val expectedIds = tracks.map { it.driveFileId }
        val actualIds = (0 until c.mediaItemCount).map { c.getMediaItemAt(it).mediaId }
        if (!existing || actualIds != expectedIds) {
            val resumeAt = if (existing) c.currentPosition else preferences.getLong(file.id, 0).coerceAtLeast(0)
            val resumePlaying = if (existing) c.playWhenReady else autoPlay
            val selectedIndex = tracks.indexOfFirst { it.driveFileId == file.id }.coerceAtLeast(0)
            val queue = tracks.map { track ->
                val resourceKey = if (track.driveFileId == file.id) file.resourceKey else DriveRequests.resourceKey(track.url)
                MediaItem.Builder().setMediaId(track.driveFileId).setUri(DriveRequests.file(track.driveFileId, true))
                    .setCustomCacheKey("${track.driveFileId}|$resourceKey")
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(track.title).setArtist("Kepleræ • ${track.subjectId}").build()).build()
            }
            c.setMediaItems(queue, selectedIndex, resumeAt)
            c.prepare(); c.playWhenReady = resumePlaying
        }
        speed = c.playbackParameters.speed
    }
    DisposableEffect(player, lifecycle, audio, file.id, repository) {
        val connected = player
        if (connected == null) onDispose { }
        else {
            val listener = object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
                override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    if (audio && mediaItem?.mediaId != activeMediaId) {
                        tracks.firstOrNull { it.driveFileId == mediaItem?.mediaId }?.let(trackCallback)
                    }
                }
                override fun onPlayerError(error: PlaybackException) {
                    buffering = false
                    val http = generateSequence<Throwable>(error) { it.cause }
                        .filterIsInstance<HttpDataSource.InvalidResponseCodeException>().firstOrNull()
                    failure = if (http != null) DriveRequests.errorMessage(http.responseCode,
                        DriveRequests.errorReason(String(http.responseBody, Charsets.UTF_8)))
                    else when (error.errorCode) {
                        PlaybackException.ERROR_CODE_DECODING_FAILED, PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ->
                            "Este aparelho não conseguiu decodificar o formato do arquivo."
                        else -> "Não foi possível reproduzir. Confira a conexão e as permissões no Drive."
                    }
                }
            }
            fun savePosition() {
                val id = connected.currentMediaItem?.mediaId?.takeIf { it.isNotBlank() } ?: file.id
                preferences.edit().putLong(id,
                    if (connected.playbackState == Player.STATE_ENDED) 0 else connected.currentPosition.coerceAtLeast(0)).apply()
            }
            val observer = LifecycleEventObserver { _, event ->
                if (!audio && event == Lifecycle.Event.ON_STOP) { connected.pause(); savePosition() }
            }
            connected.addListener(listener)
            playing = connected.isPlaying; buffering = connected.playbackState == Player.STATE_BUFFERING
            connected.playerError?.let(listener::onPlayerError)
            lifecycle.addObserver(observer)
            if (!audio) connected.prepare()
            onDispose {
                savePosition(); lifecycle.removeObserver(observer); connected.removeListener(listener)
                if (!audio) connected.release()
            }
        }
    }
    if (player == null) {
        if (connectionError == null) LoadingPane("Conectando ao áudio…", modifier)
        else Text(connectionError!!, modifier.padding(24.dp), color = MaterialTheme.colorScheme.error)
        return
    }
    // Valores vêm do ExoPlayer. Não há timer simulando porcentagens de reprodução.
    LaunchedEffect(player) {
        var lastSaved = 0L
        while (true) {
            position = player.currentPosition.coerceAtLeast(0)
            duration = player.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L
            if (!audio && player.isPlaying && kotlin.math.abs(position - lastSaved) >= 5000L) {
                preferences.edit().putLong(file.id, position).apply(); lastSaved = position
            }
            delay(250L)
        }
    }
    fun playPause() {
        if (player.isPlaying) player.pause() else {
            if (player.playbackState == Player.STATE_IDLE || player.playerError != null) player.prepare()
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.play()
        }
    }
    Column(modifier.fillMaxSize()) {
        if (item.type == ContentType.AUDIO) {
            AudioScreen(item, playlist, playing, buffering, position, duration,
                onPlayPause = ::playPause,
                onSeek = { player.seekTo(it); position = it }, onSelectTrack = { track ->
                    val index = (0 until player.mediaItemCount).firstOrNull { player.getMediaItemAt(it).mediaId == track.driveFileId }
                    if (index != null) { player.seekToDefaultPosition(index); player.play() } else onSelectTrack(track)
                },
                modifier = Modifier.fillMaxWidth().weight(1f))
        } else {
            Box(Modifier.fillMaxWidth().weight(1f).heightIn(min = 100.dp)
                .clip(MaterialTheme.shapes.extraLarge).background(Color.Black), contentAlignment = Alignment.Center) {
                AndroidView(factory = { ctx -> PlayerView(ctx).also { it.player = player }.apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    setEnableComposeSurfaceSyncWorkaround(true)
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                    setShowNextButton(false); setShowPreviousButton(false)
                    setShowFastForwardButton(true); setShowRewindButton(true)
                    controllerShowTimeoutMs = 5000; controllerAutoShow = true; showController()
                } }, update = { it.player = player }, modifier = Modifier.fillMaxSize())
                if (buffering) CircularWavyProgressIndicator(Modifier.size(48.dp), color = Color.White)
            }
            LinearWavyProgressIndicator(progress = { if (duration <= 0) 0f else (position.toFloat() / duration).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp))
        }
        LazyRow(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(vertical = 4.dp)) {
            items(listOf(.75f, 1f, 1.25f, 1.5f, 2f)) { rate ->
                FilterChip(selected = speed == rate, onClick = { speed = rate; player.setPlaybackSpeed(rate) },
                    label = { Text("${rate}×") })
            }
        }
        if (failure != null) {
            Text(failure!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp))
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { failure = null; buffering = true; player.prepare() }) { Text("Tentar novamente") }
                OutlinedButton(onClick = onConfigure) { Text("Configurar Drive") }
            }
        }
    }
}

@Composable private fun AudioScreen(item: StudyItem, playlist: List<StudyItem>, playing: Boolean,
    buffering: Boolean, position: Long, duration: Long, onPlayPause: () -> Unit,
    onSeek: (Long) -> Unit, onSelectTrack: (StudyItem) -> Unit, modifier: Modifier) {
    val tracks = remember(playlist, item) { (playlist + item).distinctBy { it.driveFileId.ifBlank { it.id } } }
    val current = tracks.indexOfFirst { it.driveFileId == item.driveFileId && it.driveFileId.isNotBlank() || it.id == item.id }
    var scrub by remember(item.id) { mutableStateOf<Float?>(null) }
    BoxWithConstraints(modifier) {
        val compact = maxHeight < 480.dp
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            item {
                Box(Modifier.size(if (compact) 88.dp else 148.dp).clip(MaterialTheme.shapes.extraLarge)
                    .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer,
                        MaterialTheme.colorScheme.tertiaryContainer))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.Headphones, null, Modifier.size(if (compact) 48.dp else 72.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            item {
                Text(item.title, style = MaterialTheme.typography.headlineSmall)
                Text("Sua escuta, no seu ritmo.", style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
            }
            item {
                Column(Modifier.fillMaxWidth()) {
                    val realProgress = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
                    LinearWavyProgressIndicator(progress = { scrub ?: realProgress }, modifier = Modifier.fillMaxWidth())
                    Slider(value = scrub ?: realProgress, onValueChange = { scrub = it },
                        enabled = duration > 0, onValueChangeFinished = {
                            scrub?.let { onSeek((duration * it).toLong()) }; scrub = null
                        }, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(mediaTime(if (scrub == null) position else (duration * scrub!!).toLong()), style = MaterialTheme.typography.labelMedium)
                        Text(mediaTime(duration), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    IconButton(onClick = { tracks.getOrNull(current - 1)?.let(onSelectTrack) }, enabled = current > 0) {
                        Icon(Icons.Filled.SkipPrevious, "Faixa anterior", Modifier.size(30.dp))
                    }
                    FilledIconButton(onClick = onPlayPause, modifier = Modifier.size(72.dp), shape = CircleShape) {
                        if (buffering) CircularWavyProgressIndicator(Modifier.size(32.dp),
                            color = MaterialTheme.colorScheme.onPrimary)
                        else Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            if (playing) "Pausar" else "Reproduzir", Modifier.size(36.dp))
                    }
                    IconButton(onClick = { tracks.getOrNull(current + 1)?.let(onSelectTrack) },
                        enabled = current >= 0 && current < tracks.lastIndex) {
                        Icon(Icons.Filled.SkipNext, "Próxima faixa", Modifier.size(30.dp))
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Lista de faixas", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    HelpTooltip("Sua reprodução", "A barra acompanha o áudio real. Arraste para avançar ou voltar. " +
                        "O áudio continua com a tela bloqueada. Controle também pela notificação, incluindo próxima e anterior.")
                }
            }
            items(tracks, key = { it.id }) { track ->
                val selected = track.driveFileId == item.driveFileId && track.driveFileId.isNotBlank() || track.id == item.id
                Surface(onClick = { if (!selected) onSelectTrack(track) else onPlayPause() },
                    modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large,
                    color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerLow) {
                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (selected && playing) Icons.Outlined.GraphicEq else Icons.Outlined.MusicNote, null)
                        Column(Modifier.weight(1f)) {
                            Text(track.title, style = MaterialTheme.typography.titleMedium)
                            if (selected) Text(if (playing) "Reproduzindo" else "Selecionada", style = MaterialTheme.typography.labelSmall)
                        }
                        Icon(if (selected && playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                    }
                }
            }
        }
    }
}

internal fun mediaTime(milliseconds: Long): String {
    val total = milliseconds.coerceAtLeast(0) / 1000
    return if (total >= 3600) "%d:%02d:%02d".format(java.util.Locale.ROOT, total / 3600, total / 60 % 60, total % 60)
    else "%d:%02d".format(java.util.Locale.ROOT, total / 60, total % 60)
}
```

## app/src/main/java/com/example/ui/NativePdf.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.pdf.*
import com.example.ui.components.HelpTooltip
import com.example.ui.components.LoadingPane
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.util.UUID
import kotlin.math.absoluteValue

private data class PdfDocument(val count: Int = 0, val error: String? = null)
private data class PdfBitmap(val bitmap: Bitmap? = null, val error: String? = null)
private val pdfRenderGate = Semaphore(1)
private enum class PdfTool { HAND, PEN, HIGHLIGHT, ERASER, NOTE }
private data class PendingPdfNote(val page: Int, val point: InkPoint, val existing: PdfNote? = null)

@Composable fun NativePdf(file: File, modifier: Modifier = Modifier, documentKey: String = file.nameWithoutExtension) {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("keplerae_pdf_reading", 0) }
    var savedPage by rememberSaveable(documentKey) { mutableIntStateOf(preferences.getInt(documentKey, 0)) }
    val annotations = remember(documentKey) { PdfAnnotationStore(context, documentKey) }
    val ink by annotations.state.collectAsStateWithLifecycle()
    val writeError by annotations.error.collectAsStateWithLifecycle()
    var inkReady by remember(documentKey) { mutableStateOf(false) }
    var tool by rememberSaveable(documentKey) { mutableStateOf(PdfTool.HAND) }
    var stylusOnly by remember { mutableStateOf(preferences.getBoolean("stylus_only", false)) }
    var straight by remember { mutableStateOf(preferences.getBoolean("straight_highlight", true)) }
    var inkColor by rememberSaveable { mutableLongStateOf(0xFF2457B8L) }
    var pendingNote by remember { mutableStateOf<PendingPdfNote?>(null) }
    var noteList by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    // Cada gesto é uma operação de desfazer, incluindo borracha e edição de nota.
    val history = remember(documentKey) { mutableStateMapOf<Int, List<PageAnnotations>>() }
    fun updatePage(index: Int, next: PageAnnotations) {
        val before = ink.pages[index] ?: PageAnnotations()
        if (before != next) {
            history[index] = (history[index].orEmpty() + before).takeLast(50)
            annotations.replace(index, next)
        }
    }
    LaunchedEffect(annotations) { annotations.load(); inkReady = true }
    DisposableEffect(annotations) { onDispose { annotations.close() } }
    val document by produceState(PdfDocument(), file.path) {
        value = withContext(Dispatchers.IO) {
            try {
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                    PdfRenderer(descriptor).use { renderer ->
                        check(renderer.pageCount > 0); PdfDocument(renderer.pageCount)
                    }
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { PdfDocument(error = "Não foi possível ler este PDF. Ele pode estar danificado ou protegido por senha.") }
        }
    }
    when {
        document.error != null -> Box(modifier, contentAlignment = Alignment.Center) {
            Text(document.error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(24.dp))
        }
        document.count == 0 || !inkReady -> LoadingPane("Preparando páginas…", modifier)
        else -> {
            val pager = rememberPagerState(initialPage = savedPage.coerceIn(0, document.count - 1), pageCount = { document.count })
            var zoomed by remember(documentKey) { mutableStateOf(false) }
            var resetZoom by remember(documentKey) { mutableIntStateOf(0) }
            val scope = rememberCoroutineScope()
            LaunchedEffect(pager) {
                snapshotFlow { pager.settledPage }.collect {
                    savedPage = it; preferences.edit().putInt(documentKey, it).apply(); zoomed = false
                }
            }
            Column(modifier.fillMaxSize()) {
                writeError?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }
                HorizontalPager(state = pager, userScrollEnabled = !zoomed && (tool == PdfTool.HAND || stylusOnly),
                    beyondViewportPageCount = 0, pageSpacing = 12.dp, contentPadding = PaddingValues(horizontal = 8.dp),
                    modifier = Modifier.fillMaxWidth().weight(1f).testTag("pdf_pager"), key = { it }) { index ->
                    PdfPageContent(file, index, index == pager.currentPage, resetZoom,
                        ink.pages[index] ?: PageAnnotations(), tool, stylusOnly, straight, inkColor,
                        Modifier.fillMaxSize().graphicsLayer {
                            val fraction = ((pager.currentPage - index) + pager.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                            scaleX = 1f - .12f * fraction; scaleY = scaleX; alpha = 1f - .45f * fraction; clip = true
                        }, onZoomChanged = { if (index == pager.currentPage) zoomed = it },
                        onChange = { updatePage(index, it) },
                        onNote = { point, existing -> pendingNote = PendingPdfNote(index, point, existing) })
                }
                Surface(shape = MaterialTheme.shapes.extraLarge, tonalElevation = 6.dp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp).fillMaxWidth()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        PdfTool.entries.forEach { candidate ->
                            FilledTonalIconToggleButton(checked = tool == candidate, onCheckedChange = { tool = candidate },
                                modifier = Modifier.testTag("pdf_tool_${candidate.name}")) {
                                Icon(when (candidate) {
                                    PdfTool.HAND -> Icons.Outlined.PanTool
                                    PdfTool.PEN -> Icons.Outlined.Edit
                                    PdfTool.HIGHLIGHT -> Icons.Outlined.BorderColor
                                    PdfTool.ERASER -> Icons.Outlined.AutoFixNormal
                                    PdfTool.NOTE -> Icons.Outlined.StickyNote2
                                }, when (candidate) {
                                    PdfTool.HAND -> "Mover página"; PdfTool.PEN -> "Caneta"; PdfTool.HIGHLIGHT -> "Marca-texto"
                                    PdfTool.ERASER -> "Borracha"; PdfTool.NOTE -> "Adicionar nota no PDF"
                                })
                            }
                        }
                        IconButton(enabled = history[pager.currentPage].orEmpty().isNotEmpty(), onClick = {
                            val undo = history[pager.currentPage].orEmpty()
                            annotations.replace(pager.currentPage, undo.last()); history[pager.currentPage] = undo.dropLast(1)
                        }) { Icon(Icons.AutoMirrored.Filled.Undo, "Desfazer") }
                        IconButton(onClick = { noteList = true }) { Icon(Icons.Outlined.ListAlt, "Notas deste PDF") }
                        IconButton(onClick = { settings = true }) { Icon(Icons.Outlined.Tune, "Ajustar ferramentas") }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically) {
                    IconButton(enabled = pager.currentPage > 0, onClick = { resetZoom++; scope.launch { pager.animateScrollToPage(pager.currentPage - 1) } }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Página anterior")
                    }
                    Text("${pager.currentPage + 1} / ${document.count}", style = MaterialTheme.typography.labelLarge)
                    IconButton(enabled = pager.currentPage < document.count - 1, onClick = { resetZoom++; scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, "Próxima página")
                    }
                    IconButton(onClick = { resetZoom++ }) { Icon(Icons.Outlined.ZoomOutMap, "Restaurar zoom") }
                    HelpTooltip("Ler e anotar", "A mão permite trocar páginas. Caneta e marca-texto desenham; dois dedos ampliam e movem. " +
                        "Na borracha, toque no traço para removê-lo. Tudo fica salvo neste aparelho, sem mudar o PDF do Drive.")
                }
            }
            if (noteList) ModalBottomSheet(onDismissRequest = { noteList = false }) {
                val notes = ink.pages.toSortedMap().flatMap { (page, a) -> a.notes.map { page to it } }
                Text("Notas deste PDF", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(24.dp))
                if (notes.isEmpty()) Text("Use a ferramenta Nota e toque na página.", Modifier.padding(24.dp))
                LazyColumn(contentPadding = PaddingValues(16.dp)) {
                    items(notes, key = { it.second.id }) { (index, note) ->
                        ListItem(headlineContent = { Text(note.text) }, supportingContent = { Text("Página ${index+1}") },
                            trailingContent = { TextButton(onClick = { noteList = false; resetZoom++; scope.launch { pager.animateScrollToPage(index) } }) { Text("Ir") } })
                    }
                }
            }
        }
    }
    pendingNote?.let { pending ->
        var text by remember(pending) { mutableStateOf(pending.existing?.text.orEmpty()) }
        AlertDialog(onDismissRequest = { pendingNote = null }, icon = { Icon(Icons.Outlined.StickyNote2, null) },
            title = { Text("Nota • página ${pending.page+1}") }, text = {
                OutlinedTextField(text, { text = it.take(4000) }, label = { Text("Anotação") }, minLines = 3, maxLines = 8)
            }, confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = {
                val a = ink.pages[pending.page] ?: PageAnnotations()
                val note = PdfNote(pending.existing?.id ?: UUID.randomUUID().toString(), pending.point, text.trim())
                updatePage(pending.page, a.copy(notes = a.notes.filterNot { it.id == note.id } + note)); pendingNote = null
            }) { Text("Salvar") } }, dismissButton = {
                Row {
                    if (pending.existing != null) TextButton(onClick = {
                        val a = ink.pages[pending.page] ?: PageAnnotations()
                        updatePage(pending.page, a.copy(notes = a.notes.filterNot { it.id == pending.existing.id })); pendingNote = null
                    }) { Text("Excluir") }
                    TextButton(onClick = { pendingNote = null }) { Text("Cancelar") }
                }
            })
    }
    if (settings) AlertDialog(onDismissRequest = { settings = false }, icon = { Icon(Icons.Outlined.Tune, null) },
        title = { Text("Ferramentas do PDF") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Só a caneta desenha", Modifier.weight(1f))
                    Switch(stylusOnly, { stylusOnly = it; preferences.edit().putBoolean("stylus_only", it).apply() })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Marca-texto em linha reta", Modifier.weight(1f))
                    Switch(straight, { straight = it; preferences.edit().putBoolean("straight_highlight", it).apply() })
                }
                Text("Cor da caneta")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0xFF2457B8L, 0xFF242424L, 0xFFC33F54L, 0xFF137C62L).forEach { value ->
                        FilledTonalIconToggleButton(inkColor == value, { inkColor = value }) {
                            Icon(Icons.Outlined.Circle, "Cor ${value.toString(16)}", tint = Color(value))
                        }
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { settings = false }) { Text("Pronto") } })
}

@Composable private fun PdfPageContent(file: File, index: Int, active: Boolean, resetZoom: Int,
    annotation: PageAnnotations, tool: PdfTool, stylusOnly: Boolean, straight: Boolean, color: Long,
    modifier: Modifier, onZoomChanged: (Boolean) -> Unit, onChange: (PageAnnotations) -> Unit,
    onNote: (InkPoint, PdfNote?) -> Unit) {
    var zoom by remember(file.path, index) { mutableFloatStateOf(1f) }
    var pan by remember(file.path, index) { mutableStateOf(Offset.Zero) }
    var draft by remember(file.path, index) { mutableStateOf<List<InkPoint>>(emptyList()) }
    val currentAnnotation by rememberUpdatedState(annotation)
    val zoomCallback by rememberUpdatedState(onZoomChanged)
    val changeCallback by rememberUpdatedState(onChange)
    val noteCallback by rememberUpdatedState(onNote)
    LaunchedEffect(resetZoom, active) { zoom = 1f; pan = Offset.Zero; zoomCallback(false) }
    val page by produceState(PdfBitmap(), file.path, index) {
        value = pdfRenderGate.withPermit { withContext(Dispatchers.IO) {
            try {
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                    PdfRenderer(descriptor).use { renderer -> renderer.openPage(index).use { opened ->
                        val scale = minOf(1440f/opened.width, 2048f/opened.height)
                        val bitmap = Bitmap.createBitmap((opened.width*scale).toInt().coerceAtLeast(1),
                            (opened.height*scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(android.graphics.Color.WHITE)
                        opened.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); PdfBitmap(bitmap)
                    } }
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { PdfBitmap(error = "Não foi possível renderizar esta página.") }
        } }
    }
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val bitmap = page.bitmap
        when {
            page.error != null -> Text(page.error!!, color = MaterialTheme.colorScheme.error)
            bitmap == null -> LoadingPane("Carregando página ${index+1}…")
            else -> {
                val ratio = bitmap.width.toFloat()/bitmap.height
                val width = minOf(maxWidth, maxHeight*ratio); val height = width/ratio
                Box(Modifier.size(width, height).graphicsLayer {
                    scaleX = zoom; scaleY = zoom; translationX = pan.x; translationY = pan.y
                    compositingStrategy = CompositingStrategy.Offscreen
                }.background(Color.White).pointerInput(file.path, index, tool, stylusOnly, straight, color) {
                    fun normalized(p: Offset) = InkPoint(p.x/size.width, p.y/size.height).clamped()
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val canDraw = tool != PdfTool.HAND && (!stylusOnly || down.type == PointerType.Stylus || down.type == PointerType.Eraser)
                        val start = normalized(down.position)
                        var last = start; var transformed = false; var moved = false
                        var erased = currentAnnotation
                        if (canDraw) { down.consume(); if (tool == PdfTool.PEN || tool == PdfTool.HIGHLIGHT) draft = listOf(start) }
                        do {
                            val event = awaitPointerEvent()
                            event.changes.firstOrNull { it.id == down.id }?.let { pointer ->
                                last = normalized(pointer.position)
                                if (kotlin.math.hypot(last.x-start.x, last.y-start.y) > .012f) moved = true
                            }
                            val multi = event.changes.count { it.pressed } >= 2
                            val transform = multi || (!canDraw && zoom > 1.01f)
                            if (transform) {
                                transformed = true; draft = emptyList()
                                zoom = (zoom * event.calculateZoom()).coerceIn(1f, 4f)
                                val delta = event.calculatePan()
                                val limitX = size.width*(zoom-1f)/2; val limitY = size.height*(zoom-1f)/2
                                pan = Offset((pan.x+delta.x).coerceIn(-limitX, limitX), (pan.y+delta.y).coerceIn(-limitY, limitY))
                                zoomCallback(zoom > 1.01f); event.changes.forEach { it.consume() }
                            } else if (canDraw && !transformed) {
                                event.changes.firstOrNull { it.id == down.id }?.let { pointer ->
                                    last = normalized(pointer.position)
                                    when (tool) {
                                        PdfTool.PEN, PdfTool.HIGHLIGHT -> if (pointer.pressed) {
                                            draft = if (straight && tool == PdfTool.HIGHLIGHT) listOf(start, last)
                                                else if (draft.lastOrNull() != last) draft + last else draft
                                        }
                                        PdfTool.ERASER -> erased = erased.copy(strokes = erased.strokes.filterNot { strokeHit(it, last) })
                                        else -> Unit
                                    }
                                    pointer.consume()
                                }
                            }
                        } while (event.changes.any { it.pressed })
                        if (!transformed && canDraw) {
                            when (tool) {
                                PdfTool.PEN, PdfTool.HIGHLIGHT -> if (draft.isNotEmpty()) changeCallback(currentAnnotation.copy(
                                    strokes = currentAnnotation.strokes + InkStroke(UUID.randomUUID().toString(), draft,
                                        tool == PdfTool.HIGHLIGHT, if (tool == PdfTool.HIGHLIGHT) 0xFFFFD54FL else color,
                                        if (tool == PdfTool.HIGHLIGHT) .027f else .0035f)))
                                PdfTool.ERASER -> changeCallback(erased)
                                PdfTool.NOTE -> {
                                    val existing = currentAnnotation.notes.firstOrNull { kotlin.math.hypot(it.point.x-last.x, it.point.y-last.y) < .045f }
                                    noteCallback(existing?.point ?: last, existing)
                                }
                                else -> Unit
                            }
                        } else if (!transformed && !moved && tool == PdfTool.HAND) {
                            currentAnnotation.notes.firstOrNull { kotlin.math.hypot(it.point.x-last.x, it.point.y-last.y) < .045f }
                                ?.let { noteCallback(it.point, it) }
                        }
                        draft = emptyList()
                    }
                }) {
                    Image(bitmap.asImageBitmap(), "Página ${index+1}", Modifier.fillMaxSize())
                    Canvas(Modifier.fillMaxSize()) {
                        fun paint(s: InkStroke) {
                            if (s.points.isEmpty()) return
                            val strokeColor = Color(s.color).copy(alpha = if (s.highlight) .42f else 1f)
                            val blend = if (s.highlight) BlendMode.Multiply else BlendMode.SrcOver
                            val w = s.width*size.width
                            if (s.points.size == 1) drawCircle(strokeColor, w/2,
                                Offset(s.points[0].x*size.width,s.points[0].y*size.height), blendMode = blend)
                            else {
                                val path = Path().apply {
                                    moveTo(s.points[0].x*size.width,s.points[0].y*size.height)
                                    s.points.drop(1).forEach { lineTo(it.x*size.width,it.y*size.height) }
                                }
                                drawPath(path, strokeColor, style = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = blend)
                            }
                        }
                        annotation.strokes.forEach(::paint)
                        if (draft.isNotEmpty()) paint(InkStroke("draft", draft, tool == PdfTool.HIGHLIGHT,
                            if(tool==PdfTool.HIGHLIGHT) 0xFFFFD54FL else color, if(tool==PdfTool.HIGHLIGHT) .027f else .0035f))
                        annotation.notes.forEach { n ->
                            val center=Offset(n.point.x*size.width,n.point.y*size.height)
                            drawCircle(Color(0xFF7955C3),12.dp.toPx(),center)
                            drawLine(Color.White,center-Offset(5.dp.toPx(),0f),center+Offset(5.dp.toPx(),0f),2.dp.toPx())
                            drawLine(Color.White,center-Offset(0f,5.dp.toPx()),center+Offset(0f,5.dp.toPx()),2.dp.toPx())
                        }
                    }
                }
            }
        }
    }
}
```

## app/src/main/java/com/example/ui/backup/BackupControls.kt

```kotlin
package com.example.ui.backup

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.backup.*
import com.example.data.repository.StudyViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** O provedor de arquivos cuida do destino; não pede novas permissões OAuth. */
@Composable fun BackupControls(model: StudyViewModel) {
    val context=LocalContext.current
    val repository=remember(context) {BackupRepository(context)}
    val scope=rememberCoroutineScope()
    var busy by remember {mutableStateOf(false)}
    var pending by remember {mutableStateOf<PortableBackup?>(null)}
    var message by remember {mutableStateOf<String?>(null)}
    fun operation(action:suspend ()->Unit) {
        scope.launch {
            busy=true
            try {action()}
            catch(cancel:CancellationException) {throw cancel}
            catch(error:Exception) {message="Não foi possível concluir: ${error.message ?: "confira o arquivo e tente novamente"}"}
            finally {busy=false}
        }
    }
    val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) {uri->
        if(uri!=null)operation {repository.export(uri,model);message="Dados exportados. Guarde o arquivo para importar em outro dispositivo."}
    }
    val importLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {uri->
        if(uri!=null)operation {pending=repository.read(uri)}
    }
    Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("Seus dados",style=MaterialTheme.typography.titleMedium)
        Text("Transfira configurações, notas, estudo, Questões, Pomodoro e anotações de PDFs. Você pode salvar o arquivo no Google Drive.",
            style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(enabled=!busy,onClick={
            val stamp=SimpleDateFormat("yyyy-MM-dd-HHmm",Locale.ROOT).format(Date())
            export.launch("Keplerae-backup-$stamp.json")
        },modifier=Modifier.fillMaxWidth().testTag("backup_export")) {
            Icon(Icons.Outlined.FileUpload,null);Spacer(Modifier.width(8.dp));Text("Exportar dados e configurações")
        }
        OutlinedButton(enabled=!busy,onClick={importLauncher.launch(arrayOf("application/json","text/plain","application/octet-stream"))},
            modifier=Modifier.fillMaxWidth().testTag("backup_import")) {
            Icon(Icons.Outlined.FileDownload,null);Spacer(Modifier.width(8.dp));Text("Importar dados e configurações")
        }
    }
    pending?.let {backup->
        AlertDialog(onDismissRequest={pending=null},icon={Icon(Icons.Outlined.FileDownload,null)},
            title={Text("Importar seus dados?")},text={Text(backup.summary()+
                "\n\nOs registros serão mesclados com os atuais, sem duplicar IDs. Nas notas, a edição mais recente prevalece. As configurações de tema e Pomodoro serão aplicadas. A conta conectada permanece a mesma.")},
            confirmButton={TextButton(onClick={pending=null;operation {repository.importBackup(backup,model);message="Dados importados e configurações aplicadas."}},
                modifier=Modifier.testTag("backup_confirm_import")) {Text("Importar")}},
            dismissButton={TextButton(onClick={pending=null}) {Text("Cancelar")}})
    }
    if(busy)AlertDialog(onDismissRequest={},icon={Icon(Icons.Outlined.Sync,null)},
        title={Text("Preparando seus dados…")},text={LinearProgressIndicator(Modifier.fillMaxWidth())},confirmButton={})
    message?.let {text->AlertDialog(onDismissRequest={message=null},icon={Icon(Icons.Outlined.Info,null)},
        title={Text("Transferência de dados")},text={Text(text)},confirmButton={TextButton(onClick={message=null}) {Text("Fechar")}})}
}
```

## app/src/main/java/com/example/ui/components/ExpressiveComponents.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** O mesmo indicador Expressive atende carregamento inicial e atualização por gesto. */
@Composable fun ExpressiveRefreshBox(refreshing: Boolean, onRefresh: () -> Unit,
    modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val pullState = rememberPullToRefreshState()
    PullToRefreshBox(isRefreshing = refreshing, onRefresh = onRefresh, state = pullState,
        modifier = modifier, indicator = {
            PullToRefreshDefaults.LoadingIndicator(state = pullState, isRefreshing = refreshing,
                modifier = Modifier.align(Alignment.TopCenter))
        }, content = content)
}

@Composable fun LoadingPane(label: String, modifier: Modifier = Modifier,
    progress: Float? = null) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        LoadingIndicator(Modifier.size(64.dp))
        Spacer(Modifier.height(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
        if (progress != null) {
            Spacer(Modifier.height(20.dp))
            LinearWavyProgressIndicator(progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.widthIn(max = 360.dp).fillMaxWidth())
            Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 8.dp))
        }
    }
}

/** Exibição manual: o clique chama show(), sem depender de pressionar e segurar. */
@Composable fun HelpTooltip(title: String, detail: String, modifier: Modifier = Modifier) {
    val state = rememberTooltipState(isPersistent = true)
    val scope = rememberCoroutineScope()
    TooltipBox(positionProvider = TooltipDefaults.rememberRichTooltipPositionProvider(),
        state = state, enableUserInput = false, tooltip = {
            RichTooltip(title = { Text(title) }, action = {
                TextButton(onClick = { state.dismiss() }) { Text("Entendi") }
            }) { Text(detail) }
        }) {
        IconButton(onClick = { scope.launch { state.show() } }, modifier = modifier) {
            Icon(Icons.Outlined.Info, "Ajuda: $title")
        }
    }
}
```

## app/src/main/java/com/example/ui/components/FolderSurface.kt

```kotlin
package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

data class FolderTone(val top: Color, val bottom: Color, val ink: Color, val accent: Color)

/** Superfícies claras de vidro colorido; no escuro, tons profundos e progresso luminoso. */
fun folderTone(id: String, dark: Boolean): FolderTone {
    val names = listOf("fisioterapia", "portugues", "matematica", "hu_legislacao", "sus", "profisio")
    val index = names.indexOf(id).takeIf { it >= 0 }
        ?: ((id.hashCode().toLong().and(0x7fffffff)) % 6).toInt()
    val light = listOf(
        FolderTone(Color(0xFFE0F5EE), Color(0xFFB5D8CA), Color(0xFF174B3F), Color(0xFF166D58)),
        FolderTone(Color(0xFFFFE8F1), Color(0xFFEDB8D3), Color(0xFF662C4C), Color(0xFFA42765)),
        FolderTone(Color(0xFFDCEBFF), Color(0xFFA6C0E8), Color(0xFF263F69), Color(0xFF285CAF)),
        FolderTone(Color(0xFFFFECDC), Color(0xFFDBB993), Color(0xFF613C17), Color(0xFF986022)),
        FolderTone(Color(0xFFEBF3D9), Color(0xFFBECD94), Color(0xFF3F501F), Color(0xFF577223)),
        FolderTone(Color(0xFFEBE1FF), Color(0xFFC2AFE9), Color(0xFF473268), Color(0xFF7050AC))
    )
    val night = listOf(
        FolderTone(Color(0xFF223C37), Color(0xFF0E2520), Color(0xFFD5F5E8), Color(0xFF49D9AA)),
        FolderTone(Color(0xFF4A263C), Color(0xFF2E1027), Color(0xFFFFDFED), Color(0xFFF478B2)),
        FolderTone(Color(0xFF263B5C), Color(0xFF10213E), Color(0xFFDDEAFF), Color(0xFF70B3FF)),
        FolderTone(Color(0xFF4C3424), Color(0xFF301C0C), Color(0xFFFFE3C4), Color(0xFFFFAB59)),
        FolderTone(Color(0xFF354128), Color(0xFF1A2711), Color(0xFFE4EFCE), Color(0xFFB4D56C)),
        FolderTone(Color(0xFF382951), Color(0xFF211136), Color(0xFFEEE1FF), Color(0xFFC092FF))
    )
    return (if (dark) night else light)[index]
}

@Composable fun FolderSurface(tone: FolderTone, modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null, interactionSource: MutableInteractionSource? = null, content: @Composable BoxScope.() -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    val border = BorderStroke(1.dp, tone.ink.copy(alpha = .12f))
    val body: @Composable () -> Unit = {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(tone.top, tone.bottom))), content = content)
    }
    if (onClick == null) Surface(modifier, shape = shape, color = Color.Transparent,
        contentColor = tone.ink, border = border, shadowElevation = 2.dp, content = body)
    else Surface(onClick = onClick, interactionSource = interactionSource, modifier = modifier, shape = shape, color = Color.Transparent,
        contentColor = tone.ink, border = border, shadowElevation = 2.dp, content = body)
}
```

## app/src/main/java/com/example/ui/components/SharedMotion.kt

```kotlin
@file:OptIn(androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui.components

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect

/** Escopos vêm do mesmo AnimatedContent; chaves são estáveis nos dois destinos. */
@Immutable data class SharedMotion(
    val shared: SharedTransitionScope,
    val animated: AnimatedVisibilityScope,
    val scope: String = "",
) {
    private fun k(key: String) = if (scope.isEmpty()) key else "$scope/$key"
    @Composable fun element(key: String): Modifier = with(shared) {
        Modifier.sharedElement(rememberSharedContentState(k(key)), animatedVisibilityScope = animated,
            boundsTransform = { _, _ -> spring<Rect>(dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessLow) })
    }
    @Composable fun bounds(key: String): Modifier = with(shared) {
        Modifier.sharedBounds(rememberSharedContentState(k(key)), animatedVisibilityScope = animated,
            boundsTransform = { _, _ -> spring<Rect>(dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessLow) })
    }
}
```

## app/src/main/java/com/example/ui/components/SidebarNavigation.kt

```kotlin
package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import com.example.data.auth.GoogleUser
import com.example.ui.Destination
import com.example.ui.profile.GoogleAvatar

val MainDestinations = listOf(Destination.HOME, Destination.SUBJECTS,
    Destination.POMODORO, Destination.QUESTIONS, Destination.NOTES)

/** Faixa lateral estreita, ícones monocromáticos e perfil acessível em qualquer seção. */
@Composable fun SidebarNavigation(current: Destination, profile: Boolean, user: GoogleUser?,
    onNavigate: (Destination) -> Unit, onProfile: () -> Unit) {
    val active = current.takeIf { it in MainDestinations } ?: Destination.SUBJECTS
    Surface(color=MaterialTheme.colorScheme.surface, modifier=Modifier.width(64.dp).fillMaxHeight()
        .testTag("sidebar_navigation")) {
        Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical=16.dp),
                horizontalAlignment=Alignment.CenterHorizontally,
                verticalArrangement=Arrangement.spacedBy(12.dp)) {
                MainDestinations.forEach { destination ->
                    val chosen = !profile && active==destination
                    val filled = when(destination) {
                        Destination.HOME -> Icons.Filled.Home
                        Destination.SUBJECTS -> Icons.Filled.GridView
                        Destination.POMODORO -> Icons.Filled.Timer
                        Destination.QUESTIONS -> Icons.Filled.Quiz
                        else -> Icons.Filled.EditNote
                    }
                    IconButton(onClick={onNavigate(destination)},modifier=Modifier.size(48.dp)
                        .testTag("nav_${destination.name}").semantics { role=Role.Tab;selected=chosen }) {
                        Icon(if(chosen)filled else destination.icon,destination.title,Modifier.size(27.dp),
                            tint=if(chosen)MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Surface(onClick=onProfile,shape=CircleShape,
                    color=MaterialTheme.colorScheme.surface,
                    border=BorderStroke(if(profile)2.dp else 1.dp,
                        if(profile)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                    modifier=Modifier.size(48.dp).testTag("profile_rail")
                        .semantics { contentDescription="Abrir meu perfil";selected=profile }) {
                    GoogleAvatar(user,Modifier.fillMaxSize().padding(6.dp))
                }
            }
        }
    }
}
```

## app/src/main/java/com/example/ui/components/SubjectArtwork.kt

```kotlin
package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

fun subjectPalette(id: String, dark: Boolean): Pair<Color, Color> {
    val colors = when (id) {
        "fisioterapia" -> listOf(0xFFD0F4E6, 0xFF064F3C, 0xFF173D33, 0xFFAFF0D5)
        "portugues" -> listOf(0xFFFFDFEB, 0xFF70324C, 0xFF4C2638, 0xFFFFB2D0)
        "matematica" -> listOf(0xFFDBE6FF, 0xFF274777, 0xFF23344F, 0xFFB6CEFF)
        "hu_legislacao" -> listOf(0xFFFFE8CA, 0xFF654512, 0xFF49351C, 0xFFF5D49D)
        "sus" -> listOf(0xFFE1EFC4, 0xFF3C4E17, 0xFF303D1B, 0xFFD4E9AA)
        else -> listOf(0xFFEBDFFF, 0xFF533777, 0xFF3D2C50, 0xFFE0C3FF)
    }
    return if (dark) Color(colors[2]) to Color(colors[3]) else Color(colors[0]) to Color(colors[1])
}

/** Ilustrações nativas: não dependem de imagens de terceiros nem de conexão. */
@Composable fun SubjectArtwork(id: String, tint: Color, modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension * .24f
            rotate(-12f) {
                repeat(6) { n ->
                    val angle = n * PI / 3
                    val p = center + Offset((cos(angle) * r).toFloat(), (sin(angle) * r).toFloat())
                    drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = .22f), tint.copy(alpha = .07f)),
                        center = p, radius = r), r, p)
                }
            }
            drawCircle(Color.White.copy(alpha = .20f), r * 1.12f, center - Offset(r * .15f, r * .17f))
        }
        Icon(when (id) {
            "fisioterapia" -> Icons.Outlined.AccessibilityNew
            "portugues" -> Icons.AutoMirrored.Outlined.MenuBook
            "matematica" -> Icons.Outlined.Functions
            "hu_legislacao" -> Icons.Outlined.Balance
            "sus" -> Icons.Outlined.HealthAndSafety
            else -> Icons.Outlined.Psychology
        }, null, Modifier.size(44.dp), tint = tint)
    }
}
```

## app/src/main/java/com/example/ui/home/HomeScreen.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.auth.GoogleUser
import com.example.data.model.*
import com.example.data.repository.StudyState
import com.example.ui.Destination
import com.example.ui.components.*
import com.example.ui.profile.ProfileButton
import com.example.ui.theme.isDarkMode

@Composable fun HomeScreen(state: StudyState, user: GoogleUser?, motion: SharedMotion,
    onNavigate: (Destination) -> Unit, onSubject: (Subject) -> Unit,
    onOpen: (StudyItem) -> Unit, onProfile: () -> Unit, onRefresh: () -> Unit) {
    val dark = isDarkMode(state.theme)
    val recent = remember(state.items, state.accessed) {
        state.items.filter { it.id in state.accessed }.sortedByDescending { state.accessed[it.id] }.take(4)
    }
    val complete = state.items.count { it.id in state.completed }
    val progress = if (state.items.isEmpty()) 0f else complete.toFloat() / state.items.size
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val columns = if (maxWidth >= 800.dp) 3 else 2
        val wideHeader = maxWidth >= 650.dp
        ExpressiveRefreshBox(state.loading, onRefresh, Modifier.fillMaxSize()) {
            LazyVerticalGrid(columns = GridCells.Fixed(columns), modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Box(Modifier.fillMaxWidth().background(Brush.linearGradient(
                        if (dark) listOf(Color(0xFF36344F), Color(0xFF23483E))
                        else listOf(Color(0xFFFFD7E8), Color(0xFFFFECC0), Color(0xFFD4F1DB))),
                        MaterialTheme.shapes.extraLarge).padding(24.dp)) {
                        Column(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("SEU ESPAÇO DE ESTUDO", style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(user?.displayName?.substringBefore(' ')?.let { "Olá, $it" } ?: "Vamos explorar?",
                                        style = MaterialTheme.typography.titleMedium)
                                }
                                ProfileButton(user, motion, onProfile)
                            }
                            Spacer(Modifier.height(24.dp))
                            Text("Kepleræ", style = MaterialTheme.typography.displayLarge.copy(
                                fontSize = if (wideHeader) 96.sp else 62.sp,
                                lineHeight = if (wideHeader) 104.sp else 70.sp,
                                letterSpacing = (-2).sp, fontWeight = FontWeight.Bold))
                            Text("Aprender, no seu ritmo.", style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Card(shape = RoundedCornerShape(32.dp),
                        colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLowest)) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Text("Seu percurso", style = MaterialTheme.typography.headlineSmall,
                                    modifier = Modifier.weight(1f))
                                HelpTooltip("Seu percurso", "As conclusões e os favoritos ficam salvos neste aparelho. " +
                                    "Abra um material e toque em Concluir para atualizar seu progresso.")
                            }
                            Text("$complete de ${state.items.size} materiais concluídos",
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            LinearWavyProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = { if (recent.isEmpty()) onNavigate(Destination.SUBJECTS)
                                else onOpen(recent.first()) }, modifier = Modifier.heightIn(min = 52.dp)) {
                                Icon(if (recent.isEmpty()) Icons.Outlined.GridView else Icons.Filled.PlayArrow, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (recent.isEmpty()) "Escolher uma matéria" else "Retomar estudo")
                            }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf(Destination.VIDEOS, Destination.PDFS, Destination.AUDIO).forEach { dest ->
                            Card(onClick = { onNavigate(dest) }, modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerHigh)) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(dest.icon, null, tint = MaterialTheme.colorScheme.primary)
                                    Text(state.items.count { it.type == dest.type }.toString(),
                                        style = MaterialTheme.typography.headlineMedium)
                                    Text(dest.title, style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Suas matérias", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onNavigate(Destination.SUBJECTS) }) { Text("Ver todas") }
                    }
                }
                items(Subjects.all, key = { it.id }) { subject ->
                    SubjectTile(subject, state, motion, Modifier.fillMaxWidth()) { onSubject(subject) }
                }
                if (recent.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text("Continue de onde parou", style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier.padding(top = 8.dp))
                    }
                    items(recent, key = { "recent/${it.id}" }, span = { GridItemSpan(maxLineSpan) }) { item ->
                        Card(onClick = { onOpen(item) }, modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLow)) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Icon(if (item.type == ContentType.AUDIO) Icons.Outlined.Headphones
                                    else if (item.type == ContentType.PDF) Icons.Outlined.Description
                                    else Icons.Outlined.PlayCircleOutline, null, tint = MaterialTheme.colorScheme.primary)
                                Column(Modifier.weight(1f)) {
                                    Text(item.title, style = MaterialTheme.typography.titleMedium)
                                    Text(Subjects.get(item.subjectId).name, style = MaterialTheme.typography.bodySmall)
                                }
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, "Abrir material")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun SubjectTile(subject: Subject, state: StudyState, motion: SharedMotion,
    modifier: Modifier = Modifier, onClick: () -> Unit) {
    val tone = folderTone(subject.id, isDarkMode(state.theme))
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .96f else 1f, label = "subject_press")
    val rows = remember(state.items, subject.id) { state.items.filter { it.subjectId == subject.id } }
    val complete = rows.count { it.id in state.completed }
    FolderSurface(tone, modifier.then(motion.bounds("subject/${subject.id}/container"))
        .graphicsLayer { scaleX = scale; scaleY = scale }, onClick, interaction) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                SubjectArtwork(subject.id, tone.accent, motion.element("subject/${subject.id}/art").size(68.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(20.dp), tint = tone.ink.copy(alpha = .7f))
            }
            Text(subject.name, style = MaterialTheme.typography.titleMedium, minLines = 2,
                modifier = motion.bounds("subject/${subject.id}/name"))
            Text("${rows.size} materiais", style = MaterialTheme.typography.labelLarge, color = tone.ink.copy(alpha = .8f))
            LinearProgressIndicator(progress = { if (rows.isEmpty()) 0f else complete.toFloat()/rows.size },
                modifier = Modifier.fillMaxWidth(), color = tone.accent, trackColor = tone.ink.copy(alpha = .12f))
        }
    }
}
```

## app/src/main/java/com/example/ui/login/LoginRoute.kt

```kotlin
package com.example.ui.login

import android.app.Activity
import android.content.MutableContextWrapper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.auth.GoogleLoginViewModel
import com.example.data.auth.GoogleLoginConfiguration
import com.example.data.auth.GoogleUser
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** O lançamento de Credential Manager fica na tela e acompanha seu ciclo de vida. */
@Composable
fun LoginRoute(viewModel: GoogleLoginViewModel) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val credentials = remember(context.applicationContext) {
        CredentialManager.create(context.applicationContext)
    }
    val webClientId = context.getString(R.string.google_web_client_id).trim()
    val driveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult(),
    ) { result ->
        viewModel.receiveDriveResult(result.data, result.resultCode == Activity.RESULT_OK)
    }

    LaunchedEffect(state.driveResolution) {
        val pending = state.driveResolution ?: return@LaunchedEffect
        viewModel.consumeDriveResolution()
        try {
            driveLauncher.launch(IntentSenderRequest.Builder(pending.intentSender).build())
        } catch (error: Exception) {
            viewModel.credentialFailure(error)
        }
    }

    LoginScreen(busy = state.busy, error = state.error, onGoogleSignIn = {
        if (!viewModel.beginSignIn()) return@LoginScreen
        if (!GoogleLoginConfiguration.isWebClientId(webClientId)) {
            viewModel.configurationMissing()
            return@LoginScreen
        }
        scope.launch {
            try {
                // Fluxo explícito do botão: permite escolher/adicionar uma conta Google.
                val option = GetSignInWithGoogleOption.Builder(webClientId).build()
                val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                val response = credentials.getCredential(
                    context = MutableContextWrapper(context),
                    request = request,
                )
                val custom = response.credential as? CustomCredential
                    ?: error("Tipo de credencial inesperado")
                check(custom.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    "Tipo de credencial inesperado"
                }
                val google = GoogleIdTokenCredential.createFrom(custom.data)
                val user = GoogleUser(
                    email = google.id,
                    displayName = google.displayName?.takeIf { it.isNotBlank() } ?: google.id,
                    photoUrl = google.profilePictureUri?.toString(),
                )
                // O ID token não é salvo, não é registrado em log e não vai à API Drive.
                // Esta aplicação local não possui um servidor nem usa Firebase Auth.
                viewModel.authorizeDrive(user)
            } catch (error: CancellationException) {
                viewModel.cancelCredentialRequest()
                throw error
            } catch (error: Exception) {
                viewModel.credentialFailure(error)
            }
        }
    })
}
```

## app/src/main/java/com/example/ui/login/LoginScreen.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.login

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState

/**
 * Tela visual independente do Google: também pode ser usada em Preview e teste.
 * Texto, ícone e um único botão. Nenhum dado de autenticação pertence à UI.
 */
@Composable
fun LoginScreen(
    busy: Boolean,
    error: String?,
    onGoogleSignIn: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    // O padrão do Haze evita blur nos aparelhos em que ele não é confiável.
    // O fallbackTint mantém o vidro translúcido nessas versões/dispositivos.
    val haze = rememberHazeState()
    val preview = LocalInspectionMode.current
    var visible by remember { mutableStateOf(preview) }
    LaunchedEffect(Unit) { visible = true }

    BoxWithConstraints(modifier.fillMaxSize().background(colors.surface)) {
        val compact = maxHeight < 480.dp
        LoginBackdrop(haze, Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().safeDrawingPadding()
                .padding(horizontal = 28.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier.fillMaxWidth().weight(1f),
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = visible,
                    // O rodapé fica no final; só o conteúdo central rola quando necessário.
                    modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    enter = fadeIn(tween(380)) + slideInVertically(
                        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy),
                        initialOffsetY = { it / 12 },
                    ),
                ) {
                    Column(
                        Modifier.widthIn(max = 420.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        val logoShape = RoundedCornerShape(if (compact) 34.dp else 48.dp)
                        Box(
                            Modifier.size(if (compact) 148.dp else 204.dp)
                                .shadow(24.dp, logoShape, clip = false,
                                    ambientColor = colors.primary.copy(alpha = .18f),
                                    spotColor = colors.primary.copy(alpha = .28f))
                                .clip(logoShape)
                                .hazeEffect(haze, glassStyle(.48f))
                                .border(1.dp, Brush.linearGradient(listOf(
                                    Color.White.copy(alpha = .75f), colors.primary.copy(alpha = .13f),
                                )), logoShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            // Arquivo definitivo enviado pelo usuário, sem redesenho.
                            Image(
                                painter = painterResource(R.drawable.keplerae_logo),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.size(if (compact) 112.dp else 160.dp)
                                    .clip(RoundedCornerShape(if (compact) 20.dp else 28.dp)),
                            )
                        }
                        Spacer(Modifier.height(if (compact) 20.dp else 36.dp))
                        Text(
                            text = stringResource(R.string.app_name),
                            style = if (compact) MaterialTheme.typography.displayMedium
                                else MaterialTheme.typography.displayLarge,
                            fontWeight = FontWeight.Bold,
                            color = colors.onSurface,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().semantics { heading() },
                        )
                        Spacer(Modifier.height(if (compact) 24.dp else 40.dp))
                        GoogleGlassButton(busy, onGoogleSignIn, haze)
                        AnimatedVisibility(visible = error != null) {
                            Text(
                                text = error.orEmpty(), color = colors.error,
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
                                    .semantics { liveRegion = LiveRegionMode.Polite }
                                    .testTag("login_error"),
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text(
                text = stringResource(R.string.developed_by),
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }
    }
}

@Composable
private fun GoogleGlassButton(busy: Boolean, onClick: () -> Unit, haze: HazeState) {
    val colors = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(32.dp)
    val interactions = remember { MutableInteractionSource() }
    val pressed by interactions.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .97f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium), label = "googleButtonScale",
    )
    Button(
        onClick = onClick, enabled = !busy, interactionSource = interactions, shape = shape,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent, contentColor = colors.onSurface,
            disabledContainerColor = Color.Transparent, disabledContentColor = colors.onSurface,
        ),
        contentPadding = PaddingValues(horizontal = 22.dp, vertical = 18.dp),
        modifier = Modifier.widthIn(max = 340.dp).fillMaxWidth().heightIn(min = 64.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(18.dp, shape, clip = false,
                ambientColor = colors.primary.copy(alpha = .16f),
                spotColor = colors.primary.copy(alpha = .24f))
            .clip(shape).hazeEffect(haze, glassStyle(.72f))
            .border(1.dp, Brush.linearGradient(listOf(
                Color.White.copy(alpha = .78f), colors.outline.copy(alpha = .30f),
            )), shape)
            .semantics { stateDescription = if (busy) "Conectando ao Google" else "Pronto para entrar" }
            .testTag("google_sign_in"),
    ) {
        // Mantém as cores do G: não usar Icon(tint = ...) neste recurso.
        Image(painterResource(R.drawable.ic_google_g), contentDescription = null,
            modifier = Modifier.size(28.dp).clip(CircleShape).background(Color.White).padding(4.dp))
        Text(
            text = stringResource(R.string.google_sign_in),
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
        )
        if (busy) LoadingIndicator(
            color = colors.primary,
            modifier = Modifier.size(20.dp),
        ) else Spacer(Modifier.size(20.dp))
    }
}

@Composable
private fun glassStyle(tintAlpha: Float): HazeStyle {
    val colors = MaterialTheme.colorScheme
    return HazeStyle(
        backgroundColor = colors.surface,
        tint = HazeTint(colors.surface.copy(alpha = tintAlpha)),
        blurRadius = 28.dp, noiseFactor = .025f,
        fallbackTint = HazeTint(colors.surface.copy(alpha = .88f)),
    )
}

/** Anéis grandes, recortados nas bordas, como na referência. Sem bitmap de fundo. */
@Composable
private fun LoginBackdrop(haze: HazeState, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    Canvas(modifier.hazeSource(haze)) {
        drawRect(Brush.verticalGradient(listOf(colors.surface, colors.primaryContainer.copy(alpha = .40f), colors.surface)))
        fun orb(center: Offset, radius: Float, color: Color) {
            drawCircle(Brush.radialGradient(listOf(
                color.copy(alpha = .08f), color.copy(alpha = .38f), Color.Transparent,
            ), center = center, radius = radius * 1.14f), radius * 1.14f, center)
            drawCircle(Brush.radialGradient(listOf(
                colors.surface.copy(alpha = .96f), colors.primaryContainer.copy(alpha = .82f),
            ), center = center - Offset(radius * .25f, radius * .30f), radius = radius * 1.35f), radius, center)
            drawCircle(Color.White.copy(alpha = .42f), radius, center, style = Stroke(1.5.dp.toPx()))
        }
        val radius = minOf(size.width * .62f, size.height * .36f)
        orb(Offset(-radius * .28f, -radius * .23f), radius, colors.primary)
        orb(Offset(size.width + radius * .40f, size.height * .36f), radius * .42f, colors.primary)
        orb(Offset(size.width + radius * .02f, size.height + radius * .10f), radius * 1.26f, colors.secondary)
        orb(Offset(-radius * .36f, size.height * .88f), radius * .72f, colors.primary)
    }
}
```

## app/src/main/java/com/example/ui/notes/NotesScreen.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.example.ui.notes

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.notes.*
import com.example.ui.productivity.calmColors
import java.util.UUID

private data class NoteTone(val container: Color, val onContainer: Color)

private val ToneNames = listOf("Lilás", "Verde", "Azul", "Laranja", "Rosa")

/** Cinco cores pastel, com versão escura que mantém o contraste do texto. */
@Composable private fun noteTones(): List<NoteTone> {
    val dark = com.example.ui.theme.LocalKepleraeDarkTheme.current
    return if (dark) listOf(
        NoteTone(Color(0xFF3B2F5C), Color(0xFFEDE3FF)),
        NoteTone(Color(0xFF2B4A2C), Color(0xFFDDF8D2)),
        NoteTone(Color(0xFF26455C), Color(0xFFDCEFFF)),
        NoteTone(Color(0xFF5C4526), Color(0xFFFFEBCB)),
        NoteTone(Color(0xFF5C2E43), Color(0xFFFFE0EE)),
    ) else listOf(
        NoteTone(Color(0xFFD9C6F8), Color(0xFF2E2347)),
        NoteTone(Color(0xFFBFF0A0), Color(0xFF1F3A12)),
        NoteTone(Color(0xFFB8DFF8), Color(0xFF12344D)),
        NoteTone(Color(0xFFF8D9A0), Color(0xFF4A3410)),
        NoteTone(Color(0xFFF8C9DE), Color(0xFF4D1E34)),
    )
}

private fun formatDate(millis: Long): String =
    java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.forLanguageTag("pt-BR"))
        .format(java.util.Date(millis))

/** Aba Anotações: lista em grade/lista de cartões coloridos e editor em tela cheia. */
@Composable fun NotesScreen() {
    val context = LocalContext.current
    val store = remember { NoteStore.get(context) }
    val state by store.state.collectAsStateWithLifecycle()
    // null = lista; qualquer outro valor é o id da anotação aberta (nova ou existente).
    var editingId by rememberSaveable { mutableStateOf<String?>(null) }
    val editing = editingId
    if (editing != null) {
        NoteEditor(
            existing = state.notes.firstOrNull { it.id == editing }, id = editing,
            tags = state.tags, store = store, defaultTone = state.notes.size % NOTE_TONE_COUNT,
            onSave = { store.upsert(it); editingId = null },
            onDelete = { store.delete(editing); editingId = null },
            onCancel = { editingId = null },
        )
    } else {
        NotesList(state, store, onOpen = { editingId = it }, onNew = { editingId = UUID.randomUUID().toString() })
    }
}

@Composable private fun NotesList(state: NoteState, store: NoteStore, onOpen: (String) -> Unit, onNew: () -> Unit) {
    val c = calmColors()
    val tones = noteTones()
    var query by rememberSaveable { mutableStateOf("") }
    var selectedTag by rememberSaveable { mutableStateOf<String?>(null) }
    var grid by rememberSaveable { mutableStateOf(true) }
    var newTag by remember { mutableStateOf(false) }
    var renameTag by remember { mutableStateOf(false) }
    var deleteTag by remember { mutableStateOf(false) }
    val activeTag = state.tags.firstOrNull { it.id == selectedTag }
    val visible = remember(state.notes, activeTag?.id, query) { visibleNotes(state.notes, activeTag?.id, query) }
    val tagNames = remember(state.tags) { state.tags.associate { it.id to it.name } }

    CompositionLocalProvider(LocalContentColor provides c.ink) {
        Box(Modifier.fillMaxSize()) {
        LazyVerticalStaggeredGrid(
            columns = if (grid) StaggeredGridCells.Adaptive(170.dp) else StaggeredGridCells.Fixed(1),
            modifier = Modifier.fillMaxSize().background(c.background).testTag("notes_screen"),
            contentPadding = PaddingValues(start = 20.dp, top = 20.dp, end = 20.dp, bottom = 110.dp),
            verticalItemSpacing = 12.dp,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(span = StaggeredGridItemSpan.FullLine) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Notas", style = MaterialTheme.typography.displaySmall)
                        Text("Seus blocos de notas.", color = c.muted)
                    }
                    IconButton(onClick = { grid = !grid }) {
                        Icon(
                            if (grid) Icons.Outlined.ViewAgenda else Icons.Outlined.GridView,
                            if (grid) "Mostrar em lista" else "Mostrar em grade",
                        )
                    }
                }
            }
            item(span = StaggeredGridItemSpan.FullLine) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("notes_search"),
                    placeholder = { Text("Buscar anotações") },
                    leadingIcon = { Icon(Icons.Outlined.Search, null) },
                    trailingIcon = {
                        if (query.isNotBlank()) IconButton(onClick = { query = "" }) {
                            Icon(Icons.Outlined.Close, "Limpar busca")
                        }
                    },
                    shape = RoundedCornerShape(28.dp),
                )
            }
            item(span = StaggeredGridItemSpan.FullLine) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(selected = activeTag == null, onClick = { selectedTag = null },
                            label = { Text("#Todas") })
                    }
                    items(state.tags, key = { it.id }) { tag ->
                        FilterChip(selected = activeTag?.id == tag.id, onClick = { selectedTag = tag.id },
                            label = { Text("#${tag.name}") })
                    }
                    item {
                        AssistChip(onClick = { newTag = true }, label = { Text("Novo bloco") },
                            leadingIcon = { Icon(Icons.Outlined.Add, null, Modifier.size(18.dp)) })
                    }
                }
            }
            if (activeTag != null) item(span = StaggeredGridItemSpan.FullLine) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { renameTag = true }) {
                        Icon(Icons.Outlined.Edit, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Renomear bloco")
                    }
                    TextButton(onClick = { deleteTag = true }) {
                        Icon(Icons.Outlined.Delete, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Excluir bloco")
                    }
                }
            }
            if (visible.isEmpty()) item(span = StaggeredGridItemSpan.FullLine) {
                val filtering = query.isNotBlank() || activeTag != null
                Column(
                    Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Icon(Icons.Outlined.EditNote, null, Modifier.size(44.dp), tint = c.accent)
                    Text(
                        if (filtering) "Nenhuma anotação encontrada" else "Crie sua primeira anotação",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        if (filtering) "Tente outro termo ou escolha outro bloco."
                        else "Guarde resumos, macetes e lembretes de estudo.",
                        color = c.muted,
                    )
                    if (!filtering) Button(onClick = onNew) { Text("Nova anotação") }
                }
            }
            items(visible, key = { it.id }) { note ->
                NoteCard(
                    note = note, tone = tones.getOrElse(note.tone) { tones[0] },
                    tagName = note.tagId?.let { tagNames[it] }, onClick = { onOpen(note.id) },
                )
            }
        }
        ExtendedFloatingActionButton(onClick = onNew, icon = { Icon(Icons.Outlined.Add, null) },
            text = { Text("Nova nota") }, modifier = Modifier.align(Alignment.BottomEnd)
                .padding(20.dp).testTag("note_new"))
        }
    }

    if (newTag) NameDialog("Novo bloco", "", onDismiss = { newTag = false }) { name ->
        try { selectedTag = store.createTag(name); null }
        catch (e: IllegalArgumentException) { e.message ?: "Nome inválido." }
    }
    if (renameTag && activeTag != null) NameDialog("Renomear bloco", activeTag.name, onDismiss = { renameTag = false }) { name ->
        try { store.renameTag(activeTag.id, name); null }
        catch (e: IllegalArgumentException) { e.message ?: "Nome inválido." }
    }
    if (deleteTag && activeTag != null) AlertDialog(
        onDismissRequest = { deleteTag = false },
        icon = { Icon(Icons.Outlined.Delete, null) },
        title = { Text("Excluir bloco?") },
        text = { Text("As anotações de #${activeTag.name} continuam salvas, apenas sem bloco.") },
        confirmButton = {
            TextButton(onClick = { store.deleteTag(activeTag.id); selectedTag = null; deleteTag = false }) { Text("Excluir") }
        },
        dismissButton = { TextButton(onClick = { deleteTag = false }) { Text("Cancelar") } },
    )
}

@Composable private fun NoteCard(note: Note, tone: NoteTone, tagName: String?, onClick: () -> Unit) {
    val tilt = remember(note.id) { Animatable(0f) }
    LaunchedEffect(note.id) {
        delay((note.id.hashCode().toLong().and(0x7fffffff) % 160))
        tilt.animateTo(-2.5f, tween(130)); tilt.animateTo(2f, tween(170))
        tilt.animateTo(0f, spring(dampingRatio = .65f, stiffness = 300f))
    }
    Surface(
        onClick = onClick, shape = RoundedCornerShape(20.dp), color = tone.container,
        border = BorderStroke(1.dp, tone.onContainer.copy(alpha = .3f)), shadowElevation = 1.dp,
        contentColor = tone.onContainer, modifier = Modifier.fillMaxWidth().graphicsLayer { rotationZ = tilt.value }.testTag("note_${note.id}"),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                note.title.ifBlank { "Sem título" }, style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Text(
                formatDate(note.updatedAt), style = MaterialTheme.typography.labelSmall,
                color = tone.onContainer.copy(alpha = .65f),
            )
            if (note.body.isNotBlank()) Text(
                note.body, style = MaterialTheme.typography.bodySmall, maxLines = 6,
                overflow = TextOverflow.Ellipsis, color = tone.onContainer.copy(alpha = .85f),
            )
            if (tagName != null) Text("#$tagName", style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable private fun transparentFieldColors(ink: Color) = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    disabledContainerColor = Color.Transparent, errorContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    disabledIndicatorColor = Color.Transparent, errorIndicatorColor = Color.Transparent,
    focusedTextColor = ink, unfocusedTextColor = ink, cursorColor = ink,
    focusedPlaceholderColor = ink.copy(alpha = .5f), unfocusedPlaceholderColor = ink.copy(alpha = .5f),
)

@Composable private fun NoteEditor(
    existing: Note?, id: String, tags: List<NoteTag>, store: NoteStore, defaultTone: Int,
    onSave: (Note) -> Unit, onDelete: () -> Unit, onCancel: () -> Unit,
) {
    val c = calmColors()
    val tones = noteTones()
    var title by rememberSaveable(id) { mutableStateOf(existing?.title.orEmpty()) }
    var body by rememberSaveable(id) { mutableStateOf(existing?.body.orEmpty()) }
    var tone by rememberSaveable(id) { mutableIntStateOf(existing?.tone ?: defaultTone) }
    var tagId by rememberSaveable(id) { mutableStateOf(existing?.tagId) }
    var menu by remember { mutableStateOf(false) }
    var newTag by remember { mutableStateOf(false) }
    var discard by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val current = tones.getOrElse(tone) { tones[0] }
    val tagName = tags.firstOrNull { it.id == tagId }?.name
    val changed = title != (existing?.title ?: "") || body != (existing?.body ?: "") ||
        tone != (existing?.tone ?: defaultTone) || tagId != existing?.tagId

    fun cancel() { if (changed) discard = true else onCancel() }
    fun save() {
        if (noteIsBlank(title, body)) return
        if (existing != null && !changed) { onCancel(); return }
        val now = System.currentTimeMillis()
        onSave(Note(id, title.trim(), body.trimEnd(), tagId, tone, existing?.createdAt ?: now, now))
    }
    BackHandler { cancel() }

    CompositionLocalProvider(LocalContentColor provides c.ink) {
        Column(
            Modifier.fillMaxSize().background(c.background).imePadding()
                .padding(horizontal = 16.dp, vertical = 12.dp).testTag("note_editor"),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { cancel() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                Spacer(Modifier.weight(1f))
                Box {
                    AssistChip(
                        onClick = { menu = true }, label = { Text(tagName?.let { "#$it" } ?: "Sem bloco") },
                        leadingIcon = { Icon(Icons.Outlined.Folder, null, Modifier.size(18.dp)) },
                    )
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Sem bloco") }, onClick = { tagId = null; menu = false })
                        tags.forEach { tag ->
                            DropdownMenuItem(text = { Text("#${tag.name}") }, onClick = { tagId = tag.id; menu = false })
                        }
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Novo bloco…") },
                            leadingIcon = { Icon(Icons.Outlined.Add, null) },
                            onClick = { menu = false; newTag = true },
                        )
                    }
                }
                if (existing != null) IconButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Outlined.Delete, "Excluir anotação")
                }
            }
            Surface(
                Modifier.weight(1f).fillMaxWidth(), shape = RoundedCornerShape(32.dp),
                color = current.container, contentColor = current.onContainer,
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 16.dp)) {
                    val fieldColors = transparentFieldColors(current.onContainer)
                    TextField(
                        value = title, onValueChange = { title = it },
                        modifier = Modifier.fillMaxWidth().testTag("note_title"),
                        textStyle = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
                        placeholder = { Text("Título", style = MaterialTheme.typography.headlineSmall) },
                        maxLines = 3, colors = fieldColors,
                    )
                    Text(
                        formatDate(existing?.updatedAt ?: System.currentTimeMillis()),
                        modifier = Modifier.padding(horizontal = 16.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = current.onContainer.copy(alpha = .65f),
                    )
                    TextField(
                        value = body, onValueChange = { body = it },
                        modifier = Modifier.fillMaxWidth().weight(1f).testTag("note_body"),
                        placeholder = { Text("Escreva sua anotação…") }, colors = fieldColors,
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                tones.forEachIndexed { index, option ->
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(option.container)
                            .border(if (index == tone) 3.dp else 1.dp, if (index == tone) c.accent else c.border, CircleShape)
                            .selectable(index == tone, onClick = { tone = index }, role = Role.RadioButton)
                            .semantics { contentDescription = "Cor ${ToneNames.getOrElse(index) { "${index + 1}" }}" },
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { cancel() }) { Text("Cancelar") }
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = { save() }, enabled = !noteIsBlank(title, body),
                    modifier = Modifier.testTag("note_confirm"),
                ) { Text("Confirmar") }
            }
        }
    }

    if (newTag) NameDialog("Novo bloco", "", onDismiss = { newTag = false }) { name ->
        try { tagId = store.createTag(name); null }
        catch (e: IllegalArgumentException) { e.message ?: "Nome inválido." }
    }
    if (discard) AlertDialog(
        onDismissRequest = { discard = false },
        icon = { Icon(Icons.Outlined.EditNote, null) },
        title = { Text("Descartar alterações?") },
        text = { Text("O que você escreveu nesta anotação não será salvo.") },
        confirmButton = { TextButton(onClick = { discard = false; onCancel() }) { Text("Descartar") } },
        dismissButton = { TextButton(onClick = { discard = false }) { Text("Continuar editando") } },
    )
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        icon = { Icon(Icons.Outlined.Delete, null) },
        title = { Text("Excluir anotação?") },
        text = { Text("Esta ação não pode ser desfeita.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Excluir") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } },
    )
}

/** [onConfirm] devolve a mensagem de erro, ou null quando salvou e o diálogo pode fechar. */
@Composable private fun NameDialog(
    title: String, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> String?,
) {
    var name by remember { mutableStateOf(initial) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Folder, null) },
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name, onValueChange = { name = it; error = null }, singleLine = true,
                label = { Text("Nome do bloco") }, isError = error != null,
                supportingText = { error?.let { Text(it) } },
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val result = onConfirm(name)
                error = result
                if (result == null) onDismiss()
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
```

## app/src/main/java/com/example/ui/productivity/PomodoroArtwork.kt

```kotlin
package com.example.ui.productivity

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.painterResource
import com.example.R
import kotlin.math.*

/** Cena em camadas: a vara pertence à arte; linha, estrela e partículas são animadas. */
@Composable fun PomodoroArtwork(active: Boolean, modifier: Modifier=Modifier) {
    val c=calmColors()
    val dark=c.background.luminance()<.35f
    val loop=rememberInfiniteTransition(label="cosmic_scene")
    val phase by loop.animateFloat(0f,(2*PI).toFloat(),infiniteRepeatable(tween(6000,easing=LinearEasing)),label="fishing_motion")
    val orbit by loop.animateFloat(0f,(2*PI).toFloat(),infiniteRepeatable(tween(18000,easing=LinearEasing)),label="saturn_ring")
    val meteor by loop.animateFloat(0f,1f,infiniteRepeatable(tween(11000,easing=LinearEasing)),label="shooting_star")
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            repeat(28) { i ->
                val x=size.width*((i*37%97+1)/100f)
                val y=size.height*((i*29%89+3)/100f)+sin(orbit+i)*5.dp.toPx()
                val alpha=if(dark).58f+.25f*sin(phase+i)else .72f+.20f*sin(phase+i)
                val color=if(dark)Color(0xFFC2DCCE)else if(i%3==0)Color(0xFF586541)else c.accent
                val p=Offset(x,y)
                if(i%4==0) {
                    val r=(2+i%3).dp.toPx()
                    drawLine(color.copy(alpha=alpha),p-Offset(r,0f),p+Offset(r,0f),1.4.dp.toPx())
                    drawLine(color.copy(alpha=alpha),p-Offset(0f,r),p+Offset(0f,r),1.4.dp.toPx())
                } else drawCircle(color.copy(alpha=alpha),(1.2f+i%2).dp.toPx(),p)
            }
            // Uma passagem curta, seguida de vários segundos de céu tranquilo.
            if(active&&meteor<.12f) {
                val t=meteor/.12f
                val head=Offset(size.width*(.08f+.72f*t),size.height*(.07f+.20f*t))
                val tail=head-Offset(size.width*.13f,size.height*.036f)
                val color=if(dark)Color(0xFFEDE4BB)else Color(0xFF72623F)
                drawLine(Brush.linearGradient(listOf(Color.Transparent,color),tail,head),tail,head,2.dp.toPx(),StrokeCap.Round)
                drawCircle(color,2.5.dp.toPx(),head)
            }
        }
        Crossfade(active,Modifier.fillMaxSize(),label="tomato_scene") { fishing ->
            Box(Modifier.fillMaxSize().graphicsLayer {
                if(fishing) {translationY=sin(phase)*5.dp.toPx();rotationZ=sin(phase)*1.2f}
            }) {
                Image(painterResource(if(fishing)R.drawable.pomo_fishing else R.drawable.pomo_rest),
                    if(fishing)"Tomate astronauta pescando estrelas" else "Tomate astronauta descansando em Saturno",
                    Modifier.fillMaxSize(),contentScale=ContentScale.Fit)
                Canvas(Modifier.fillMaxSize()) {
                    // ContentScale.Fit para as duas artes 1536 × 1024. Mantém as âncoras em qualquer tela.
                    val w=min(size.width,size.height*1.5f);val h=w/1.5f
                    val left=(size.width-w)/2;val top=(size.height-h)/2
                    fun point(x:Float,y:Float)=Offset(left+x*w,top+y*h)
                    if(fishing) {
                        val tip=point(.741f,.107f)
                        val catch=point(.785f+sin(phase)*.014f,.39f+sin(phase)*.072f)
                        val line=Path().apply {
                            moveTo(tip.x,tip.y)
                            quadraticBezierTo(tip.x+w*.03f,catch.y-h*.09f,catch.x,catch.y)
                        }
                        drawPath(line,if(dark)Color(0xFFE7D399)else Color(0xFF887445),style=Stroke(1.4.dp.toPx()))
                        val radius=w*.042f
                        drawCircle(Color(0xFFFFC966).copy(alpha=.15f),radius*1.8f,catch)
                        drawCircle(Color(0xFFFFD37C).copy(alpha=.22f),radius*1.3f,catch)
                        val star=Path()
                        repeat(10) { i ->
                            val a=-PI/2+i*PI/5;val r=if(i%2==0)radius else radius*.47f
                            val x=catch.x+cos(a).toFloat()*r;val y=catch.y+sin(a).toFloat()*r
                            if(i==0)star.moveTo(x,y)else star.lineTo(x,y)
                        }
                        star.close();drawPath(star,Color(0xFFFFD777))
                        drawPath(star,Color(0xFFB58A36),style=Stroke(1.dp.toPx()))
                    } else {
                        // Reflexos percorrem os anéis; o personagem continua descansando.
                        rotate(-19f,point(.51f,.60f)) {
                            repeat(9) { i ->
                                val a=orbit+i*(2*PI/9).toFloat()
                                val p=point(.51f+cos(a)*.34f,.60f+sin(a)*.10f)
                                val col=if(i%3==0)Color(0xFF788657)else if(dark)Color(0xFFC7ECDA)else Color(0xFF72628B)
                                drawCircle(col.copy(alpha=.5f),2.8.dp.toPx(),p)
                                drawCircle(col.copy(alpha=.16f),5.dp.toPx(),p)
                            }
                        }
                    }
                }
            }
        }
    }
}
```

## app/src/main/java/com/example/ui/productivity/PomodoroScreen.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.productivity

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.productivity.*
import kotlinx.coroutines.delay
import java.util.Calendar

@Composable fun PomodoroScreen() {
    val context=LocalContext.current
    val store=remember { PomodoroStore.get(context) }
    val state by store.state.collectAsStateWithLifecycle()
    val c=calmColors()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var custom by rememberSaveable { mutableStateOf(false) }
    var credits by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var elapsed by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var wall by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var message by remember { mutableStateOf<String?>(null) }
    fun startTimer() {
        runCatching { PomodoroService.command(context,PomodoroService.START) }
            .onFailure { message="Não foi possível iniciar o cronômetro. ${it.localizedMessage.orEmpty()}" }
    }
    val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if(!granted) message="O cronômetro funciona no app. Permita notificações nas configurações do Android para ver o tempo fora dele."
        startTimer()
    }
    LaunchedEffect(state.running) {
        if(state.running) {
            runCatching { PomodoroService.command(context,PomodoroService.RESTORE) }
            while(true) { wall=System.currentTimeMillis();elapsed=SystemClock.elapsedRealtime();delay(250) }
        }
    }
    val remaining=remainingAt(state,wall,elapsed)
    val total=state.history.sumOf { it.durationMs }
    val progress=(1f-remaining.toFloat()/state.phaseDurationMs.coerceAtLeast(1)).coerceIn(0f,1f)
    val weeks=remember(state.history) { (6 downTo 0).map { ago ->
        val cal=Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR,-ago) }
        val key=dateLabel(cal.timeInMillis,"yyyy-MM-dd")
        val minutes=state.history.filter { dateLabel(it.finishedAt,"yyyy-MM-dd")==key }.sumOf { it.durationMs }/60_000f
        ChartPoint(dateLabel(cal.timeInMillis,"dd/MM"),minutes) } }
    // A paleta local colore superfícies; a tipografia e a preferência global continuam no MaterialTheme.
    CompositionLocalProvider(LocalContentColor provides c.ink) {
        BoxWithConstraints(Modifier.fillMaxSize().background(c.background)) {
            val largeClock=maxWidth>=600.dp
            LazyColumn(Modifier.fillMaxSize().testTag("pomodoro_screen"),contentPadding=PaddingValues(20.dp),
                horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(18.dp)) {
                item {
                    Column(Modifier.fillMaxWidth()) {
                        Text("Pomodoro",style=MaterialTheme.typography.displaySmall)
                        Text("Uma estrela de cada vez.",color=c.muted)
                    }
                }
                item { ProductivityTabs(tab,{tab=it},Modifier.fillMaxWidth()) }
                if(tab==0) {
                    item { PomodoroArtwork(state.running&&state.phase==PomodoroPhase.FOCUS,Modifier.fillMaxWidth().height(270.dp)) }
                    item {
                        Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)) {
                            Text(state.phase.label,style=MaterialTheme.typography.titleLarge,color=c.accent)
                            Text(formatTimer(remaining),style=MaterialTheme.typography.displayLarge.copy(
                                fontSize=if(largeClock)108.sp else 88.sp,lineHeight=if(largeClock)118.sp else 100.sp,
                                fontWeight=FontWeight.Bold,fontFeatureSettings="tnum"),maxLines=1,
                                modifier=Modifier.testTag("pomodoro_time"))
                            Text(if(state.paused)"Pausado" else if(state.running)"Em andamento" else "Pronto para começar",color=c.muted)
                            Text("${state.cycle.coerceAtMost(state.settings.cycles)} de ${state.settings.cycles} focos concluídos",
                                style=MaterialTheme.typography.bodySmall,color=c.muted)
                            if(state.settings.ambienceEnabled) Text("♫ ${AmbientPresets.get(state.settings.ambienceId).title}",
                                style=MaterialTheme.typography.labelMedium,color=c.accent)
                        }
                    }
                    item { CosmicWavyProgress(progress,state.running,Modifier.fillMaxWidth()) }
                    item {
                        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(20.dp)) {
                            FilledTonalIconButton(onClick={confirmReset=true},modifier=Modifier.size(56.dp),
                                colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=c.surface,contentColor=c.accent)) {
                                Icon(Icons.Outlined.RestartAlt,"Zerar etapa") }
                            FilledIconButton(onClick={
                                if(state.running) PomodoroService.command(context,PomodoroService.PAUSE)
                                else if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                                    permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                else startTimer()
                            },modifier=Modifier.size(84.dp).testTag("pomodoro_start"),
                                colors=IconButtonDefaults.filledIconButtonColors(containerColor=c.accent,contentColor=c.surface)) {
                                Icon(if(state.running)Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    if(state.running)"Pausar" else "Iniciar",Modifier.size(38.dp)) }
                            FilledTonalIconButton(onClick={PomodoroService.command(context,PomodoroService.SKIP)},modifier=Modifier.size(56.dp),
                                colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=c.surface,contentColor=c.accent)) {
                                Icon(Icons.Outlined.SkipNext,"Pular etapa sem registrar foco") }
                        }
                    }
                    item { Text("Só focos completos entram no total. Pular ou zerar não registra um pomodoro.",style=MaterialTheme.typography.bodySmall,color=c.muted) }
                }
                if(tab==1) {
                    item {
                        Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                            CalmCard(Modifier.weight(1f),c.lilac) { Text(state.history.size.toString(),style=MaterialTheme.typography.headlineLarge);Text("Pomodoros") }
                            CalmCard(Modifier.weight(1f),c.mint) { Text(formatStudyTime(total),style=MaterialTheme.typography.headlineLarge);Text("Tempo de foco") }
                        }
                    }
                    item { CalmCard(Modifier.fillMaxWidth()) {
                        Text("Últimos 7 dias",style=MaterialTheme.typography.titleLarge)
                        Text("Minutos de foco concluídos",style=MaterialTheme.typography.bodySmall,color=c.muted)
                        StudyChart(weeks,metricLabel="Minutos de foco por dia",unit="minutos de foco") } }
                    item { Text("Seu histórico",style=MaterialTheme.typography.titleLarge,modifier=Modifier.fillMaxWidth()) }
                    if(state.history.isEmpty()) item {Text("Seu primeiro foco concluído aparecerá aqui.",color=c.muted)}
                    items(state.history.sortedByDescending { it.finishedAt }.take(50),key={it.id}) { record ->
                        CalmCard(Modifier.fillMaxWidth()) {
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Icon(Icons.Outlined.CheckCircle,null,tint=c.accent);Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {Text("Foco concluído");Text(dateLabel(record.finishedAt),style=MaterialTheme.typography.bodySmall,color=c.muted)}
                                Text(formatStudyTime(record.durationMs)) }
                        }
                    }
                }
                if(tab==2) {
                    item {
                        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(c.sky,c.lilac,c.mint)),RoundedCornerShape(32.dp)).padding(24.dp)) {
                            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Outlined.Spa,null,Modifier.size(36.dp),tint=c.accent)
                                Text("Crie seu ambiente",style=MaterialTheme.typography.headlineMedium)
                                Text("Escolha um som e encontre seu ritmo.",color=c.muted) }
                        }
                    }
                    item {
                        CalmCard(Modifier.fillMaxWidth()) {
                            SettingSwitch("Som durante o foco","Ambiente contínuo, separado do alarme",state.settings.ambienceEnabled) {
                                store.configure(state.settings.copy(ambienceEnabled=it)) }
                            var volume by remember(state.settings.ambienceVolume) { mutableFloatStateOf(state.settings.ambienceVolume) }
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Icon(Icons.Outlined.VolumeUp,null,tint=c.accent);Spacer(Modifier.width(12.dp))
                                Text("Volume",Modifier.weight(1f));Text("${(volume*100).toInt()}%",color=c.muted) }
                            Slider(value=volume,onValueChange={volume=it},onValueChangeFinished={store.configure(state.settings.copy(ambienceVolume=volume))},
                                enabled=state.settings.ambienceEnabled,colors=SliderDefaults.colors(thumbColor=c.accent,activeTrackColor=c.accent))
                            Text("O ambiente toca durante o foco e para nas pausas. Usa o volume de mídia do aparelho.",style=MaterialTheme.typography.bodySmall,color=c.muted)
                        }
                    }
                    items(AmbientPresets.all.chunked(2),key={it.first().id}) { pair ->
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                            pair.forEach { preset -> AmbientSoundCard(preset,state.settings.ambienceId==preset.id,Modifier.weight(1f)) {
                                store.configure(state.settings.copy(ambienceId=preset.id)) } }
                        }
                    }
                    item { Text("Salões e biblioteca: paisagens sonoras inspiradas, com sons de natureza e leitura.",style=MaterialTheme.typography.bodySmall,color=c.muted) }
                    item {
                        CalmCard(Modifier.fillMaxWidth()) {
                            Text("Seu ciclo",style=MaterialTheme.typography.titleLarge)
                            val activeStage=state.running||state.paused
                            listOf(PomodoroSettings(),PomodoroSettings(50,10,20,4),PomodoroSettings(90,15,30,2)).forEach { preset ->
                                OutlinedButton(onClick={store.configure(state.settings.copy(focusMinutes=preset.focusMinutes,
                                    shortMinutes=preset.shortMinutes,longMinutes=preset.longMinutes,cycles=preset.cycles))},
                                    modifier=Modifier.fillMaxWidth()) {
                                    Text("${preset.focusMinutes} / ${preset.shortMinutes} / ${preset.longMinutes} min • ${preset.cycles} focos") } }
                            Text("Foco / pausa curta / pausa longa",style=MaterialTheme.typography.bodySmall,color=c.muted)
                            FilledTonalButton(onClick={custom=true},modifier=Modifier.fillMaxWidth().testTag("pomodoro_customize")) {
                                Icon(Icons.Outlined.Tune,null);Spacer(Modifier.width(8.dp));Text("Personalizar ciclo") }
                            Text("Atual: ${state.settings.focusMinutes} / ${state.settings.shortMinutes} / ${state.settings.longMinutes} min • ${state.settings.cycles} focos",style=MaterialTheme.typography.bodySmall)
                            if(activeStage)Text("As novas durações serão usadas na próxima etapa. Para aplicá-las agora, zere a etapa atual.",style=MaterialTheme.typography.bodySmall,color=c.muted)
                        }
                    }
                    item {
                        CalmCard(Modifier.fillMaxWidth(),c.blush) {
                            SettingSwitch("Alarme ao terminar","Toque curto na conclusão de cada etapa",state.settings.sounds) {
                                store.configure(state.settings.copy(sounds=it)) }
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                listOf("bell" to "Sino","soft" to "Suave").forEach { (id,name) ->
                                    FilterChip(selected=state.settings.sound==id,onClick={store.configure(state.settings.copy(sound=id));
                                        if(state.settings.sounds)PomodoroAudio.play(context,id)},label={Text(name)},leadingIcon={Icon(Icons.Outlined.NotificationsNone,null)}) } }
                            SettingSwitch("Avançar automaticamente","Iniciar foco e pausas em sequência",state.settings.autoAdvance) {
                                store.configure(state.settings.copy(autoAdvance=it)) }
                            Text("O contador aparece na notificação. Permita notificações no Android para acompanhar fora do app.",style=MaterialTheme.typography.bodySmall,color=c.muted)
                            TextButton(onClick={credits=true}) {Icon(Icons.Outlined.Info,null);Spacer(Modifier.width(8.dp));Text("Créditos dos sons")}
                        }
                    }
                }
                message?.let { text -> item {Text(text,color=MaterialTheme.colorScheme.error)} }
            }
        }
    }
    if(confirmReset) AlertDialog(onDismissRequest={confirmReset=false},icon={Icon(Icons.Outlined.RestartAlt,null)},
        title={Text("Zerar esta etapa?")},text={Text("O histórico permanece salvo. O foco incompleto não será contado.")},
        confirmButton={TextButton(onClick={PomodoroService.command(context,PomodoroService.RESET);confirmReset=false}) {Text("Zerar")}},
        dismissButton={TextButton(onClick={confirmReset=false}) {Text("Cancelar")}})
    if(custom) PomodoroSettingsDialog(state.settings,onDismiss={custom=false},onSave={store.configure(it);custom=false;message="Ciclo salvo: ${it.focusMinutes} / ${it.shortMinutes} / ${it.longMinutes} min • ${it.cycles} focos"})
    if(credits) {
        val text=remember {context.assets.open("pomodoro_sound_credits.txt").bufferedReader().use {it.readText()}}
        AlertDialog(onDismissRequest={credits=false},icon={Icon(Icons.Outlined.Info,null)},title={Text("Créditos dos sons")},
            text={LazyColumn(Modifier.heightIn(max=360.dp)) {item {Text(text,style=MaterialTheme.typography.bodySmall)}}},
            confirmButton={TextButton(onClick={credits=false}) {Text("Fechar")}})
    }
}

@Composable private fun SettingSwitch(title:String,detail:String,checked:Boolean,onChange:(Boolean)->Unit) {
    val c=calmColors()
    Row(verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {Text(title,style=MaterialTheme.typography.titleMedium);Text(detail,style=MaterialTheme.typography.bodySmall,color=c.muted)}
        Switch(checked,onChange)
    }
}

@Composable private fun AmbientSoundCard(preset:AmbientPreset,selected:Boolean,modifier:Modifier,onSelect:()->Unit) {
    val c=calmColors();val color=listOf(c.lilac,c.sky,c.mint,c.blush)[preset.palette]
    Card(onClick=onSelect,modifier=modifier,shape=RoundedCornerShape(28.dp),
        colors=CardDefaults.cardColors(containerColor=color,contentColor=c.ink),
        border=if(selected)androidx.compose.foundation.BorderStroke(2.dp,c.accent)else null) {
        Column(Modifier.padding(18.dp).heightIn(min=140.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            val icon=when(preset.id) {"clock"->Icons.Outlined.Schedule;"wind"->Icons.Outlined.Air;"rain"->Icons.Outlined.WaterDrop
                "storm"->Icons.Outlined.Thunderstorm;"fire","gryffindor"->Icons.Outlined.LocalFireDepartment
                "library"->Icons.Outlined.LocalLibrary;else->Icons.Outlined.AutoAwesome}
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                Icon(icon,null,Modifier.size(28.dp),tint=c.accent);Spacer(Modifier.weight(1f))
                if(selected)Icon(Icons.Outlined.CheckCircle,"Som selecionado",tint=c.accent) }
            Text(preset.title,style=MaterialTheme.typography.titleMedium)
            Text(preset.detail,style=MaterialTheme.typography.bodySmall,color=c.muted)
        }
    }
}

fun formatStudyTime(ms: Long): String { val minutes=ms/60_000;return if(minutes>=60) "${minutes/60}h ${minutes%60}min" else "${minutes}min" }

@Composable private fun PomodoroSettingsDialog(current: PomodoroSettings,onDismiss:()->Unit,onSave:(PomodoroSettings)->Unit) {
    var focus by rememberSaveable {mutableStateOf(current.focusMinutes.toString())}
    var short by rememberSaveable {mutableStateOf(current.shortMinutes.toString())}
    var long by rememberSaveable {mutableStateOf(current.longMinutes.toString())}
    var cycles by rememberSaveable {mutableStateOf(current.cycles.toString())}
    var error by remember {mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,icon={Icon(Icons.Outlined.Tune,null)},title={Text("Seu ciclo")},
        text={Column(Modifier.heightIn(max=360.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(focus,{focus=it.filter { ch -> ch in '0'..'9' }.take(3);error=false},label={Text("Foco (1–180 min)")},modifier=Modifier.testTag("custom_focus"),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            OutlinedTextField(short,{short=it.filter { ch -> ch in '0'..'9' }.take(2);error=false},label={Text("Pausa curta (1–90 min)")},modifier=Modifier.testTag("custom_short"),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            OutlinedTextField(long,{long=it.filter { ch -> ch in '0'..'9' }.take(2);error=false},label={Text("Pausa longa (1–90 min)")},modifier=Modifier.testTag("custom_long"),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            OutlinedTextField(cycles,{cycles=it.filter { ch -> ch in '0'..'9' }.take(2);error=false},label={Text("Focos por ciclo (1–12)")},modifier=Modifier.testTag("custom_cycles"),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            if(error) Text("Confira os limites de cada campo.",color=MaterialTheme.colorScheme.error)
        }},confirmButton={TextButton(onClick={
            val settings=current.copy(focusMinutes=focus.toIntOrNull()?:0,shortMinutes=short.toIntOrNull()?:0,
                longMinutes=long.toIntOrNull()?:0,cycles=cycles.toIntOrNull()?:0)
            if(settings.valid()) onSave(settings) else error=true
        },modifier=Modifier.testTag("custom_save")) {Text("Salvar")}},dismissButton={TextButton(onClick=onDismiss) {Text("Cancelar")}})
}
```

## app/src/main/java/com/example/ui/productivity/ProductivityDesign.kt

```kotlin
package com.example.ui.productivity

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

data class CalmColors(val background:Color,val surface:Color,val ink:Color,val muted:Color,
    val lilac:Color,val sky:Color,val mint:Color,val blush:Color,val accent:Color,val border:Color)

/** Paleta da referência de meditação, preservando contraste nos dois temas. */
@Composable fun calmColors():CalmColors {
    val dark=com.example.ui.theme.LocalKepleraeDarkTheme.current
    return if(dark) CalmColors(Color(0xFF15161D),Color(0xFF23252F),Color(0xFFF4F0FF),Color(0xFFC0BDCF),
        Color(0xFF38314E),Color(0xFF273D4C),Color(0xFF283F3A),Color(0xFF49363F),Color(0xFFC9BAFF),Color(0xFF494551))
    else CalmColors(Color(0xFFF3F4F8),Color(0xFFFCFCFF),Color(0xFF303041),Color(0xFF636277),
        Color(0xFFE8E0F7),Color(0xFFDDECF6),Color(0xFFDDF3ED),Color(0xFFF5E0E9),Color(0xFF7163A7),Color.White)
}

@Composable fun CalmCard(modifier:Modifier=Modifier,color:Color=calmColors().surface,
    content:@Composable ColumnScope.()->Unit) {
    val c=calmColors()
    Surface(modifier.shadow(9.dp,RoundedCornerShape(30.dp),ambientColor=c.accent.copy(alpha=.08f),
        spotColor=c.accent.copy(alpha=.10f)),shape=RoundedCornerShape(30.dp),color=color,
        border=BorderStroke(1.dp,c.border.copy(alpha=.72f))) {
        Column(Modifier.padding(22.dp),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)
    }
}

/** Uma única cápsula com seleção sólida; os rótulos continuam acessíveis. */
@Composable fun ProductivityTabs(selected:Int,onSelect:(Int)->Unit,modifier:Modifier=Modifier) {
    val c=calmColors()
    val titles=listOf("Foco","Progresso","Ajustes")
    val icons=listOf(Icons.Outlined.Timer,Icons.Outlined.BarChart,Icons.Outlined.Tune)
    Surface(modifier,shape=RoundedCornerShape(26.dp),color=c.surface,
        border=BorderStroke(1.dp,c.border),shadowElevation=3.dp) {
        Row(Modifier.selectableGroup().padding(6.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
            titles.forEachIndexed { index,title ->
                val bg by animateColorAsState(if(index==selected)c.lilac else Color.Transparent,label="focus_tab_color")
                Row(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(bg)
                    .selectable(index==selected,onClick={onSelect(index)},role=Role.Tab).padding(vertical=13.dp),
                    horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically) {
                    Icon(icons[index],null,Modifier.size(18.dp),tint=if(index==selected)c.accent else c.muted)
                    Spacer(Modifier.width(5.dp));Text(title,style=MaterialTheme.typography.labelLarge,maxLines=1,color=c.ink)
                }
            }
        }
    }
}

/** Onda com amplitude constante: permanece visível até no primeiro segundo do foco. */
@Composable fun CosmicWavyProgress(progress:Float,running:Boolean,modifier:Modifier=Modifier) {
    val c=calmColors()
    val phase=if(running) {
        val loop=rememberInfiniteTransition(label="pomodoro_wave")
        val value by loop.animateFloat(0f,6.283185f,infiniteRepeatable(tween(1800,easing=LinearEasing)),label="wave_phase")
        value
    } else 0f
    Canvas(modifier.height(28.dp).semantics { progressBarRangeInfo=ProgressBarRangeInfo(progress.coerceIn(0f,1f),0f..1f) }) {
        val path=Path();val wave=32.dp.toPx();val amplitude=4.dp.toPx()
        var x=0f
        while(x<=size.width+2f) {
            val y=size.height/2+sin(x/wave*(2*PI).toFloat()-phase)*amplitude
            if(x==0f)path.moveTo(x,y)else path.lineTo(x,y)
            x+=2f
        }
        drawPath(path,c.accent.copy(alpha=.20f),style=Stroke(3.dp.toPx(),cap=StrokeCap.Round))
        clipRect(right=size.width*progress.coerceIn(0f,1f)) {
            drawPath(path,c.accent,style=Stroke(4.dp.toPx(),cap=StrokeCap.Round))
        }
        val end=size.width*progress.coerceIn(0f,1f)
        drawCircle(c.accent,3.dp.toPx(),Offset(end,size.height/2+sin(end/wave*(2*PI).toFloat()-phase)*amplitude))
    }
}
```

## app/src/main/java/com/example/ui/productivity/QuestionsScreen.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui.productivity

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.productivity.*
import com.example.ui.components.HelpTooltip
import java.util.Locale

@Composable fun QuestionsScreen() {
    val context=LocalContext.current
    val store=remember { QuestionStore.get(context) }
    val state by store.state.collectAsStateWithLifecycle()
    val c=calmColors()
    var subjectId by rememberSaveable { mutableStateOf<String?>(null) }
    var create by rememberSaveable { mutableStateOf(false) }
    var adding by rememberSaveable { mutableStateOf(false) }
    var deleteId by remember { mutableStateOf<String?>(null) }
    var deleteSubjectId by rememberSaveable { mutableStateOf<String?>(null) }
    var confirmReset by rememberSaveable { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val records=remember(state.records,subjectId) { state.records.filter { subjectId==null||it.subjectId==subjectId } }
    val totals=remember(records) { questionTotals(records) }
    val daily=remember(records) { cumulativeQuestionDays(records) }
    val colors=questionSeriesColors()
    val title=state.subjects.firstOrNull {it.id==subjectId}?.name ?: "Todas as matérias"
    CompositionLocalProvider(LocalContentColor provides c.ink) {
        LazyColumn(Modifier.fillMaxSize().background(c.background).testTag("questions_screen"),contentPadding=PaddingValues(20.dp),
            verticalArrangement=Arrangement.spacedBy(20.dp)) {
            item {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Questões",style=MaterialTheme.typography.displaySmall)
                        Text("Cada registro conta sua evolução.",color=c.muted) }
                    FilledTonalIconButton(onClick={create=true}, modifier=Modifier.testTag("questions_new_block")) { Icon(Icons.Outlined.CreateNewFolder,"Criar bloco de matéria") }
                    Box {
                        IconButton(onClick={menu=true}, modifier=Modifier.testTag("questions_menu")) { Icon(Icons.Outlined.MoreVert,"Opções de questões") }
                        DropdownMenu(expanded=menu,onDismissRequest={menu=false}) {
                            DropdownMenuItem(text={Text("Zerar tudo",color=MaterialTheme.colorScheme.error)},
                                leadingIcon={Icon(Icons.Outlined.DeleteSweep,null)},
                                enabled=state.subjects.isNotEmpty()||state.records.isNotEmpty(),
                                onClick={menu=false;confirmReset=true},modifier=Modifier.testTag("questions_reset"))
                        }
                    }
                }
            }
            item {
                Surface(shape=RoundedCornerShape(26.dp),color=c.surface,border=BorderStroke(1.dp,c.border),shadowElevation=3.dp) {
                    LazyRow(contentPadding=PaddingValues(horizontal=10.dp,vertical=4.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        item { FilterChip(selected=subjectId==null,onClick={subjectId=null},label={Text("Geral")}) }
                        items(state.subjects,key={it.id}) { s -> FilterChip(selected=subjectId==s.id,onClick={subjectId=s.id},label={Text(s.name)}) }
                        item { AssistChip(onClick={create=true},label={Text("Nova matéria")},leadingIcon={Icon(Icons.Outlined.Add,null)}) }
                    }
                }
            }
            item {
                // Duas superfícies deslocadas reproduzem a profundidade da referência, sem números fictícios.
                Box(Modifier.fillMaxWidth().padding(bottom=14.dp)) {
                    Surface(Modifier.matchParentSize().padding(horizontal=22.dp).offset(y=14.dp),
                        shape=RoundedCornerShape(32.dp),color=c.surface.copy(alpha=.55f),shadowElevation=2.dp) {}
                    CalmCard(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {Text("Seu desempenho",style=MaterialTheme.typography.titleLarge)
                                Text(title,style=MaterialTheme.typography.bodySmall,color=c.muted)}
                            HelpTooltip("Como calculamos","Taxa = soma de acertos ÷ soma de questões × 100. As três curvas mostram os totais acumulados por dia. O filtro é aplicado a todos os cartões, curvas e registros.") }
                        HorizontalDivider(color=c.border)
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            DashboardMetric("Questões",totals.total,colors[0],Modifier.weight(1f))
                            DashboardMetric("Acertos",totals.correct,colors[1],Modifier.weight(1f))
                            DashboardMetric("Erros",totals.wrong,colors[2],Modifier.weight(1f)) }
                        QuestionEvolutionChart(daily)
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                            Text("${records.size} registros • ${daily.size} dias",style=MaterialTheme.typography.labelMedium,color=c.muted)
                            Text("Acerto: ${if(totals.total==0L)"—" else String.format(Locale("pt","BR"),"%.1f%%",totals.accuracy)}",
                                style=MaterialTheme.typography.labelLarge,color=colors[1]) }
                    }
                }
            }
            item {
                FilledTonalButton(onClick={if(state.subjects.isEmpty())create=true else adding=true},
                    modifier=Modifier.fillMaxWidth().heightIn(min=56.dp),
                    colors=ButtonDefaults.filledTonalButtonColors(containerColor=c.lilac,contentColor=c.ink)) {
                    Icon(Icons.Outlined.Calculate,null);Spacer(Modifier.width(8.dp));Text("Registrar e calcular") }
            }
            if(state.subjects.isNotEmpty()) {
                item {Text("Seus blocos",style=MaterialTheme.typography.headlineSmall)}
                items(state.subjects.chunked(2),key={it.first().id}) { pair ->
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        pair.forEachIndexed { index,s ->
                            val t=questionTotals(state.records.filter {it.subjectId==s.id})
                            Card(onClick={subjectId=s.id},modifier=Modifier.weight(1f),shape=RoundedCornerShape(28.dp),
                                colors=CardDefaults.cardColors(containerColor=if(index==0)c.sky else c.mint,contentColor=c.ink),
                                border=if(subjectId==s.id)BorderStroke(2.dp,c.accent)else null) {
                                Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                                        Icon(Icons.Outlined.Folder,null,tint=c.accent)
                                        Spacer(Modifier.weight(1f))
                                        IconButton(onClick={deleteSubjectId=s.id}, modifier=Modifier.testTag("delete_block_${s.id}")) {
                                            Icon(Icons.Outlined.DeleteOutline,"Apagar bloco ${s.name}",tint=c.muted)
                                        }
                                    }
                                    Text(s.name,style=MaterialTheme.typography.titleMedium)
                                    Text("${t.total} questões",style=MaterialTheme.typography.bodySmall,color=c.muted)
                                    Text(if(t.total==0L)"Sem registros" else String.format(Locale("pt","BR"),"%.1f%% de acerto",t.accuracy),
                                        style=MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                        if(pair.size==1)Spacer(Modifier.weight(1f))
                    }
                }
            }
            item {Text("Histórico",style=MaterialTheme.typography.headlineSmall)}
            if(records.isEmpty()) item {CalmCard(Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Insights,null,tint=c.accent)
                Text("Seu próximo passo começa aqui.",style=MaterialTheme.typography.titleMedium)
                Text("Crie uma matéria e registre sua primeira sessão de questões.",color=c.muted) } }
            items(records.sortedByDescending {it.recordedAt},key={it.id}) { r ->
                val name=state.subjects.firstOrNull {it.id==r.subjectId}?.name ?: "Matéria"
                val percent=100.0*r.correct/(r.correct.toLong()+r.wrong)
                CalmCard(Modifier.fillMaxWidth().animateItem()) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                            Text(name,style=MaterialTheme.typography.titleMedium)
                            Text(dateLabel(r.recordedAt),style=MaterialTheme.typography.labelMedium,color=c.muted)
                            Text("${r.correct} acertos • ${r.wrong} erros • ${String.format(Locale("pt","BR"),"%.1f%%",percent)}") }
                        IconButton(onClick={deleteId=r.id}) {Icon(Icons.Outlined.DeleteOutline,"Excluir registro")}
                    }
                }
            }
        }
    }
    if(create) {
        var name by rememberSaveable { mutableStateOf("") };var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(onDismissRequest={create=false},icon={Icon(Icons.Outlined.CreateNewFolder,null)},title={Text("Nova matéria")},
            text={Column { OutlinedTextField(name,{name=it.take(80);error=null},label={Text("Nome do bloco")},singleLine=true)
                error?.let { Text(it,color=MaterialTheme.colorScheme.error) } }},
            confirmButton={TextButton(onClick={runCatching { store.createSubject(name) }.onSuccess { subjectId=it;create=false }
                .onFailure { error=it.message }}) {Text("Criar")}},dismissButton={TextButton(onClick={create=false}) {Text("Cancelar")}})
    }
    if(adding) {
        var chosen by rememberSaveable { mutableStateOf(subjectId ?: state.subjects.first().id) }
        var correct by rememberSaveable { mutableStateOf("") };var wrong by rememberSaveable { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(onDismissRequest={adding=false},icon={Icon(Icons.Outlined.Calculate,null)},title={Text("Registrar questões")},
            text={Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
                LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)) { items(state.subjects) { s ->
                    FilterChip(selected=chosen==s.id,onClick={chosen=s.id},label={Text(s.name)}) } }
                OutlinedTextField(correct,{correct=it.take(7);error=null},label={Text("Acertos")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                OutlinedTextField(wrong,{wrong=it.take(7);error=null},label={Text("Erros")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                Text("Data: ${dateLabel(System.currentTimeMillis())}",style=MaterialTheme.typography.bodySmall)
                error?.let { Text(it,color=MaterialTheme.colorScheme.error) }
            }},confirmButton={TextButton(onClick={
                val c=correct.toIntOrNull();val w=wrong.toIntOrNull()
                if(!validQuestionCounts(c,w)) error="Use inteiros de 0 a 1.000.000. O total deve ser maior que zero."
                else { store.add(chosen,c!!,w!!);adding=false }
            }) {Text("Calcular e salvar")}},dismissButton={TextButton(onClick={adding=false}) {Text("Cancelar")}})
    }
    if(deleteId!=null) AlertDialog(onDismissRequest={deleteId=null},icon={Icon(Icons.Outlined.DeleteOutline,null)},
        title={Text("Excluir este registro?")},text={Text("Os totais e os gráficos serão recalculados.")},
        confirmButton={TextButton(onClick={store.deleteRecord(deleteId!!);deleteId=null}) {Text("Excluir")}},
        dismissButton={TextButton(onClick={deleteId=null}) {Text("Cancelar")}})
    deleteSubjectId?.let { id ->
        val block=state.subjects.firstOrNull { it.id==id }
        val count=state.records.count { it.subjectId==id }
        AlertDialog(onDismissRequest={deleteSubjectId=null},icon={Icon(Icons.Outlined.DeleteOutline,null)},
            title={Text("Apagar ${block?.name ?: "bloco"}?")},
            text={Text("O bloco e seus $count registros serão apagados. Os totais e gráficos serão recalculados. Essa ação não pode ser desfeita.")},
            confirmButton={TextButton(onClick={store.deleteSubject(id);if(subjectId==id)subjectId=null;deleteSubjectId=null},
                modifier=Modifier.testTag("confirm_delete_block")) {Text("Apagar bloco")}},
            dismissButton={TextButton(onClick={deleteSubjectId=null}) {Text("Cancelar")}})
    }
    if(confirmReset) AlertDialog(onDismissRequest={confirmReset=false},icon={Icon(Icons.Outlined.DeleteSweep,null)},
        title={Text("Zerar todas as questões?")},
        text={Text("Todos os blocos e registros de questões serão apagados. Esta ação não pode ser desfeita. Materiais, notas e Pomodoro permanecem salvos.")},
        confirmButton={TextButton(onClick={store.resetAll();subjectId=null;confirmReset=false},
            modifier=Modifier.testTag("confirm_reset_questions")) {Text("Zerar tudo")}},
        dismissButton={TextButton(onClick={confirmReset=false}) {Text("Cancelar")}})
}

@Composable private fun DashboardMetric(label:String,value:Long,color:Color,modifier:Modifier) {
    val c=calmColors()
    Column(modifier,verticalArrangement=Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(color,RoundedCornerShape(50)));Spacer(Modifier.width(5.dp))
            Text(label,style=MaterialTheme.typography.labelMedium,color=c.muted) }
        Text(value.toString(),style=MaterialTheme.typography.headlineSmall,maxLines=1)
    }
}
```

## app/src/main/java/com/example/ui/productivity/StudyCharts.kt

```kotlin
package com.example.ui.productivity

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

data class ChartPoint(val label: String, val primary: Float, val secondary: Float = 0f)
fun dateLabel(time: Long, pattern: String="dd/MM HH:mm"): String=SimpleDateFormat(pattern,Locale("pt","BR")).format(Date(time))

/** Valores reais, sem dados de demonstração; descrição acessível contém todos os pontos. */
@Composable fun StudyChart(points: List<ChartPoint>, percent: Boolean=false, modifier: Modifier=Modifier,
    metricLabel: String = if(percent) "Acertos por dia" else "Acertos e erros por dia", unit: String = "acertos") {
    val primary=MaterialTheme.colorScheme.primary
    val secondary=MaterialTheme.colorScheme.error
    val grid=MaterialTheme.colorScheme.outlineVariant
    if(points.isEmpty()) { Text("Seus registros aparecerão aqui.",color=MaterialTheme.colorScheme.onSurfaceVariant);return }
    val shown=points.takeLast(14)
    val max=if(percent) 100f else shown.maxOf { it.primary+it.secondary }.coerceAtLeast(1f)
    Column(modifier) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(if(percent) "100%" else max.toInt().toString(),style=MaterialTheme.typography.labelSmall)
            Text(metricLabel,style=MaterialTheme.typography.labelSmall)
        }
        Canvas(Modifier.fillMaxWidth().height(156.dp).padding(vertical=10.dp)
            .semantics { contentDescription=shown.joinToString("; ") {
                "${it.label}: ${it.primary}${if(percent) "%" else " $unit"}" + if(!percent&&it.secondary>0) ", ${it.secondary} erros" else ""
            } }) {
            for(i in 0..4) {
                val y=size.height*i/4
                drawLine(grid,Offset(0f,y),Offset(size.width,y),1.dp.toPx())
            }
            if(percent) {
                val line=Path()
                shown.forEachIndexed { i,p ->
                    val x=if(shown.size==1) size.width/2 else size.width*i/(shown.size-1)
                    val y=size.height*(1-p.primary.coerceIn(0f,100f)/100f)
                    if(i==0) line.moveTo(x,y) else line.lineTo(x,y)
                }
                drawPath(line,primary,style=Stroke(3.dp.toPx()))
                shown.forEachIndexed { i,p ->
                    val x=if(shown.size==1) size.width/2 else size.width*i/(shown.size-1)
                    drawCircle(primary,4.dp.toPx(),Offset(x,size.height*(1-p.primary.coerceIn(0f,100f)/100f)))
                }
            } else {
                val cell=size.width/shown.size;val bar=cell*.62f
                shown.forEachIndexed { i,p ->
                    val h=size.height*p.primary/max;val e=size.height*p.secondary/max
                    val x=cell*i+(cell-bar)/2
                    drawRect(primary,Offset(x,size.height-h),Size(bar,h))
                    drawRect(secondary,Offset(x,size.height-h-e),Size(bar,e))
                }
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(shown.first().label,style=MaterialTheme.typography.labelSmall)
            Text(shown.last().label,style=MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable fun StatTile(label: String, value: String, modifier: Modifier=Modifier) {
    Card(modifier,colors=CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Text(value,style=MaterialTheme.typography.headlineSmall)
            Text(label,style=MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable fun questionSeriesColors():List<androidx.compose.ui.graphics.Color> {
    val dark=calmColors().background.luminance()<.35f
    return if(dark)listOf(androidx.compose.ui.graphics.Color(0xFF94B9F5),androidx.compose.ui.graphics.Color(0xFF82CCAB),androidx.compose.ui.graphics.Color(0xFFF0A19A))
    else listOf(androidx.compose.ui.graphics.Color(0xFF456FB4),androidx.compose.ui.graphics.Color(0xFF31735B),androidx.compose.ui.graphics.Color(0xFFB95450))
}

/** Três séries reais e acumuladas. Sem média de percentuais ou dados de demonstração. */
@Composable fun QuestionEvolutionChart(points:List<com.example.data.productivity.CumulativeQuestionDay>) {
    val c=calmColors();val colors=questionSeriesColors()
    if(points.isEmpty()) {
        Box(Modifier.fillMaxWidth().height(160.dp),contentAlignment=androidx.compose.ui.Alignment.Center) {
            Text("O gráfico começa no primeiro registro.",style=MaterialTheme.typography.bodyMedium,color=c.muted) }
        return
    }
    val shown=points.takeLast(14);val max=shown.maxOf {it.total}.coerceAtLeast(1).toFloat()
    val description=shown.joinToString("; ") { "${dateLabel(it.recordedAt,"dd/MM/yyyy")}: total ${it.total}, acertos ${it.correct}, erros ${it.wrong}" }
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("Evolução acumulada • escala 0–${shown.maxOf {it.total}}",style=MaterialTheme.typography.labelSmall,color=c.muted)
        Canvas(Modifier.fillMaxWidth().height(178.dp).padding(8.dp).semantics {contentDescription=description}) {
            for(i in 0..3) {
                val y=size.height*i/3
                drawLine(c.muted.copy(alpha=.12f),Offset(0f,y),Offset(size.width,y),1.dp.toPx()) }
            listOf<(com.example.data.productivity.CumulativeQuestionDay)->Long>({it.total},{it.correct},{it.wrong}).forEachIndexed { series,value ->
                val line=Path()
                shown.forEachIndexed { index,p ->
                    val x=if(shown.size==1)size.width/2 else size.width*index/(shown.size-1)
                    val y=size.height*(1-value(p).toFloat()/max)
                    if(index==0)line.moveTo(x,y)else line.lineTo(x,y)
                }
                drawPath(line,colors[series],style=Stroke(2.5.dp.toPx(),cap=androidx.compose.ui.graphics.StrokeCap.Round))
                shown.forEachIndexed { index,p ->
                    val x=if(shown.size==1)size.width/2 else size.width*index/(shown.size-1)
                    val y=size.height*(1-value(p).toFloat()/max)
                    drawCircle(c.surface,4.5.dp.toPx(),Offset(x,y))
                    drawCircle(colors[series],3.dp.toPx(),Offset(x,y)) }
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(dateLabel(shown.first().recordedAt,"dd/MM"),style=MaterialTheme.typography.labelSmall,color=c.muted)
            Text(dateLabel(shown.last().recordedAt,"dd/MM"),style=MaterialTheme.typography.labelSmall,color=c.muted) }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(16.dp)) {
            listOf("Total","Acertos","Erros").forEachIndexed { i,label ->
                Text("● $label",style=MaterialTheme.typography.labelMedium,color=colors[i]) }
        }
    }
}
```

## app/src/main/java/com/example/ui/profile/ProfileScreen.kt

```kotlin
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalSharedTransitionApi::class)
package com.example.ui.profile

import android.os.Build
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.example.data.auth.GoogleUser
import com.example.data.repository.StudyState
import com.example.data.repository.ThemeMode
import com.example.ui.components.SharedMotion
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable fun GoogleAvatar(user: GoogleUser?, modifier: Modifier = Modifier) {
    val placeholder = rememberVectorPainter(Icons.Outlined.Person)
    AsyncImage(model = ImageRequest.Builder(LocalContext.current).data(user?.photoUrl)
        .crossfade(true).build(), placeholder = placeholder, error = placeholder,
        fallback = placeholder, contentDescription = "Foto da conta Google",
        contentScale = ContentScale.Crop, modifier = modifier.clip(CircleShape))
}

@Composable fun ProfileButton(user: GoogleUser?, motion: SharedMotion, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer,
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.surface.copy(alpha = .8f)),
        modifier = motion.bounds("profile-container").size(56.dp).testTag("profile_open")) {
        GoogleAvatar(user, motion.element("profile-avatar").fillMaxSize().padding(3.dp))
    }
}

@Composable fun ProfileScreen(user: GoogleUser?, state: StudyState, motion: SharedMotion,
    onTheme: (ThemeMode) -> Unit, onDynamicColor: (Boolean) -> Unit,
    onConfigureDrive: () -> Unit, onSignOut: () -> Unit,
    onBack: () -> Unit = {}, onAppearance: () -> Unit = {},
    backupContent: @Composable () -> Unit = {}) {
    var confirmExit by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentAlignment = Alignment.TopCenter) {
        Surface(shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.surfaceContainerLow,
            modifier = motion.bounds("profile-container").widthIn(max = 620.dp).fillMaxWidth()) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("profile_back")) { Icon(Icons.AutoMirrored.Filled.ArrowBack,"Voltar") }
                    IconButton(onClick = onAppearance, modifier = Modifier.testTag("settings")) {
                        Icon(Icons.Outlined.Tune,"Preferências")
                    }
                }
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(3.dp, MaterialTheme.colorScheme.primary.copy(alpha = .3f))) {
                    GoogleAvatar(user, motion.element("profile-avatar").size(112.dp).padding(5.dp))
                }
                Text(user?.displayName?.takeIf { it.isNotBlank() } ?: "Minha conta",
                    style = MaterialTheme.typography.headlineMedium, modifier = Modifier.testTag("profile_name"))
                if (user != null) Text(user.email, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Seu espaço, do seu jeito.", style = MaterialTheme.typography.titleMedium)
                // O destaque representa a preferência, incluindo o modo automático.
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)) {
                    ThemeOrb(dark = false, selected = state.theme == ThemeMode.LIGHT, modifier = Modifier.weight(1f)) { onTheme(ThemeMode.LIGHT) }
                    ThemeOrb(dark = true, selected = state.theme == ThemeMode.DARK, modifier = Modifier.weight(1f)) { onTheme(ThemeMode.DARK) }
                }
                FilterChip(selected = state.theme == ThemeMode.SYSTEM,
                    onClick = { onTheme(ThemeMode.SYSTEM) },
                    label = { Text("Acompanhar o sistema") },
                    leadingIcon = { Icon(Icons.Outlined.Devices, null) },
                    modifier = Modifier.testTag("profile_theme_SYSTEM"))
                HorizontalDivider()
                backupContent()
                HorizontalDivider()
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Cores do seu Android", style = MaterialTheme.typography.titleMedium)
                        Text(if (Build.VERSION.SDK_INT >= 31) "Combine com o papel de parede."
                            else "Paleta Kepleræ neste Android.", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = state.dynamicColor, onCheckedChange = onDynamicColor,
                        enabled = Build.VERSION.SDK_INT >= 31)
                }
                OutlinedButton(onClick = onConfigureDrive, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.Cloud, null); Spacer(Modifier.width(8.dp)); Text("Google Drive")
                }
                FilledTonalButton(onClick = { confirmExit = true }, modifier = Modifier.fillMaxWidth().testTag("sign_out")) {
                    Icon(Icons.AutoMirrored.Outlined.Logout, null)
                    Spacer(Modifier.width(8.dp)); Text("Desconectar")
                }
                Text("Kepleræ 1.0.1 · Madox Fênix", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (confirmExit) AlertDialog(onDismissRequest = { confirmExit = false },
        icon = { Icon(Icons.AutoMirrored.Outlined.Logout, null) },
        title = { Text("Desconectar do Kepleræ?") },
        text = { Text("Você voltará à tela de login. Favoritos, progresso e tema ficam salvos neste aparelho.") },
        confirmButton = { TextButton(onClick = { confirmExit = false; onSignOut() },
            modifier = Modifier.testTag("confirm_sign_out")) { Text("Desconectar") } },
        dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Cancelar") } })
}

/** Sol e lua com volume e brilho, inspirados na referência Cycle of Vitality. */
@Composable private fun ThemeOrb(dark: Boolean, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var tap by remember { mutableIntStateOf(0) }
    val pulse = remember { Animatable(0f) }
    LaunchedEffect(tap) {
        if (tap > 0) {
            pulse.snapTo(0f)
            pulse.animateTo(1f, tween(1100))
            pulse.snapTo(0f)
        }
    }
    val scale by animateFloatAsState(if (selected) 1f else .90f,
        animationSpec = spring(dampingRatio = .8f), label = "theme_selection")
    Surface(onClick = { tap++; onClick() }, shape = MaterialTheme.shapes.extraLarge,
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
        border = BorderStroke(if (selected) 2.dp else 1.dp,
            if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
        shadowElevation = if (selected) 8.dp else 0.dp,
        modifier = modifier.widthIn(max = 128.dp).aspectRatio(1f).graphicsLayer { scaleX = scale; scaleY = scale }
            .testTag(if (dark) "profile_theme_DARK" else "profile_theme_LIGHT")
            .then(Modifier.themeSemantics(dark, selected))) {
        Canvas(Modifier.fillMaxSize().padding(20.dp)) {
            val progress = pulse.value
            val motion = sin(PI * progress).toFloat()
            val r = size.minDimension * .28f
            val colors = if (dark) listOf(Color(0xFFE8FFA5), Color(0xFF5DAC68), Color(0xFF205D44))
                else listOf(Color(0xFFFFF2A8), Color(0xFFFFB247), Color(0xFFE5732C))
            drawCircle(Brush.radialGradient(listOf(colors[1].copy(alpha = .26f), Color.Transparent),
                radius = size.minDimension * .52f), size.minDimension * .52f)
            val lighting = Brush.radialGradient(colors, center = center - Offset(r * .5f, r * .5f), radius = r * 2f)
            if (dark) {
                val outer = Path().apply { addOval(androidx.compose.ui.geometry.Rect(center - Offset(r * 1.3f, r * 1.3f),
                    center + Offset(r * 1.3f, r * 1.3f))) }
                val hole = Path().apply { addOval(androidx.compose.ui.geometry.Rect(
                    center + Offset(-r * .1f, -r * 1.55f), center + Offset(r * 1.7f, r * .85f))) }
                val crescent = Path.combine(PathOperation.Difference, outer, hole)
                drawPath(crescent, lighting)
                listOf(Offset(1.25f, -.9f), Offset(.4f, -1.4f), Offset(1.5f, .35f)).forEachIndexed { i, star ->
                    val blink = (1f - .65f * motion * (.5f + .5f * sin(progress * 6 * PI + i))).toFloat()
                    val point = center + star * r
                    val radius = r * (if (i == 0) .13f else .08f) * (1f + motion * .22f)
                    drawCircle(Color(0xFFE6FFC0).copy(alpha = blink), radius, point)
                    drawLine(Color(0xFFE6FFC0).copy(alpha = blink * motion),
                        point - Offset(radius * 2, 0f), point + Offset(radius * 2, 0f), r * .025f)
                    drawLine(Color(0xFFE6FFC0).copy(alpha = blink * motion),
                        point - Offset(0f, radius * 2), point + Offset(0f, radius * 2), r * .025f)
                }
            } else {
                rotate(motion * 18f) { repeat(12) { i ->
                    val a = i * PI / 6
                    val unit = Offset(cos(a).toFloat(), sin(a).toFloat())
                    val reach = 1f + motion * .12f * sin(progress * 6 * PI + i).toFloat()
                    drawLine(colors[1], center + unit * (r * 1.35f), center + unit * (r * 1.68f * reach),
                        strokeWidth = r * .18f, cap = StrokeCap.Round)
                } }
                drawCircle(lighting, r)
                drawCircle(Color.White.copy(alpha = .28f), r * .82f, center - Offset(r * .1f, r * .1f),
                    style = Stroke(width = r * .045f))
            }
        }
    }
}
```

## app/src/main/java/com/example/ui/profile/ThemeSemantics.kt

```kotlin
package com.example.ui.profile

import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics

internal fun Modifier.themeSemantics(dark: Boolean, isSelected: Boolean): Modifier = semantics {
    contentDescription = if (dark) "Tema escuro" else "Tema claro"
    selected = isSelected
}
```

## app/src/main/java/com/example/ui/theme/Color.kt

```kotlin
package com.example.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/** Paleta do Kepleræ para Android 7–11 e quando as cores dinâmicas estão desligadas. */
internal val KepleraeLightColors = lightColorScheme(
    primary = Color(0xFF245DA8),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD9E7FF),
    onPrimaryContainer = Color(0xFF071D3D),
    secondary = Color(0xFF006B63),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFA4F2E4),
    onSecondaryContainer = Color(0xFF00201C),
    tertiary = Color(0xFF5A4D85),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFE7DEFF),
    onTertiaryContainer = Color(0xFF21143F),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFF8F9FF),
    onBackground = Color(0xFF18202C),
    surface = Color(0xFFF8F9FF),
    onSurface = Color(0xFF18202C),
    surfaceVariant = Color(0xFFDFE4EF),
    onSurfaceVariant = Color(0xFF424854),
    outline = Color(0xFF737A88),
    outlineVariant = Color(0xFFC3C9D5),
    inverseSurface = Color(0xFF2D3542),
    inverseOnSurface = Color(0xFFEDF0FA),
    inversePrimary = Color(0xFFA7C8FF),
    scrim = Color(0xFF000000),
    surfaceTint = Color(0xFF245DA8),
    surfaceBright = Color(0xFFF8F9FF),
    surfaceDim = Color(0xFFD7DCE6),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF1F4FC),
    surfaceContainer = Color(0xFFEBEFF8),
    surfaceContainerHigh = Color(0xFFE5E9F2),
    surfaceContainerHighest = Color(0xFFDFE3ED),
)

internal val KepleraeDarkColors = darkColorScheme(
    primary = Color(0xFFA7C8FF),
    onPrimary = Color(0xFF003064),
    primaryContainer = Color(0xFF17457B),
    onPrimaryContainer = Color(0xFFD9E7FF),
    secondary = Color(0xFF86D5C8),
    onSecondary = Color(0xFF003731),
    secondaryContainer = Color(0xFF005047),
    onSecondaryContainer = Color(0xFFA4F2E4),
    tertiary = Color(0xFFCABEED),
    onTertiary = Color(0xFF332650),
    tertiaryContainer = Color(0xFF4B3D6A),
    onTertiaryContainer = Color(0xFFE7DEFF),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF0F1726),
    onBackground = Color(0xFFE0E6F2),
    surface = Color(0xFF0F1726),
    onSurface = Color(0xFFE0E6F2),
    surfaceVariant = Color(0xFF424854),
    onSurfaceVariant = Color(0xFFC3C9D5),
    outline = Color(0xFF8D95A4),
    outlineVariant = Color(0xFF424854),
    inverseSurface = Color(0xFFE0E6F2),
    inverseOnSurface = Color(0xFF2D3542),
    inversePrimary = Color(0xFF245DA8),
    scrim = Color(0xFF000000),
    surfaceTint = Color(0xFFA7C8FF),
    surfaceBright = Color(0xFF354052),
    surfaceDim = Color(0xFF0F1726),
    surfaceContainerLowest = Color(0xFF0A111E),
    surfaceContainerLow = Color(0xFF182132),
    surfaceContainer = Color(0xFF1C2637),
    surfaceContainerHigh = Color(0xFF273143),
    surfaceContainerHighest = Color(0xFF323D50),
)
```

## app/src/main/java/com/example/ui/theme/Shape.kt

```kotlin
package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/** Formas compartilhadas: os componentes usam MaterialTheme.shapes. */
internal val KepleraeShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(24.dp),
    large = RoundedCornerShape(32.dp),
    extraLarge = RoundedCornerShape(40.dp),
)
```

## app/src/main/java/com/example/ui/theme/Theme.kt

```kotlin
package com.example.ui.theme

import android.os.Build
import android.util.Log
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFontFamilyResolver
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.text.font.createFontFamilyResolver
import com.example.data.repository.ThemeMode
import kotlinx.coroutines.CoroutineExceptionHandler

/** Modo aplicado ao app, inclusive quando a escolha diverge do tema do aparelho. */
val LocalKepleraeDarkTheme = staticCompositionLocalOf { false }

@Composable
fun isDarkMode(mode: ThemeMode): Boolean = when (mode) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

/**
 * Mesma assinatura da versão 1.2.2: MainActivity e preferências continuam integradas.
 * Android 12+: cores do papel de parede. Android 7–11: paleta do ícone Kepleræ.
 */
@Composable
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
fun KepleraeTheme(
    mode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    val dark = isDarkMode(mode)
    val context = LocalContext.current
    val preview = LocalInspectionMode.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !preview -> {
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        dark -> KepleraeDarkColors
        else -> KepleraeLightColors
    }
    val fontResolver = remember(context) {
        createFontFamilyResolver(
            context,
            CoroutineExceptionHandler { _, error ->
                // Falhas no download não bloqueiam o app: o resolver usa o fallback.
                Log.w("KepleraeFonts", "Fonte Google indisponível; usando fonte local.", error)
            },
        )
    }
    CompositionLocalProvider(LocalFontFamilyResolver provides fontResolver,
        LocalKepleraeDarkTheme provides dark) {
        MaterialExpressiveTheme(
            colorScheme = colorScheme,
            typography = if (preview) PreviewTypography else Typography,
            shapes = KepleraeShapes,
        ) {
            // A camada Expressive fornece movimento; esta camada reage às cores
            // imediatamente, sem recriar a Activity ou perder a navegação.
            MaterialTheme(colorScheme = colorScheme,
                typography = if (preview) PreviewTypography else Typography,
                shapes = KepleraeShapes, content = content)
        }
    }
}
```

## app/src/main/java/com/example/ui/theme/Type.kt

```kotlin
package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.DeviceFontFamilyName
import androidx.compose.ui.text.font.Font as DeviceFont
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font as GoogleFontFace
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.unit.sp
import com.example.R

private val googleFontsProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs,
)

/** Roboto do Google Fonts, com fallback local por peso, inclusive sem internet. */
private val KepleraeFontFamily = FontFamily(
    *listOf(FontWeight.Normal, FontWeight.Medium, FontWeight.SemiBold, FontWeight.Bold)
        .flatMap { weight ->
            listOf(
                GoogleFontFace(
                    googleFont = GoogleFont("Roboto"),
                    fontProvider = googleFontsProvider,
                    weight = weight,
                ),
                DeviceFont(familyName = DeviceFontFamilyName("sans-serif"), weight = weight),
            )
        }.toTypedArray(),
)

private fun materialTypography(family: FontFamily): Typography {
    fun style(size: Int, height: Int, weight: FontWeight, spacing: Float = 0f) = TextStyle(
        fontFamily = family,
        fontWeight = weight,
        fontSize = size.sp,
        lineHeight = height.sp,
        letterSpacing = spacing.sp,
    )
    // A escala mantém os 15 papéis do Material 3. Não usa tamanhos em pixels.
    return Typography(
        displayLarge = style(57, 64, FontWeight.Bold, -0.25f),
        displayMedium = style(45, 52, FontWeight.Bold),
        displaySmall = style(36, 44, FontWeight.SemiBold),
        headlineLarge = style(32, 40, FontWeight.Bold),
        headlineMedium = style(28, 36, FontWeight.SemiBold),
        headlineSmall = style(24, 32, FontWeight.SemiBold),
        titleLarge = style(22, 28, FontWeight.Medium),
        titleMedium = style(16, 24, FontWeight.Medium, 0.15f),
        titleSmall = style(14, 20, FontWeight.Medium, 0.1f),
        bodyLarge = style(16, 24, FontWeight.Normal, 0.5f),
        bodyMedium = style(14, 20, FontWeight.Normal, 0.25f),
        bodySmall = style(12, 16, FontWeight.Normal, 0.4f),
        labelLarge = style(14, 20, FontWeight.Medium, 0.1f),
        labelMedium = style(12, 16, FontWeight.Medium, 0.5f),
        labelSmall = style(11, 16, FontWeight.Medium, 0.5f),
    )
}

// Nome preservado para os arquivos que já importam Typography no projeto atual.
val Typography: Typography = materialTypography(KepleraeFontFamily)

/** O preview do Android Studio usa a mesma escala sem iniciar downloads. */
internal val PreviewTypography: Typography = materialTypography(FontFamily.SansSerif)
```

## app/src/main/res/drawable/ic_google_g.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<!-- Marca Google G: manter cores e proporção; não aplicar tint. -->
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="20dp" android:height="20dp" android:viewportWidth="48" android:viewportHeight="48">
    <path android:fillColor="#4285F4" android:pathData="M43.61,24.46c0,-1.36 -0.12,-2.65 -0.35,-3.92H24v7.42h11.04c-0.48,2.43 -1.93,4.49 -4.10,5.88v4.90h6.64c3.88,-3.58 6.03,-8.87 6.03,-14.28z" />
    <path android:fillColor="#34A853" android:pathData="M24,44c5.40,0 9.93,-1.79 13.24,-4.86l-6.64,-4.90c-1.84,1.24 -4.21,1.99 -6.60,1.99c-5.23,0 -9.67,-3.52 -11.26,-8.25H5.89v5.06C9.18,39.54 16.02,44 24,44z" />
    <path android:fillColor="#FBBC05" android:pathData="M12.74,27.98A12.03,12.03 0,0 1,12.10 24c0,-1.39 0.24,-2.73 0.64,-3.98V14.96H5.89A19.80,19.80 0,0 0,4 24c0,3.24 0.77,6.31 1.89,9.04z" />
    <path android:fillColor="#EA4335" android:pathData="M24,11.77c2.94,0 5.57,1.01 7.65,3.02l5.74,-5.74C33.91,5.81 29.40,4 24,4C16.02,4 9.18,8.46 5.89,14.96l6.85,5.06C14.33,15.29 18.77,11.77 24,11.77z" />
</vector>
```

## app/src/main/res/drawable/ic_kepler_symbol.xml

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">
    <path android:fillColor="#FFFFFF" android:pathData="M3,5.5 C6.5,4.5 9,5 12,7 C15,5 17.5,4.5 21,5.5 L21,18 C17.5,17 15,17.5 12,19.5 C9,17.5 6.5,17 3,18 Z"/>
    <path android:strokeColor="#5146A4" android:strokeWidth="1.2" android:fillColor="#00000000" android:pathData="M12,7 L12,18"/>
    <path android:fillColor="#C7F3DA" android:pathData="M17.5,1 L18.4,3.1 L20.5,4 L18.4,4.9 L17.5,7 L16.6,4.9 L14.5,4 L16.6,3.1 Z"/>
</vector>
```

## app/src/main/res/drawable/ic_launcher_background.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <gradient android:startColor="#EEF5FF" android:endColor="#BBB8F7" android:angle="315" />
</shape>
```

## app/src/main/res/drawable/ic_launcher_foreground.xml

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#F7F1FF" android:pathData="M28,35 C39,32 46,34 54,40 C62,34 69,32 80,35 L80,72 C69,69 62,71 54,77 C46,71 39,69 28,72 Z"/>
    <path android:strokeColor="#5146A4" android:strokeWidth="3" android:strokeLineCap="round" android:fillColor="#00000000" android:pathData="M54,41 L54,71"/>
    <path android:fillColor="#C7F3DA" android:pathData="M71,22 L74,28 L80,31 L74,34 L71,40 L68,34 L62,31 L68,28 Z"/>
</vector>
```

## app/src/main/res/drawable/ic_launcher_monochrome.xml

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#FFFFFF" android:pathData="M28,35 C39,32 46,34 52,39 L52,76 C45,71 38,69 28,72 Z M56,39 C62,34 69,32 80,35 L80,72 C70,69 63,71 56,76 Z M71,22 L74,28 L80,31 L74,34 L71,40 L68,34 L62,31 L68,28 Z"/>
</vector>
```

## app/src/main/res/drawable/ic_pomodoro_notification.xml

```xml
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">
    <path android:fillColor="#FFFFFFFF" android:pathData="M10,1h4v2h-4zM11,7h2v6h-2zM12,4a9,9 0,1 0,0 18a9,9 0,1 0,0 -18M12,6a7,7 0,1 1,0 14a7,7 0,1 1,0 -14" android:fillType="evenOdd" />
</vector>
```

## app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/keplerae_launcher_foreground" />
</adaptive-icon>
```

## app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/keplerae_launcher_foreground" />
</adaptive-icon>
```

## app/src/main/res/mipmap-anydpi-v33/ic_launcher.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/keplerae_launcher_foreground" />
    <monochrome android:drawable="@drawable/ic_launcher_monochrome" />
</adaptive-icon>
```

## app/src/main/res/mipmap-anydpi-v33/ic_launcher_round.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/keplerae_launcher_foreground" />
    <monochrome android:drawable="@drawable/ic_launcher_monochrome" />
</adaptive-icon>
```

## app/src/main/res/values/colors.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="purple_200">#FFBB86FC</color>
    <color name="purple_500">#FF6200EE</color>
    <color name="purple_700">#FF3700B3</color>
    <color name="teal_200">#FF03DAC5</color>
    <color name="teal_700">#FF018786</color>
    <color name="black">#FF000000</color>
    <color name="white">#FFFFFFFF</color>
</resources>
```

## app/src/main/res/values/font_certs.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<!--
  Copyright 2022 The Android Open Source Project

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->
<resources>
    <array name="com_google_android_gms_fonts_certs">
        <item>@array/com_google_android_gms_fonts_certs_dev</item>
        <item>@array/com_google_android_gms_fonts_certs_prod</item>
    </array>
    <string-array name="com_google_android_gms_fonts_certs_dev">
        <item>
            MIIEqDCCA5CgAwIBAgIJANWFuGx90071MA0GCSqGSIb3DQEBBAUAMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbTAeFw0wODA0MTUyMzM2NTZaFw0zNTA5MDEyMzM2NTZaMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbTCCASAwDQYJKoZIhvcNAQEBBQADggENADCCAQgCggEBANbOLggKv+IxTdGNs8/TGFy0PTP6DHThvbbR24kT9ixcOd9W+EaBPWW+wPPKQmsHxajtWjmQwWfna8mZuSeJS48LIgAZlKkpFeVyxW0qMBujb8X8ETrWy550NaFtI6t9+u7hZeTfHwqNvacKhp1RbE6dBRGWynwMVX8XW8N1+UjFaq6GCJukT4qmpN2afb8sCjUigq0GuMwYXrFVee74bQgLHWGJwPmvmLHC69EH6kWr22ijx4OKXlSIx2xT1AsSHee70w5iDBiK4aph27yH3TxkXy9V89TDdexAcKk/cVHYNnDBapcavl7y0RiQ4biu8ymM8Ga/nmzhRKya6G0cGw8CAQOjgfwwgfkwHQYDVR0OBBYEFI0cxb6VTEM8YYY6FbBMvAPyT+CyMIHJBgNVHSMEgcEwgb6AFI0cxb6VTEM8YYY6FbBMvAPyT+CyoYGapIGXMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbYIJANWFuGx90071MAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEEBQADggEBABnTDPEF+3iSP0wNfdIjIz1AlnrPzgAIHVvXxunW7SBrDhEglQZBbKJEk5kT0mtKoOD1JMrSu1xuTKEBahWRbqHsXclaXjoBADb0kkjVEJu/Lh5hgYZnOjvlba8Ld7HCKePCVePoTJBdI4fvugnL8TsgK05aIskyY0hKI9L8KfqfGTl1lzOv2KoWD0KWwtAWPoGChZxmQ+nBli+gwYMzM1vAkP+aayLe0a1EQimlOalO762r0GXO0ks+UeXde2Z4e+8S/pf7pITEI/tP+MxJTALw9QUWEv9lKTk+jkbqxbsh8nfBUapfKqYn0eidpwq2AzVp3juYl7//fKnaPhJD9gs=
        </item>
    </string-array>
    <string-array name="com_google_android_gms_fonts_certs_prod">
        <item>
            MIIEQzCCAyugAwIBAgIJAMLgh0ZkSjCNMA0GCSqGSIb3DQEBBAUAMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtHb29nbGUgSW5jLjEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDAeFw0wODA4MjEyMzEzMzRaFw0zNjAxMDcyMzEzMzRaMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtHb29nbGUgSW5jLjEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDCCASAwDQYJKoZIhvcNAQEBBQADggENADCCAQgCggEBAKtWLgDYO6IIrgqWbxJOKdoR8qtW0I9Y4sypEwPpt1TTcvZApxsdyxMJZ2JORland2qSGT2y5b+3JKkedxiLDmpHpDsz2WCbdxgxRczfey5YZnTJ4VZbH0xqWVW/8lGmPav5xVwnIiJS6HXk+BVKZF+JcWjAsb/GEuq/eFdpuzSqeYTcfi6idkyugwfYwXFU1+5fZKUaRKYCwkkFQVfcAs1fXA5V+++FGfvjJ/CxURaSxaBvGdGDhfXE28LWuT9ozCl5xw4Yq5OGazvV24mZVSoOO0yZ31j7kYvtwYK6NeADwbSxDdJEqO4k//0zOHKrUiGYXtqw/A0LFFtqoZKFjnkCAQOjgdkwgdYwHQYDVR0OBBYEFMd9jMIhF1Ylmn/Tgt9r45jk14alMIGmBgNVHSMEgZ4wgZuAFMd9jMIhF1Ylmn/Tgt9r45jk14aloXikdjB0MQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLR29vZ2xlIEluYy4xEDAOBgNVBAsTB0FuZHJvaWQxEDAOBgNVBAMTB0FuZHJvaWSCCQDC4IdGZEowjTAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBAUAA4IBAQBt0lLO74UwLDYKqs6Tm8/yzKkEu116FmH4rkaymUIE0P9KaMftGlMexFlaYjzmB2OxZyl6euNXEsQH8gjwyxCUKRJNexBiGcCEyj6z+a1fuHHvkiaai+KL8W1EyNmgjmyy8AW7P+LLlkR+ho5zEHatRbM/YAnqGcFh5iZBqpknHf1SKMXFh4dd239FJ1jWYfbMDMy3NS5CTMQ2XFI1MvcyUTdZPErjQfTbQe3aDQsQcafEQPD+nqActifKZ0Np0IS9L9kR/wbNvyz6ENwPiTrjV2KRkEjH78ZMcUQXg0L3BYHJ3lc69Vs5Ddf9uUGGMYldX3WfMBEmh/9iFBDAaTCK
        </item>
    </string-array>
</resources>
```

## app/src/main/res/values/google_login.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- ID público de cliente OAuth do tipo Web, no MESMO projeto do cliente Android.
         Exemplo de formato: 123456789-abc.apps.googleusercontent.com.
         Preencha antes de gerar o APK. Não coloque aqui chave de API ou client secret. -->
    <string name="google_web_client_id" translatable="false"></string>
    <string name="google_sign_in">Entrar com Google</string>
    <string name="developed_by">Desenvolvido por Madox Fênix</string>
</resources>
```

## app/src/main/res/values/strings.xml

```xml
<resources><string name="app_name">Kepleræ</string></resources>
```

## app/src/main/res/values/themes.xml

```xml
<resources>
    <style name="Theme.MyApplication" parent="Theme.AppCompat.Light.NoActionBar">
        <item name="android:windowLightStatusBar">true</item>
        <item name="android:windowActionModeOverlay">true</item>
        <item name="android:fontFamily">sans</item>
        <item name="android:windowBackground">#FCF8FF</item>
    </style>
</resources>
```

## app/src/main/res/values-night/themes.xml

```xml
<resources><style name="Theme.MyApplication" parent="Theme.AppCompat.NoActionBar">
<item name="android:windowLightStatusBar">false</item><item name="android:fontFamily">sans</item><item name="android:windowBackground">#141218</item>
</style></resources>
```

## app/src/main/res/xml/backup_rules.xml

```xml
<?xml version="1.0" encoding="utf-8"?><!--
   Sample backup rules file; uncomment and customize as necessary.
   See https://developer.android.com/guide/topics/data/autobackup
   for details.
   Note: This file is ignored for devices older than API 31
   See https://developer.android.com/about/versions/12/backup-restore
-->
<full-backup-content>
    <exclude domain="sharedpref" path="keplerae_drive.xml" />
        <exclude domain="file" path="pdfs/" />
    <exclude domain="sharedpref" path="keplerae_google_session.xml" />
    <!--
   <include domain="sharedpref" path="."/>
   <exclude domain="sharedpref" path="device.xml"/>
-->
</full-backup-content>
```

## app/src/main/res/xml/data_extraction_rules.xml

```xml
<?xml version="1.0" encoding="utf-8"?><!--
   Sample data extraction rules file; uncomment and customize as necessary.
   See https://developer.android.com/about/versions/12/backup-restore#xml-changes
   for details.
-->
<data-extraction-rules>
    <cloud-backup>
        <exclude domain="sharedpref" path="keplerae_drive.xml" />
        <exclude domain="file" path="pdfs/" />
        <exclude domain="sharedpref" path="keplerae_google_session.xml" />
        <!-- TODO: Use <include> and <exclude> to control what is backed up.
        <include .../>
        <exclude .../>
        -->
    </cloud-backup>
    <device-transfer>
        <exclude domain="sharedpref" path="keplerae_drive.xml" />
        <exclude domain="file" path="pdfs/" />
        <exclude domain="sharedpref" path="keplerae_google_session.xml" />
    </device-transfer>
</data-extraction-rules>
```

## app/src/test/java/com/example/BackupMergeTest.kt

```kotlin
package com.example

import com.example.data.backup.*
import com.example.data.notes.*
import com.example.data.pdf.*
import com.example.data.productivity.*
import org.junit.Assert.*
import org.junit.Test

class BackupMergeTest {
    @Test fun newerNoteWinsAndSameNamedTagIsRemappedWithoutDuplicates() {
        val local=NoteState(listOf(NoteTag("local","Estudo")),
            listOf(Note("n","Antiga","", "local",0,1,10)))
        val incoming=NoteState(listOf(NoteTag("other","ESTUDO")),
            listOf(Note("n","Atualizada","texto","other",2,1,20),
                Note("new","Nova","texto",null,0,2,30)))
        val merged=mergeNotes(local,incoming)
        assertEquals(1,merged.tags.size)
        assertEquals("local",merged.notes.first {it.id=="n"}.tagId)
        assertEquals("Atualizada",merged.notes.first {it.id=="n"}.title)
        assertEquals(merged,mergeNotes(merged,incoming))
        assertEquals(merged,mergeNotes(merged,local))
    }
    @Test fun questionRecordsKeepTotalsAndUseExistingSubjectByName() {
        val local=QuestionState(listOf(QuestionSubject("a","SUS")),
            listOf(QuestionRecord("old","a",8,2,1)))
        val incoming=QuestionState(listOf(QuestionSubject("b","sus")),
            listOf(QuestionRecord("new","b",9,1,2)))
        val merged=mergeQuestions(local,incoming)
        assertEquals(1,merged.subjects.size)
        assertTrue(merged.records.all {it.subjectId=="a"})
        assertEquals(QuestionTotals(17,3),questionTotals(merged.records))
        assertEquals(merged,mergeQuestions(merged,incoming))
    }
    @Test fun focusHistoryDoesNotDoubleCountWhenImportedTwice() {
        val local=listOf(FocusRecord("first",100,60_000))
        val incoming=listOf(FocusRecord("second",200,120_000),local.first())
        val merged=mergeHistory(local,incoming)
        assertEquals(2,merged.size)
        assertEquals(180_000L,merged.sumOf {it.durationMs})
        assertEquals(merged,mergeHistory(merged,incoming))
    }
    @Test fun annotationsKeepExistingInkAndAddImportedPinsAndPages() {
        val stroke=InkStroke("s",listOf(InkPoint(.2f,.3f)),false,0xFF123456L,.01f)
        val note=PdfNote("pin",InkPoint(.4f,.5f),"Revisar")
        val local=AnnotationDocument(mapOf(0 to PageAnnotations(listOf(stroke))))
        val incoming=AnnotationDocument(mapOf(0 to PageAnnotations(listOf(stroke),listOf(note)),
            2 to PageAnnotations(notes=listOf(note.copy(id="pin2")))))
        val merged=mergeAnnotations(local,incoming)
        assertEquals(listOf(stroke),merged.pages[0]!!.strokes)
        assertEquals(listOf(note),merged.pages[0]!!.notes)
        assertEquals(2,merged.pages.size)
        assertEquals(merged,mergeAnnotations(merged,incoming))
    }
}
```

## app/src/test/java/com/example/DriveRequestsTest.kt

```kotlin
package com.example

import com.example.data.drive.*
import org.junit.Assert.*
import org.junit.Test
import java.net.URLDecoder

class DriveRequestsTest {
    @Test fun mediaUsesApiAndCredentialsStayOutOfUrl() {
        val url = DriveRequests.file("real-ID_1", true)
        assertTrue(url.startsWith("https://www.googleapis.com/drive/v3/files/real-ID_1?"))
        assertTrue(url.contains("alt=media"))
        val headers = DriveCredentials("test-key").headers("app", "cert", "real-ID_1", "resource-key")
        assertEquals("test-key", headers["X-Goog-Api-Key"])
        assertEquals("real-ID_1/resource-key", headers["X-Goog-Drive-Resource-Keys"])
        assertFalse(url.contains("test-key"))
    }
    @Test fun googleAuthorizationReplacesAnonymousKey() {
        val headers = DriveCredentials("key", "token").headers("app", "cert", "id", "")
        assertEquals("Bearer token", headers["Authorization"])
        assertFalse(headers.containsKey("X-Goog-Api-Key"))
        assertFalse(headers.containsKey("X-Goog-Drive-Resource-Keys"))
    }
    @Test fun folderQueriesPreserveRealIdsAndPagination() {
        val url = URLDecoder.decode(DriveRequests.folder("folder_ID", "next+token"), "UTF-8")
        assertTrue(url.contains("'folder_ID' in parents and trashed = false"))
        assertTrue(url.contains("pageToken=next+token"))
        assertEquals("abc-def_1", DriveRequests.folderId("https://drive.google.com/drive/folders/abc-def_1?usp=sharing"))
        assertEquals("0-real_key", DriveRequests.resourceKey("https://drive.google.com/file/d/id/view?usp=sharing&resourcekey=0-real_key"))
    }
    @Test fun permissionsAndQuotaHaveDifferentRecoveryInstructions() {
        assertEquals("downloadQuotaExceeded", DriveRequests.errorReason("{\"error\":{\"errors\":[{\"reason\":\"downloadQuotaExceeded\"}]}}"))
        assertTrue(DriveRequests.errorMessage(404, "notFound").contains("autorize"))
        assertTrue(DriveRequests.errorMessage(403, "downloadQuotaExceeded").contains("limite"))
        assertTrue(DriveRequests.errorMessage(401, "authError").contains("expirou"))
        assertTrue(DriveRequests.errorMessage(403, "fileNotDownloadable").contains("proprietário"))
        assertTrue(DriveRequests.errorMessage(403, "accessNotConfigured").contains("Ative"))
    }
    @Test(expected = IllegalArgumentException::class) fun rejectInjectedFileIds() {
        DriveRequests.file("id?key=untrusted")
    }
}
```

## app/src/test/java/com/example/GoogleLoginConfigurationTest.kt

```kotlin
package com.example

import com.example.data.auth.GoogleLoginConfiguration
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GoogleLoginConfigurationTest {
    @Test fun acceptsPublicWebClientId() {
        assertTrue(GoogleLoginConfiguration.isWebClientId("1234567890-abc_def-123.apps.googleusercontent.com"))
        // Não restringir IDs antigos a um único formato de prefixo.
        assertTrue(GoogleLoginConfiguration.isWebClientId("1234567890.apps.googleusercontent.com"))
    }

    @Test fun rejectsApiKeysSecretsAndCopiedConfigurationText() {
        listOf("", "AIzaExampleKey", "GOCSPX-example", "{\"client_id\":\"123-a.apps.googleusercontent.com\"}",
            "https://123-a.apps.googleusercontent.com", "123-a.apps.googleusercontent.com\nextra")
            .forEach { assertFalse(GoogleLoginConfiguration.isWebClientId(it)) }
    }
}
```

## app/src/test/java/com/example/ItemOrderTest.kt

```kotlin
package com.example

import com.example.data.repository.mergeVisibleOrder
import com.example.data.repository.moveId
import com.example.data.repository.reconcileOrder
import org.junit.Assert.assertEquals
import org.junit.Test

class ItemOrderTest {
    @Test fun savedOrderSurvivesCatalogAdditionsAndRemovals() {
        assertEquals(listOf("b", "a", "new"),
            reconcileOrder(listOf("a", "b", "new"), listOf("removed", "b", "b", "a")))
    }
    @Test fun reorderingFilteredRowsDoesNotMoveHiddenRows() {
        assertEquals(listOf("c", "hidden", "a", "b"),
            mergeVisibleOrder(listOf("a", "hidden", "b", "c"), listOf("c", "a", "b")))
    }
    @Test fun dragUsesItemKeysAndIgnoresHeadersOrRemovedItems() {
        val order = listOf("a", "b", "c")
        assertEquals(listOf("b", "c", "a"), moveId(order, "a", "c"))
        assertEquals(order, moveId(order, "header", "b"))
        assertEquals(order, moveId(order, "a", "removed"))
    }
}
```

## app/src/test/java/com/example/NotesFilterTest.kt

```kotlin
package com.example

import com.example.data.notes.Note
import com.example.data.notes.cleanTagName
import com.example.data.notes.noteIsBlank
import com.example.data.notes.visibleNotes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NotesFilterTest {
    private fun note(id: String, title: String, body: String = "", tag: String? = null, updated: Long = 0L) =
        Note(id, title, body, tag, 0, 0L, updated)

    @Test fun ordersByMostRecentlyEdited() {
        val result = visibleNotes(listOf(note("a", "A", updated = 1), note("b", "B", updated = 3), note("c", "C", updated = 2)), null, "")
        assertEquals(listOf("b", "c", "a"), result.map { it.id })
    }

    @Test fun filtersByTag() {
        val notes = listOf(note("a", "A", tag = "t1"), note("b", "B", tag = "t2"), note("c", "C"))
        assertEquals(listOf("a"), visibleNotes(notes, "t1", "").map { it.id })
        assertEquals(3, visibleNotes(notes, null, "").size)
    }

    @Test fun searchIgnoresAccentsAndCase() {
        val notes = listOf(note("a", "Fisioterapia respiratória", "Ventilação"), note("b", "Outro"))
        assertEquals(listOf("a"), visibleNotes(notes, null, "RESPIRATORIA").map { it.id })
        assertEquals(listOf("a"), visibleNotes(notes, null, "ventilacao").map { it.id })
    }

    @Test fun cleanTagNameRemovesHashAndExtraSpaces() {
        assertEquals("Plantão UTI", cleanTagName("  #Plantão   UTI "))
    }

    @Test fun blankDetection() {
        assertTrue(noteIsBlank("  ", ""))
        assertFalse(noteIsBlank("", "texto"))
    }
}
```

## app/src/test/java/com/example/PdfInkGeometryTest.kt

```kotlin
package com.example

import com.example.data.pdf.*
import org.junit.Assert.*
import org.junit.Test

class PdfInkGeometryTest {
    @Test fun eraserHitsBetweenRecordedPoints() {
        val stroke = InkStroke("line", listOf(InkPoint(.1f,.1f),InkPoint(.9f,.9f)),false,0xFF000000,.005f)
        assertTrue(strokeHit(stroke,InkPoint(.5f,.5f)))
        assertFalse(strokeHit(stroke,InkPoint(.5f,.8f)))
    }
    @Test fun tapStrokeCanBeErasedAndCoordinatesStayInsidePage() {
        val point = InkPoint(-.1f,1.2f).clamped()
        assertEquals(InkPoint(0f,1f),point)
        assertTrue(strokeHit(InkStroke("dot",listOf(point),false,0xFF000000,.01f),point))
        assertFalse(strokeHit(InkStroke("empty",emptyList(),false,0xFF000000,.01f),point))
    }
    @Test fun cacheIdentityChangesWithAccountAndDriveId() {
        assertNotEquals(pdfStorageKey("one@example.com","id"),pdfStorageKey("two@example.com","id"))
        assertNotEquals(pdfStorageKey("one@example.com","id"),pdfStorageKey("one@example.com","other"))
        assertEquals(pdfStorageKey("one@example.com","id"),pdfStorageKey("one@example.com","id"))
        assertTrue(pdfStorageKey("account","../id").matches(Regex("[0-9a-f]{64}")))
    }
}
```

## app/src/test/java/com/example/ProductivityMathTest.kt

```kotlin
package com.example

import com.example.data.productivity.*
import org.junit.Assert.*
import org.junit.Test

class ProductivityMathTest {
    @Test fun globalAccuracyWeightsEachQuestionRatherThanEachSession() {
        val records=listOf(QuestionRecord("a","s",1,0,0),QuestionRecord("b","s",0,9,0))
        val total=questionTotals(records)
        assertEquals(10L,total.total)
        assertEquals(10.0,total.accuracy,0.001)
        assertEquals(90.0,total.errorRate,0.001)
    }
    @Test fun rejectsEmptyNegativeAndOverflowInput() {
        assertFalse(validQuestionCounts(0,0));assertFalse(validQuestionCounts(-1,2))
        assertFalse(validQuestionCounts(null,3));assertFalse(validQuestionCounts(Int.MAX_VALUE,0))
        assertTrue(validQuestionCounts(0,8));assertTrue(validQuestionCounts(5,0))
    }
    @Test fun emptyStatsHaveNoNaNAndLargeTotalsUseLong() {
        assertEquals(0.0,questionTotals(emptyList()).accuracy,0.0)
        val records=(1..4000).map { QuestionRecord(it.toString(),"s",1_000_000,1_000_000,0) }
        assertEquals(8_000_000_000L,questionTotals(records).total)
    }
    @Test fun onlyFinishedFocusAddsTimeAndLongBreakFollowsFixedCycles() {
        val state=PomodoroState(running=true,phaseDurationMs=1_500_000,sessionId="focus1",cycle=3)
        val done=finishPhase(state,1234)
        assertEquals(PomodoroPhase.LONG_BREAK,done.phase)
        assertEquals(4,done.cycle);assertEquals(1,done.history.size)
        assertEquals(1_500_000L,done.history.single().durationMs)
        assertEquals(done,finishPhase(done,1500))
        val next=finishPhase(done.copy(running=true,sessionId="break1"),1800)
        assertEquals(PomodoroPhase.FOCUS,next.phase);assertEquals(0,next.cycle)
        assertEquals(1,next.history.size)
    }
    @Test fun pauseAndRestartRestoreDeadlineAndClampExpiredTimer() {
        val s=PomodoroState(running=true,deadlineWall=5000,deadlineElapsed=4000,bootEpoch=1000,phaseDurationMs=5000)
        assertEquals(3000L,remainingAt(s,2000,1000))
        assertEquals(0L,remainingAt(s,6000,5000))
        assertEquals(1700L,remainingAt(s.copy(running=false,remainingMs=1700),9000,8000))
    }
}
```

## app/src/test/java/com/example/QuestionEvolutionTest.kt

```kotlin
package com.example

import com.example.data.productivity.*
import org.junit.Assert.*
import org.junit.Test
import java.util.TimeZone

class QuestionEvolutionTest {
    private val utc=TimeZone.getTimeZone("UTC")
    @Test fun dailyAccumulationSortsAndCombinesSessions() {
        val records=listOf(QuestionRecord("later","math",3,1,86_400_100L),
            QuestionRecord("first","math",10,2,100L),QuestionRecord("same","math",2,3,200L))
        val days=cumulativeQuestionDays(records,utc)
        assertEquals(2,days.size)
        assertEquals(12L,days[0].correct);assertEquals(5L,days[0].wrong)
        assertEquals(15L,days[1].correct);assertEquals(6L,days[1].wrong)
        assertEquals(questionTotals(records).total,days.last().total)
    }
    @Test fun filteringBeforeAccumulationKeepsSubjectsIndependent() {
        val records=listOf(QuestionRecord("a","math",9,1,100L),QuestionRecord("b","language",2,8,200L))
        val days=cumulativeQuestionDays(records.filter {it.subjectId=="math"},utc)
        assertEquals(10L,days.single().total);assertEquals(9L,days.single().correct)
    }
    @Test fun totalsDoNotOverflowIntAndDeletionRecalculates() {
        val records=(0..2999).map {QuestionRecord("$it","s",1_000_000,1_000_000,it.toLong())}
        assertEquals(6_000_000_000L,cumulativeQuestionDays(records,utc).single().total)
        assertEquals(5_998_000_000L,cumulativeQuestionDays(records.drop(1),utc).single().total)
        assertTrue(cumulativeQuestionDays(emptyList(),utc).isEmpty())
    }
    @Test fun groupingUsesRequestedLocalDay() {
        val records=listOf(QuestionRecord("a","s",1,0,0L),QuestionRecord("b","s",1,0,10_800_000L))
        assertEquals(1,cumulativeQuestionDays(records,utc).size)
        assertEquals(2,cumulativeQuestionDays(records,TimeZone.getTimeZone("GMT-03:00")).size)
    }
}
```

## app/src/test/java/com/example/StudyAdjustmentsTest.kt

```kotlin
package com.example

import com.example.data.productivity.*
import org.junit.Assert.*
import org.junit.Test

class StudyAdjustmentsTest {
    @Test fun deletingBlockRemovesOnlyItsRecordsAndRecalculatesTotals() {
        val state=QuestionState(listOf(QuestionSubject("a","A"),QuestionSubject("b","B")),
            listOf(QuestionRecord("1","a",8,2,1),QuestionRecord("2","b",3,1,2)))
        val result=withoutQuestionSubject(state,"a")
        assertEquals(listOf("b"),result.subjects.map { it.id })
        assertEquals(listOf("2"),result.records.map { it.id })
        assertEquals(4L,questionTotals(result.records).total)
        assertEquals(75.0,questionTotals(result.records).accuracy,.001)
        assertEquals(result,withoutQuestionSubject(result,"a"))
    }
    @Test fun editingInactiveCycleImmediatelySetsNewFocusAndKeepsHistory() {
        val record=FocusRecord("completed",1,25*60000L)
        val state=PomodoroState(phase=PomodoroPhase.LONG_BREAK,cycle=4,history=listOf(record))
        val result=applyPomodoroSettings(state,PomodoroSettings(40,7,18,6))
        assertEquals(PomodoroPhase.FOCUS,result.phase)
        assertEquals(40*60000L,result.remainingMs)
        assertEquals(result.remainingMs,result.phaseDurationMs)
        assertEquals(0,result.cycle)
        assertEquals(listOf(record),result.history)
        assertFalse(result.running)
    }
    @Test fun editingActiveOrPausedCyclePreservesCurrentDeadlineAndDuration() {
        listOf(PomodoroState(running=true,deadlineWall=2000,deadlineElapsed=1000),
            PomodoroState(paused=true,remainingMs=1400)).forEach { state ->
            val result=applyPomodoroSettings(state,PomodoroSettings(50,10,20,2))
            assertEquals(state.copy(settings=result.settings),result)
            assertEquals(2,result.settings.cycles)
        }
    }
    @Test fun changingSoundAloneDoesNotResetProgress() {
        val state=PomodoroState(cycle=2,phase=PomodoroPhase.SHORT_BREAK,remainingMs=300000)
        assertEquals(state.copy(settings=state.settings.copy(ambienceId="wind")),
            applyPomodoroSettings(state,state.settings.copy(ambienceId="wind")))
    }
}
```

## app/src/test/java/com/example/StudyItemTest.kt

```kotlin
package com.example

import com.example.data.model.*
import org.junit.Assert.*
import org.junit.Test

class StudyItemTest {
    private fun item(kind: LinkKind = LinkKind.FILE) = StudyItem("id", "Fonética e acentuação", "01.mp4", "portugues",
        listOf("Aula 01"), ContentType.VIDEO, if (kind == LinkKind.FILE) "https://drive.google.com/file/d/realId/view?usp=drivesdk"
        else "https://drive.google.com/drive/folders/folderId", kind, if (kind == LinkKind.FILE) "realId" else "", "", "planilha.xlsx")
    @Test fun folderLinksAreNeverChangedToFilePreviews() {
        val folder = item(LinkKind.FOLDER)
        assertEquals(folder.url, folder.previewUrl)
        assertEquals("https://drive.google.com/file/d/realId/preview", item().previewUrl)
    }
    @Test fun onlyExpectedDriveLinksAreAllowed() {
        assertTrue(isAllowedDriveUrl(item().url))
        assertTrue(isAllowedDriveUrl(item(LinkKind.FOLDER).url))
        assertFalse(isAllowedDriveUrl("https://drive.google.com.evil.test/file/d/x"))
        assertFalse(isAllowedDriveUrl("http://drive.google.com/file/d/x"))
        assertFalse(isAllowedDriveUrl("javascript:alert(1)"))
        assertFalse(isAllowedDriveUrl("https://user@drive.google.com/file/d/x"))
    }
    @Test fun accentInsensitiveSearchAndExactFolderPrefixes() {
        assertTrue(item().matches("FONETICA"))
        assertTrue(item().matches("acentuacao"))
        assertFalse(item().matches("cardiologia"))
        assertEquals(1, itemsInPath(listOf(item()), listOf("Aula 01")).size)
        assertEquals(0, itemsInPath(listOf(item()), listOf("Aula 0")).size)
    }
}
```

## build.gradle.kts

```kotlin
plugins {
    id("com.android.application") version "8.11.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.21" apply false
}
```

## gradle/wrapper/gradle-wrapper.properties

```text
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.13-bin.zip
networkTimeout=60000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
```

## gradle.properties

```text
org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
```

## scripts/configure_google_login.py

```python
"""Preenche o ID público Web pelo Actions ou confere o valor já salvo no XML."""
import os
import re
from pathlib import Path
from xml.etree import ElementTree

PATH = Path("app/src/main/res/values/google_login.xml")


def configure():
    document = ElementTree.parse(PATH)
    node = document.find(".//string[@name='google_web_client_id']")
    if node is None:
        raise ValueError("Recurso google_web_client_id ausente")
    value = (os.environ.get("GOOGLE_WEB_CLIENT_ID") or node.text or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]+\.apps\.googleusercontent\.com", value):
        raise ValueError(
            "Configure a variável GOOGLE_WEB_CLIENT_ID no GitHub ou preencha "
            "google_web_client_id em google_login.xml. Use o ID público OAuth do tipo Web "
            "no mesmo projeto do cliente Android. Chave de API e client secret não servem."
        )
    node.text = value
    document.write(PATH, encoding="utf-8", xml_declaration=True)
    # Não registrar valores de credenciais em logs, mesmo quando são IDs públicos.
    print("ID OAuth Web configurado; tipo de cliente deve ser Web no Google Cloud.")


if __name__ == "__main__":
    configure()
```

## scripts/fetch_ambient_sounds.py

```python
#!/usr/bin/env python3
"""Ambientes locais de 120s, costuras equal-power e atribuição preservada.
O relógio fica intacto. Sem rede, conserva os OGGs prontos incluídos.
"""
import argparse
import array
import hashlib
import json
import math
from pathlib import Path
import subprocess
import tempfile
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'app/src/main/res/raw'
ASSETS=ROOT/'app/src/main/assets'
RATE=22050
SECONDS=120
BLANKET='775f2a767230a9681850d1b1e085be58656f1382'
SOURCES=[
 ('fire',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/fireplace.ogg','10890350b03b3644bc11299637a915a8738faceb','ezwa','Public Domain','https://soundbible.com/1543-Fireplace.html'),
 ('wind',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/wind.ogg','349b7d398194e60e60629b8952fadf2b54b64fd9','felix.blume; edição Porrumentzio','CC0 1.0','https://freesound.org/people/felix.blume/sounds/217506/'),
 ('room',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/coffee-shop.ogg','a93acfbde2c3cddf4ac31bc27d14f19b44121aa5','stephan','Public Domain','https://soundbible.com/1664-Restaurant-Ambiance.html'),
 ('storm',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/storm.ogg','cf6f788da00f9c3fc7ab014f538afc51eaf26b12','digifishmusic; edição Porrumentzio','CC BY 4.0','https://freesound.org/people/digifishmusic/sounds/41739/'),
 ('rain','https://raw.githubusercontent.com/mateusfg7/Noisekun/main/.github/assets/sounds/rain.ogg','7945216b9e95dcf5493848d752e3d639f91e8f01','SFXProducer','CC0 1.0','https://www.youtube.com/watch?v=3oMcTXhXOpc'),
]

def download(url):
 req=urllib.request.Request(url,headers={'User-Agent':'Keplerae-build/1.0.1'})
 with urllib.request.urlopen(req,timeout=25) as response:data=response.read(16_000_001)
 if len(data)>16_000_000:raise ValueError('Arquivo maior que o limite')
 return data

def cross(a,b):
 """Equal power conserva energia entre segmentos não correlacionados."""
 n=len(a)
 return array.array('f',(a[i]*math.cos(math.pi/2*i/(n-1))+b[i]*math.sin(math.pi/2*i/(n-1)) for i in range(n)))

def seal(values,overlap):
 # Termina antes da cauda que abre a volta seguinte: sem fade até silêncio.
 return cross(values[-overlap:],values[:overlap])+values[overlap:-overlap]

def seamless_pcm(data,seconds=SECONDS):
 with tempfile.TemporaryDirectory() as folder:
  source=Path(folder)/'source';source.write_bytes(data)
  raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(source),'-t','300','-ac','1','-ar',str(RATE),'-f','s16le','-'],timeout=40)
 values=array.array('h');values.frombytes(raw)
 if len(values)<100:raise ValueError('Som vazio')
 overlap=min(3*RATE,len(values)//4)
 base=seal(array.array('f',values),overlap);result=base[:]
 target=seconds*RATE+overlap;offsets=(.17,.43,.71,.29,.83,.57);step=0
 while len(result)<target:
  offset=int(len(base)*offsets[step%len(offsets)])
  segment=base[offset:]+base[:offset]
  result=result[:-overlap]+cross(result[-overlap:],segment[:overlap])+segment[overlap:];step+=1
 result=seal(result[:target],overlap)
 peak=max(map(abs,result)) or 1
 return array.array('h',(round(value/peak*15000) for value in result))

def prepare(data,destination):
 pcm=seamless_pcm(data)
 subprocess.run(['ffmpeg','-y','-v','error','-f','s16le','-ar',str(RATE),'-ac','1','-i','-','-c:a','libvorbis','-q:a','4',str(destination)],input=pcm.tobytes(),check=True,timeout=40)
 destination.with_suffix('.wav').unlink(missing_ok=True)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--local-sources',type=Path);parser.add_argument('--offline',action='store_true');args=parser.parse_args()
 provenance_path=ROOT/'design/ambient-sound-provenance.json'
 existing=json.loads(provenance_path.read_text()) if provenance_path.exists() else []
 provenance={Path(item['file']).stem:item for item in existing}
 for name,url,expected,author,license_name,original in SOURCES:
  destination=RAW/f'ambient_{name}.ogg';local=args.local_sources/f'{name}.ogg' if args.local_sources else None
  try:
   if local and local.exists():data=local.read_bytes()
   elif args.offline:raise ConnectionError('Modo offline')
   else:data=download(url)
   actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   if actual!=expected:raise ValueError('Fonte alterada')
   prepare(data,destination)
   provenance[f'ambient_{name}']={'file':destination.name,'author':author,'license':license_name,'source':original,'git_blob':expected,'download':url}
   print(f'Ambiente preparado: {destination.name}, {SECONDS}s')
  except (OSError,ValueError,subprocess.SubprocessError) as error:
   if not destination.exists():
    fallback=destination.with_suffix('.wav')
    if not fallback.exists():raise
    prepare(fallback.read_bytes(),destination)
   print(f'Ambiente incluído preservado: {destination.name} ({type(error).__name__})')
 library=RAW/'ambient_library.ogg'
 if not library.exists():prepare(library.with_suffix('.wav').read_bytes(),library)
 # Android usa o nome-base como ID: não pode haver WAV e OGG do mesmo som.
 for destination in RAW.glob('ambient_*.ogg'):
  destination.with_suffix('.wav').unlink(missing_ok=True)
 for stem,item in provenance.items():
  if stem=='ambient_clock':continue
  item['file']=stem+'.ogg'
  item['changes']='120s, mono 22050Hz, normalização, segmentos alternados e costuras equal-power de até 3s'
 provenance_path.write_text(json.dumps(list(provenance.values()),ensure_ascii=False,indent=2)+'\n')
 credits=['SONS DE AMBIENTE — KEPLERÆ 1.0.1','']
 for item in provenance.values():credits.extend([item['file']+' — '+item['author'],item['license'],item['source'],item.get('changes',''),''])
 credits.extend(['CC0: https://creativecommons.org/publicdomain/zero/1.0/','CC BY 4.0: https://creativecommons.org/licenses/by/4.0/',
  'Casas e biblioteca: combinações inspiradas; sem trilhas ou gravações dos filmes.',
  'Relógio preservado. Outros ambientes: colagem de segmentos com transições; não são gravações novas de dois minutos.'])
 (ASSETS/'pomodoro_sound_credits.txt').write_text('\n'.join(credits)+'\n')

if __name__=='__main__':main()
```

## scripts/fetch_pomodoro_sounds.py

```python
#!/usr/bin/env python3
"""Instala sons de domínio público fixados em um commit, sem dependências extras.
Os WAVs originais incluídos no ZIP continuam utilizáveis se a origem estiver fora do ar.
"""
import hashlib
import io
import json
from pathlib import Path
import struct
import urllib.request
import wave

ROOT = Path(__file__).resolve().parents[1]
COMMIT = "0bdbbe370c42897e12b7c5b0b26d96228e0d2931"
FILES = [("bell1.wav", "3b7bf89fdf2a516aa27680f1c34c42af4a5025bb", "pomo_bell.wav"),
         ("metal1.wav", "9eba344bc130b5171d8393d46ad3c6f7ed67b8f5", "pomo_soft.wav")]

def normalized_wav(data):
    with wave.open(io.BytesIO(data)) as source:
        if source.getcomptype() != "NONE" or source.getsampwidth() not in (2, 3, 4):
            raise ValueError("Formato PCM não suportado")
        rate, channels, width = source.getframerate(), source.getnchannels(), source.getsampwidth()
        raw = source.readframes(min(source.getnframes(), int(rate * 2.4)))
    values = []
    step = width * channels
    for offset in range(0, len(raw) - step + 1, step):
        values.append(sum(int.from_bytes(raw[offset+c*width:offset+(c+1)*width], "little", signed=True)
                          for c in range(channels)) / channels)
    peak = max(map(abs, values), default=1) or 1
    pcm = bytearray()
    for index, value in enumerate(values):
        fade = min(1.0, index / max(1, int(rate*.008)), (len(values)-index) / max(1, int(rate*.15)))
        pcm.extend(struct.pack("<h", int(value/peak*12000*fade)))
    result=io.BytesIO()
    with wave.open(result,"wb") as output:
        output.setnchannels(1);output.setsampwidth(2);output.setframerate(rate);output.writeframes(pcm)
    return result.getvalue()

def main():
    provenance=[]
    for name, expected, destination in FILES:
        url=f"https://raw.githubusercontent.com/code4fukui/sound-cc0/{COMMIT}/{name}"
        path=ROOT/"app/src/main/res/raw"/destination
        try:
            request=urllib.request.Request(url,headers={"User-Agent":"Keplerae-build/2.3"})
            with urllib.request.urlopen(request,timeout=30) as response: data=response.read(5_000_000)
            actual=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
            if actual!=expected: raise ValueError("Hash da fonte difere do commit fixado")
            path.write_bytes(normalized_wav(data))
            provenance.append({"file":destination,"source":url,"license":"public domain / Unlicense", "git_blob":expected})
            print(f"Som público validado: {name}")
        except Exception as error:
            if not path.exists(): raise
            provenance.append({"file":destination,"source":"original tone bundled with Keplerae", "license":"CC0", "fallback":True})
            print(f"Origem indisponível; usando som original incluído ({type(error).__name__}).")
    (ROOT/"design/pomodoro-sound-provenance.json").write_text(json.dumps(provenance,indent=2)+"\n")

if __name__=="__main__":main()
```

## scripts/generate_ambient_fallbacks.py

```python
#!/usr/bin/env python3
"""Reserva sonora original CC0. Só cria recursos ausentes; não substitui fontes públicas."""
import array
import math
from pathlib import Path
import random
import wave

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'app/src/main/res/raw'
RATE=22050

def main():
    RAW.mkdir(parents=True,exist_ok=True)
    seconds=12;n=RATE*seconds;rng=random.Random(24)
    clock=[0.0]*n
    for beat in range(seconds*2):
        start=int(beat*.5*RATE)
        for i in range(int(.065*RATE)):
            if start+i>=n:break
            t=i/RATE;freq=1800 if beat%2==0 else 1350
            clock[start+i]=(math.sin(2*math.pi*freq*t)+.35*rng.uniform(-1,1))*math.exp(-t*95)
    noise=[rng.uniform(-1,1) for _ in range(n)];rain=[];last=0.0
    for i,x in enumerate(noise):
        last=.72*last+.28*x;rain.append(last*(.76+.10*math.sin(2*math.pi*i/n)))
    library=[x*.035 for x in noise]
    for sec in [1.4,4.3,8.6,10.2]:
        start=int(sec*RATE);length=int(.6*RATE)
        for i in range(length):
            if start+i<n:library[start+i]+=rng.uniform(-1,1)*math.sin(math.pi*i/length)**2*.5
    for name,values in [('ambient_clock.wav',clock),('ambient_rain.wav',rain),('ambient_library.wav',library)]:
        path=RAW/name
        if path.exists() or path.with_suffix('.ogg').exists():continue
        peak=max(map(abs,values)) or 1
        pcm=array.array('h',(int(x/peak*12000) for x in values))
        with wave.open(str(path),'wb') as out:
            out.setnchannels(1);out.setsampwidth(2);out.setframerate(RATE);out.writeframes(pcm.tobytes())
        print(f'Reserva original CC0: {name}')

if __name__=='__main__':main()
```

## scripts/generate_icons.py

```python
#!/usr/bin/env python3
"""Integra os assets aprovados da 2.5, sem redesenhar o logo por código."""
from pathlib import Path
from PIL import Image, ImageDraw
root = Path(__file__).resolve().parents[1]
full = Image.open(root/'design/icon-512.png').convert('RGBA')
foreground = Image.open(root/'design/keplerae-2.5-emblem.png').convert('RGBA')
res = root/'app/src/main/res'
full.resize((512,512),Image.Resampling.LANCZOS).save(res/'drawable-nodpi/keplerae_logo.png')
# A figura ocupa a zona segura; cada launcher aplica sua própria máscara.
canvas = Image.new('RGBA',(432,432),(0,0,0,0))
canvas.alpha_composite(foreground.resize((288,288),Image.Resampling.LANCZOS),(72,72))
canvas.save(res/'drawable-nodpi/keplerae_launcher_foreground.png')
for density,size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    icon = full.resize((size,size),Image.Resampling.LANCZOS)
    icon.save(res/f'mipmap-{density}/ic_launcher.png')
    mask = Image.new('L',(size,size),0)
    ImageDraw.Draw(mask).ellipse((0,0,size-1,size-1),fill=255)
    icon.putalpha(mask);icon.save(res/f'mipmap-{density}/ic_launcher_round.png')
print('Ícones 2.5 gerados para todas as densidades.')
```

## scripts/import_catalog.py

```python
#!/usr/bin/env python3
"""Importa as planilhas originais sem inventar URLs, títulos ou durações."""
import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse
from openpyxl import load_workbook

SOURCES = [
 ('Hu_Brasil_Fisioterapia_modulos_0_a_32(1).xlsx', 'fisioterapia', ['Fisioterapia']),
 ('Portugues_Adriana_Referencia-5-1(1).xlsx', 'portugues', ['Aulas']),
 ('Aulas_Raciocinio_Logico_e_Matematica(1).xlsx', 'matematica', ['Raciocínio Lógico e Matemática']),
 ('Aulas_Raciocinio_Logico_e_Matematica(2).xlsx', 'matematica', ['Raciocínio Lógico e Matemática']),
 ('Aulas_Legislacao_EBSERH(1).xlsx', 'hu_legislacao', ['Legislação EBSERH']),
 ('Aulas_SUS-1(1).xlsx', 'sus', ['Aulas SUS']),
 ('Aulas_Profisio(1).xlsx', 'profisio', ['Vídeos', 'Artigos', 'Áudios']),
]

def build(source_dir):
    items, seen, duplicates, skipped = [], set(), 0, []
    for name, subject, sheets in SOURCES:
        book = load_workbook(source_dir / name, data_only=True)
        for sheet_name in sheets:
            sheet = book[sheet_name]
            for row_no, row in enumerate(sheet.iter_rows(min_row=2), start=2):
                values = [c.value for c in row]
                if not any(values): continue
                module = str(values[0] or 'Geral').strip()
                portuguese = subject == 'portugues'
                filename = str(values[2 if portuguese else 1] or '').strip()
                link_cell = row[3]
                url = str(link_cell.hyperlink.target if link_cell.hyperlink else values[3] or '').strip()
                parsed = urlparse(url)
                if parsed.scheme != 'https' or parsed.hostname != 'drive.google.com':
                    skipped.append({'source':name,'sheet':sheet_name,'row':row_no,'reason':'Sem URL válida do Drive'})
                    continue
                folder = '/folders/' in parsed.path
                title_ref = str(values[5] or '').strip() if portuguese else ''
                title = title_ref if title_ref and title_ref != 'Nome individual a identificar' else re.sub(r'\.(mp4|pdf|mp3|m4a|wav)$','',filename,flags=re.I)
                ext = filename.lower().rsplit('.',1)[-1]
                kind = 'PDF' if ext == 'pdf' else 'AUDIO' if ext in ['mp3','m4a','wav'] else 'VIDEO'
                key = (subject,url,filename,module) if folder else (subject,parsed.path)
                if key in seen:
                    duplicates += 1
                    continue
                seen.add(key)
                notes = [str(values[6])] if portuguese and len(values)>6 and values[6] else []
                if folder: notes.append('A planilha fornece o link da pasta. Localize '+filename+' no Google Drive.')
                path = module.split(' / ') if subject == 'profisio' else [module]
                file_id = re.search(r'/file/d/([^/]+)',parsed.path)
                uid = hashlib.sha256(repr(key).encode()).hexdigest()[:20]
                items.append(dict(id=uid,title=title or filename,filename=filename,subjectId=subject,
                    folderPath=path,type=kind,url=url,linkKind='FOLDER' if folder else 'FILE',
                    driveFileId=file_id.group(1) if file_id else '',note=' '.join(notes),
                    source=name,sheet=sheet_name,row=row_no))
    report = dict(total=len(items),bySubject=dict(Counter(x['subjectId'] for x in items)),
                  byType=dict(Counter(x['type'] for x in items)),
                  fileLinks=sum(x['linkKind']=='FILE' for x in items),
                  folderLinks=sum(x['linkKind']=='FOLDER' for x in items),
                  duplicateRowsRemoved=duplicates,skippedRows=skipped)
    return items,report

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('source_dir',type=Path)
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'app/src/main/assets/catalog.json')
    args=parser.parse_args()
    items,report=build(args.source_dir)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n')
    (args.output.parent/'catalog_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False))
```

## scripts/recover_signing.py

```python
#!/usr/bin/env python3
"""Descriptografa o artifact e configura o Secret via gh, sem mostrar a chave."""
import argparse
import base64
import hashlib
import subprocess
import tempfile
import zipfile
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--artifact',required=True)
p.add_argument('--private-key',required=True)
p.add_argument('--destination',required=True,help='Pasta privada fora do repositório')
p.add_argument('--repository',help='owner/repo: também configura KEPLERAE_KEYSTORE_B64 com gh já autenticado')
a=p.parse_args()
def run(args,**kwargs): return subprocess.run(args,check=True,capture_output=True,**kwargs)
with tempfile.TemporaryDirectory() as temporary:
    work=Path(temporary)
    with zipfile.ZipFile(a.artifact) as z:
        for name in ['debug.keystore.enc','key-password.enc']:
            matches=[n for n in z.namelist() if Path(n).name==name]
            if len(matches)!=1: raise SystemExit('Artifact cifrado inválido.')
            (work/name).write_bytes(z.read(matches[0]))
    password=work/'password'
    run(['openssl','pkeyutl','-decrypt','-inkey',a.private_key,'-in',str(work/'key-password.enc'),
         '-out',str(password),'-pkeyopt','rsa_padding_mode:oaep','-pkeyopt','rsa_oaep_md:sha256'])
    key=work/'debug.keystore'
    run(['openssl','enc','-d','-aes-256-cbc','-pbkdf2','-iter','200000','-in',str(work/'debug.keystore.enc'),
         '-out',str(key),'-pass',f'file:{password}'])
    cert=work/'cert.der'
    run(['keytool','-exportcert','-keystore',str(key),'-storepass','android','-alias','androiddebugkey','-file',str(cert)])
    if hashlib.sha1(cert.read_bytes()).hexdigest().upper()!='16007901DBBFAB9DE7B5539FFAC604FAF19DBC8A':
        raise SystemExit('SHA-1 incorreto. A chave não será usada.')
    dest=Path(a.destination).resolve();dest.mkdir(parents=True,exist_ok=True,mode=0o700)
    target=dest/'debug.keystore'
    if target.exists(): raise SystemExit('Já existe um backup neste destino; ele não será sobrescrito.')
    target.write_bytes(key.read_bytes());target.chmod(0o600)
    if a.repository:
        run(['gh','secret','set','KEPLERAE_KEYSTORE_B64','--repo',a.repository],input=base64.b64encode(key.read_bytes()))
        print('Secret de assinatura configurado.')
print('SHA-1 confirmado e backup privado salvo. Nenhuma chave foi exibida.')
```

## scripts/restore_signing.py

```python
#!/usr/bin/env python3
"""Restaura o Secret sem imprimir sua representação base64 nem bytes privados."""
import base64
import os
from pathlib import Path
value = ''.join(os.environ.get('KEYSTORE_B64', '').split())
if not value:
    raise SystemExit('O Secret KEPLERAE_KEYSTORE_B64 não está configurado. Execute primeiro o resgate cifrado da assinatura anterior.')
try:
    contents = base64.b64decode(value, validate=True)
except ValueError:
    raise SystemExit('Secret de assinatura inválido: base64 incorreto.')
if not contents:
    raise SystemExit('Secret de assinatura vazio.')
folder = Path('.signing'); folder.mkdir(mode=0o700, exist_ok=True)
file = folder / 'debug.keystore'; file.write_bytes(contents); file.chmod(0o600)
print('Assinatura restaurada do Secret.')
```

## scripts/smoke_release.py

```python
#!/usr/bin/env python3
"""Instala o release real e detecta encerramento/crash na abertura após R8."""
import subprocess
import sys
import time
PACKAGE = 'com.aistudio.keplerae.stdy'
def adb(*args): return subprocess.run(['adb', *args], check=True, capture_output=True, text=True).stdout
adb('install', '-r', sys.argv[1])
adb('logcat', '-c')
adb('shell','am','force-stop',PACKAGE)
adb('shell','am','start','-W','-n',f'{PACKAGE}/com.example.MainActivity')
time.sleep(6)
logs = adb('logcat','-d','-b','crash')
if PACKAGE in logs and ('FATAL EXCEPTION' in logs or 'Fatal signal' in logs):
    print(logs)
    raise SystemExit('O APK release falhou ao abrir.')
if not adb('shell','pidof',PACKAGE).strip(): raise SystemExit('O processo release não permaneceu aberto.')
print('APK release instalado e aberto no emulador.')
```

## scripts/validate_ambient_sounds.py

```python
#!/usr/bin/env python3
"""Confere duração e costuras dos ambientes incluídos, sem substituir escuta real."""
import array
import json
from pathlib import Path
import subprocess
ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT/'app/src/main/res/raw'
for name in ('wind', 'rain', 'storm', 'fire', 'room', 'library'):
    path = RAW/f'ambient_{name}.ogg'
    info = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_streams',
                                              '-show_format', '-of', 'json', str(path)]))
    assert abs(float(info['format']['duration']) - 120) < .02, path.name
    assert info['streams'][0]['channels'] == 1, path.name
    pcm = array.array('h')
    pcm.frombytes(subprocess.check_output(['ffmpeg', '-v', 'error', '-i', str(path),
                                         '-ac', '1', '-ar', '22050', '-f', 's16le', '-']))
    assert len(pcm) == 120*22050, path.name
    assert 100 < max(map(abs, pcm)) < 32767, path.name
    # Uma costura não deve exceder as variações presentes na própria gravação.
    differences = sorted(abs(pcm[i] - pcm[i-1]) for i in range(1, len(pcm), 10))
    typical_limit = differences[int(len(differences)*.99)]
    assert abs(pcm[-1] - pcm[0]) <= max(512, typical_limit), path.name
    assert not path.with_suffix('.wav').exists(), path.name
print('6 ambientes: 120s, mono, sem clipping digital nem salto atípico na costura.')
```

## scripts/validate_catalog.py

```python
#!/usr/bin/env python3
import json
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse
root=Path(__file__).resolve().parents[1]
rows=json.loads((root/'app/src/main/assets/catalog.json').read_text())
report=json.loads((root/'app/src/main/assets/catalog_report.json').read_text())
assert len(rows)==report['total']==1022
assert len({r['id'] for r in rows})==len(rows)
assert set(r['subjectId'] for r in rows)=={'fisioterapia','portugues','matematica','hu_legislacao','sus','profisio'}
assert dict(Counter(r['type'] for r in rows))==report['byType']
for r in rows:
    u=urlparse(r['url'])
    assert u.scheme=='https' and u.hostname=='drive.google.com' and u.username is None
    assert r['title'] and r['filename'] and r['folderPath'] and r['source']
    assert all(p.strip() for p in r['folderPath'])
    if r['linkKind']=='FILE':
        assert '/file/d/' in u.path and r['driveFileId'] == u.path.split('/file/d/')[1].split('/')[0]
    else:
        assert '/drive/folders/' in u.path and not r['driveFileId']
        assert 'link da pasta' in r['note']
assert sum(r['linkKind']=='FOLDER' for r in rows)==342
assert not any('Keplerae_DriveFolderId' in r['url'] for r in rows)
assert sum(r['subjectId']=='matematica' for r in rows)==17
assert sum(r['type']=='AUDIO' for r in rows)==13
assert sum(r['subjectId']=='profisio' and r['type']=='PDF' for r in rows)==284
print('Catálogo validado: 1.022 itens; URLs, formatos, pastas e deduplicação consistentes.')
```

## scripts/validate_network_permissions.py

```python
import os
import re
import subprocess
import sys
from pathlib import Path
from xml.etree import ElementTree

REQUIRED = {"android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE"}
ANDROID_NAME = "{http://schemas.android.com/apk/res/android}name"


def validate(permissions):
    missing = REQUIRED - set(permissions)
    if missing:
        raise ValueError("Permissões de rede ausentes: " + ", ".join(sorted(missing)))


if __name__ == "__main__":
    if len(sys.argv) == 2:
        sdk = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
        if not sdk:
            raise RuntimeError("SDK Android não encontrado")
        aapt = Path(sdk) / "build-tools" / "36.0.0" / "aapt"
        output = subprocess.check_output([str(aapt), "dump", "permissions", sys.argv[1]], text=True)
        validate(re.findall(r"uses-permission: name='([^']+)'", output))
        print("APK final: permissões de internet e estado da rede presentes.")
    else:
        manifest = ElementTree.parse("app/src/main/AndroidManifest.xml").getroot()
        validate(node.get(ANDROID_NAME) for node in manifest.findall("uses-permission"))
        print("Manifesto: permissões de rede corretas.")
```

## scripts/validate_release.py

```python
#!/usr/bin/env python3
"""Validação estrutural pública da release 1.0.1; testes Kotlin/Android rodam no CI."""
from pathlib import Path
import runpy
ROOT=Path(__file__).resolve().parents[1]
runpy.run_path(str(ROOT/'scripts/validate_v25.py'),run_name='__main__')
gradle=(ROOT/'app/build.gradle.kts').read_text()
assert 'versionCode = 28' in gradle and 'versionName = "1.0.1"' in gradle
assert 'isMinifyEnabled = true' in gradle and 'isShrinkResources = true' in gradle
workflow=(ROOT/'.github/workflows/compilar-apk.yml').read_text()
assert 'Keplerae-1.0.1.zip' in workflow and 'assembleRelease' in workflow
assert workflow.index('validate_release.py')<workflow.index('Restaurar assinatura')
assert 'KEPLERAE_KEYSTORE_B64' in workflow and 'actions/cache' not in workflow
raw=ROOT/'app/src/main/res/raw'
names=[f.stem for f in raw.iterdir() if f.is_file()]
assert len(names)==len(set(names)), 'Recursos raw duplicados'
ui=ROOT/'app/src/main/java/com/example/ui'
app=(ui/'KepleraeApp.kt').read_text()
assert 'SidebarNavigation(' in app and 'FloatingAppNavigation' not in app and 'bottomBar =' not in app
sidebar=(ui/'components/SidebarNavigation.kt').read_text()
assert 'profile_rail' in sidebar and 'GoogleAvatar' in sidebar
profile=(ui/'profile/ProfileScreen.kt').read_text()
assert 'backupContent()' in profile and 'Kepleræ 1.0.1' in profile
codec=(ROOT/'app/src/main/java/com/example/data/backup/BackupJson.kt').read_text()
assert 'schemaVersion' in codec and 'MAX_BACKUP_BYTES' in codec
for private in ('accessToken','idToken','apiKey','keystore','password','photoUrl','email'):
    assert f'.put("{private}"' not in codec, f'Credencial/conta no backup: {private}'
assert 'backup_confirm_import' in (ui/'backup/BackupControls.kt').read_text()
print('Release 1.0.1/código 28, navegação lateral, backup portátil e workflow: estrutura OK.')
```

## scripts/validate_v25.py

```python
#!/usr/bin/env python3
"""Verificações estruturais; não substituem compilação Kotlin nem testes Android."""
import re
import xml.etree.ElementTree as ET
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
NS = '{http://schemas.android.com/apk/res/android}'
xml_files = list((ROOT/'app/src').rglob('*.xml'))
for file in xml_files: ET.parse(file)
manifest = ET.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot()
services = {s.attrib[NS+'name']:s for s in manifest.find('application').findall('service')}
assert '.data.playback.PlaybackService' in services
assert 'mediaPlayback' in services['.data.playback.PlaybackService'].attrib[NS+'foregroundServiceType']
assert any(a.attrib.get(NS+'name')=='androidx.media3.session.MediaSessionService'
           for a in services['.data.playback.PlaybackService'].iter('action'))
permissions = {p.attrib[NS+'name'] for p in manifest.findall('uses-permission')}
assert {'android.permission.INTERNET','android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK','android.permission.WAKE_LOCK'} <= permissions
# Recursos referenciados por Kotlin precisam existir antes de AAPT/AGP.
res = ROOT/'app/src/main/res'
resources = {}
for folder in res.iterdir():
    if not folder.is_dir(): continue
    kind = folder.name.split('-')[0]
    if kind == 'values':
        for file in folder.glob('*.xml'):
            for node in ET.parse(file).getroot():
                if 'name' in node.attrib: resources.setdefault(node.tag.replace('string-array','array'),set()).add(node.attrib['name'])
    else:
        resources.setdefault(kind,set()).update(p.stem for p in folder.iterdir() if p.is_file())
for file in (ROOT/'app/src/main/java').rglob('*.kt'):
    for kind,name in re.findall(r'(?<![\w.])R\.(\w+)\.(\w+)',file.read_text()):
        assert name in resources.get(kind,set()),f'Recurso ausente: {file.name}: R.{kind}.{name}'
# Nunca inclui material privado no pacote de código público.
for file in ROOT.rglob('*'):
    if file.is_file() and 'build' not in file.parts:
        assert file.suffix not in {'.keystore','.jks','.pem'},f'Material de assinatura no projeto: {file}'
assert not (ROOT/'.github/workflows/android-apk.yml').exists()
# Detecta delimitadores quebrados em edições, respeitando strings e comentários Kotlin.
def balanced(text):
    length=len(text)
    def comment(i):
        depth=1;i+=2
        while depth and i<length:
            if text.startswith('/*',i): depth+=1;i+=2
            elif text.startswith('*/',i): depth-=1;i+=2
            else:i+=1
        assert depth==0,'Comentário não fechado'
        return i
    def quoted(i):
        quote='"""' if text.startswith('"""',i) else text[i]
        i+=len(quote)
        while i<length:
            if text.startswith(quote,i):return i+len(quote)
            if quote!='"""' and text[i]=='\\':i+=2;continue
            if quote!='\'' and text.startswith('${',i):
                depth=1;i+=2
                while depth and i<length:
                    if text[i] in ['"',"'"]:i=quoted(i)
                    elif text.startswith('/*',i):i=comment(i)
                    elif text.startswith('//',i):i=text.find('\n',i) if '\n' in text[i:] else length
                    elif text[i]=='{':depth+=1;i+=1
                    elif text[i]=='}':depth-=1;i+=1
                    else:i+=1
                assert depth==0,'Interpolação não fechada'
            else:i+=1
        raise AssertionError('String não fechada')
    i=0;stack=[];pairs={')':'(',']':'[','}':'{'}
    while i<length:
        if text.startswith('//',i):i=text.find('\n',i) if '\n' in text[i:] else length
        elif text.startswith('/*',i):i=comment(i)
        elif text[i] in ['"',"'"]:i=quoted(i)
        elif text[i]=='`':
            i=text.find('`',i+1)+1;assert i>0,'Identificador não fechado'
        elif text[i] in '([{':stack.append(text[i]);i+=1
        elif text[i] in ')]}':
            assert stack and stack.pop()==pairs[text[i]],f'Delimitador incorreto na posição {i}'
            i+=1
        else:i+=1
    assert not stack,'Delimitador não fechado'
files=list((ROOT/'app/src').rglob('*.kt'))+list(ROOT.rglob('*.kts'))
for file in files:
    try:balanced(file.read_text())
    except AssertionError as error:raise AssertionError(f'{file.relative_to(ROOT)}: {error}') from error
print(f'Estrutura validada: {len(files)} arquivos Kotlin/Gradle, {len(xml_files)} XMLs, recursos e serviço de áudio.')
```

## scripts/verify_signing.py

```python
#!/usr/bin/env python3
import hashlib
import subprocess
import tempfile
from pathlib import Path
EXPECTED = '16007901DBBFAB9DE7B5539FFAC604FAF19DBC8A'
file = Path('.signing/debug.keystore')
if not file.is_file(): raise SystemExit('Assinatura anterior ausente. Não será criada uma chave nova.')
with tempfile.TemporaryDirectory() as temporary:
    cert = Path(temporary) / 'cert.der'
    subprocess.run(['keytool','-exportcert','-keystore',str(file),'-storepass','android',
                    '-alias','androiddebugkey','-file',str(cert)],check=True,capture_output=True)
    actual = hashlib.sha1(cert.read_bytes()).hexdigest().upper()
if actual != EXPECTED: raise SystemExit('A assinatura difere do APK instalado. Recupere a chave anterior.')
print('SHA-1 da versão instalada confirmado.')
```

## settings.gradle.kts

```kotlin
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "Keplerae"
include(":app")
```
