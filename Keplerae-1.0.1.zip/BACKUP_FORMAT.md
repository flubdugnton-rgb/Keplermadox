# Backup portátil Kepleræ — schemaVersion 1

O arquivo é JSON UTF-8, com `format: "keplerae-backup"`, `schemaVersion: 1`, `appVersion: "1.0.1"` e `exportedAt` em milissegundos Unix UTC. `appVersion` é informativo; a compatibilidade é determinada pelo schemaVersion. Tema é `SYSTEM`, `LIGHT` ou `DARK`. Os IDs são strings estáveis; preserve-os ao implementar clientes iOS/macOS.

## Campos

| Seção | Conteúdo |
|---|---|
| study | favorites/completed: arrays de IDs do catálogo; accessed: array {id, at}; itemOrder: array de IDs; theme; dynamicColor |
| notes | tags: {id,name}; items: {id,title,body,tagId,tone,createdAt,updatedAt}; tagId pode ser null; tone de 0 a 4 |
| questions | subjects: {id,name}; records: {id,subjectId,correct,wrong,recordedAt} |
| pomodoro | settings com foco/pausas/ciclos, alarme, avanço automático, ambiente e volume; history: {id,finishedAt,durationMs} |
| pdf | stylusOnly; straightHighlight; documents: {driveFileId,lastPage,annotations} |

`annotations` tem version 1 e pages: {page, strokes, notes}. Cada traço: {id,highlight,color,width,points}; points contém pares [x,y]. Cada pin: {id,x,y,text}. X/Y e width são frações da área real da página, de 0 a 1; width deve ser maior que zero. color é ARGB unsigned de 32 bits, escrito como inteiro JSON. page/lastPage são índices a partir de zero. Os nomes de arquivo hash e o email da conta Android não fazem parte do contrato.

## Como importar

1. Validar format/schemaVersion, limites, IDs únicos e relações antes de escrever.
2. Unir favoritos/conclusões, usar o acesso mais recente por ID e priorizar a ordem importada, adicionando os IDs locais restantes.
3. Blocos de Notas e matérias de Questões são reaproveitados por ID ou nome sem diferenciar maiúsculas. Remapear referências dos registros para o ID escolhido. Em notas com o mesmo ID, vence updatedAt maior; empates mantêm a nota local.
4. Registros de questões e focos do Pomodoro não se repetem por ID; conflito mantém o registro local. Totais/gráficos são derivados dos registros, sem exportar valores redundantes.
5. Unir traços/pins por ID dentro da página. Aplicar a página de leitura importada. Mapear driveFileId para o cache local da conta conectada. Um índice local preserva documentos importados ainda não baixados.
6. Aplicar tema/cores e configurações do Pomodoro. O timer ativo do aparelho não é restaurado do backup; continua com seu prazo atual. Em iOS/macOS, a preferência de cores dinâmicas deverá ser adaptada à plataforma.

A UI pede confirmação com os totais. Importar não apaga coleções locais. Uma exportação antiga pode recuperar registros que você já excluiu; o formato não armazena tombstones de exclusão nem implementa sincronização contínua.

## Limites e gravação

O leitor aceita até 25 MiB e 50.000 objetos por coleção. IDs têm até 256 caracteres; nomes de blocos até 30 e matérias de Questões até 80. Notas aceitam título até 2.000 e corpo até 200.000 caracteres. Questões: cada contagem de 0 a 1.000.000 e total maior que zero. Foco 1–180 min, pausas 1–90 min, ciclos 1–12, volume finito 0–1. Históricos de foco aceitam duração de 1 ms a 180 minutos. Coordenadas inválidas, referências ausentes e schemas futuros são recusados.

Cada arquivo de anotações é gravado com AtomicFile; preferências usam commit/DataStore. Não há transação única entre todos os módulos. Em uma falha de armazenamento, algumas adições/configurações podem ter sido aplicadas; corrigir o problema e importar de novo é seguro quanto à duplicação por ID. O arquivo externo exportado é uma cópia legível dos seus registros, sem credenciais.

## Exemplo mínimo

```json
{
  "format": "keplerae-backup",
  "schemaVersion": 1,
  "appVersion": "1.0.1",
  "exportedAt": 1791547200000,
  "study": {
    "favorites": [], "completed": [], "accessed": [], "itemOrder": [],
    "theme": "SYSTEM", "dynamicColor": true
  },
  "notes": {"tags": [], "items": []},
  "questions": {"subjects": [], "records": []},
  "pomodoro": {
    "settings": {
      "focusMinutes": 25, "shortMinutes": 5, "longMinutes": 15, "cycles": 4,
      "sounds": true, "sound": "bell", "autoAdvance": false,
      "ambienceEnabled": false, "ambienceId": "rain", "ambienceVolume": 0.35
    },
    "history": []
  },
  "pdf": {"stylusOnly": false, "straightHighlight": true, "documents": []}
}
```

Os IDs das faixas de ambiente existentes são definidos em PomodoroAmbience.kt. Para uma futura versão multiplataforma, mantenha os mesmos IDs ou forneça o mapeamento correspondente. Nenhuma chave, login ou mídia é carregada pelo importador. O usuário continua entrando com Google normalmente em cada instalação.
