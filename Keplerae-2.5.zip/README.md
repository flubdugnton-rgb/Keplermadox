# Kepleræ 2.5.0

Projeto Android completo, baseado na 2.4 instalada. `applicationId` continua `com.aistudio.keplerae.stdy`; versão 2.5.0 / código 26. Favoritos, conclusões, ordem dos materiais, conta Google, preferências, questões e histórico do Pomodoro são preservados na atualização assinada com a chave anterior.

## Mudanças

- Notificação Pomodoro usa o cronômetro do Android. A fase e o ciclo atualizam somente quando o estado muda; o serviço confere o prazo a cada 200 ms–30 s, sem reconstruir a notificação a cada segundo.
- Shared elements têm escopo por aba. Trocar de aba usa fade de 120/80 ms; entrar em matéria/pasta mantém a continuidade visual. Filtros dos cartões usam `remember`.
- Tela cheia esconde também status e navegação do Android, com barras transitórias por gesto.
- PDFs salvos no aparelho abrem offline e lembram a página. O cache é separado por conta e usa download atômico.
- Caneta, marca-texto (livre ou reto), borracha de traço inteiro, notas com pins, lista de notas, desfazer e modo “só a caneta desenha”. Um dedo desenha; dois ampliam/movem. A mão libera o pager. As coordenadas acompanham o zoom. As alterações ficam locais; o PDF original do Drive não muda.
- Áudio em `MediaSessionService`: continua com a tela bloqueada, com controles de reprodução e playlist na notificação. O token Google é renovado ao abrir requisições de mídia; um 401 limpa o token antigo e tenta novamente uma vez. Vídeo mantém a pausa ao sair do app.
- Aba Notas com FAB, edição, blocos, busca, cores, grade/lista e pequeno movimento de entrada dos cartões. Apenas os três arquivos de Notas e o teste correspondente foram aproveitados do ZIP enviado.
- Pastas/matérias têm gradientes suaves no claro e cores profundas no escuro, com progresso real. Novo ícone claro mantém livro e órbitas, incluindo as densidades Android e a versão temática monocromática.
- APK de uso diário passa a ser release, com R8 e redução de recursos, usando a mesma assinatura.

## Assinatura: resgate antes da troca de workflow

O repositório é `flubdugnton-rgb/Keplermadox`. A conexão atual consegue ler o projeto e os resultados de Actions, mas a tentativa de publicar o resgate foi recusada com HTTP 403: `Resource not accessible by integration`. O conector também não disponibiliza administração de Secrets. Não houve alteração remota, resgate da chave, criação do Secret nem compilação da 2.5.

1. A etapa seguinte é publicar o workflow temporário e executá-lo pela interface do GitHub. O Codex pode continuar pelo navegador após autorização para esse fallback, exigida porque o conector não permite a operação. Não é necessário preparar base64 no Termux.
2. O arquivo separado `resgatar-assinatura.yml` deve ficar em `.github/workflows/resgatar-assinatura.yml`. Ele só roda manualmente: não gera outro APK nem consome minutos em cada push. Recupera o cache `keplerae-native-debug-signing-v1`, confere o SHA-1 e disponibiliza somente `keystore-backup-cifrado` por 1 dia.
3. A senha aleatória do backup AES-256-CBC/PBKDF2 é protegida com RSA-OAEP. A chave pública do destinatário está no workflow; a privada fica apenas em **Resgate-assinatura-PRIVADO.zip**, fora do projeto. **Nunca envie esse ZIP privado ao GitHub.** Guarde-o offline: ele permite abrir o artifact cifrado. Ele não contém ainda a assinatura original do app.
4. `scripts/recover_signing.py` faz a descriptografia e a conferência do certificado. Com acesso via `gh` já autenticado, também envia diretamente a chave em base64 para `KEPLERAE_KEYSTORE_B64`, sem imprimir seu conteúdo. Mantém uma cópia privada fora do repositório. Essa etapa continua pendente enquanto não houver acesso para resgate/administração do Secret.
5. Depois de confirmar o backup e o Secret, apague o artifact de resgate e remova o workflow temporário. Se o cache já tiver expirado, será necessário um backup anterior da chave: não é possível recuperá-la do APK ou do SHA-1. O código bloqueia release com outra assinatura.

SHA-1 esperado: `16:00:79:01:DB:BF:AB:9D:E7:B5:53:9F:FA:C6:04:FA:F1:9D:BC:8A`.

## Compilação no GitHub

Após preservar a assinatura:

1. Envie `Keplerae-2.5.zip` intacto à raiz do repositório. Ele contém o projeto direto, sem pasta externa.
2. Substitua `.github/workflows/compilar-apk.yml` pelo arquivo 2.5 entregue separadamente. A cópia dentro do ZIP, sozinha, não altera o workflow do GitHub.
3. Remova `.github/workflows/android-apk.yml`, se ainda existir no repositório. Ele foi removido deste projeto e a consulta ao caminho remoto também retornou 404, indicando que já está ausente.
4. Preserve a variável já configurada `GOOGLE_WEB_CLIENT_ID`. Não precisa criar novos clientes OAuth: pacote e certificado continuam os mesmos. Nenhum client secret, refresh token ou assinatura privada entra no código.
5. O workflow restaura e confere o Secret nos dois jobs, executa testes unitários release, lint, compilação release e testes de dispositivo. O job interface instala também o APK release real e verifica se permanece aberto sem crash após R8.
6. Artifact: `Keplerae-2.5-APK`. Arquivo: `Keplerae-2.5.0-release.apk`. Instale como atualização; não desinstale a versão anterior. O artifact de verificações inclui `mapping.txt` para investigar erros em código otimizado.

## Gradle e dependências

AGP 8.11.1, Gradle 8.13, Kotlin 2.2.21, Java 17; compile/target SDK 36, min SDK 24. O workflow instala Gradle; o projeto não inclui wrapper JAR.

Única nova dependência Android nesta versão:

```kotlin
implementation("androidx.media3:media3-session:1.8.1")
```

Media3 ExoPlayer/UI também ficam em 1.8.1. Continuam Compose 1.9.4, Material3 **1.5.0-alpha07** (alpha já autorizada), Haze 1.7.0, Coil 3.3.0, Credential Manager 1.6.0, Google Identity Services, DataStore e a tipografia Google. Não foi necessário acrescentar outra biblioteca de PDF, desenho ou animação.

## Dados e limitações práticas

PDFs ficam em `filesDir/pdfs` com chave SHA-256 de conta + ID do Drive. Cache é excluído do backup Android para não consumir a cota; notas gerais e anotações permanecem incluídas. PDFs locais só são baixados novamente quando ausentes. O conteúdo cacheado pode ficar desatualizado se o original for substituído no Drive.

Anotações em `filesDir/annotations/<chave>.json`, com escrita atômica. Desfazer cobre as últimas 50 operações por página durante a abertura atual; traços e notas persistem entre aberturas. A borracha remove traços completos. O marca-texto usa Multiply sobre página branca. Exportação de PDF anotado fica para uma versão posterior.

Os relatórios da 2.4 mostraram duas falhas de dispositivo. O teste de interface agora espera a sheet fechar e usa o botão do perfil, evitando encerrar a Activity com dois Back consecutivos. O teste do pager usa arrasto controlado, sem fling; sua falha anterior ainda precisa ser reavaliada no emulador. Não houve execução em aparelho/emulador nem compilação Kotlin da 2.5 nesta entrega. Verificações locais e testes preparados estão descritos em `CHECKS-2.5.md`; não equivalem a APK aprovado.

## Referências técnicas

- Media3: https://developer.android.com/media/media3/session/background-playback
- Resolução de requisições: https://developer.android.com/reference/androidx/media3/datasource/ResolvingDataSource
