# Arquivos da atualização 2.5

Base: Kepleræ 2.4.0. Código completo dos arquivos incluído no projeto ZIP.

## Alterados

- `.github/workflows/compilar-apk.yml`
- `ARQUIVOS_ALTERADOS.md`
- `README.md`
- `app/build.gradle.kts`
- `app/proguard-rules.pro`
- `app/src/androidTest/java/com/example/InterfaceTest.kt`
- `app/src/androidTest/java/com/example/NativePdfPagerTest.kt`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/example/data/auth/GoogleLoginViewModel.kt`
- `app/src/main/java/com/example/data/productivity/PomodoroService.kt`
- `app/src/main/java/com/example/ui/CatalogScreen.kt`
- `app/src/main/java/com/example/ui/DriveViewer.kt`
- `app/src/main/java/com/example/ui/KepleraeApp.kt`
- `app/src/main/java/com/example/ui/NativeMedia.kt`
- `app/src/main/java/com/example/ui/NativePdf.kt`
- `app/src/main/java/com/example/ui/components/SharedMotion.kt`
- `app/src/main/java/com/example/ui/home/HomeScreen.kt`
- `app/src/main/java/com/example/ui/profile/ProfileScreen.kt`
- `app/src/main/res/drawable-nodpi/keplerae_launcher_foreground.png`
- `app/src/main/res/drawable-nodpi/keplerae_logo.png`
- `app/src/main/res/drawable/ic_launcher_background.xml`
- `app/src/main/res/mipmap-hdpi/ic_launcher.png`
- `app/src/main/res/mipmap-hdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-mdpi/ic_launcher.png`
- `app/src/main/res/mipmap-mdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-xhdpi/ic_launcher.png`
- `app/src/main/res/mipmap-xhdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-xxhdpi/ic_launcher.png`
- `app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-xxxhdpi/ic_launcher.png`
- `app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png`
- `app/src/main/res/xml/backup_rules.xml`
- `app/src/main/res/xml/data_extraction_rules.xml`
- `design/icon-512.png`
- `scripts/generate_icons.py`

## Novos

- `.github/workflows/resgatar-assinatura.yml`
- `CHANGELOG-2.5.md`
- `CHECKS-2.5.md`
- `app/src/androidTest/java/com/example/NotesScreenTest.kt`
- `app/src/androidTest/java/com/example/PdfPersistenceTest.kt`
- `app/src/main/java/com/example/data/notes/NoteModel.kt`
- `app/src/main/java/com/example/data/notes/NoteStore.kt`
- `app/src/main/java/com/example/data/pdf/PdfAnnotations.kt`
- `app/src/main/java/com/example/data/pdf/PdfCache.kt`
- `app/src/main/java/com/example/data/playback/DrivePlaybackSource.kt`
- `app/src/main/java/com/example/data/playback/PlaybackService.kt`
- `app/src/main/java/com/example/ui/components/FolderSurface.kt`
- `app/src/main/java/com/example/ui/notes/NotesScreen.kt`
- `app/src/test/java/com/example/NotesFilterTest.kt`
- `app/src/test/java/com/example/PdfInkGeometryTest.kt`
- `design/keplerae-2.5-emblem.png`
- `scripts/recover_signing.py`
- `scripts/restore_signing.py`
- `scripts/smoke_release.py`
- `scripts/validate_v25.py`
- `scripts/verify_signing.py`

## Removidos

- `.github/workflows/android-apk.yml`

