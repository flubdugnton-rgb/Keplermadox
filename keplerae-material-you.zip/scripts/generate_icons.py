#!/usr/bin/env python3
"""Rasteriza o símbolo original em todos os tamanhos do launcher."""
from pathlib import Path
from PIL import Image, ImageDraw
root=Path(__file__).resolve().parents[1]

def icon(size,rounded=False):
    scale=8
    s=size*scale
    im=Image.new('RGBA',(s,s))
    d=ImageDraw.Draw(im)
    def p(x,y): return (x/108*s,y/108*s)
    if rounded: d.ellipse([0,0,s,s],fill='#5146A4')
    else: d.rounded_rectangle([0,0,s,s],radius=s*.25,fill='#5146A4')
    # Cubic Bezier boundaries reproduce icon.svg and the Android vector.
    def cubic(a,b,c,e):
        pts=[]
        for n in range(33):
            t=n/32
            pts.append(p((1-t)**3*a[0]+3*(1-t)**2*t*b[0]+3*(1-t)*t*t*c[0]+t**3*e[0],
                         (1-t)**3*a[1]+3*(1-t)**2*t*b[1]+3*(1-t)*t*t*c[1]+t**3*e[1]))
        return pts
    pts=cubic((28,35),(39,32),(46,34),(54,40))+cubic((54,40),(62,34),(69,32),(80,35))
    pts+=[p(80,72)]+cubic((80,72),(69,69),(62,71),(54,77))+cubic((54,77),(46,71),(39,69),(28,72))
    d.polygon(pts,fill='#F7F1FF')
    d.line([p(54,41),p(54,71)],fill='#5146A4',width=round(s/108*3))
    d.polygon([p(*v) for v in [(71,22),(74,28),(80,31),(74,34),(71,40),(68,34),(62,31),(68,28)]],fill='#C7F3DA')
    return im.resize((size,size),Image.Resampling.LANCZOS)
for density,size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    dest=root/'app/src/main/res'/f'mipmap-{density}'
    dest.mkdir(exist_ok=True)
    icon(size).save(dest/'ic_launcher.png')
    icon(size,True).save(dest/'ic_launcher_round.png')
icon(512).save(root/'design/icon-512.png')
print('Ícones gerados: 10 launcher PNGs e 1 PNG de 512 px')
