# Kepleræ 1.1.0

App Android nativo em Kotlin e Jetpack Compose com Material 3, formas expressivas, animação nas transições e ao tocar nas matérias, cores dinâmicas e temas Sistema, Claro e Escuro. Em tablets, a navegação vira uma barra lateral. Requer Android 7.0 ou superior. Mantém o identificador original `com.aistudio.keplerae.stdy`.

## Conteúdo

| Matéria | Materiais |
| --- | ---: |
| Fisioterapia — HU Brasil | 170 |
| Português | 356 |
| Matemática e Raciocínio Lógico | 17 |
| HU Legislação — EBSERH | 33 |
| SUS | 135 |
| Profisio | 311 |
| Total | 1.022 |

703 aulas, 306 PDFs e 13 áudios. Profisio preserva a hierarquia especialidade → ciclo → volume. Os dois arquivos de Matemática eram duplicados; 17 linhas foram deduplicadas. Duas linhas de Fisioterapia registram pendências sem URL e estão documentadas em `catalog_report.json`.

Todos os links originais estão em `app/src/main/assets/catalog.json`. Não há API, chave de API, Firebase ou sincronização simulada. Favoritos, conclusões, acessos recentes e aparência são salvos no aparelho.

342 registros de Português fornecem apenas o link de uma pasta. O app conserva cada título, nome esperado do arquivo e notas de conferência. O botão **Abrir pasta** abre a pasta para localizar o arquivo. O ID de um vídeo ou PDF não pode ser deduzido do ID de uma pasta.

680 registros têm link de arquivo e abrem no visualizador de prévia do Google Drive dentro do app, incluindo áudio. O próprio player do Drive oferece os controles. Se o material pedir login ou permissão, use **Abrir no Drive**. A leitura/reprodução depende das permissões do material e da internet. Esta versão não tem download offline ou áudio em segundo plano.

## Design e ícone

Figma editável: https://www.figma.com/design/pQWmh3JrwAj83TcxTWGATW

Inclui início claro, início escuro, PDFs do Profisio e uma aula de Português, com componentes e tokens. O plano Figma atual permite um modo por coleção, então as paletas foram organizadas em coleções separadas.

Ícone genérico original: livro com uma estrela. Inclui PNGs em todas as densidades, ícone adaptativo e versão monocromática para ícones temáticos. As fontes estão em `design/icon.svg` e `design/icon-512.png`.

## Gerar APK no GitHub

1. O destino escolhido para o projeto é https://github.com/flubdugnton-rgb/Keplermadox. Autorize esse repositório na conexão GitHub do ChatGPT para publicar por ela.
2. Envie o conteúdo desta pasta para a raiz do repositório, incluindo `.github/workflows/android-apk.yml`.
3. Abra **Actions → Compilar APK Keplerae → Run workflow**. O fluxo também roda em push para `main` ou `master`.
4. Depois do sucesso, baixe **Keplerae-APK** em **Artifacts**, extraia o ZIP e instale `Keplerae-1.1.0-debug.apk` no Android.

O fluxo instala Java 17, Gradle 8.13 e SDK Android 36. Valida o catálogo, executa testes unitários e lint, compila o APK de teste assinado e o disponibiliza por 30 dias. A chave de teste usa cache; se esse cache for apagado, poderá ser necessário desinstalar a versão anterior. Desinstalar pode remover favoritos e progresso.

Para publicação na Play Store, configure uma assinatura de distribuição própria. O build release permanece sem assinatura. O ZIP original não trazia `gradlew` nem `gradle-wrapper.jar`; o Actions usa `setup-gradle`, que instala o Gradle fixado sem esses arquivos.

## Compilar no computador

Abra a pasta no Android Studio, ou instale JDK 17, Android SDK 36 e Gradle 8.13. Defina `ANDROID_HOME` ou crie `local.properties` com `sdk.dir=/caminho/do/android-sdk`.

```bash
gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

Para o teste de interface, inicie um emulador ou conecte um Android:

```bash
gradle :app:connectedDebugAndroidTest
```

Também é possível marcar **Executar teste de interface no emulador** no fluxo manual do GitHub.

## Atualizar links

As planilhas não são necessárias para compilar: o JSON já está incluído. Para reimportar, coloque os sete arquivos em uma pasta e instale `openpyxl`:

```bash
python3 scripts/import_catalog.py /caminho/das/planilhas
python3 scripts/validate_catalog.py
```

## Verificação desta entrega

Conferidos os 1.022 registros contra suas planilhas, formatos, URLs, pastas, duplicação e nomes esperados. Validados os XMLs Android e o YAML do Actions. Revisadas visualmente as quatro telas no Figma. Incluídos testes Kotlin para URLs de arquivo/pasta, busca sem acentos e hierarquia, e teste de interface para catálogo e temas.

O catálogo e os arquivos de projeto foram verificados localmente. A publicação foi tentada, mas o GitHub recusou a gravação com erro 403 (`Resource not accessible by integration`). O navegador deste ambiente também bloqueou o acesso ao GitHub (`ERR_BLOCKED_BY_CLIENT`). Ainda não há APK compilado. Após autorizar o repositório e publicar os arquivos, a compilação, os testes unitários e o lint serão executados pelo GitHub Actions. O teste de interface no emulador está disponível na execução manual.

## Alternativa: compilar o ZIP publicado

Envie `keplerae-material-you.zip` sem extrair para a raiz do repositório. Depois, crie `.github/workflows/compilar-apk.yml` com o conteúdo do arquivo `compilar-apk.yml` fornecido separadamente. Esse fluxo extrai o projeto no runner, valida, testa e compila. Não basta enviar o ZIP: o fluxo precisa estar fora dele no caminho indicado. Após salvar os dois arquivos em `main`, acompanhe Actions e baixe o artefato `Keplerae-APK` após uma execução bem-sucedida.
