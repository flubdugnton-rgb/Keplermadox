package com.example.data.repository

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

enum class ThemeMode(val label: String) { SYSTEM("Sistema"), LIGHT("Claro"), DARK("Escuro") }
data class StudyState(
    val items: List<StudyItem> = emptyList(),
    val favorites: Set<String> = emptySet(),
    val completed: Set<String> = emptySet(),
    val accessed: Map<String, Long> = emptyMap(),
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val loading: Boolean = true,
    val error: String? = null
)
class StudyViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application
    private val preferences = application.getSharedPreferences("keplerae", 0)
    private val mutableState = MutableStateFlow(StudyState(
        favorites = preferences.getStringSet("favorites", emptySet())!!.toSet(),
        completed = preferences.getStringSet("completed", emptySet())!!.toSet(),
        accessed = readAccessed(),
        theme = runCatching { ThemeMode.valueOf(preferences.getString("theme", "SYSTEM")!!) }.getOrDefault(ThemeMode.SYSTEM),
        dynamicColor = preferences.getBoolean("dynamic_color", true)
    ))
    val state = mutableState.asStateFlow()
    init { reload() }
    fun reload() {
        mutableState.value = mutableState.value.copy(loading = true, error = null)
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching {
                val json = JSONArray(app.assets.open("catalog.json").bufferedReader().use { it.readText() })
                List(json.length()) { index ->
                    val row = json.getJSONObject(index)
                    val path = row.getJSONArray("folderPath")
                    StudyItem(row.getString("id"), row.getString("title"), row.getString("filename"),
                        row.getString("subjectId"), List(path.length()) { path.getString(it) },
                        ContentType.valueOf(row.getString("type")), row.getString("url"),
                        LinkKind.valueOf(row.getString("linkKind")), row.getString("driveFileId"),
                        row.getString("note"), row.getString("source"))
                }.also { rows -> require(rows.all { isAllowedDriveUrl(it.url) }) }
            } }
            mutableState.value = result.fold(
                onSuccess = { mutableState.value.copy(items = it, loading = false) },
                onFailure = { mutableState.value.copy(loading = false, error = "Não foi possível carregar a biblioteca.") }
            )
        }
    }
    private fun readAccessed(): Map<String,Long> = runCatching {
        val json = JSONObject(preferences.getString("accessed", "{}")!!)
        json.keys().asSequence().associateWith { json.getLong(it) }
    }.getOrDefault(emptyMap())
    fun toggleFavorite(id: String) {
        val next = mutableState.value.favorites.toMutableSet().apply { if (!add(id)) remove(id) }
        preferences.edit().putStringSet("favorites", next).apply()
        mutableState.value = mutableState.value.copy(favorites = next)
    }
    fun toggleCompleted(id: String) {
        val next = mutableState.value.completed.toMutableSet().apply { if (!add(id)) remove(id) }
        preferences.edit().putStringSet("completed", next).apply()
        mutableState.value = mutableState.value.copy(completed = next)
    }
    fun recordAccess(id: String) {
        val next = mutableState.value.accessed + (id to System.currentTimeMillis())
        preferences.edit().putString("accessed", JSONObject(next).toString()).apply()
        mutableState.value = mutableState.value.copy(accessed = next)
    }
    fun setTheme(theme: ThemeMode) {
        preferences.edit().putString("theme", theme.name).apply()
        mutableState.value = mutableState.value.copy(theme = theme)
    }
    fun setDynamicColor(enabled: Boolean) {
        preferences.edit().putBoolean("dynamic_color", enabled).apply()
        mutableState.value = mutableState.value.copy(dynamicColor = enabled)
    }
}
