@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.LibraryBooks
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.*
import com.example.data.repository.*
import com.example.ui.theme.isDarkMode

enum class Destination(val title: String, val icon: ImageVector, val type: ContentType?) {
    HOME("Início", Icons.Outlined.Home, null),
    VIDEOS("Aulas", Icons.Outlined.PlayCircleOutline, ContentType.VIDEO),
    PDFS("PDFs", Icons.AutoMirrored.Filled.LibraryBooks, ContentType.PDF),
    AUDIO("Áudios", Icons.Outlined.Headphones, ContentType.AUDIO),
    SUBJECTS("Matérias", Icons.Outlined.GridView, null)
}

@Composable fun KepleraeApp(state: StudyState, model: StudyViewModel) {
    var destinationName by rememberSaveable { mutableStateOf(Destination.HOME.name) }
    var subjectId by rememberSaveable { mutableStateOf<String?>(null) }
    var pathKey by rememberSaveable { mutableStateOf("") }
    var settings by rememberSaveable { mutableStateOf(false) }
    var activeId by rememberSaveable { mutableStateOf<String?>(null) }
    val destination = Destination.valueOf(destinationName)
    val subject = subjectId?.let { Subjects.get(it) }
    val path = if (pathKey.isBlank()) emptyList() else pathKey.split('\u001f')
    val activeItem = state.items.firstOrNull { it.id == activeId }
    val context = LocalContext.current
    fun navigate(next: Destination) { destinationName = next.name; subjectId = null; pathKey = "" }
    fun select(next: Subject) { subjectId = next.id; pathKey = "" }
    fun open(item: StudyItem) {
        model.recordAccess(item.id)
        if (item.linkKind == LinkKind.FOLDER) {
            openDrive(context, item.url)
        } else activeId = item.id
    }
    fun back() { if (path.isNotEmpty()) pathKey = path.dropLast(1).joinToString("\u001f") else subjectId = null }
    BackHandler(enabled = subject != null && activeItem == null && !settings) { back() }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val expanded = maxWidth >= 700.dp
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (subject == null) {
                            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(16.dp)) {
                                Icon(painterResource(R.drawable.ic_kepler_symbol), null,
                                    Modifier.padding(10.dp).size(24.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                        }
                        Text(subject?.name ?: "Kepleræ", style = MaterialTheme.typography.titleLarge,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }, navigationIcon = {
                    if (subject != null) IconButton(onClick = ::back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
                }, actions = {
                    IconButton(onClick = { settings = true }, modifier = Modifier.testTag("settings")) {
                        Icon(Icons.Outlined.Palette, "Aparência")
                    }
                }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface))
            },
            bottomBar = {
                if (!expanded) NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                    Destination.entries.forEach { dest -> NavigationBarItem(
                        selected = destination == dest,
                        onClick = { navigate(dest) },
                        icon = { Icon(dest.icon, null) },
                        label = { Text(dest.title) }, modifier = Modifier.testTag("nav_${dest.name}"))
                    }
                }
            }, containerColor = MaterialTheme.colorScheme.surface
        ) { padding ->
            Row(Modifier.fillMaxSize().padding(padding)) {
                if (expanded) NavigationRail(containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxHeight()) {
                    Spacer(Modifier.height(24.dp))
                    Destination.entries.forEach { dest -> NavigationRailItem(selected = destination == dest,
                        onClick = { navigate(dest) }, icon = { Icon(dest.icon, null) }, label = { Text(dest.title) }) }
                }
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
                    Box(Modifier.widthIn(max = 960.dp).fillMaxSize()) {
                        when {
                            state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                            state.error != null -> Column(Modifier.align(Alignment.Center).padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(state.error)
                                Button(onClick = model::reload) { Text("Tentar novamente") }
                            }
                            else -> AnimatedContent(targetState = subjectId to destination,
                                transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "destinations") { (selectedId, dest) ->
                                if (selectedId == null && dest == Destination.HOME) {
                                    Dashboard(state, ::navigate, ::select, ::open)
                                } else {
                                    Catalog(state, dest, selectedId?.let { Subjects.get(it) }, path,
                                        onSelectSubject = ::select,
                                        onFolder = { pathKey = (path + it).joinToString("\u001f") },
                                        onOpen = ::open, onFavorite = model::toggleFavorite, onCompleted = model::toggleCompleted)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (settings) AppearanceSheet(state, model, onDismiss = { settings = false })
    if (activeItem != null) DriveViewer(activeItem, state, onDismiss = { activeId = null },
        onFavorite = { model.toggleFavorite(activeItem.id) }, onCompleted = { model.toggleCompleted(activeItem.id) })
}

@Composable private fun Dashboard(state: StudyState, onNavigate: (Destination) -> Unit,
    onSubject: (Subject) -> Unit, onOpen: (StudyItem) -> Unit) {
    val recent = remember(state.items, state.accessed) {
        state.items.filter { it.id in state.accessed }.sortedByDescending { state.accessed[it.id] }.take(4)
    }
    val complete = state.items.count { it.id in state.completed }
    val progress = if (state.items.isEmpty()) 0f else complete.toFloat() / state.items.size
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("SEU ESPAÇO DE ESTUDO", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(6.dp))
                    Text("Aprender,\nno seu ritmo.", style = MaterialTheme.typography.displayLarge)
                }
                OrbitShape(Modifier.size(92.dp))
            }
        }
        item {
            Card(shape = RoundedCornerShape(32.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.AutoAwesome, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        Spacer(Modifier.width(10.dp))
                        Text("Seu percurso", style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    Text("$complete de ${state.items.size} materiais concluídos",
                        color = MaterialTheme.colorScheme.onPrimaryContainer, style = MaterialTheme.typography.bodyLarge)
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp),
                        color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.surface.copy(alpha = .6f))
                    Button(onClick = { if (recent.isEmpty()) onNavigate(Destination.SUBJECTS) else onOpen(recent.first()) },
                        shape = RoundedCornerShape(24.dp)) {
                        Icon(if (recent.isEmpty()) Icons.Outlined.GridView else Icons.Filled.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (recent.isEmpty()) "Escolher uma matéria" else "Retomar estudo")
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(Destination.VIDEOS, Destination.PDFS, Destination.AUDIO).forEachIndexed { index, dest ->
                    Card(onClick = { onNavigate(dest) }, modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(topStart = if (index == 0) 28.dp else 12.dp,
                            topEnd = if (index == 2) 28.dp else 12.dp, bottomEnd = 28.dp, bottomStart = 28.dp),
                        colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerHigh)) {
                        Column(Modifier.padding(14.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(dest.icon, null, tint = MaterialTheme.colorScheme.primary)
                            Text(state.items.count { it.type == dest.type }.toString(), style = MaterialTheme.typography.headlineSmall)
                            Text(dest.title, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
        item { SectionTitle("Suas matérias", "Ver todas") { onNavigate(Destination.SUBJECTS) } }
        items(Subjects.all.chunked(2)) { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { subject -> SubjectTile(subject, state, Modifier.weight(1f)) { onSubject(subject) } }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        if (recent.isNotEmpty()) {
            item { SectionTitle("Acessados recentemente") }
            items(recent, key = { "recent_${it.id}" }) { item ->
                ListItem(headlineContent = { Text(item.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text(Subjects.get(item.subjectId).name) },
                    leadingContent = { Icon(contentIcon(item.type), null) },
                    trailingContent = { IconButton(onClick = { onOpen(item) }) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Abrir") } },
                    colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow))
            }
        }
    }
}

@Composable private fun SectionTitle(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        if (action != null) TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable private fun SubjectTile(subject: Subject, state: StudyState, modifier: Modifier, onClick: () -> Unit) {
    val dark = isDarkMode(state.theme)
    val palette = subjectPalette(subject.id, dark)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .96f else 1f, label = "card_press")
    val index = Subjects.all.indexOf(subject)
    val subjectItems = remember(state.items, subject.id) { state.items.filter { it.subjectId == subject.id } }
    val count = subjectItems.size
    val completed = subjectItems.count { it.id in state.completed }
    Card(onClick = onClick, interactionSource = interaction,
        modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale },
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = if (index % 2 == 0) 12.dp else 28.dp,
            bottomEnd = 28.dp, bottomStart = if (index % 2 == 0) 28.dp else 12.dp),
        colors = CardDefaults.cardColors(containerColor = palette.first, contentColor = palette.second)) {
        Column(Modifier.padding(18.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = if (index % 2 == 0) RoundedCornerShape(14.dp) else CircleShape,
                    color = palette.second.copy(alpha = .1f)) {
                    Text(subject.monogram, Modifier.padding(12.dp), style = MaterialTheme.typography.titleMedium,
                        color = palette.second)
                }
                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(18.dp))
            }
            Text(subject.name, style = MaterialTheme.typography.titleMedium, minLines = 2)
            Text("$count materiais", style = MaterialTheme.typography.bodyMedium)
            LinearProgressIndicator(progress = { if (count == 0) 0f else completed.toFloat() / count },
                modifier = Modifier.fillMaxWidth().height(4.dp), color = palette.second,
                trackColor = palette.second.copy(alpha = .12f))
        }
    }
}

@Composable private fun Catalog(state: StudyState, destination: Destination, subject: Subject?, path: List<String>,
    onSelectSubject: (Subject) -> Unit, onFolder: (String) -> Unit, onOpen: (StudyItem) -> Unit,
    onFavorite: (String) -> Unit, onCompleted: (String) -> Unit) {
    var query by rememberSaveable(destination, subject?.id) { mutableStateOf("") }
    var filter by rememberSaveable(destination, subject?.id) { mutableStateOf("all") }
    var typeName by rememberSaveable(destination, subject?.id) { mutableStateOf("") }
    val type = destination.type ?: typeName.takeIf { it.isNotBlank() }?.let { ContentType.valueOf(it) }
    val base = remember(state.items, destination, subject, type) { state.items.filter {
        (subject == null || it.subjectId == subject.id) && (type == null || it.type == type)
    } }
    val filtered = remember(base, state.favorites, state.completed, filter, query) { base.filter {
        it.matches(query) && when (filter) {
            "favorites" -> it.id in state.favorites
            "completed" -> it.id in state.completed
            "pending" -> it.id !in state.completed
            else -> true
        }
    } }
    val browsing = query.isBlank() && filter == "all"
    val showSubjects = browsing && subject == null
    val scoped = if (subject != null && browsing) itemsInPath(filtered, path) else filtered
    val folders = if (subject != null && browsing) scoped.mapNotNull { it.folderPath.getOrNull(path.size) }.distinct() else emptyList()
    val leaves = if (subject != null && browsing) scoped.filter { it.folderPath.size == path.size } else scoped
    val listState = rememberLazyListState()
    LaunchedEffect(path, query, filter, subject?.id, destination, typeName) { listState.scrollToItem(0) }
    LazyColumn(state = listState, contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(path.lastOrNull() ?: subject?.name ?: destination.title, style = MaterialTheme.typography.headlineLarge)
                Text(if (path.isNotEmpty()) path.joinToString(" › ") else subject?.subtitle ?: when (destination) {
                    Destination.PDFS -> "Artigos do Profisio e materiais das suas matérias"
                    Destination.AUDIO -> "Escute os áudios do Profisio"
                    Destination.VIDEOS -> "Suas aulas, organizadas por matéria"
                    else -> "Escolha uma pasta para começar"
                }, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge)
                Text("${scoped.size} materiais", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
        }
        item {
            OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("catalog_search"),
                placeholder = { Text("Buscar aulas, arquivos e pastas") },
                leadingIcon = { Icon(Icons.Outlined.Search, null) },
                trailingIcon = { if (query.isNotBlank()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Limpar busca") } },
                shape = RoundedCornerShape(28.dp))
        }
        item {
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("all" to "Todos", "favorites" to "Favoritos", "pending" to "Pendentes", "completed" to "Concluídos")) { (id, label) ->
                    FilterChip(selected = filter == id, onClick = { filter = id }, label = { Text(label) },
                        leadingIcon = { if (filter == id) Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) })
                }
            }
        }
        if (subject != null && destination.type == null) item {
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(selected = typeName.isBlank(), onClick = { typeName = "" }, label = { Text("Todos os formatos") }) }
                items(ContentType.entries) { t -> FilterChip(selected = typeName == t.name,
                    onClick = { typeName = t.name }, label = { Text(t.label) }) }
            }
        }
        if (showSubjects) {
            items(Subjects.all.filter { s -> base.any { it.subjectId == s.id } }.chunked(2)) { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { s -> SubjectTile(s, state.copy(items = base), Modifier.weight(1f)) { onSelectSubject(s) } }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        } else {
            items(folders, key = { "folder_$it" }) { name ->
                val count = scoped.count { it.folderPath.getOrNull(path.size) == name }
                Card(onClick = { onFolder(name) }, shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerHigh)) {
                    Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                            Icon(Icons.Outlined.Folder, null, Modifier.padding(14.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(name, style = MaterialTheme.typography.titleMedium)
                            Text("$count materiais", style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(18.dp))
                    }
                }
            }
            items(leaves, key = { it.id }) { item ->
                MaterialRow(item, state, onOpen, onFavorite, onCompleted)
            }
        }
        if (scoped.isEmpty()) item {
            Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Outlined.SearchOff, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
                Text("Nenhum material encontrado", style = MaterialTheme.typography.titleMedium)
                Text("Tente outro termo ou ajuste os filtros.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable private fun MaterialRow(item: StudyItem, state: StudyState, onOpen: (StudyItem) -> Unit,
    onFavorite: (String) -> Unit, onCompleted: (String) -> Unit) {
    val complete = item.id in state.completed
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(16.dp)) {
                    Icon(contentIcon(item.type), null, Modifier.padding(12.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(item.title, style = MaterialTheme.typography.titleMedium)
                    Text(item.filename, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(if (complete) "Concluído" else "${Subjects.get(item.subjectId).name} · ${item.type.label}",
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = { onFavorite(item.id) }) {
                    Icon(if (item.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        if (item.id in state.favorites) "Remover dos favoritos" else "Favoritar",
                        tint = MaterialTheme.colorScheme.primary)
                }
            }
            if (item.note.isNotBlank()) Text(item.note, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween) {
                FilledTonalButton(onClick = { onOpen(item) }) {
                    Icon(if (item.linkKind == LinkKind.FOLDER) Icons.Outlined.FolderOpen else contentIcon(item.type),
                        null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (item.linkKind == LinkKind.FOLDER) "Abrir pasta" else when (item.type) {
                        ContentType.VIDEO -> "Assistir"
                        ContentType.PDF -> "Ler PDF"
                        ContentType.AUDIO -> "Ouvir"
                    })
                }
                IconToggleButton(checked = complete, onCheckedChange = { onCompleted(item.id) }) {
                    Icon(if (complete) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircle,
                        if (complete) "Marcar como pendente" else "Marcar como concluído")
                }
            }
        }
    }
}

@Composable private fun AppearanceSheet(state: StudyState, model: StudyViewModel, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Text("Do seu jeito", style = MaterialTheme.typography.headlineMedium)
            Text("Aparência", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(selected = mode == state.theme, onClick = { model.setTheme(mode) },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("theme_${mode.name}"),
                        label = { Text(mode.label) })
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Cores do seu Android", style = MaterialTheme.typography.titleMedium)
                    Text(if (Build.VERSION.SDK_INT >= 31) "Use as cores do seu papel de parede." else "Disponível no Android 12 ou superior.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = state.dynamicColor, onCheckedChange = model::setDynamicColor,
                    enabled = Build.VERSION.SDK_INT >= 31)
            }
            HorizontalDivider()
            Text("Kepleræ 1.1.0", style = MaterialTheme.typography.titleMedium)
            Text("${state.items.size} materiais. Favoritos, conclusões e tema são salvos neste dispositivo.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun contentIcon(type: ContentType): ImageVector = when (type) {
    ContentType.VIDEO -> Icons.Outlined.PlayCircleOutline
    ContentType.PDF -> Icons.Outlined.Description
    ContentType.AUDIO -> Icons.Outlined.Headphones
}
private fun subjectPalette(id: String, dark: Boolean): Pair<Color, Color> {
    val colors = when (id) {
        "fisioterapia" -> listOf(0xFFD0F4E6,0xFF064F3C,0xFF173D33,0xFFAFF0D5)
        "portugues" -> listOf(0xFFFFDFEB,0xFF70324C,0xFF4C2638,0xFFFFB2D0)
        "matematica" -> listOf(0xFFDBE6FF,0xFF274777,0xFF23344F,0xFFB6CEFF)
        "hu_legislacao" -> listOf(0xFFFFE8CA,0xFF654512,0xFF49351C,0xFFF5D49D)
        "sus" -> listOf(0xFFE1EFC4,0xFF3C4E17,0xFF303D1B,0xFFD4E9AA)
        else -> listOf(0xFFEBDFFF,0xFF533777,0xFF3D2C50,0xFFE0C3FF)
    }
    return if (dark) Color(colors[2]) to Color(colors[3]) else Color(colors[0]) to Color(colors[1])
}
@Composable private fun OrbitShape(modifier: Modifier) {
    val primary = MaterialTheme.colorScheme.primaryContainer
    val accent = MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        rotate(15f) {
            val half = size.width / 2f
            listOf(Offset(0f,0f),Offset(half,0f),Offset(0f,half),Offset(half,half)).forEach {
                drawCircle(primary, half * .67f, it + Offset(half / 2f, half / 2f))
            }
            drawCircle(accent, size.width * .12f, center)
        }
    }
}
fun openDrive(context: android.content.Context, url: String) {
    if (!isAllowedDriveUrl(url)) return
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        .onFailure { Toast.makeText(context, "Nenhum aplicativo disponível para abrir o link.", Toast.LENGTH_LONG).show() }
}
