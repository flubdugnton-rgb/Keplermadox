@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui

import android.annotation.SuppressLint
import android.view.View
import android.webkit.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.StudyItem
import com.example.data.repository.StudyState

@SuppressLint("SetJavaScriptEnabled")
@Composable fun DriveViewer(item: StudyItem, state: StudyState, onDismiss: () -> Unit,
    onFavorite: () -> Unit, onCompleted: () -> Unit) {
    val context = LocalContext.current
    var loading by remember(item.id) { mutableStateOf(true) }
    var error by remember(item.id) { mutableStateOf(false) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var fullscreenView by remember { mutableStateOf<View?>(null) }
    var fullscreenCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }
    fun exitFullscreen() { fullscreenView = null; fullscreenCallback?.onCustomViewHidden(); fullscreenCallback = null }
    DisposableEffect(item.id) {
        onDispose {
            fullscreenCallback?.onCustomViewHidden()
            webView?.apply { stopLoading(); onPause(); removeAllViews(); destroy() }
        }
    }
    Dialog(onDismissRequest = { if (fullscreenView != null) exitFullscreen() else onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Surface(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize()) {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                topBar = { TopAppBar(title = { Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = { IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Fechar") } },
                    actions = { IconButton(onClick = onFavorite) {
                        Icon(if (item.id in state.favorites) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favoritar")
                    } }) },
                bottomBar = {
                    Surface(color = MaterialTheme.colorScheme.surfaceContainer) {
                        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (item.note.isNotBlank()) Text(item.note, style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                FilledTonalButton(onClick = { openDrive(context, item.url) }, modifier = Modifier.weight(1f)) {
                                    Text("Abrir no Drive")
                                }
                                Button(onClick = onCompleted, modifier = Modifier.weight(1f)) {
                                    Text(if (item.id in state.completed) "Concluído ✓" else "Concluir")
                                }
                            }
                            Text("Se o Drive pedir acesso ou login, toque em Abrir no Drive.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.mediaPlaybackRequiresUserGesture = true
                            settings.allowFileAccess = false
                            settings.allowContentAccess = false
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            CookieManager.getInstance().setAcceptCookie(true)
                            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) { loading = false }
                                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, err: WebResourceError?) {
                                    if (request?.isForMainFrame == true) { error = true; loading = false }
                                }
                                override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, response: WebResourceResponse?) {
                                    if (request?.isForMainFrame == true && (response?.statusCode ?: 0) >= 400) { error = true; loading = false }
                                }
                                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                    return request?.url?.scheme !in listOf("https", "http")
                                }
                            }
                            webChromeClient = object : WebChromeClient() {
                                override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                                    if (view == null || fullscreenView != null) { callback?.onCustomViewHidden(); return }
                                    fullscreenView = view; fullscreenCallback = callback
                                }
                                override fun onHideCustomView() { exitFullscreen() }
                            }
                            webView = this
                            loadUrl(item.previewUrl)
                        }
                    })
                    if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
                    if (error) Surface(Modifier.fillMaxSize()) {
                        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Outlined.CloudOff, null, Modifier.size(48.dp))
                            Spacer(Modifier.height(16.dp))
                            Text("Não foi possível abrir o arquivo", style = MaterialTheme.typography.titleLarge)
                            Text("Confira sua conexão ou abra o material no Drive.")
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = { error = false; loading = true; webView?.reload() }) { Text("Tentar novamente") }
                        }
                    }
                }
            }
            if (fullscreenView != null) Box(Modifier.fillMaxSize()) {
                AndroidView(factory = { fullscreenView!! }, modifier = Modifier.fillMaxSize())
                IconButton(onClick = { exitFullscreen() }, modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding()) {
                    Icon(Icons.Filled.Close, "Sair da tela cheia", tint = androidx.compose.ui.graphics.Color.White)
                }
            }
            }
        }
    }
}
