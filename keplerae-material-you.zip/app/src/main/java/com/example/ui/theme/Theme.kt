package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.data.repository.ThemeMode

private val Light = lightColorScheme(
    primary = Color(0xFF5146A4), onPrimary = Color.White,
    primaryContainer = Color(0xFFE4DFFF), onPrimaryContainer = Color(0xFF21164E),
    secondary = Color(0xFF5D5B71), secondaryContainer = Color(0xFFE4DFF8),
    onSecondaryContainer = Color(0xFF1A182B), tertiary = Color(0xFF006A61),
    tertiaryContainer = Color(0xFF9EF2E3), onTertiaryContainer = Color(0xFF00201B),
    background = Color(0xFFFCF8FF), surface = Color(0xFFFCF8FF),
    onBackground = Color(0xFF1C1B22), onSurface = Color(0xFF1C1B22),
    onSurfaceVariant = Color(0xFF484551), outline = Color(0xFF797582),
    outlineVariant = Color(0xFFCAC4D2), surfaceVariant = Color(0xFFE7E1EF),
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFF6F2FC),
    surfaceContainer = Color(0xFFF0ECF6), surfaceContainerHigh = Color(0xFFEAE6F0),
    surfaceContainerHighest = Color(0xFFE5E1EB)
)
private val Dark = darkColorScheme(
    primary = Color(0xFFC9BFFF), onPrimary = Color(0xFF29206F),
    primaryContainer = Color(0xFF403489), onPrimaryContainer = Color(0xFFE4DFFF),
    secondary = Color(0xFFC8C3DE), secondaryContainer = Color(0xFF454255),
    onSecondaryContainer = Color(0xFFE4DFF8), tertiary = Color(0xFF82D5C7),
    tertiaryContainer = Color(0xFF005047), onTertiaryContainer = Color(0xFF9EF2E3),
    background = Color(0xFF141218), surface = Color(0xFF141218),
    onBackground = Color(0xFFE7E1EA), onSurface = Color(0xFFE7E1EA),
    onSurfaceVariant = Color(0xFFCAC4D2), outline = Color(0xFF938E9B),
    outlineVariant = Color(0xFF484551), surfaceVariant = Color(0xFF484551),
    surfaceContainerLowest = Color(0xFF0F0D13), surfaceContainerLow = Color(0xFF1C1A21),
    surfaceContainer = Color(0xFF201E25), surfaceContainerHigh = Color(0xFF2B2930),
    surfaceContainerHighest = Color(0xFF36343B)
)
@Composable fun isDarkMode(mode: ThemeMode) = when (mode) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}
@Composable fun KepleraeTheme(mode: ThemeMode = ThemeMode.SYSTEM, dynamicColor: Boolean = true, content: @Composable () -> Unit) {
    val dark = isDarkMode(mode)
    val context = LocalContext.current
    val colors = if (dynamicColor && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else if (dark) Dark else Light
    MaterialTheme(colorScheme = colors, typography = Typography,
        shapes = Shapes(extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(16.dp),
            medium = RoundedCornerShape(24.dp), large = RoundedCornerShape(32.dp), extraLarge = RoundedCornerShape(40.dp)),
        content = content)
}
