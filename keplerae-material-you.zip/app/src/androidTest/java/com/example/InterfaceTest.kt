package com.example

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class InterfaceTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()
    @Test fun catalogAndThemeControlsWork() {
        compose.waitUntil(timeoutMillis = 20000) {
            compose.onAllNodesWithText("Seu percurso").fetchSemanticsNodes().isNotEmpty()
        }
        compose.onNodeWithTag("settings").performClick()
        compose.onNodeWithTag("theme_DARK").performClick()
        compose.onNodeWithTag("theme_DARK").assertIsSelected()
        compose.onNodeWithTag("theme_LIGHT").performClick()
        compose.onNodeWithTag("theme_LIGHT").assertIsSelected()
        compose.onNodeWithTag("theme_SYSTEM").performClick()
        compose.onNodeWithTag("theme_SYSTEM").assertIsSelected()
        compose.activityRule.scenario.onActivity { it.onBackPressedDispatcher.onBackPressed() }
        compose.onNodeWithTag("nav_PDFS").performClick()
        compose.onNodeWithTag("catalog_search").performTextInput("AVALIAÇÃO FISIOTERAPÊUTICA")
        compose.onAllNodesWithText("AVALIAÇÃO FISIOTERAPÊUTICA EM TERAPIA INTENSIVA", substring = true)
            .onFirst().assertExists()
    }
}
