#!/usr/bin/env python3
"""Prepara loops públicos com atribuição. WAVs completos já vêm no projeto.
Sem rede, preserva esses recursos. Nunca é preciso abrir site durante o foco.
"""
import array
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tempfile
import urllib.request
import wave
import zipfile

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'app/src/main/res/raw'
ASSETS=ROOT/'app/src/main/assets'
BLANKET='775f2a767230a9681850d1b1e085be58656f1382'
SOURCES=[
    ('ambient_fire.wav',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/fireplace.ogg','10890350b03b3644bc11299637a915a8738faceb','ezwa','Public Domain','https://soundbible.com/1543-Fireplace.html'),
    ('ambient_wind.wav',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/wind.ogg','349b7d398194e60e60629b8952fadf2b54b64fd9','felix.blume; edição Porrumentzio','CC0 1.0','https://freesound.org/people/felix.blume/sounds/217506/'),
    ('ambient_room.wav',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/coffee-shop.ogg','a93acfbde2c3cddf4ac31bc27d14f19b44121aa5','stephan','Public Domain','https://soundbible.com/1664-Restaurant-Ambiance.html'),
    ('ambient_storm.wav',f'https://raw.githubusercontent.com/rafaelmardojai/blanket/{BLANKET}/data/resources/sounds/storm.ogg','cf6f788da00f9c3fc7ab014f538afc51eaf26b12','digifishmusic; edição Porrumentzio','CC BY 4.0','https://freesound.org/people/digifishmusic/sounds/41739/'),
    ('ambient_rain.wav','https://raw.githubusercontent.com/mateusfg7/Noisekun/main/.github/assets/sounds/rain.ogg','7945216b9e95dcf5493848d752e3d639f91e8f01','SFXProducer','CC0 1.0','https://www.youtube.com/watch?v=3oMcTXhXOpc'),
]
CLOCK_URL='https://opengameart.org/sites/default/files/ticking_clock.zip'

def download(url):
    request=urllib.request.Request(url,headers={'User-Agent':'Keplerae-build/2.4'})
    with urllib.request.urlopen(request,timeout=25) as response:
        data=response.read(16_000_001)
    if len(data)>16_000_000:raise ValueError('Arquivo maior que o limite')
    return data

def loop_wav(data):
    # O ffmpeg decodifica; a padronização e a costura usam apenas a biblioteca padrão.
    with tempfile.TemporaryDirectory() as folder:
        source=Path(folder)/'source';decoded=Path(folder)/'decoded.wav';source.write_bytes(data)
        subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(source),'-t','30','-ac','1','-ar','22050',str(decoded)],check=True,timeout=40)
        with wave.open(str(decoded),'rb') as audio:
            if audio.getsampwidth()!=2:raise ValueError('PCM inesperado')
            values=array.array('h');values.frombytes(audio.readframes(audio.getnframes()));rate=audio.getframerate()
    if len(values)<100:raise ValueError('Som vazio')
    # Sobreposição da cauda com o início, seguida do corpo, evita saltos no loop.
    overlap=min(int(rate*.12),len(values)//8)
    cross=[values[-overlap+i]*(1-i/overlap)+values[i]*(i/overlap) for i in range(overlap)]
    result=cross+list(values[overlap:-overlap])
    peak=max(map(abs,result)) or 1
    pcm=array.array('h',(round(x/peak*15000) for x in result))
    output=io.BytesIO()
    with wave.open(output,'wb') as wav:
        wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(rate);wav.writeframes(pcm.tobytes())
    return output.getvalue()

def main():
    provenance_path=ROOT/'design/ambient-sound-provenance.json'
    existing=json.loads(provenance_path.read_text()) if provenance_path.exists() else []
    provenance={item['file']:item for item in existing}
    for destination,url,expected,author,license_name,original in SOURCES:
        try:
            data=download(url)
            actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            if actual!=expected:raise ValueError('Fonte mudou; preservando o loop incluído')
            (RAW/destination).write_bytes(loop_wav(data))
            provenance[destination]={'file':destination,'author':author,'license':license_name,'source':original,
                'git_blob':expected,'download':url,'changes':'30s máximo, mono 22050Hz, volume normalizado e costura de loop'}
            print(f'Som público preparado: {destination}')
        except Exception as error:
            if not (RAW/destination).exists():raise
            print(f'Som incluído preservado: {destination} ({type(error).__name__})')
    try:
        archive=zipfile.ZipFile(io.BytesIO(download(CLOCK_URL)))
        choices=[n for n in archive.namelist() if n.lower().endswith(('.wav','.ogg','.mp3')) and '__MACOSX' not in n]
        if not choices:raise ValueError('Sem áudio no arquivo público')
        data=archive.read(choices[0])
        (RAW/'ambient_clock.wav').write_bytes(loop_wav(data))
        provenance['ambient_clock.wav']={'file':'ambient_clock.wav','author':'AntumDeluge','license':'CC0 1.0',
            'source':'https://opengameart.org/content/ticking-clock-0','download':CLOCK_URL,
            'source_sha256':hashlib.sha256(data).hexdigest(),'changes':'mono 22050Hz, volume normalizado e costura de loop'}
        print('Relógio público preparado')
    except Exception as error:
        if not (RAW/'ambient_clock.wav').exists():raise
        print(f'Relógio incluído preservado ({type(error).__name__})')
    provenance_path.write_text(json.dumps(list(provenance.values()),ensure_ascii=False,indent=2)+'\n')
    credits=['SONS DE AMBIENTE — KEPLERÆ 2.4','']
    for item in provenance.values():
        credits.extend([item['file']+' — '+item['author'],item['license'],item['source'],item.get('changes',''),''])
    credits.extend(['CC0: https://creativecommons.org/publicdomain/zero/1.0/',
        'CC BY 4.0: https://creativecommons.org/licenses/by/4.0/',
        'Trovões: digifishmusic / Freesound 41739, editados por Porrumentzio (Blanket) e adaptados para loop pelo Kepleræ.',
        'Casas e biblioteca: combinações inspiradas; sem trilhas ou gravações dos filmes.'])
    ASSETS.mkdir(parents=True,exist_ok=True)
    (ASSETS/'pomodoro_sound_credits.txt').write_text('\n'.join(credits)+'\n')

if __name__=='__main__':main()
