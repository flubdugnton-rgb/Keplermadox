#!/usr/bin/env python3
"""Reserva sonora original CC0. Só cria recursos ausentes; não substitui fontes públicas."""
import array
import math
from pathlib import Path
import random
import wave

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'app/src/main/res/raw'
RATE=22050

def main():
    RAW.mkdir(parents=True,exist_ok=True)
    seconds=12;n=RATE*seconds;rng=random.Random(24)
    clock=[0.0]*n
    for beat in range(seconds*2):
        start=int(beat*.5*RATE)
        for i in range(int(.065*RATE)):
            if start+i>=n:break
            t=i/RATE;freq=1800 if beat%2==0 else 1350
            clock[start+i]=(math.sin(2*math.pi*freq*t)+.35*rng.uniform(-1,1))*math.exp(-t*95)
    noise=[rng.uniform(-1,1) for _ in range(n)];rain=[];last=0.0
    for i,x in enumerate(noise):
        last=.72*last+.28*x;rain.append(last*(.76+.10*math.sin(2*math.pi*i/n)))
    library=[x*.035 for x in noise]
    for sec in [1.4,4.3,8.6,10.2]:
        start=int(sec*RATE);length=int(.6*RATE)
        for i in range(length):
            if start+i<n:library[start+i]+=rng.uniform(-1,1)*math.sin(math.pi*i/length)**2*.5
    for name,values in [('ambient_clock.wav',clock),('ambient_rain.wav',rain),('ambient_library.wav',library)]:
        path=RAW/name
        if path.exists():continue
        peak=max(map(abs,values)) or 1
        pcm=array.array('h',(int(x/peak*12000) for x in values))
        with wave.open(str(path),'wb') as out:
            out.setnchannels(1);out.setsampwidth(2);out.setframerate(RATE);out.writeframes(pcm.tobytes())
        print(f'Reserva original CC0: {name}')

if __name__=='__main__':main()
