# Kepleræ 2.4.0

Projeto Android completo: Jetpack Compose, Material You / Material 3 Expressive.
Pacote `com.aistudio.keplerae.stdy`; versionCode **25**; minSdk 24; compile/targetSdk 36.

## Subir para o GitHub e compilar

1. Envie **Keplerae-2.4.zip** intacto para a raiz de `flubdugnton-rgb/Keplermadox`.
2. Abra **.github/workflows/compilar-apk.yml** e substitua todo o conteúdo pelo `compilar-apk.yml` 2.4 entregue com o ZIP. Se precisar recriar, use esse caminho completo em Add file → Create new file.
3. Mantenha a variável **GOOGLE_WEB_CLIENT_ID** e o cache de assinatura existentes. Não precisa mudar nenhuma configuração Google para esta atualização.
4. O commit inicia **Compilar Keplerae 2.4 - Ambientes e evolução**. Manualmente: Actions → esse workflow → Run workflow.
5. Após sucesso do job APK, baixe **Keplerae-2.4-APK**, extraia e instale **Keplerae-2.4.0-debug.apk** como atualização da versão anterior.
6. O job de interface publica relatórios e capturas reais de Pomodoro/Ajustes/Questões em claro e escuro. Confira os resultados; falha precisa ser analisada.

Não renomeie o ZIP: o workflow espera exatamente `Keplerae-2.4.zip`. Ele extrai o projeto para `android-project`, sem pasta extra dentro do ZIP. O ZIP anterior pode ficar no repositório; este workflow usa apenas a versão 2.4.

A assinatura anterior permanece no cache `keplerae-native-debug-signing-v1`. O workflow verifica o SHA-1 `16:00:79:01:DB:BF:AB:9D:E7:B5:53:9F:FA:C6:04:FA:F1:9D:BC:8A` e recusa uma chave diferente para preservar atualização e OAuth. Não desinstale a versão anterior para atualizar.

## Mudanças

Veja `CHANGELOG-2.4.md`. Barra geral duplicada removida em todos os destinos. Preferências ficam no perfil; navegação de pastas tem botão de voltar no próprio conteúdo. A barra do player mantém controles funcionais de arquivo, favoritar e tela cheia.

Menus: Início → Aulas → PDFs → Áudios → Matérias → Pomodoro → Questões. No telefone o menu inferior rola horizontalmente; no tablet há navegação lateral.

Pomodoro: relógio maior, onda contínua, abas em cápsula, estrelas visíveis nos dois temas, linha/estrela pescada animadas e passagem de estrela cadente. Saturno em repouso mantém o personagem deitado, estrelas móveis, reflexos orbitais e detalhes verde militar. Ajustes usam a paleta suave da referência de meditação, com versão escura.

Som durante o foco é opcional e separado do alarme final. Há dez ambientes e controle de volume. Salões e biblioteca são paisagens sonoras inspiradas, compostas com sons de natureza, sala e leitura. O ambiente para nas pausas ou ao pausar/pular/zerar; o Android controla foco sonoro. Ao remover os fones, o ambiente silencia; pausar e iniciar novamente permite retomar.

Questões: dashboard elevado, filtros em cápsula, blocos e três curvas de totais acumulados por dia: questões, acertos e erros. Últimos 14 dias registrados visíveis, incluindo no acumulado todos os dias anteriores. Cartões e histórico consideram todos os registros filtrados. A taxa continua `soma de acertos / soma de questões × 100`; não é média simples de percentuais. Datas, exclusões e filtros recalculam os valores reais.

## Dados e funcionalidades preservadas

Os novos campos de ambiente têm padrão desligado / chuva / 35%, preservando os ciclos e histórico da 2.3. Sessão Google persistente, renovação de acesso Drive, catálogo de 1.022 materiais, ordem, favoritos, conclusões, players internos, PDF e temas continuam como na base 2.3.

O timer usa relógio monotônico, estado persistido e serviço com notificação. Só focos completos somam ao histórico. Permissão de notificações é necessária no Android 13+ para mostrar o contador fora do app. Forçar parada ou desligar o aparelho pode interromper o alerta; ao reabrir, o estado é reconciliado sem duplicar conclusões.

## Sons e recursos

Sete loops PCM incluídos e dois alarmes. Quatro loops públicos foram baixados e tiveram hash conferido nesta entrega: lareira, vento, sala e trovões. Relógio, chuva e páginas têm recursos originais CC0 incluídos. O workflow tenta substituir relógio e chuva por fontes públicas verificadas; se não houver rede, mantém os arquivos incluídos.

Atribuição e proveniência estão em `design/ambient-sound-provenance.json`, `design/POMODORO-ASSETS.md` e nos créditos dentro do app. O workflow atualiza os créditos para refletir os sons efetivamente usados na compilação. Todos tocam dentro do app, sem internet após instalar.

## Dependências

Java 17; Gradle 8.13; AGP 8.11.1; Kotlin / Compose plugin 2.2.21.
Compose UI/Foundation/Animation 1.9.4; Material 3 **1.5.0-alpha07** (alpha já autorizada); Haze 1.7.0; Coil 3.3.0; DataStore 1.1.7; Reorderable 2.5.1; Credentials 1.6.0; GoogleID 1.1.1; Play Services Auth 22.0.0; Coroutines 1.10.2; Media3 1.8.1.

**Nenhuma dependência Android adicional** na 2.4. Canvas anima/desenha; Android MediaPlayer reproduz loops. O workflow usa Python padrão e ffmpeg para preparar recursos. O projeto usa `gradle` instalado pelo workflow; não inclui wrapper JAR.

## Arquivos principais da 2.4

- `app/build.gradle.kts`: versão 2.4.0 / código 25.
- `app/src/main/AndroidManifest.xml`: tipo/permissão de serviço para reprodução ambiente.
- `ui/KepleraeApp.kt`, `CatalogScreen.kt`, `profile/ProfileScreen.kt`: remoção da barra e acesso a preferências/voltar.
- `ui/productivity/ProductivityDesign.kt`: paleta clara/escura, cartões, abas e onda.
- `ui/productivity/PomodoroScreen.kt`, `PomodoroArtwork.kt`: telas, ajustes e animações.
- `data/productivity/PomodoroModel.kt`, `PomodoroStore.kt`, `PomodoroService.kt`, `PomodoroAmbience.kt`: preferências, migração e reprodução.
- `ui/productivity/QuestionsScreen.kt`, `StudyCharts.kt`, `data/productivity/QuestionModel.kt`: dashboard e curvas acumuladas.
- `res/drawable-nodpi/pomo_*.png`, `res/raw/ambient_*.wav`, `assets/pomodoro_sound_credits.txt`: recursos completos.
- `scripts/fetch_ambient_sounds.py`, `generate_ambient_fallbacks.py`, `.github/workflows/compilar-apk.yml`.
- `QuestionEvolutionTest.kt`, `PomodoroMigrationTest.kt`, `ProductivityDesignTest.kt`, `InterfaceTest.kt`: testes matemáticos, migração, navegação e capturas.

Os caminhos Java acima partem de `app/src/main/java/com/example/`. O arquivo `Keplerae-2.4-Codigo-Completo.md` reúne o código textual integral com os caminhos; o ZIP inclui também imagens e áudio.

## Verificação desta entrega

Catálogo e permissões de rede validados localmente. XML, recursos PNG/WAV, scripts Python, referências de recursos e estrutura do workflow conferidos. Catálogo, arquivos de autenticação/Drive, stores de questões e players internos comparados com a base 2.3, sem alterações.

**Esta 2.4 ainda não foi compilada nem executada em Android neste ambiente**, que não dispõe de SDK/Gradle. O workflow executará testes unitários, lint, compilação e testes de dispositivo após subir os arquivos. A compilação bem-sucedida anterior da 2.3 não valida o novo código 2.4.
