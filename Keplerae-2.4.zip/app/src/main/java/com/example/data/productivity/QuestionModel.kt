package com.example.data.productivity

data class QuestionSubject(val id: String, val name: String)
data class QuestionRecord(val id: String, val subjectId: String, val correct: Int, val wrong: Int, val recordedAt: Long)
data class QuestionState(val subjects: List<QuestionSubject> = emptyList(), val records: List<QuestionRecord> = emptyList())
data class QuestionTotals(val correct: Long, val wrong: Long) {
    val total: Long get() = correct + wrong
    val accuracy: Double get() = if(total==0L) 0.0 else 100.0*correct/total
    val errorRate: Double get() = if(total==0L) 0.0 else 100.0*wrong/total
}
fun questionTotals(records: List<QuestionRecord>): QuestionTotals = QuestionTotals(
    records.sumOf { it.correct.toLong() },records.sumOf { it.wrong.toLong() })
fun validQuestionCounts(correct: Int?, wrong: Int?): Boolean = correct!=null && wrong!=null &&
    correct in 0..1_000_000 && wrong in 0..1_000_000 && correct.toLong()+wrong>0

/** Cada ponto contém o acumulado até aquele dia local, incluindo dias fora da janela do gráfico. */
data class CumulativeQuestionDay(val recordedAt:Long,val correct:Long,val wrong:Long) {
    val total:Long get()=correct+wrong
}
fun cumulativeQuestionDays(records:List<QuestionRecord>,
    timeZone:java.util.TimeZone=java.util.TimeZone.getDefault()):List<CumulativeQuestionDay> {
    val formatter=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.ROOT).apply {this.timeZone=timeZone}
    val groups=records.sortedBy {it.recordedAt}.groupBy {formatter.format(java.util.Date(it.recordedAt))}
    var correct=0L;var wrong=0L
    return groups.values.map { day ->
        correct+=day.sumOf {it.correct.toLong()};wrong+=day.sumOf {it.wrong.toLong()}
        CumulativeQuestionDay(day.first().recordedAt,correct,wrong)
    }
}
