package com.example.data.productivity

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.media.AudioManager
import android.content.pm.ServiceInfo
import android.content.pm.PackageManager
import android.Manifest
import android.annotation.SuppressLint
import android.media.MediaPlayer
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect

object PomodoroAudio {
    private var player: MediaPlayer?=null
    fun play(context: Context, sound: String) {
        player?.release()
        player=MediaPlayer.create(context.applicationContext, if(sound=="soft") R.raw.pomo_soft else R.raw.pomo_bell)
        player?.setOnCompletionListener { it.release(); if(player===it) player=null }
        player?.start()
    }
}

/** Serviço iniciado pelo usuário, com notificação visível e parada explícita. */
@SuppressLint("MissingPermission") // FGS permitido sem POST_NOTIFICATIONS; posts normais verificados abaixo.
class PomodoroService : Service() {
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    private var timer: Job?=null
    private var lock: PowerManager.WakeLock?=null
    private var audioObserver: Job?=null
    private var noisyRegistered=false
    private val ambience by lazy { PomodoroAmbience(this) }
    private val noisyReceiver=object:BroadcastReceiver() {
        override fun onReceive(context:Context?,intent:Intent?) { ambience.muteForNoisyOutput() }
    }
    private val store by lazy { PomodoroStore.get(this) }
    override fun onBind(intent: Intent?): IBinder?=null
    override fun onCreate() {
        super.onCreate()
        ContextCompat.registerReceiver(this,noisyReceiver,IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
            ContextCompat.RECEIVER_NOT_EXPORTED)
        noisyRegistered=true
        if(Build.VERSION.SDK_INT>=26) {
            val manager=getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL,"Pomodoro em andamento",NotificationManager.IMPORTANCE_LOW).apply { setSound(null,null) })
            manager.createNotificationChannel(NotificationChannel(DONE_CHANNEL,"Conclusões do Pomodoro",NotificationManager.IMPORTANCE_DEFAULT).apply { setSound(null,null) })
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when(intent?.action) {
            PAUSE -> { store.pause(); stopTimer(); return START_NOT_STICKY }
            RESET -> { store.reset(); stopTimer(); return START_NOT_STICKY }
            SKIP -> { store.skip(); stopTimer(); return START_NOT_STICKY }
            RESTORE -> Unit
            else -> { ambience.allowUserStart();store.start() }
        }
        if(!store.state.value.running) { stopSelf(); return START_NOT_STICKY }
        val initialNotification=notification(store.state.value)
        startVisible(initialNotification,store.state.value)
        audioObserver?.cancel()
        audioObserver=scope.launch {
            store.state.collect { current ->
                if(current.running) {
                    startVisible(notification(current),current)
                    ambience.update(current.settings,current.phase==PomodoroPhase.FOCUS)
                } else ambience.stop()
            }
        }
        lock?.let { if(it.isHeld) it.release() }
        lock=(getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"keplerae:pomodoro")
            .apply { acquire(store.state.value.phaseDurationMs+30_000L) }
        timer?.cancel()
        timer=scope.launch {
            while(isActive && store.state.value.running) {
                val endedPhase=store.state.value.phase
                if(store.finishIfDue()) {
                    val state=store.state.value
                    ambience.stop()
                    if(state.settings.sounds) PomodoroAudio.play(this@PomodoroService,state.settings.sound)
                    if(canNotify() && NotificationManagerCompat.from(this@PomodoroService).areNotificationsEnabled()) {
                        val done=NotificationCompat.Builder(this@PomodoroService,DONE_CHANNEL)
                            .setSmallIcon(R.drawable.ic_pomodoro_notification)
                            .setContentTitle("${endedPhase.label} concluído")
                            .setContentText("Próxima etapa: ${state.phase.label.lowercase()}.")
                            .setContentIntent(openApp()).setAutoCancel(true).setSilent(true).build()
                        getSystemService(NotificationManager::class.java).notify(ID+1,done)
                    }
                    if(state.settings.autoAdvance) {
                        store.start()
                        lock?.let { if(it.isHeld) it.release(); it.acquire(store.state.value.phaseDurationMs+30_000L) }
                    } else { stopTimer(); break }
                }
                if(canNotify()) getSystemService(NotificationManager::class.java).notify(ID,notification(store.state.value))
                delay(1000)
            }
        }
        return START_STICKY
    }
    private fun startVisible(n:Notification,s:PomodoroState) {
        if(Build.VERSION.SDK_INT>=34) {
            val type=ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                if(s.settings.ambienceEnabled&&s.phase==PomodoroPhase.FOCUS)
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            startForeground(ID,n,type)
        } else startForeground(ID,n)
    }
    private fun openApp(): PendingIntent=PendingIntent.getActivity(this,0,
        Intent(this,MainActivity::class.java).putExtra("open_pomodoro",true)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun canNotify(): Boolean = Build.VERSION.SDK_INT<33 ||
        ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED
    private fun action(name: String): PendingIntent=PendingIntent.getService(this,name.hashCode(),
        Intent(this,PomodoroService::class.java).setAction(name),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun notification(s: PomodoroState): Notification {
        val remaining=remainingAt(s,System.currentTimeMillis(),SystemClock.elapsedRealtime())
        return NotificationCompat.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_pomodoro_notification)
            .setContentTitle("Pomodoro • ${s.phase.label}")
            .setContentText("${formatTimer(remaining)} • ciclo ${s.cycle.coerceAtMost(s.settings.cycles-1)+1}/${s.settings.cycles}")
            .setWhen(System.currentTimeMillis()+remaining).setUsesChronometer(true).setChronometerCountDown(true)
            .setContentIntent(openApp()).setOngoing(true).setOnlyAlertOnce(true).setSilent(true)
            .addAction(0,"Pausar",action(PAUSE)).addAction(0,"Parar",action(RESET)).build()
    }
    private fun stopTimer() {
        timer?.cancel(); timer=null
        audioObserver?.cancel();audioObserver=null;ambience.stop()
        lock?.let { if(it.isHeld) it.release() }; lock=null
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    override fun onDestroy() {
        timer?.cancel();audioObserver?.cancel();ambience.stop(); scope.cancel()
        if(noisyRegistered) { unregisterReceiver(noisyReceiver);noisyRegistered=false }
        lock?.let { if(it.isHeld) it.release() }; lock=null
        super.onDestroy()
    }
    companion object {
        const val START="pomodoro.start"; const val RESTORE="pomodoro.restore"
        const val PAUSE="pomodoro.pause"; const val RESET="pomodoro.reset"; const val SKIP="pomodoro.skip"
        private const val CHANNEL="keplerae_pomodoro_timer"
        private const val DONE_CHANNEL="keplerae_pomodoro_done"
        private const val ID=2300
        fun command(context: Context, action: String) {
            val intent=Intent(context,PomodoroService::class.java).setAction(action)
            if(action==START||action==RESTORE) ContextCompat.startForegroundService(context,intent)
            else context.startService(intent)
        }
    }
}
fun formatTimer(ms: Long): String {
    val seconds=((ms+999)/1000).coerceAtLeast(0)
    return "%02d:%02d".format(seconds/60,seconds%60)
}
