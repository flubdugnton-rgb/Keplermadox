@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)
package com.example.ui.productivity

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.productivity.*
import kotlinx.coroutines.delay
import java.util.Calendar

@Composable fun PomodoroScreen() {
    val context=LocalContext.current
    val store=remember { PomodoroStore.get(context) }
    val state by store.state.collectAsStateWithLifecycle()
    val c=calmColors()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var custom by rememberSaveable { mutableStateOf(false) }
    var credits by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var elapsed by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var wall by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var message by remember { mutableStateOf<String?>(null) }
    fun startTimer() {
        runCatching { PomodoroService.command(context,PomodoroService.START) }
            .onFailure { message="Não foi possível iniciar o cronômetro. ${it.localizedMessage.orEmpty()}" }
    }
    val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if(!granted) message="O cronômetro funciona no app. Permita notificações nas configurações do Android para ver o tempo fora dele."
        startTimer()
    }
    LaunchedEffect(state.running) {
        if(state.running) {
            runCatching { PomodoroService.command(context,PomodoroService.RESTORE) }
            while(true) { wall=System.currentTimeMillis();elapsed=SystemClock.elapsedRealtime();delay(250) }
        }
    }
    val remaining=remainingAt(state,wall,elapsed)
    val total=state.history.sumOf { it.durationMs }
    val progress=(1f-remaining.toFloat()/state.phaseDurationMs.coerceAtLeast(1)).coerceIn(0f,1f)
    val weeks=remember(state.history) { (6 downTo 0).map { ago ->
        val cal=Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR,-ago) }
        val key=dateLabel(cal.timeInMillis,"yyyy-MM-dd")
        val minutes=state.history.filter { dateLabel(it.finishedAt,"yyyy-MM-dd")==key }.sumOf { it.durationMs }/60_000f
        ChartPoint(dateLabel(cal.timeInMillis,"dd/MM"),minutes) } }
    // A paleta local colore superfícies; a tipografia e a preferência global continuam no MaterialTheme.
    CompositionLocalProvider(LocalContentColor provides c.ink) {
        BoxWithConstraints(Modifier.fillMaxSize().background(c.background)) {
            val largeClock=maxWidth>=600.dp
            LazyColumn(Modifier.fillMaxSize().testTag("pomodoro_screen"),contentPadding=PaddingValues(20.dp),
                horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(18.dp)) {
                item {
                    Column(Modifier.fillMaxWidth()) {
                        Text("Pomodoro",style=MaterialTheme.typography.displaySmall)
                        Text("Uma estrela de cada vez.",color=c.muted)
                    }
                }
                item { ProductivityTabs(tab,{tab=it},Modifier.fillMaxWidth()) }
                if(tab==0) {
                    item { PomodoroArtwork(state.running&&state.phase==PomodoroPhase.FOCUS,Modifier.fillMaxWidth().height(270.dp)) }
                    item {
                        Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)) {
                            Text(state.phase.label,style=MaterialTheme.typography.titleLarge,color=c.accent)
                            Text(formatTimer(remaining),style=MaterialTheme.typography.displayLarge.copy(
                                fontSize=if(largeClock)108.sp else 88.sp,lineHeight=if(largeClock)118.sp else 100.sp,
                                fontWeight=FontWeight.Bold,fontFeatureSettings="tnum"),maxLines=1,
                                modifier=Modifier.testTag("pomodoro_time"))
                            Text(if(state.paused)"Pausado" else if(state.running)"Em andamento" else "Pronto para começar",color=c.muted)
                            Text("${state.cycle.coerceAtMost(state.settings.cycles)} de ${state.settings.cycles} focos concluídos",
                                style=MaterialTheme.typography.bodySmall,color=c.muted)
                            if(state.settings.ambienceEnabled) Text("♫ ${AmbientPresets.get(state.settings.ambienceId).title}",
                                style=MaterialTheme.typography.labelMedium,color=c.accent)
                        }
                    }
                    item { CosmicWavyProgress(progress,state.running,Modifier.fillMaxWidth()) }
                    item {
                        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(20.dp)) {
                            FilledTonalIconButton(onClick={confirmReset=true},modifier=Modifier.size(56.dp),
                                colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=c.surface,contentColor=c.accent)) {
                                Icon(Icons.Outlined.RestartAlt,"Zerar etapa") }
                            FilledIconButton(onClick={
                                if(state.running) PomodoroService.command(context,PomodoroService.PAUSE)
                                else if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                                    permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                else startTimer()
                            },modifier=Modifier.size(84.dp).testTag("pomodoro_start"),
                                colors=IconButtonDefaults.filledIconButtonColors(containerColor=c.accent,contentColor=c.surface)) {
                                Icon(if(state.running)Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    if(state.running)"Pausar" else "Iniciar",Modifier.size(38.dp)) }
                            FilledTonalIconButton(onClick={PomodoroService.command(context,PomodoroService.SKIP)},modifier=Modifier.size(56.dp),
                                colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=c.surface,contentColor=c.accent)) {
                                Icon(Icons.Outlined.SkipNext,"Pular etapa sem registrar foco") }
                        }
                    }
                    item { Text("Só focos completos entram no total. Pular ou zerar não registra um pomodoro.",style=MaterialTheme.typography.bodySmall,color=c.muted) }
                }
                if(tab==1) {
                    item {
                        Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                            CalmCard(Modifier.weight(1f),c.lilac) { Text(state.history.size.toString(),style=MaterialTheme.typography.headlineLarge);Text("Pomodoros") }
                            CalmCard(Modifier.weight(1f),c.mint) { Text(formatStudyTime(total),style=MaterialTheme.typography.headlineLarge);Text("Tempo de foco") }
                        }
                    }
                    item { CalmCard(Modifier.fillMaxWidth()) {
                        Text("Últimos 7 dias",style=MaterialTheme.typography.titleLarge)
                        Text("Minutos de foco concluídos",style=MaterialTheme.typography.bodySmall,color=c.muted)
                        StudyChart(weeks,metricLabel="Minutos de foco por dia",unit="minutos de foco") } }
                    item { Text("Seu histórico",style=MaterialTheme.typography.titleLarge,modifier=Modifier.fillMaxWidth()) }
                    if(state.history.isEmpty()) item {Text("Seu primeiro foco concluído aparecerá aqui.",color=c.muted)}
                    items(state.history.sortedByDescending { it.finishedAt }.take(50),key={it.id}) { record ->
                        CalmCard(Modifier.fillMaxWidth()) {
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Icon(Icons.Outlined.CheckCircle,null,tint=c.accent);Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {Text("Foco concluído");Text(dateLabel(record.finishedAt),style=MaterialTheme.typography.bodySmall,color=c.muted)}
                                Text(formatStudyTime(record.durationMs)) }
                        }
                    }
                }
                if(tab==2) {
                    item {
                        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(c.sky,c.lilac,c.mint)),RoundedCornerShape(32.dp)).padding(24.dp)) {
                            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Outlined.Spa,null,Modifier.size(36.dp),tint=c.accent)
                                Text("Crie seu ambiente",style=MaterialTheme.typography.headlineMedium)
                                Text("Escolha um som e encontre seu ritmo.",color=c.muted) }
                        }
                    }
                    item {
                        CalmCard(Modifier.fillMaxWidth()) {
                            SettingSwitch("Som durante o foco","Ambiente contínuo, separado do alarme",state.settings.ambienceEnabled) {
                                store.configure(state.settings.copy(ambienceEnabled=it)) }
                            var volume by remember(state.settings.ambienceVolume) { mutableFloatStateOf(state.settings.ambienceVolume) }
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Icon(Icons.Outlined.VolumeUp,null,tint=c.accent);Spacer(Modifier.width(12.dp))
                                Text("Volume",Modifier.weight(1f));Text("${(volume*100).toInt()}%",color=c.muted) }
                            Slider(value=volume,onValueChange={volume=it},onValueChangeFinished={store.configure(state.settings.copy(ambienceVolume=volume))},
                                enabled=state.settings.ambienceEnabled,colors=SliderDefaults.colors(thumbColor=c.accent,activeTrackColor=c.accent))
                            Text("O ambiente toca durante o foco e para nas pausas. Usa o volume de mídia do aparelho.",style=MaterialTheme.typography.bodySmall,color=c.muted)
                        }
                    }
                    items(AmbientPresets.all.chunked(2),key={it.first().id}) { pair ->
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                            pair.forEach { preset -> AmbientSoundCard(preset,state.settings.ambienceId==preset.id,Modifier.weight(1f)) {
                                store.configure(state.settings.copy(ambienceId=preset.id)) } }
                        }
                    }
                    item { Text("Salões e biblioteca: paisagens sonoras inspiradas, com sons de natureza e leitura.",style=MaterialTheme.typography.bodySmall,color=c.muted) }
                    item {
                        CalmCard(Modifier.fillMaxWidth()) {
                            Text("Seu ciclo",style=MaterialTheme.typography.titleLarge)
                            val editable=!state.running&&!state.paused
                            listOf(PomodoroSettings(),PomodoroSettings(50,10,20,4),PomodoroSettings(90,15,30,2)).forEach { preset ->
                                OutlinedButton(onClick={store.configure(state.settings.copy(focusMinutes=preset.focusMinutes,
                                    shortMinutes=preset.shortMinutes,longMinutes=preset.longMinutes,cycles=preset.cycles))},
                                    enabled=editable,modifier=Modifier.fillMaxWidth()) {
                                    Text("${preset.focusMinutes} / ${preset.shortMinutes} / ${preset.longMinutes} min • ${preset.cycles} focos") } }
                            Text("Foco / pausa curta / pausa longa",style=MaterialTheme.typography.bodySmall,color=c.muted)
                            FilledTonalButton(onClick={custom=true},enabled=editable,modifier=Modifier.fillMaxWidth()) {
                                Icon(Icons.Outlined.Tune,null);Spacer(Modifier.width(8.dp));Text("Personalizar ciclo") }
                            Text("Atual: ${state.settings.focusMinutes} / ${state.settings.shortMinutes} / ${state.settings.longMinutes} min • ${state.settings.cycles} focos",style=MaterialTheme.typography.bodySmall)
                            if(!editable)Text("Zere a etapa para alterar suas durações.",style=MaterialTheme.typography.bodySmall,color=c.muted)
                        }
                    }
                    item {
                        CalmCard(Modifier.fillMaxWidth(),c.blush) {
                            SettingSwitch("Alarme ao terminar","Toque curto na conclusão de cada etapa",state.settings.sounds) {
                                store.configure(state.settings.copy(sounds=it)) }
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                listOf("bell" to "Sino","soft" to "Suave").forEach { (id,name) ->
                                    FilterChip(selected=state.settings.sound==id,onClick={store.configure(state.settings.copy(sound=id));
                                        if(state.settings.sounds)PomodoroAudio.play(context,id)},label={Text(name)},leadingIcon={Icon(Icons.Outlined.NotificationsNone,null)}) } }
                            SettingSwitch("Avançar automaticamente","Iniciar foco e pausas em sequência",state.settings.autoAdvance) {
                                store.configure(state.settings.copy(autoAdvance=it)) }
                            Text("O contador aparece na notificação. Permita notificações no Android para acompanhar fora do app.",style=MaterialTheme.typography.bodySmall,color=c.muted)
                            TextButton(onClick={credits=true}) {Icon(Icons.Outlined.Info,null);Spacer(Modifier.width(8.dp));Text("Créditos dos sons")}
                        }
                    }
                }
                message?.let { text -> item {Text(text,color=MaterialTheme.colorScheme.error)} }
            }
        }
    }
    if(confirmReset) AlertDialog(onDismissRequest={confirmReset=false},icon={Icon(Icons.Outlined.RestartAlt,null)},
        title={Text("Zerar esta etapa?")},text={Text("O histórico permanece salvo. O foco incompleto não será contado.")},
        confirmButton={TextButton(onClick={PomodoroService.command(context,PomodoroService.RESET);confirmReset=false}) {Text("Zerar")}},
        dismissButton={TextButton(onClick={confirmReset=false}) {Text("Cancelar")}})
    if(custom) PomodoroSettingsDialog(state.settings,onDismiss={custom=false},onSave={store.configure(it);custom=false})
    if(credits) {
        val text=remember {context.assets.open("pomodoro_sound_credits.txt").bufferedReader().use {it.readText()}}
        AlertDialog(onDismissRequest={credits=false},icon={Icon(Icons.Outlined.Info,null)},title={Text("Créditos dos sons")},
            text={LazyColumn(Modifier.heightIn(max=360.dp)) {item {Text(text,style=MaterialTheme.typography.bodySmall)}}},
            confirmButton={TextButton(onClick={credits=false}) {Text("Fechar")}})
    }
}

@Composable private fun SettingSwitch(title:String,detail:String,checked:Boolean,onChange:(Boolean)->Unit) {
    val c=calmColors()
    Row(verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {Text(title,style=MaterialTheme.typography.titleMedium);Text(detail,style=MaterialTheme.typography.bodySmall,color=c.muted)}
        Switch(checked,onChange)
    }
}

@Composable private fun AmbientSoundCard(preset:AmbientPreset,selected:Boolean,modifier:Modifier,onSelect:()->Unit) {
    val c=calmColors();val color=listOf(c.lilac,c.sky,c.mint,c.blush)[preset.palette]
    Card(onClick=onSelect,modifier=modifier,shape=RoundedCornerShape(28.dp),
        colors=CardDefaults.cardColors(containerColor=color,contentColor=c.ink),
        border=if(selected)androidx.compose.foundation.BorderStroke(2.dp,c.accent)else null) {
        Column(Modifier.padding(18.dp).heightIn(min=140.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            val icon=when(preset.id) {"clock"->Icons.Outlined.Schedule;"wind"->Icons.Outlined.Air;"rain"->Icons.Outlined.WaterDrop
                "storm"->Icons.Outlined.Thunderstorm;"fire","gryffindor"->Icons.Outlined.LocalFireDepartment
                "library"->Icons.Outlined.LocalLibrary;else->Icons.Outlined.AutoAwesome}
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                Icon(icon,null,Modifier.size(28.dp),tint=c.accent);Spacer(Modifier.weight(1f))
                if(selected)Icon(Icons.Outlined.CheckCircle,"Som selecionado",tint=c.accent) }
            Text(preset.title,style=MaterialTheme.typography.titleMedium)
            Text(preset.detail,style=MaterialTheme.typography.bodySmall,color=c.muted)
        }
    }
}

fun formatStudyTime(ms: Long): String { val minutes=ms/60_000;return if(minutes>=60) "${minutes/60}h ${minutes%60}min" else "${minutes}min" }

@Composable private fun PomodoroSettingsDialog(current: PomodoroSettings,onDismiss:()->Unit,onSave:(PomodoroSettings)->Unit) {
    var focus by rememberSaveable {mutableStateOf(current.focusMinutes.toString())}
    var short by rememberSaveable {mutableStateOf(current.shortMinutes.toString())}
    var long by rememberSaveable {mutableStateOf(current.longMinutes.toString())}
    var cycles by rememberSaveable {mutableStateOf(current.cycles.toString())}
    var error by remember {mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,icon={Icon(Icons.Outlined.Tune,null)},title={Text("Seu ciclo")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(focus,{focus=it.take(3)},label={Text("Foco (1–180 min)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            OutlinedTextField(short,{short=it.take(2)},label={Text("Pausa curta (1–90 min)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            OutlinedTextField(long,{long=it.take(2)},label={Text("Pausa longa (1–90 min)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            OutlinedTextField(cycles,{cycles=it.take(2)},label={Text("Focos por ciclo (1–12)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            if(error) Text("Confira os limites de cada campo.",color=MaterialTheme.colorScheme.error)
        }},confirmButton={TextButton(onClick={
            val settings=current.copy(focusMinutes=focus.toIntOrNull()?:0,shortMinutes=short.toIntOrNull()?:0,
                longMinutes=long.toIntOrNull()?:0,cycles=cycles.toIntOrNull()?:0)
            if(settings.valid()) onSave(settings) else error=true
        }) {Text("Salvar")}},dismissButton={TextButton(onClick=onDismiss) {Text("Cancelar")}})
}
